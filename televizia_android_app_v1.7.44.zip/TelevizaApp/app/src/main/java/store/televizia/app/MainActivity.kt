package store.televizia.app

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.graphics.Color
import android.view.View
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.media3.common.Player
import androidx.media3.ui.AspectRatioFrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import store.televizia.app.databinding.ActivityMainBinding

class MainActivity : BaseActivity() {
    companion object {
        const val ALL = Lang.ALL
    }
    private var autoPending = false
    private var gateDone = false

    private lateinit var b: ActivityMainBinding
    private val h = Handler(Looper.getMainLooper())
    private var clockR: Runnable? = null
    private var tickCount = 0
    private var groups: List<String> = emptyList()
    private var group = ALL
    private var current: Channel? = null
    private var started = false
    private var goingFullscreen = false
    private var prevChannel: Channel? = null
    private var offered = false

    // TV: სრული ეკრანი იმავე ეკრანზე (ვიდეოს ზედაპირი არსად გადადის -> გაყინვა არ არის)
    private var fs = false
    private var fsAt = 0L
    private val hideFsInfo = Runnable { b.fsBar?.visibility = View.GONE }   // საათი სრულ ეკრანზე მუდმივად რჩება
    private var loadAnim: android.animation.ValueAnimator? = null
    private var loadingNow = false
    private val autoFit = object : Player.Listener {
        override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
            applyAutoFit(videoSize.width, videoSize.height, videoSize.pixelWidthHeightRatio)
        }
    }

    private fun applyAutoFit(w: Int, hgt: Int, par: Float) {
        if (w <= 0 || hgt <= 0 || !::b.isInitialized) return
        val video = w * par / hgt
        if (video < 1.70f) {   // ვიწრო ნაკადი (4:3, 5:4) -> ეკრანის (სრულ ეკრანზე) ან 16:9 კადრის ფორმაზე იჭიმება
            val dm0 = resources.displayMetrics
            val scr = maxOf(dm0.widthPixels, dm0.heightPixels).toFloat() / minOf(dm0.widthPixels, dm0.heightPixels)
            b.preview.findViewById<AspectRatioFrameLayout>(resources.getIdentifier("exo_content_frame", "id", packageName))
                ?.setAspectRatio(if (fs || overlayTv) scr else 16f / 9f)
        }
        if (fs || overlayTv) {
            val dm = resources.displayMetrics
            val screen = dm.widthPixels.toFloat() / dm.heightPixels
            b.preview.resizeMode = if (Math.abs(video - screen) / screen < 0.12f) AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            else AspectRatioFrameLayout.RESIZE_MODE_FIT
        } else b.preview.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
    }

    private fun refit() {
        StreamHub.peek()?.player?.videoSize?.let { applyAutoFit(it.width, it.height, it.pixelWidthHeightRatio) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // TV: ვიდეო მუდამ მთელ ეკრანზეა, არხების სია და ტელეპროგრამა - მის ზემოდან (ნახევრად გამჭვირვალე პანელები)
    private var overlayTv = false
    private var epgOpen = false

    private fun setupTvOverlay() {
        val root = b.rootLand ?: run { setContentView(b.root); return }
        val left = b.leftCol ?: run { setContentView(b.root); return }
        val right = b.rightCol ?: run { setContentView(b.root); return }
        val pb = b.previewBox
        val frame = FrameLayout(this)
        frame.setBackgroundColor(Color.BLACK)
        (pb.parent as? ViewGroup)?.removeView(pb)
        root.removeAllViews()
        frame.addView(pb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val w = resources.displayMetrics.widthPixels
        val pw = minOf(dp(480), (w * 0.42f).toInt())
        left.layoutParams = FrameLayout.LayoutParams(pw, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START)
        left.setBackgroundColor(0xE6101018.toInt())
        left.setPadding(dp(16), dp(16), dp(10), dp(16))
        right.layoutParams = FrameLayout.LayoutParams(pw, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START).apply { leftMargin = pw }
        right.setBackgroundColor(0xE0101018.toInt())
        right.setPadding(dp(14), dp(16), dp(16), dp(16))
        frame.addView(left)
        frame.addView(right)
        right.visibility = View.GONE
        setContentView(frame)
        overlayTv = true
    }

    private fun overlayEnterFs() {
        fs = true
        epgOpen = false
        fsAt = android.os.SystemClock.uptimeMillis()
        b.leftCol?.visibility = View.GONE
        b.rightCol?.visibility = View.GONE
        b.previewError.textSize = 20f
        val dm = resources.displayMetrics
        b.loadingLogo?.let { it.layoutParams = it.layoutParams.apply { width = minOf((520 * dm.density).toInt(), (dm.widthPixels * 0.55f).toInt()) } }
        refit()
        showFsInfo()
        b.fsClock?.visibility = View.VISIBLE
        applyLoadingUi()
    }

    private fun overlayExitFs() {
        fs = false
        epgOpen = false
        digits.cancel()
        h.removeCallbacks(hideFsInfo)
        b.fsBar?.visibility = View.GONE
        b.fsNumBox?.visibility = View.GONE
        b.leftCol?.visibility = View.VISIBLE
        b.rightCol?.visibility = View.GONE
        refit()
        applyLoadingUi()
        updateEpg(current)
        focusCurrent(8)
    }

    private fun openEpgPanel() {
        if (!overlayTv) return
        epgOpen = true
        b.rightCol?.visibility = View.VISIBLE
    }

    private fun closeEpgPanel() {
        if (!overlayTv || !epgOpen) return
        epgOpen = false
        b.rightCol?.visibility = View.GONE
    }

    private fun enterFs() {
        if (overlayTv) { if (!fs && current != null) overlayEnterFs(); return }
        if (fs || current == null || b.leftCol == null) return
        fs = true
        fsAt = android.os.SystemClock.uptimeMillis()
        b.rootLand?.setPadding(0, 0, 0, 0)
        b.rootLand?.setBackgroundColor(Color.BLACK)
        b.leftCol?.visibility = View.GONE
        b.rightCol?.visibility = View.GONE
        (b.midCol?.layoutParams as? LinearLayout.LayoutParams)?.let { it.marginStart = 0; b.midCol?.layoutParams = it }
        b.previewError.textSize = 20f
        val dm = resources.displayMetrics
        b.loadingLogo?.let { it.layoutParams = it.layoutParams.apply { width = minOf((520 * dm.density).toInt(), (dm.widthPixels * 0.55f).toInt()) } }
        refit()
        showFsInfo()
        b.fsClock?.visibility = View.VISIBLE
        applyLoadingUi()
    }

    private fun exitFs() {
        if (!fs) return
        if (overlayTv) { overlayExitFs(); return }
        fs = false
        digits.cancel()
        h.removeCallbacks(hideFsInfo)
        b.fsBar?.visibility = View.GONE
        b.fsClock?.visibility = View.GONE
        b.fsNumBox?.visibility = View.GONE
        b.rootLand?.setPadding(dp(16), dp(16), dp(16), dp(16))
        b.rootLand?.setBackgroundColor(Color.parseColor("#0A0C14"))
        b.leftCol?.visibility = View.VISIBLE
        b.rightCol?.visibility = View.VISIBLE
        (b.midCol?.layoutParams as? LinearLayout.LayoutParams)?.let { it.marginStart = dp(12); b.midCol?.layoutParams = it }
        b.previewError.textSize = 14f
        refit()
        applyLoadingUi()
        updateEpg(current)
        focusCurrent(8)
    }

    private fun showFsInfo() {
        val ch = current ?: return
        val idx = ChannelHolder.list.indexOfFirst { it.url == ch.url }
        b.fsNum?.text = if (idx >= 0) (idx + 1).toString() else ""
        b.fsName?.text = ch.name
        b.fsLogo?.let { ImageLoader.show(ch.logo, it, ch.name) }
        val now = Epg.now(ch)
        val next = Epg.next(ch)
        b.fsNow?.text = when {
            now == null -> ""
            next == null -> "${Ui.timeOf(now.start)}  ${now.title}"
            else -> "${Ui.timeOf(now.start)}  ${now.title}  →  ${Ui.timeOf(next.start)}  ${next.title}"
        }
        val hasEpg = now != null
        b.fsNow?.visibility = if (hasEpg) View.VISIBLE else View.GONE
        b.fsProgress?.visibility = if (hasEpg) View.VISIBLE else View.GONE
        b.fsProgress?.progress = Ui.progressOf(now)
        b.fsClock?.text = b.clock.text
        b.fsBar?.visibility = View.VISIBLE
        b.fsClock?.visibility = View.VISIBLE
        h.removeCallbacks(hideFsInfo)
        h.postDelayed(hideFsInfo, 6000)
    }

    /** TELEVIZIA.STORE ლოგო სრულ ეკრანზე ჩატვირთვისას (ფერები იცვლება), სიაში - პატარა ინდიკატორი */
    private fun applyLoadingUi() {
        val logo = b.loadingLogo
        if (fs && loadingNow && logo != null) {
            b.previewLoading.visibility = View.GONE
            logo.visibility = View.VISIBLE
            if (loadAnim == null) {
                val cm = android.graphics.ColorMatrix()
                loadAnim = android.animation.ValueAnimator.ofFloat(0f, 360f).apply {
                    duration = 1800
                    repeatCount = android.animation.ValueAnimator.INFINITE
                    addUpdateListener { va ->
                        val d = va.animatedValue as Float
                        cm.setRotate(2, d * 0.3f)
                        logo.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
                        logo.alpha = 0.55f + 0.45f * Math.abs(Math.sin(Math.toRadians(d.toDouble()))).toFloat()
                    }
                    start()
                }
            }
        } else {
            loadAnim?.cancel(); loadAnim = null
            logo?.colorFilter = null
            logo?.alpha = 1f
            logo?.visibility = View.GONE
            b.previewLoading.visibility = if (loadingNow) View.VISIBLE else View.GONE
        }
    }

    private fun fsStep(delta: Int) { stepChannel(delta); showFsInfo() }

    /** სრულ ეკრანზე კატეგორიის შეცვლა (მორგებული ღილაკით): ახალი კატეგორიის პირველ არხზე გადადის */
    private fun fsGroupStep(delta: Int) {
        stepGroup(delta)
        flash(Lang.group(group))
        val first = ChannelHolder.list.firstOrNull() ?: return
        ChannelHolder.markPos(0)
        play(first)
        b.channels.scrollToPosition(0)
        showFsInfo()
    }

    /** TV სრული ეკრანი: ↑/→ შემდეგი, ↓/← წინა არხი, OK/BACK → სია, ციფრები → ნომრით */
    // ---------- პულტი: 1.7.30-ის ფუნქციები სრულ ეკრანზე ----------
    private var toast: Toast? = null
    private fun flash(msg: String) {
        toast?.cancel()
        toast = Toast.makeText(this, msg, Toast.LENGTH_SHORT).also { it.show() }
    }
    private fun openGuide() {
        exitFs()
        h.postDelayed({ if (alive()) focusEpg(8) }, 350)
    }
    private fun zapOrSeek(next: Boolean, rep: Boolean) {
        val paused = StreamHub.peek()?.player?.playWhenReady == false
        if (paused) seekBy(if (next) 10_000 else -10_000)
        else if (!rep) fsStep(if (next) 1 else -1)
    }
    private fun togglePlay() {
        StreamHub.peek()?.player?.let {
            it.playWhenReady = !it.playWhenReady
            flash(if (it.playWhenReady) "▶" else "⏸ " + getString(R.string.pause))
        }
    }
    private fun seekBy(ms: Long) {
        val p = StreamHub.peek()?.player ?: return
        if (!p.isCurrentMediaItemSeekable) { flash(getString(R.string.seek_unavailable)); return }
        val target = p.currentPosition + ms
        val tl = p.currentTimeline
        var def = androidx.media3.common.C.TIME_UNSET
        if (!tl.isEmpty) def = tl.getWindow(p.currentMediaItemIndex, androidx.media3.common.Timeline.Window()).defaultPositionMs
        if (p.isCurrentMediaItemLive && def != androidx.media3.common.C.TIME_UNSET && target >= def) p.seekToDefaultPosition()
        else p.seekTo(target.coerceAtLeast(0))
        flash(getString(if (ms < 0) R.string.seek_back else R.string.seek_fwd))
    }
    private fun trackName(g: androidx.media3.common.Tracks.Group): String {
        val f = g.getTrackFormat(0)
        val lang = f.language?.takeIf { it.isNotBlank() && it != "und" }
            ?.let { java.util.Locale.forLanguageTag(it).getDisplayLanguage(java.util.Locale.forLanguageTag(Lang.current())) }
            ?.takeIf { it.isNotBlank() }
        return f.label?.takeIf { it.isNotBlank() } ?: lang ?: getString(R.string.track_default)
    }
    private fun cycleSubtitles() {
        val p = StreamHub.peek()?.player ?: return
        val groups = p.currentTracks.groups.filter { it.type == androidx.media3.common.C.TRACK_TYPE_TEXT && it.isSupported }
        if (groups.isEmpty()) { flash(getString(R.string.subs_none)); return }
        val next = groups.indexOfFirst { it.isSelected } + 1
        val params = p.trackSelectionParameters.buildUpon()
        if (next >= groups.size) {
            params.setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
            flash(getString(R.string.subs_off))
        } else {
            params.setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
                .setOverrideForType(androidx.media3.common.TrackSelectionOverride(groups[next].mediaTrackGroup, 0))
            flash(getString(R.string.subs_fmt, trackName(groups[next])))
        }
        p.trackSelectionParameters = params.build()
    }
    private fun cycleAudio() {
        val p = StreamHub.peek()?.player ?: return
        val groups = p.currentTracks.groups.filter { it.type == androidx.media3.common.C.TRACK_TYPE_AUDIO && it.isSupported }
        if (groups.size < 2) { flash(getString(R.string.audio_none)); return }
        val next = (groups.indexOfFirst { it.isSelected }.coerceAtLeast(0) + 1) % groups.size
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setOverrideForType(androidx.media3.common.TrackSelectionOverride(groups[next].mediaTrackGroup, 0)).build()
        flash(getString(R.string.audio_fmt, trackName(groups[next])))
    }

    private fun fsKey(event: KeyEvent): Boolean {
        val k = event.keyCode
        if (k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN || k == KeyEvent.KEYCODE_VOLUME_MUTE) return false
        val handledUp = KeyMap.isDpad(k) || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER ||
            k == KeyEvent.KEYCODE_NUMPAD_ENTER || k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ESCAPE
        if (event.action != KeyEvent.ACTION_DOWN) return handledUp
        val rep = event.repeatCount > 0
        if (!KeyMap.isDpad(k)) {
            when (KeyMap.get(this, k)) {
                KeyMap.Act.NEXT_CH -> { if (!rep) fsStep(1); return true }
                KeyMap.Act.PREV_CH -> { if (!rep) fsStep(-1); return true }
                KeyMap.Act.LAST -> { if (!rep) prevChannel?.let { play(it); showFsInfo() }; return true }
                KeyMap.Act.INFO -> { if (!rep) fsInfoKey(); return true }
                KeyMap.Act.PANEL -> { if (!rep) exitFs(); return true }
                KeyMap.Act.GUIDE -> { if (!rep) openGuide(); return true }
                KeyMap.Act.SUBS -> { if (!rep) cycleSubtitles(); return true }
                KeyMap.Act.AUDIO -> { if (!rep) cycleAudio(); return true }
                KeyMap.Act.ASPECT -> return true
                KeyMap.Act.PAUSE -> { if (!rep) togglePlay(); return true }
                KeyMap.Act.SEEK_BACK -> { seekBy(-10_000); return true }
                KeyMap.Act.SEEK_FWD -> { seekBy(10_000); return true }
                KeyMap.Act.FAV -> { if (!rep) current?.let { toggleFav(it) }; return true }
                KeyMap.Act.HIDE -> { if (!rep) current?.let { confirmHide(it) }; return true }
                KeyMap.Act.PREV_GROUP -> { if (!rep) fsGroupStep(-1); return true }
                KeyMap.Act.NEXT_GROUP -> { if (!rep) fsGroupStep(1); return true }
                KeyMap.Act.GROUP_MENU -> { if (!rep) { exitFs(); categoryMenu() }; return true }
                else -> {}
            }
        }
        when (k) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> { if (!rep) fsStep(1) }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { if (!rep) fsStep(-1) }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_RIGHT -> zapOrSeek(true, rep)
            KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT -> zapOrSeek(false, rep)
            KeyEvent.KEYCODE_MEDIA_STOP -> exitFs()
            KeyEvent.KEYCODE_MUTE -> StreamHub.peek()?.player?.let { it.volume = if (it.volume == 0f) 1f else 0f }
            KeyEvent.KEYCODE_PROG_BLUE -> exitFs()
            KeyEvent.KEYCODE_CAPTIONS -> cycleSubtitles()
            KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK -> cycleAudio()
            KeyEvent.KEYCODE_TV_ZOOM_MODE, KeyEvent.KEYCODE_ZOOM_IN -> {}
            KeyEvent.KEYCODE_LAST_CHANNEL -> prevChannel?.let { play(it); showFsInfo() }
            KeyEvent.KEYCODE_DEL -> if (digits.active) digits.cancel() else prevChannel?.let { play(it); showFsInfo() }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> togglePlay()
            KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_PROG_YELLOW -> if (!rep) fsInfoKey()
            KeyEvent.KEYCODE_BOOKMARK -> if (!rep) current?.let { toggleFav(it) }
            KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_BACK -> if (digits.active) digits.cancel() else finishAffinity()   // EXIT/BACK სრულ ეკრანზე: გასვლა
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (digits.active) digits.commit()
                else if (!rep && android.os.SystemClock.uptimeMillis() - fsAt > 700) { swallowKey = k; swallowAt = android.os.SystemClock.uptimeMillis(); exitFs() }
            }
            KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_PROG_GREEN, KeyEvent.KEYCODE_TV_DATA_SERVICE -> if (!rep) openGuide()
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_PROG_RED, KeyEvent.KEYCODE_TV_CONTENTS_MENU,
            KeyEvent.KEYCODE_SEARCH, KeyEvent.KEYCODE_SETTINGS -> if (!rep) exitFs()
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> digits.digit(k - KeyEvent.KEYCODE_0)
            in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> digits.digit(k - KeyEvent.KEYCODE_NUMPAD_0)
            else -> return false
        }
        return true
    }

    private val isTv: Boolean get() = Device.tv(this)
    private val landscape: Boolean by lazy {
        resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    /** TV: OK = არხი იწყება და იხსნება სრულ ეკრანზე. ტელეფონი: პირველი შეხება = გადართვა, ხელახლა იმავეზე = სრული ეკრანი */
    private val channelAdapter = ChannelAdapter { ch, p ->
        ChannelHolder.markPos(p)
        if (isTv) {
            play(ch)
            openFullscreen()
        } else if (ch.url == current?.url) {
            openFullscreen()
        } else {
            play(ch)
        }
    }
    private lateinit var groupAdapter: GroupAdapter
    private val programAdapter = ProgramAdapter(
        onClick = { onProgramClick(it) },
        canPlay = { p -> current?.let { Catchup.canPlay(it, p) } == true }
    )

    private val digits = DigitEntry(
        size = { ChannelHolder.list.size },
        nameAt = { ChannelHolder.list.getOrNull(it)?.name },
        onUpdate = { d, name, valid ->
            if (fs) {
                b.fsNumBox?.visibility = View.VISIBLE
                b.fsNumDigits?.text = d
                b.fsNumDigits?.setTextColor(if (valid) 0xFF00D9C0.toInt() else 0xFFFF5C72.toInt())
                b.fsNumName?.text = when {
                    name != null -> name
                    valid -> ""
                    else -> getString(R.string.no_such_channel)
                }
            }
            b.status.text = when {
                name != null -> "$d · $name"
                valid -> d
                else -> "$d · ${getString(R.string.no_such_channel)}"
            }
        },
        onCommit = { pos ->
            ChannelHolder.list.getOrNull(pos)?.let {
                ChannelHolder.markPos(pos)
                play(it)
                b.channels.scrollToPosition(pos)
                if (fs) showFsInfo()
            }
        },
        onClose = { b.status.text = statusText(); b.fsNumBox?.visibility = View.GONE }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.token(this) == null) {
            goLogin()
            return
        }
        b = ActivityMainBinding.inflate(layoutInflater)
        if (isTv && b.leftCol != null && b.rightCol != null) setupTvOverlay() else setContentView(b.root)
        sizePreview()

        if (savedInstanceState == null) autoPending = true   // მხოლოდ TV: გახსნისას არხი სრულ ეკრანზე
        applyDeviceButtons()
        showPlan(Session.plan(this))
        refreshPlan()
        b.channels.layoutManager = LinearLayoutManager(this)
        b.channels.setHasFixedSize(true)
        b.channels.setItemViewCacheSize(10)
        b.channels.adapter = channelAdapter

        groupAdapter = GroupAdapter(landscape) { g -> selectGroup(g) }
        b.groups.layoutManager = if (landscape) LinearLayoutManager(this)
        else LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.groups.adapter = groupAdapter

        b.epgList.layoutManager = LinearLayoutManager(this)
        b.epgList.adapter = programAdapter

        // ტელეფონი ვერტიკალურად: ინფო ბლოკზე შეხებით იხსნება/იკეცება მთელი ტელეპროგრამა
        if (!landscape) {
            updateEpgHint()
            b.infoBlock.setOnClickListener {
                b.epgList.visibility = if (b.epgList.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                updateEpgHint()
            }
        }

        channelAdapter.onLong = { channelMenu(it) }
        b.groupPrev?.setOnClickListener { stepGroup(-1) }
        b.groupNext?.setOnClickListener { stepGroup(1) }
        b.btnKeys?.setOnClickListener { startActivity(Intent(this, KeysActivity::class.java)) }
        b.btnLang.visibility = View.GONE   // ენის არჩევა მხოლოდ შესვლის გვერდზეა

        b.btnFullscreen.setOnClickListener { openFullscreen() }
        // ვიდეოზე: შეხება = სრული ეკრანი, გადასმა = შემდეგი/წინა არხი
        b.preview.setOnTouchListener(SwipeTouch(this, onTap = { openFullscreen() }, onSwipe = { next ->
            stepChannel(if (next) 1 else -1)
        }))
        b.btnLogout.setOnClickListener {
            StreamHub.release()
            Session.clear(this)
            Store.clear(this)
            ChannelHolder.reset()
            Epg.attach(emptyList())
            goLogin()
        }
        if (ChannelHolder.all.isEmpty()) ChannelHolder.group = Store.lastGroup(this) ?: ALL
        loadChannels()
        // განახლების/შეტყობინების ფანჯარა სრულ ეკრანს არ უნდა დაეფაროს: ჯერ ველოდებით სერვერის პასუხს (მაქს. 3 წმ)
        Gate.check(this, { shown ->
            gateDone = true
            if (shown) autoPending = false else maybeAutoOpen()
        }) { }
        h.postDelayed({ gateDone = true; maybeAutoOpen() }, 3000)
    }

    private fun showPlan(text: String) {
        b.planInfo.text = text
        b.planInfo.visibility = if (text.isBlank()) View.GONE else View.VISIBLE
    }

    private fun refreshPlan() {
        val token = Session.token(this) ?: return
        val app = applicationContext
        Thread {
            val t = Api.planText(token)
            if (t != null) {
                Session.setPlan(app, t)
                runOnUiThread { if (alive()) showPlan(t) }
            }
        }.start()
    }

    /** TV-ზე "პულტი / სრული ეკრანი" არ ჩანს — მხოლოდ მობილურზე */
    private fun applyDeviceButtons() {
        val v = if (isTv) View.GONE else View.VISIBLE
        b.btnLogout.visibility = View.VISIBLE   // TV-ზეც: გასვლა მთავარ ეკრანზე (OK-ით)
        b.btnKeys?.visibility = v
        b.btnFullscreen.visibility = v
        if (isTv) {   // კატეგორიების პანელი მთლიანად ფოკუსირდება: ↑ არხების სიიდან, ←/→ ცვლის კატეგორიას, OK — კატეგორიების სია
            b.groupPrev?.isFocusable = false
            b.groupNext?.isFocusable = false
            b.groupHeader?.let { hd ->
                hd.isFocusable = true
                hd.isClickable = true
                hd.setOnClickListener { categoryMenu() }
            }
        }
    }

    /** TV: ფოკუსი "გასვლა" ღილაკზე */
    private fun focusLogout() {
        if (b.btnLogout.visibility == View.VISIBLE) b.btnLogout.requestFocus()
    }

    /** ბოლო არხი სრულ ეკრანზე გაიხსნას აპლიკაციის ჩართვისას */
    private fun maybeAutoOpen() {
        if (autoPending && gateDone && started && current != null && alive()) {
            if (!isTv) { autoPending = false; return }
            autoPending = false
            openFullscreen()
        }
    }

    /** TV: ფოკუსი მიმდინარე არხზე (და არა კატეგორიის ისრებზე) */
    private fun focusCurrent(retries: Int) {
        if (!isTv || !::b.isInitialized) return
        focusPosition(ChannelHolder.list.indexOfFirst { it.url == current?.url }, retries)
    }

    private fun focusPosition(pos: Int, retries: Int) {
        if (pos < 0 || !::b.isInitialized) return
        b.channels.scrollToPosition(pos)
        b.channels.postDelayed({
            if (!alive()) return@postDelayed
            val v = b.channels.findViewHolderForAdapterPosition(pos)?.itemView
            v?.requestFocus()
            // სიის ხელახლა აგებისას ფოკუსი ისრებზე გადადიოდა — ვამოწმებთ და საჭიროებისას ვიმეორებთ
            if ((v == null || !v.hasFocus()) && retries > 0) focusPosition(pos, retries - 1)
        }, 120)
    }

    /** TV: ფოკუსი ტელეპროგრამაზე (მიმდინარე გადაცემაზე) */
    private fun focusEpg(retries: Int) {
        if (!::b.isInitialized || (b.epgList.adapter?.itemCount ?: 0) == 0) return
        openEpgPanel()
        val idx = programAdapter.liveIndex().coerceAtLeast(0)
        b.epgList.scrollToPosition(idx)
        b.epgList.postDelayed({
            if (!alive()) return@postDelayed
            val v = b.epgList.findViewHolderForAdapterPosition(idx)?.itemView
            v?.requestFocus()
            if ((v == null || !v.hasFocus()) && retries > 0) focusEpg(retries - 1)
        }, 120)
    }

    /** TV: ფოკუსი კატეგორიების პანელზე (ყველა / ფავორიტები / ...) */
    private fun focusHeader() {
        b.groupHeader?.requestFocus()
    }

    /**
     * TV: წრიული ნავიგაცია: [კატეგორიების პანელი] → არხი 1 → ... → ბოლო არხი → გასვლა → [კატეგორიების პანელი].
     * პანელზე: ←/→ წინა/შემდეგი კატეგორია ან ფავორიტები, ↓ პირველი არხი, ↑ გასვლა/ბოლო არხი, OK — კატეგორიების სია.
     * არხებზე: → ტელეპროგრამა. true = დამუშავდა
     */
    private fun tvListKey(k: Int): Boolean {
        if (!isTv) return false
        val f = currentFocus ?: return false
        val n = ChannelHolder.list.size
        val hasLogout = b.btnLogout.visibility == View.VISIBLE
        if (f === b.groupHeader) {
            when (k) {
                KeyEvent.KEYCODE_DPAD_LEFT -> stepGroup(-1)
                KeyEvent.KEYCODE_DPAD_RIGHT -> stepGroup(1)
                KeyEvent.KEYCODE_DPAD_DOWN -> if (n > 0) focusPosition(0, 8) else if (hasLogout) focusLogout()
                KeyEvent.KEYCODE_DPAD_UP -> if (hasLogout) focusLogout() else if (n > 0) focusPosition(n - 1, 8)
                else -> return false
            }
            return true
        }
        if (f === b.btnLogout) {   // გასვლიდან ↑ — არხების სიის ბოლოში, ↓ — კატეგორიების პანელზე (წრე)
            if (k == KeyEvent.KEYCODE_DPAD_UP) { if (n > 0) focusPosition(n - 1, 8) else focusHeader(); return true }
            if (k == KeyEvent.KEYCODE_DPAD_DOWN) { focusHeader(); return true }
            return false
        }
        if (f.parent === b.epgList) {   // ტელეპროგრამაში ← არხებზე ბრუნდება
            if (k == KeyEvent.KEYCODE_DPAD_LEFT) { closeEpgPanel(); focusCurrent(8); return true }
            if (k == KeyEvent.KEYCODE_DPAD_RIGHT) return true
            return false
        }
        if (n == 0 || f.parent !== b.channels) return false
        val pos = b.channels.getChildAdapterPosition(f)
        when (k) {
            KeyEvent.KEYCODE_DPAD_UP -> if (pos == 0) { focusHeader(); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> if (pos == n - 1) { if (hasLogout) focusLogout() else focusHeader(); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> return true   // კატეგორიას პანელზე ←/→ ცვლის (↑-ით ავდივართ), ან წითელი / მწვანე ღილაკი
            KeyEvent.KEYCODE_DPAD_RIGHT -> { focusEpg(8); return true }
        }
        return false
    }

    /** გადახედვის სიმაღლე: 16:9, მაგრამ დაბალ ეკრანზე არა უმეტეს 34%-ისა — სია ყოველთვის საკმარისად ჩანს */
    private fun sizePreview() {
        if (landscape) return
        val dm = resources.displayMetrics
        val byWidth = dm.widthPixels * 9 / 16
        val cap = (dm.heightPixels * 0.34f).toInt()
        val lp = b.previewBox.layoutParams
        lp.height = minOf(byWidth, cap)
        b.previewBox.layoutParams = lp
    }

    override fun onStart() {
        super.onStart()
        if (!::b.isInitialized) return
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)   // ეკრანმზოგი არ ჩაირთოს ყურებისას
        started = true
        goingFullscreen = false
        clockR = Ui.startClock(b.clock, h) {
            b.fsClock?.text = b.clock.text
            // ყოველ წუთს გადაცემების სახელები და პროგრესი ახლდება
            if (++tickCount % 6 == 0) {
                channelAdapter.refresh()
                updateEpg(current)
            }
        }
        val sc = StreamHub.get(this)
        sc.listen(
            this,
            loading = {
                loadingNow = true
                applyLoadingUi()
                b.previewError.visibility = View.GONE
            },
            playing = {
                loadingNow = false
                applyLoadingUi()
                b.previewError.visibility = View.GONE
                b.status.text = statusText()
            },
            failed = {
                loadingNow = false
                applyLoadingUi()
                b.previewError.visibility = View.VISIBLE
            }
        )
        sc.detachVideo()
        b.preview.player = sc.ensurePlayer()
        sc.player?.addListener(autoFit)
        sc.onRebuilt = { np -> b.preview.player = np; np.addListener(autoFit); refit() }
        refit()
        syncFromHolder()
        current?.let { sc.play(it.url) }
        applyDeviceButtons()
        focusCurrent(5)
        maybeAutoOpen()
    }

    override fun onStop() {
        super.onStop()
        started = false
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        clockR?.let { h.removeCallbacks(it) }
        clockR = null
        if (!::b.isInitialized) return
        digits.cancel()
        StreamHub.peek()?.player?.removeListener(autoFit)
        loadAnim?.cancel(); loadAnim = null
        b.preview.player = null
        StreamHub.peek()?.unlisten(this)
        // სრულ ეკრანზე გადასვლისას ან ეკრანის შებრუნებისას ფლეიერი რჩება; სხვა შემთხვევაში (Home) ვთიშავთ
        if (!goingFullscreen && !isChangingConfigurations) StreamHub.release()
    }

    // ---------- არხების ჩატვირთვა ----------

    private fun alive() = !isFinishing && !isDestroyed

    /** 1) მყისიერად: მეხსიერებიდან ან დისკის ქეშიდან  2) ფონურად: სერვერიდან განახლება */
    private fun loadChannels() {
        val token = Session.token(this) ?: run { goLogin(); return }
        val app = applicationContext

        if (ChannelHolder.all.isNotEmpty()) {
            showChannels(startPlayback = ChannelHolder.current == null)
        } else {
            b.status.text = getString(R.string.channels_loading)
        }

        Thread {
            var m3uText: String? = null
            if (ChannelHolder.all.isEmpty()) {
                val cached = Store.loadM3u(app)
                if (cached != null) {
                    val parsed = M3u.parse(cached)
                    if (parsed.isNotEmpty()) {
                        Epg.attach(parsed)
                        ChannelHolder.all = parsed
                        m3uText = cached
                        runOnUiThread { if (alive()) showChannels(startPlayback = true) }
                    }
                }
            }

            val res = Api.playlist(token)
            if (res.ok && res.body.isNotBlank()) {
                Store.saveM3u(app, res.body)
                val parsed = M3u.parse(res.body)
                if (parsed.isNotEmpty()) {
                    m3uText = res.body
                    val old = ChannelHolder.all
                    val same = old.size == parsed.size &&
                        old.indices.all { old[it].url == parsed[it].url && old[it].name == parsed[it].name && old[it].logo == parsed[it].logo }
                    if (!same) {
                        Epg.attach(parsed)
                        ChannelHolder.all = parsed
                        runOnUiThread { if (alive()) showChannels(startPlayback = ChannelHolder.current == null) }
                    }
                }
            } else if (res.denied) {
                // სერვერმა უარი თქვა (პაკეტი/ვადა) — ძველ სიას აღარ ვტოვებთ
                Store.clear(app)
                ChannelHolder.all = emptyList()
                ChannelHolder.list = emptyList()
                runOnUiThread {
                    if (alive()) {
                        StreamHub.release()
                        channelAdapter.submit(emptyList())
                        b.status.text = res.message
                    }
                }
                return@Thread
            } else if (ChannelHolder.all.isEmpty()) {
                runOnUiThread { if (alive()) b.status.text = res.message }
            }

            startEpg(m3uText)
        }.start()
    }

    /** EPG ცალკე ფონურად (პროცესზე ერთხელ); დასრულებისას სია და პროგრამა ახლდება */
    private fun startEpg(m3uText: String?) {
        if (ChannelHolder.epgStarted) return
        ChannelHolder.epgStarted = true
        val app = applicationContext
        val urls = if (m3uText != null) M3u.epgUrls(m3uText) else emptyList()
        val ok = Epg.load(app, urls, ChannelHolder.all)
        if (ok) {
            runOnUiThread {
                if (alive()) {
                    channelAdapter.refresh()
                    updateEpg(current)
                }
            }
        } else {
            ChannelHolder.epgStarted = false   // შემდეგ გახსნაზე ისევ ვცადოთ
        }
    }

    private fun showChannels(startPlayback: Boolean) {
        val all = visibleChannels()
        groups = listOf(ALL, Lang.FAV) + all.map { it.group }.distinct()
        group = if (ChannelHolder.group in groups) ChannelHolder.group else ALL
        groupAdapter.submit(groups, group)
        applyFilter()
        if (startPlayback) {
            val last = Store.lastUrl(this)
            val ch = ChannelHolder.list.firstOrNull { it.url == last }
                ?: all.firstOrNull { it.url == last }
                ?: ChannelHolder.list.firstOrNull()
            if (ch != null) {
                play(ch)
                val pos = ChannelHolder.list.indexOfFirst { it.url == ch.url }
                if (pos >= 0) b.channels.scrollToPosition(pos)
                focusCurrent(5)
                maybeAutoOpen()
            }
        } else {
            syncFromHolder()
        }
    }

    private fun selectGroup(g: String) {
        group = g
        ChannelHolder.group = g
        Store.setLastGroup(this, g)
        groupAdapter.submit(groups, group)
        applyFilter()
    }

    private fun applyFilter() {
        ChannelHolder.group = group
        val base = visibleChannels()
        val shown = when (group) {
            ALL -> base
            Lang.FAV -> base.filter { UserLists.isFav(this, it) }
            else -> base.filter { it.group == group }
        }
        ChannelHolder.list = shown
        updateGroupHeader()
        channelAdapter.submit(shown)
        current?.let { channelAdapter.select(it.url) }
        b.status.text = statusText()
    }

    private fun statusText(): String {
        val n = ChannelHolder.list.size
        if (group == Lang.FAV && n == 0) return "ფავორიტები ცარიელია: არხზე გრძელი OK ან INFO (i)"
        return if (landscape) {
            getString(R.string.status_land, n, groups.indexOf(group).coerceAtLeast(0) + 1, groups.size.coerceAtLeast(1))
        } else {
            getString(R.string.status_portrait, Lang.group(group), n)
        }
    }

    /** ლანდშაფტში: კატეგორიის სახელი გადამრთველში */
    private fun updateGroupHeader() {
        b.groupTitle?.text = Lang.group(group)
    }

    private fun stepGroup(delta: Int) {
        if (groups.isEmpty()) return
        val i = Math.floorMod(groups.indexOf(group) + delta, groups.size)
        selectGroup(groups[i])
    }

    /** ტელეფონი ვერტიკალურად: წარწერა "▾ ტელეპროგრამა" არხის ქვემოთ (ღია პროგრამაზე ▴ და გამოყოფილია) */
    private fun updateEpgHint() {
        val hint = b.epgHint ?: return
        val open = b.epgList.visibility == View.VISIBLE
        hint.text = (if (open) "▴ " else "▾ ") + getString(R.string.programs_hint)
        hint.isSelected = open
        hint.setTextColor(if (open) 0xFFFFFFFF.toInt() else 0xFF00F0D4.toInt())
    }

    private fun nameLabel(ch: Channel): String =
        if (landscape) getString(R.string.programs_title, ch.name) else ch.name

    // ---------- დაკვრა ----------

    private fun play(ch: Channel) {
        // არხი ამჟამინდელ კატეგორიაში არ არის (მაგ. ციფრებით/ბოლო არხით) → ვაჩვენებთ ყველა არხს, რომ სია და ისრები ამ არხიდან დაიწყოს
        if (ChannelHolder.list.none { it.url == ch.url } && ChannelHolder.all.any { it.url == ch.url }) {
            group = ALL
            applyFilter()
        }
        val old = current
        if (old != null && old.url != ch.url) prevChannel = old
        current = ch
        ChannelHolder.current = ch
        Store.setLastUrl(this, ch.url)
        b.nowName.text = nameLabel(ch)
        channelAdapter.select(ch.url)
        b.btnFullscreen.isEnabled = true
        if (!fs) updateEpg(ch)   // სრულ ეკრანზე გადართვისას ტელეპროგრამა ჩანს არ არის — მთავარ ნაკადს არ ვაჭედებთ; გასვლისას განახლდება
        if (started) StreamHub.get(this).play(ch.url)
    }

    /** გადაცემაზე დაჭერა: გასული — არქივი, მიმდინარე — პირდაპირ ეთერი */
    private fun onProgramClick(p: Program) {
        val ch = current ?: return
        val t = System.currentTimeMillis()
        when {
            t >= p.start && t < p.stop -> { b.nowName.text = nameLabel(ch); StreamHub.get(this).play(ch.url); if (isTv) openFullscreen() }
            p.start > t -> Toast.makeText(this, "ეს გადაცემა ჯერ არ დაწყებულა", Toast.LENGTH_SHORT).show()
            Catchup.canPlay(ch, p) -> {
                b.nowName.text = "📼 ${ch.name} · ${Ui.timeOf(p.start)} ${p.title}"
                StreamHub.get(this).play(Catchup.url(ch, p))
                if (isTv) openFullscreen()   // გასული გადაცემა მთელ ეკრანზე
            }
            else -> Toast.makeText(this, "ამ გადაცემის არქივი მიუწვდომელია", Toast.LENGTH_SHORT).show()
        }
    }

    /** პროგრამის სია იხსნება მიმდინარე გადაცემაზე; გასული გადაცემები ზემოთ გადასახვევია */
    private fun scrollProgramsToLive() {
        val i = programAdapter.liveIndex()
        (b.epgList.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager)
            ?.scrollToPositionWithOffset(i, 0)
    }

    /** გადაცემა ახლა / შემდეგ და მთელი პროგრამა */
    private fun updateEpg(ch: Channel?) {
        if (ch == null) return
        val now = Epg.now(ch)
        if (now != null) {
            b.epgNow.text = "${Ui.timeOf(now.start)}–${Ui.timeOf(now.stop)}  ${now.title}"
            b.epgNow.visibility = View.VISIBLE
            b.epgProgress.progress = Ui.progressOf(now)
            b.epgProgress.visibility = View.VISIBLE
            val nx = Epg.next(ch)
            if (nx != null) {
                b.epgNext.text = getString(R.string.next_fmt, Ui.timeOf(nx.start), nx.title)
                b.epgNext.visibility = View.VISIBLE
            } else b.epgNext.visibility = View.GONE
        } else {
            b.epgNow.visibility = View.GONE
            b.epgProgress.visibility = View.GONE
            b.epgNext.visibility = View.GONE
        }
        programAdapter.submit(Epg.schedule(ch))
        scrollProgramsToLive()
    }

    private fun openFullscreen() {
        val ch = current ?: return
        if (isTv && b.leftCol != null) { enterFs(); return }
        ChannelHolder.current = ch
        goingFullscreen = true
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", ch.url))
    }

    /** სრულ ეკრანიდან დაბრუნებისას ან ეკრანის შებრუნებისას — მიმდინარე არხის სინქრონიზაცია */
    private fun syncFromHolder() {
        val ch = ChannelHolder.current ?: return
        current = ch
        b.nowName.text = nameLabel(ch)
        channelAdapter.select(ch.url)
        b.btnFullscreen.isEnabled = true
        updateEpg(ch)
        val pos = ChannelHolder.list.indexOfFirst { it.url == ch.url }
        if (pos >= 0 && !b.channels.canScrollVertically(-1) && pos > 3) b.channels.scrollToPosition(pos)
    }

    // ---------- ფავორიტები და არხის წაშლა (მხოლოდ აპლიკაციაში) ----------
    private fun visibleChannels(): List<Channel> = ChannelHolder.all.filter { !UserLists.isHidden(this, it) }

    /** არხზე მოქმედებები: ფავორიტი / წაშლა სიიდან (საიტზე არაფერი იცვლება) */
    private fun channelMenu(ch: Channel) {
        if (!alive()) return
        val fav = UserLists.isFav(this, ch)
        val items = arrayOf(if (fav) "★ ამოღება ფავორიტებიდან" else "☆ ფავორიტებში დამატება", "🗑 არხის წაშლა სიიდან", "დახურვა")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> toggleFav(ch)
                    1 -> confirmHide(ch)
                }
            }.show()
    }

    private fun toggleFav(ch: Channel) {
        val added = UserLists.toggleFav(this, ch)
        flash(if (added) "★ დაემატა ფავორიტებში" else "ამოიღეთ ფავორიტებიდან")
        val pos = ChannelHolder.list.indexOfFirst { it.url == ch.url }
        applyFilter()
        if (isTv && pos >= 0) focusPosition(pos.coerceAtMost((ChannelHolder.list.size - 1).coerceAtLeast(0)), 8)
    }

    private fun confirmHide(ch: Channel) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("წაიშალოს „" + ch.name + "“?")
            .setMessage("არხი მხოლოდ ამ აპლიკაციაში დაიმალება. საიტზე და სხვა მოწყობილობებზე არაფერი შეიცვლება. აღდგენა: MENU → კატეგორიები → აღდგენა.")
            .setPositiveButton("წაშლა") { _, _ ->
                val pos = ChannelHolder.list.indexOfFirst { it.url == ch.url }
                UserLists.hide(this, ch)
                val wasCurrent = current?.url == ch.url
                showChannels(startPlayback = false)
                if (wasCurrent) ChannelHolder.list.getOrNull(pos.coerceAtLeast(0).coerceAtMost((ChannelHolder.list.size - 1).coerceAtLeast(0)))?.let { play(it) }
                if (isTv && pos >= 0) focusPosition(pos.coerceAtMost((ChannelHolder.list.size - 1).coerceAtLeast(0)), 8)
                flash("არხი წაიშალა")
            }
            .setNegativeButton("არა", null)
            .show()
    }

    /** კატეგორიის არჩევა სიიდან (პულტზე ფერადი ღილაკების გარეშეც): MENU / ⚙ */
    private fun categoryMenu() {
        if (!alive()) return
        val labels = groups.map { Lang.group(it) }.toTypedArray()
        val b0 = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("კატეგორია")
            .setSingleChoiceItems(labels, groups.indexOf(group).coerceAtLeast(0)) { dlg, which ->
                selectGroup(groups[which])
                dlg.dismiss()
                if (isTv) focusCurrent(8)
            }
        val hc = UserLists.hiddenCount(this)
        if (hc > 0) b0.setNeutralButton("წაშლილების აღდგენა ($hc)") { _, _ ->
            UserLists.unhideAll(this)
            showChannels(startPlayback = false)
            flash("არხები აღდგა")
        }
        b0.setNegativeButton("დახურვა", null)
        b0.show()
    }

    /** არხი, რომელზეც ფოკუსია (სიაში) ან მიმდინარე */
    private fun focusedChannel(): Channel? {
        val f = currentFocus
        if (f != null && f.parent === b.channels) {
            val pos = b.channels.getChildAdapterPosition(f)
            ChannelHolder.list.getOrNull(pos)?.let { return it }
        }
        return current
    }

    private var lastInfoAt = 0L
    private fun fsInfoKey() {
        val now = android.os.SystemClock.uptimeMillis()
        if (now - lastInfoAt < 3000 && b.fsBar?.visibility == View.VISIBLE) { lastInfoAt = 0; current?.let { channelMenu(it) } }
        else { lastInfoAt = now; showFsInfo() }
    }

    private fun stepChannel(delta: Int) {
        val list = ChannelHolder.list
        if (list.isEmpty()) return
        // მიმდინარე არხი ამ კატეგორიაში არ არის (კატეგორია შეიცვალა) → CH+ პირველზე, CH− ბოლოზე
        val inList = ChannelHolder.index >= 0 && list.any { it.url == current?.url }
        val pos = if (inList) Math.floorMod(ChannelHolder.index + delta, list.size) else if (delta > 0) 0 else list.size - 1
        ChannelHolder.markPos(pos)
        play(list[pos])
        b.channels.scrollToPosition(pos)
    }

    /**
     * პულტი (TV): CH+/CH− (P▲/P▼), ციფრები 0–9, LAST/DEL → წინა არხი, ⏯ → სრული ეკრანი,
     * RED/GREEN → წინა/შემდეგი კატეგორია (FAV-იც → შემდეგი), YELLOW → ენა, BLUE → სრული ეკრანი,
     * EXIT → გასვლა, OK → არხი სრულ ეკრანზე.
     */
    private var swallowKey = 0
    private var swallowAt = 0L
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        Device.noteKey(this, event)
        // OK-მ სრული ეკრანი დახურა: იმავე დაჭერის გაგრძელება/აშვება სიის არხს არ უნდა "დააჭიროს"
        if (swallowKey != 0 && android.os.SystemClock.uptimeMillis() - swallowAt > 3000) swallowKey = 0
        if (swallowKey != 0 && event.keyCode == swallowKey) {
            if (event.action == KeyEvent.ACTION_UP) swallowKey = 0
            return true
        }
        if (fs && ::b.isInitialized && fsKey(event)) return true
        if (overlayTv && !fs && ::b.isInitialized && (event.keyCode == KeyEvent.KEYCODE_BACK || event.keyCode == KeyEvent.KEYCODE_ESCAPE) && current != null && !digits.active) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                // EXIT/BACK: ჯერ ღია პანელი იხურება (ტელეპროგრამა → არხების სია → სრული ეკრანი), სრულ ეკრანზე — გასვლა
                if (epgOpen) { closeEpgPanel(); focusCurrent(8) }
                else enterFs()
            }
            return true
        }
        if (event.action == KeyEvent.ACTION_DOWN && ::b.isInitialized) {
            val k = event.keyCode
            offerKeysOnce()
            if (tvListKey(event.keyCode)) return true
            // მორგებული ღილაკები (↑↓←→ მთავარზე ფოკუსისთვისაა და არ გამოიყენება)
            if (!KeyMap.isDpad(k)) {
                when (KeyMap.get(this, k)) {
                    KeyMap.Act.NEXT_CH -> { if (event.repeatCount == 0) stepChannel(1); return true }
                    KeyMap.Act.PREV_CH -> { if (event.repeatCount == 0) stepChannel(-1); return true }
                    KeyMap.Act.LAST -> {
                        if (event.repeatCount == 0) prevChannel?.let {
                            play(it)
                            val pos = ChannelHolder.list.indexOfFirst { c -> c.url == it.url }
                            if (pos >= 0) b.channels.scrollToPosition(pos)
                        }
                        return true
                    }
                    KeyMap.Act.FAV -> { if (event.repeatCount == 0) focusedChannel()?.let { toggleFav(it) }; return true }
                    KeyMap.Act.HIDE -> { if (event.repeatCount == 0) focusedChannel()?.let { confirmHide(it) }; return true }
                    KeyMap.Act.PREV_GROUP -> { if (event.repeatCount == 0) stepGroup(-1); return true }
                    KeyMap.Act.NEXT_GROUP -> { if (event.repeatCount == 0) stepGroup(1); return true }
                    KeyMap.Act.GROUP_MENU -> { if (event.repeatCount == 0) categoryMenu(); return true }
                    else -> {}
                }
            }
            when (k) {
                KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_TV_DATA_SERVICE -> { focusEpg(8); return true }
                KeyEvent.KEYCODE_CAPTIONS -> { cycleSubtitles(); return true }
                KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK -> { cycleAudio(); return true }
                KeyEvent.KEYCODE_MUTE -> { StreamHub.peek()?.player?.let { it.volume = if (it.volume == 0f) 1f else 0f }; return true }
                KeyEvent.KEYCODE_MEDIA_STOP -> { return true }
            }
            when {
                k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_PAGE_UP -> {
                    stepChannel(1)
                    return true
                }
                k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_PAGE_DOWN -> {
                    stepChannel(-1)
                    return true
                }
                // ◀◀ ▶▶ და ⏮ ⏭ — წინა / შემდეგი არხი (გამეორებას ვუგულებელვყოფთ)
                k == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || k == KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    if (event.repeatCount == 0) stepChannel(1)
                    return true
                }
                k == KeyEvent.KEYCODE_MEDIA_REWIND || k == KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    if (event.repeatCount == 0) stepChannel(-1)
                    return true
                }
                k == KeyEvent.KEYCODE_MEDIA_PLAY || k == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || k == KeyEvent.KEYCODE_PROG_BLUE -> {
                    if (current != null) {
                        openFullscreen()
                        return true
                    }
                }
                k == KeyEvent.KEYCODE_PROG_RED -> {
                    stepGroup(-1)
                    return true
                }
                k == KeyEvent.KEYCODE_PROG_GREEN -> {
                    stepGroup(1)
                    return true
                }
                k == KeyEvent.KEYCODE_PROG_YELLOW -> {
                    focusLogout()   // TV: სწრაფად "გასვლა" ღილაკზე
                    return true
                }
                // ფერადი ღილაკების გარეშე პულტები: MENU / ⚙ = კატეგორიების სია
                k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_SETTINGS || k == KeyEvent.KEYCODE_TV_CONTENTS_MENU -> {
                    if (event.repeatCount == 0) categoryMenu()
                    return true
                }
                // INFO (i) = არხის მენიუ (ფავორიტი / წაშლა); FAV = ფავორიტში დამატება/ამოღება
                k == KeyEvent.KEYCODE_INFO -> {
                    if (event.repeatCount == 0) focusedChannel()?.let { channelMenu(it) }
                    return true
                }
                k == KeyEvent.KEYCODE_BOOKMARK -> {
                    if (event.repeatCount == 0) focusedChannel()?.let { toggleFav(it) }
                    return true
                }
                k == KeyEvent.KEYCODE_LAST_CHANNEL || (k == KeyEvent.KEYCODE_DEL && !digits.active) -> {
                    prevChannel?.let {
                        play(it)
                        val pos = ChannelHolder.list.indexOfFirst { c -> c.url == it.url }
                        if (pos >= 0) b.channels.scrollToPosition(pos)
                    }
                    return true
                }
                k in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                    digits.digit(k - KeyEvent.KEYCODE_0)
                    return true
                }
                k in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> {
                    digits.digit(k - KeyEvent.KEYCODE_NUMPAD_0)
                    return true
                }
                (k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER) && digits.active -> {
                    digits.commit()
                    return true
                }
                (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_DEL) && digits.active -> {
                    digits.cancel()
                    return true
                }
                k == KeyEvent.KEYCODE_ESCAPE -> {   // EXIT
                    if (digits.active) digits.cancel() else finish()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    /** პულტის პირველივე ღილაკზე ერთხელ შევთავაზოთ ღილაკების მორგება (მხოლოდ თუ პულტითაა და ჯერ არ მოუგვარებია) */
    private fun offerKeysOnce() {
        if (!Device.remoteSeen || offered) return
        val prefs = getSharedPreferences("tv_keys", MODE_PRIVATE)
        if (prefs.getBoolean("offered", false) || !KeyMap.isEmpty(this)) { offered = true; return }
        offered = true
        prefs.edit().putBoolean("offered", true).apply()
        h.post {
            if (isFinishing || isDestroyed) return@post
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(R.string.keys_offer_title)
                .setMessage(R.string.keys_offer_msg)
                .setPositiveButton(R.string.keys_offer_yes) { _, _ -> startActivity(Intent(this, KeysActivity::class.java)) }
                .setNegativeButton(R.string.later_btn, null)
                .show()
        }
    }

    private fun goLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
