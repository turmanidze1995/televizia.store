package store.televizia.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * არხის ლოგოების ჩამტვირთავი:
 *  - გადამისამართებებს (http -> https) ხელით მიჰყვება, აქვს User-Agent
 *  - მეხსიერების + დისკის ქეში (მეორედ ჩატვირთვა მყისიერია)
 *  - დიდ სიაში სწრაფი გადახვევისას ძველი მოთხოვნები ირიყება
 *  - ლოგო რომ ვერ ჩაიტვირთა, ჩანს არხის პირველი ასოები
 */
object ImageLoader {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val failed = HashSet<String>()
    private val pool = ThreadPoolExecutor(
        6, 6, 30, TimeUnit.SECONDS, ArrayBlockingQueue(80),
        ThreadPoolExecutor.DiscardOldestPolicy()
    )
    private val main = Handler(Looper.getMainLooper())
    private var dir: File? = null
    private val dirReady = AtomicBoolean(false)

    fun show(rawUrl: String, view: ImageView, name: String = "") {
        val url = normalize(rawUrl)
        view.tag = url
        val fallback = InitialsDrawable(name)
        view.setImageDrawable(fallback)
        if (url.isBlank()) return
        cache.get(url)?.let { view.setImageBitmap(it); return }
        if (synchronized(failed) { failed.contains(url) }) return
        val ctx = view.context.applicationContext
        pool.execute {
            if (dirReady.compareAndSet(false, true)) {
                dir = File(ctx.cacheDir, "logos").also { it.mkdirs() }
            }
            val bmp = fromDisk(url) ?: download(url)
            if (bmp != null) cache.put(url, bmp) else synchronized(failed) { failed.add(url) }
            main.post { if (view.tag == url && bmp != null) view.setImageBitmap(bmp) }
        }
    }

    private fun normalize(raw: String): String {
        var u = raw.trim().replace(" ", "%20")
        if (u.isEmpty()) return ""
        if (u.startsWith("//")) u = "https:$u"
        else if (u.startsWith("/")) u = BASE_URL + u
        return u
    }

    private fun key(url: String): String =
        MessageDigest.getInstance("MD5").digest(url.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun fromDisk(url: String): Bitmap? = try {
        val f = File(dir, key(url))
        if (f.exists() && f.length() > 0) decode(f.readBytes()) else null
    } catch (e: Exception) {
        null
    }

    private fun download(start: String): Bitmap? {
        var url = start
        try {
            for (hop in 0..5) {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 10000
                c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/110 Mobile Safari/537.36")
                c.setRequestProperty("Accept", "image/png,image/jpeg,image/webp,image/*;q=0.8,*/*;q=0.5")
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location") ?: return null
                    url = URL(URL(url), loc).toString()
                    c.disconnect()
                    continue
                }
                if (code !in 200..299) {
                    c.disconnect()
                    return null
                }
                val bytes = c.inputStream.use { it.readBytes() }
                c.disconnect()
                if (bytes.isEmpty() || bytes.size > 3_000_000) return null
                val bmp = decode(bytes) ?: return null
                try { File(dir, key(start)).writeBytes(bytes) } catch (e: Exception) { }
                return bmp
            }
        } catch (e: Exception) {
        }
        return null
    }

    /** დიდ სურათს ვამცირებთ (სიის ლოგოსთვის 200px საკმარისია) */
    private fun decode(bytes: ByteArray): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var sample = 1
        while (o.outWidth / (sample * 2) >= 200 && o.outHeight / (sample * 2) >= 200) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }
}

/** ლოგოს ნაცვლად: მომრგვალებული ბარათი არხის პირველი ასოებით */
class InitialsDrawable(name: String) : Drawable() {
    private val text: String = name.trim()
        .split(" ", ":", "-", "_")
        .filter { it.isNotBlank() }
        .let { parts ->
            val useful = parts.filter { it.uppercase() != "GE" && it.uppercase() != "HD" }.ifEmpty { parts }
            useful.take(2).joinToString("") { it.take(1) }.uppercase()
        }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#24305E") }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00D9C0")
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    override fun draw(c: Canvas) {
        val r = bounds
        if (r.isEmpty) return
        c.drawRoundRect(RectF(r), r.height() / 4f, r.height() / 4f, bg)
        fg.textSize = r.height() * 0.45f
        val y = r.exactCenterY() - (fg.descent() + fg.ascent()) / 2
        c.drawText(text, r.exactCenterX(), y, fg)
    }

    override fun setAlpha(alpha: Int) { bg.alpha = alpha; fg.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
