package store.televizia.app

import android.graphics.Color
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import store.televizia.app.databinding.ItemChannelBinding

/** არხების სია: ნომერი, ლოგო, სახელი, მიმდინარე გადაცემა, რჩეულის ვარსკვლავი */
class ChannelAdapter(
    private val onClick: (Channel, Int) -> Unit,
    private val onLong: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    private var items: List<Channel> = emptyList()
    private var selectedUrl: String = ""
    var favs: Set<String> = emptySet()

    class VH(val b: ItemChannelBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(list: List<Channel>) {
        items = list
        notifyDataSetChanged()
    }

    fun select(url: String) {
        selectedUrl = url
        notifyDataSetChanged()
    }

    fun refresh() = notifyDataSetChanged()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemChannelBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val ch = items[position]
        h.b.num.text = (position + 1).toString()
        h.b.name.text = ch.name
        val nowP = Epg.now(ch.epgId)
        h.b.now.text = if (nowP != null) "${Ui.timeOf(nowP.start)}  ${nowP.title}" else ""
        h.b.prog.progress = Ui.progressOf(nowP)
        h.b.fav.visibility = if (favs.contains(ch.url)) View.VISIBLE else View.GONE
        ImageLoader.show(ch.logo, h.b.logo, ch.name)
        h.b.root.isSelected = ch.url == selectedUrl
        h.b.root.setOnClickListener { onClick(ch, position) }
        h.b.root.setOnLongClickListener {
            onLong(ch)
            true
        }
    }
}

/** კატეგორიები: TV/ლანდშაფტზე ვერტიკალური სია, ტელეფონზე ჰორიზონტალური ჩიპები */
class GroupAdapter(
    private val vertical: Boolean,
    private val onClick: (String) -> Unit
) : RecyclerView.Adapter<GroupAdapter.VH>() {
    private var items: List<String> = emptyList()
    private var selected: String = ""

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    fun submit(list: List<String>, sel: String) {
        items = list
        selected = sel
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val tv = TextView(parent.context)
        tv.setPadding(30, 16, 30, 16)
        tv.textSize = 14f
        tv.setTextColor(Color.WHITE)
        tv.isFocusable = true
        tv.isClickable = true
        if (vertical) {
            tv.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            tv.setBackgroundResource(R.drawable.item_bg)
            val lp = ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, 0, 0, 8)
            tv.layoutParams = lp
        } else {
            tv.gravity = Gravity.CENTER
            tv.setBackgroundResource(R.drawable.chip_bg)
            val lp = ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, 0, 12, 0)
            tv.layoutParams = lp
        }
        return VH(tv)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val g = items[position]
        h.tv.text = g
        h.tv.isSelected = g == selected
        h.tv.setOnClickListener { onClick(g) }
    }
}

/** პროგრამის სია (EPG) — დრო და სათაური */
class ProgramAdapter : RecyclerView.Adapter<ProgramAdapter.VH>() {
    private var items: List<Program> = emptyList()

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    fun submit(list: List<Program>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val tv = TextView(parent.context)
        tv.setPadding(20, 12, 20, 12)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 14f
        tv.setBackgroundResource(R.drawable.item_bg)
        tv.isFocusable = true
        val lp = ViewGroup.MarginLayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(0, 0, 0, 6)
        tv.layoutParams = lp
        return VH(tv)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = items[position]
        h.tv.text = "${Ui.timeOf(p.start)}   ${p.title}"
    }
}
