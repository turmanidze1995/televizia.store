package store.televizia.app

import android.animation.ValueAnimator
import android.app.UiModeManager
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import store.televizia.app.databinding.ActivityLiveBinding

private enum class Panel { NONE, CHANNELS, EPG }

/**
 * მთავარი ეკრანი (ფლეიერი + სია ერთად).
 * TV და ტელეფონი ლანდშაფტში: ვიდეო სრულ ეკრანზე, OK/MENU — არხების სია, GUIDE — პროგრამა.
 * ტელეფონი პორტრეტში: ზემოთ ვიდეო, ქვემოთ სია.
 */
class MainActivity : AppCompatActivity() {
    companion object {
        /** ტელეფონი: true = მომხმარებელმა სრულ ეკრანზე (ჰორიზონტალურად) გადართო */
        var phoneFullscreen = false
        const val G_ALL = "ყველა"
        const val G_FAV = "★ რჩეულები"
        const val G_RECENT = "🕘 ბოლოს ნანახი"
        // ეს ღილაკები სისტემას ან ფოკუსის გადაადგილებას ეკუთვნის — კოდს არ ვაჩვენებთ
        val IGNORED_KEYS = setOf(
            KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_VOLUME_MUTE,
            KeyEvent.KEYCODE_HOME, KeyEvent.KEYCODE_POWER, KeyEvent.KEYCODE_APP_SWITCH,
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_TAB, KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_VOICE_ASSIST,
            KeyEvent.KEYCODE_ASSIST, KeyEvent.KEYCODE_UNKNOWN, KeyEvent.KEYCODE_TV_INPUT,
            KeyEvent.KEYCODE_TV_POWER, KeyEvent.KEYCODE_TV
        )
    }

    private lateinit var b: ActivityLiveBinding
    private val h = Handler(Looper.getMainLooper())
    private var engine: VlcEngine? = null
    private var isTv = false
    private var compact = false
    private var panel = Panel.NONE
    private var loadAnim: ValueAnimator? = null
    private var clockR: Runnable? = null
    private var lastBack = 0L
    private var attempt = 0            // 0 = აპარატული დეკოდერი, 1 = პროგრამული (სარეზერვო)
    private var retryPending = false
    private var switching = false       // არხი შეიცვალა, ახალი დაკვრა ჯერ არ დაწყებულა — ძველი არხის შეცდომებს ვიგნორებთ
    private var lastStepAt = 0L
    private var favs: MutableSet<String> = HashSet()
    private val digitBuf = StringBuilder()

    private val channelAdapter = ChannelAdapter(
        onClick = { _, pos ->
            playIndex(pos)
            showPanel(Panel.NONE)
        },
        onLong = { ch -> toggleFav(ch) }
    )
    private lateinit var groupAdapter: GroupAdapter
    private val programAdapter = ProgramAdapter()

    private val hideInfoR = Runnable { if (!compact) b.infoBar.visibility = View.INVISIBLE }
    private val playR = Runnable { startPlayback() }
    private val stableR = Runnable { attempt = 0 }
    private val hideHudR = Runnable { b.hud.visibility = View.GONE }
    private val digitR = Runnable { commitDigits() }
    private val timeoutR = Runnable { channelFailed() }
    private val retryR = Runnable {
        retryPending = false
        startPlayback()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.token(this) == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val uiMode = getSystemService(UI_MODE_SERVICE) as UiModeManager
        isTv = uiMode.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            packageManager.hasSystemFeature("android.software.leanback")
        // ტელევიზორი — ყოველთვის ჰორიზონტალურად; ტელეფონი — ვერტიკალურად (ვიდეო ზემოთ, სია ქვემოთ),
        // „სრულ ეკრანზე“ ღილაკით ჰორიზონტალურად, უკან ღილაკით ისევ ვერტიკალურად
        requestedOrientation = when {
            isTv -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            phoneFullscreen -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        b = ActivityLiveBinding.inflate(layoutInflater)
        setContentView(b.root)

        compact = !isTv && resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT

        groupAdapter = GroupAdapter(!compact) { g -> selectGroup(g) }
        b.channels.layoutManager = LinearLayoutManager(this)
        b.channels.adapter = channelAdapter
        b.groups.layoutManager = if (compact) {
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        } else {
            LinearLayoutManager(this)
        }
        b.groups.adapter = groupAdapter
        b.epgList.layoutManager = LinearLayoutManager(this)
        b.epgList.adapter = programAdapter

        b.btnFs.setOnClickListener {
            phoneFullscreen = true
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        b.btnLogout.setOnClickListener { logout() }
        b.touch.setOnClickListener {
            if (compact) flashInfo() else togglePanel(Panel.CHANNELS)
        }
        b.search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        b.search.setOnEditorActionListener { _, _, _ ->
            b.search.clearFocus()
            if (!compact) focusCurrent()
            true
        }

        if (!compact) {
            b.panel.visibility = View.GONE
            b.epgPanel.visibility = View.GONE
        }
        loadChannels()
    }

    override fun onStart() {
        super.onStart()
        if (!::b.isInitialized) return
        clockR = Ui.startClock(b.clock, h)
        if (engine == null) {
            engine = VlcEngine(this, b.video) { s, pct -> onPlayState(s, pct) }
            if (ChannelHolder.all.isNotEmpty()) startInitial()
        }
    }

    override fun onStop() {
        super.onStop()
        clockR?.let { h.removeCallbacks(it) }
        clockR = null
        if (!::b.isInitialized) return
        h.removeCallbacks(timeoutR)
        h.removeCallbacks(retryR)
        h.removeCallbacks(playR)
        h.removeCallbacks(stableR)
        engine?.release()
        engine = null
        stopLoadAnim()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::b.isInitialized && !compact) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    // ---------------------------------------------------------------- არხების ჩატვირთვა

    private fun loadChannels() {
        if (ChannelHolder.all.isNotEmpty()) {
            onChannelsReady()
            return
        }
        val token = Session.token(this)
        if (token == null) {
            logout()
            return
        }
        b.status.text = "არხები იტვირთება…"
        startLoadAnim()
        Thread {
            val res = Api.playlist(token)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (!res.ok) {
                    stopLoadAnim()
                    b.status.text = res.message
                    b.errorBox.text = res.message
                    b.errorBox.visibility = View.VISIBLE
                    return@runOnUiThread
                }
                ChannelHolder.all = M3u.parse(res.body)
                onChannelsReady()
                Thread {
                    Epg.load()
                    runOnUiThread {
                        if (!isDestroyed) {
                            channelAdapter.refresh()
                            refreshEpg()
                        }
                    }
                }.start()
            }
        }.start()
    }

    private fun onChannelsReady() {
        favs = Prefs.favorites(this)
        channelAdapter.favs = favs
        ChannelHolder.groups = listOf(G_ALL, G_FAV, G_RECENT) + ChannelHolder.all.map { it.group }.distinct()
        groupAdapter.submit(ChannelHolder.groups, ChannelHolder.group)
        applyFilter()
        if (engine != null) startInitial()
    }

    private fun startInitial() {
        if (ChannelHolder.list.isEmpty()) return
        val url = ChannelHolder.currentUrl ?: Prefs.last(this)
        var i = ChannelHolder.list.indexOfFirst { it.url == url }
        if (i < 0) i = 0
        playIndex(i)
    }

    private fun selectGroup(g: String) {
        ChannelHolder.group = g
        groupAdapter.submit(ChannelHolder.groups, g)
        applyFilter()
    }

    private fun applyFilter() {
        val q = b.search.text.toString().trim().lowercase()
        val all = ChannelHolder.all
        var src: List<Channel> = when (ChannelHolder.group) {
            G_ALL -> all
            G_FAV -> all.filter { favs.contains(it.url) }
            G_RECENT -> Prefs.recents(this).mapNotNull { u -> all.firstOrNull { it.url == u } }
            else -> all.filter { it.group == ChannelHolder.group }
        }
        if (q.isNotEmpty()) src = src.filter { it.name.lowercase().contains(q) }
        ChannelHolder.list = src
        ChannelHolder.index = src.indexOfFirst { it.url == ChannelHolder.currentUrl }
        channelAdapter.submit(src)
        channelAdapter.select(ChannelHolder.currentUrl ?: "")
        b.status.text = "${ChannelHolder.group} · ${src.size} არხი"
    }

    // ---------------------------------------------------------------- დაკვრა

    private fun playIndex(pos: Int) {
        val list = ChannelHolder.list
        if (pos !in list.indices) return
        val ch = list[pos]
        val cur = ChannelHolder.currentUrl
        if (cur != null && cur != ch.url) ChannelHolder.prevUrl = cur
        ChannelHolder.index = pos
        ChannelHolder.currentUrl = ch.url
        Prefs.pushRecent(this, ch.url)
        attempt = 0
        retryPending = false
        switching = true
        channelAdapter.select(ch.url)
        b.errorBox.visibility = View.GONE
        showInfo(ch, pos)
        refreshEpg()
        h.removeCallbacks(retryR)
        h.removeCallbacks(timeoutR)
        h.removeCallbacks(stableR)
        // სწრაფი გადართვისას (ღილაკის ხანგრძლივი დაჭერა) ყოველ არხს არ ვტვირთავთ — მხოლოდ ბოლოს
        h.removeCallbacks(playR)
        startLoadAnim()
        h.postDelayed(playR, 250)
    }

    private fun startPlayback() {
        val u = ChannelHolder.currentUrl ?: return
        switching = false
        startLoadAnim()
        engine?.play(u, attempt == 0)
        h.removeCallbacks(timeoutR)
        h.postDelayed(timeoutR, 20000)
    }

    private fun step(delta: Int, repeat: Int = 0) {
        val n = ChannelHolder.list.size
        if (n == 0) return
        val now = System.currentTimeMillis()
        if (repeat > 0 && now - lastStepAt < 450) return   // ღილაკის დაჭერისას არხები ზედმეტად სწრაფად არ იცვლება
        lastStepAt = now
        val base = if (ChannelHolder.index < 0) 0 else ChannelHolder.index
        playIndex(Math.floorMod(base + delta, n))
        b.channels.scrollToPosition(ChannelHolder.index)
    }

    private fun lastChannel() {
        val u = ChannelHolder.prevUrl ?: return
        var i = ChannelHolder.list.indexOfFirst { it.url == u }
        if (i < 0) {
            ChannelHolder.group = G_ALL
            groupAdapter.submit(ChannelHolder.groups, G_ALL)
            b.search.setText("")
            applyFilter()
            i = ChannelHolder.list.indexOfFirst { it.url == u }
        }
        if (i >= 0) playIndex(i)
    }

    private fun onPlayState(s: PlayState, pct: Int) {
        runOnUiThread {
            if (isDestroyed) return@runOnUiThread
            when (s) {
                PlayState.LOADING -> startLoadAnim()
                PlayState.PLAYING -> {
                    stopLoadAnim()
                    b.errorBox.visibility = View.GONE
                    h.removeCallbacks(timeoutR)
                    h.removeCallbacks(retryR)
                    retryPending = false
                    // 10 წამი უპრობლემოდ თამაშის შემდეგ ცდების ათვლა თავიდან იწყება
                    h.removeCallbacks(stableR)
                    h.postDelayed(stableR, 10000)
                }
                PlayState.ERROR, PlayState.ENDED -> if (!switching) channelFailed()
            }
        }
    }

    /** არხი ვერ აჩვენა: ერთხელ ვცდით პროგრამული დეკოდერით, შემდეგ წარწერა — სხვა არხზე თავისით არ გადადის */
    private fun channelFailed() {
        h.removeCallbacks(timeoutR)
        h.removeCallbacks(stableR)
        if (retryPending) return
        if (attempt < 1) {
            attempt++
            retryPending = true
            startLoadAnim()
            h.removeCallbacks(retryR)
            h.postDelayed(retryR, 1500)
            return
        }
        stopLoadAnim()
        b.errorBox.text = "არხი დროებით გამორთულია"
        b.errorBox.visibility = View.VISIBLE
    }

    /** ჩატვირთვისას: TELEVIZIA.STORE ლოგო ფერებში ციმციმებს */
    private fun startLoadAnim() {
        b.loadingLogo.visibility = View.VISIBLE
        if (loadAnim != null) return
        val anim = ValueAnimator.ofFloat(0f, 360f)
        anim.duration = 1800
        anim.repeatCount = ValueAnimator.INFINITE
        anim.addUpdateListener { va ->
            val d = va.animatedValue as Float
            val cm = ColorMatrix()
            cm.setRotate(0, d)
            cm.setRotate(1, d * 0.6f)
            cm.setRotate(2, d * 0.3f)
            b.loadingLogo.colorFilter = ColorMatrixColorFilter(cm)
            b.loadingLogo.alpha = 0.55f + 0.45f * Math.abs(Math.sin(Math.toRadians(d.toDouble()))).toFloat()
        }
        anim.start()
        loadAnim = anim
    }

    private fun stopLoadAnim() {
        loadAnim?.cancel()
        loadAnim = null
        b.loadingLogo.colorFilter = null
        b.loadingLogo.alpha = 1f
        b.loadingLogo.visibility = View.GONE
    }

    // ---------------------------------------------------------------- ინფო, EPG, შეტყობინებები

    private fun showInfo(ch: Channel, pos: Int) {
        b.chNum.text = (pos + 1).toString()
        b.chName.text = ch.name
        ImageLoader.show(ch.logo, b.chLogo, ch.name)
        val now = Epg.now(ch.epgId)
        b.chNow.text = if (now != null) {
            "${Ui.timeOf(now.start)}–${Ui.timeOf(now.stop)}  ${now.title}"
        } else {
            "ტელეპროგრამა არ არის"
        }
        b.chProg.progress = Ui.progressOf(now)
        flashInfo()
    }

    private fun flashInfo() {
        b.infoBar.visibility = View.VISIBLE
        h.removeCallbacks(hideInfoR)
        h.postDelayed(hideInfoR, 4000)
    }

    private fun refreshEpg() {
        val ch = ChannelHolder.list.getOrNull(ChannelHolder.index) ?: return
        val up = Epg.upcoming(ch.epgId, 40)
        programAdapter.submit(up)
        b.epgTitle.text = if (up.isEmpty()) "ტელეპროგრამა · ${ch.name}\nპროგრამა ამ არხზე არ არის" else "ტელეპროგრამა · ${ch.name}"
    }

    private fun hud(msg: String) {
        b.hud.text = msg
        b.hud.visibility = View.VISIBLE
        h.removeCallbacks(hideHudR)
        h.postDelayed(hideHudR, 2500)
    }

    private fun toggleFav(ch: Channel) {
        val added = Prefs.toggleFavorite(this, ch.url)
        favs = Prefs.favorites(this)
        channelAdapter.favs = favs
        hud(if (added) "★ დაემატა რჩეულებში: ${ch.name}" else "წაიშალა რჩეულებიდან: ${ch.name}")
        if (ChannelHolder.group == G_FAV) applyFilter() else channelAdapter.refresh()
    }

    private fun currentChannel(): Channel? = ChannelHolder.list.getOrNull(ChannelHolder.index)

    // ---------------------------------------------------------------- პანელები

    private fun showPanel(p: Panel) {
        panel = p
        if (compact) return
        b.panel.visibility = if (p == Panel.CHANNELS) View.VISIBLE else View.GONE
        b.epgPanel.visibility = if (p == Panel.EPG) View.VISIBLE else View.GONE
        if (p == Panel.CHANNELS) focusCurrent()
    }

    private fun togglePanel(p: Panel) {
        showPanel(if (panel == p) Panel.NONE else p)
    }

    private fun focusCurrent() {
        val idx = if (ChannelHolder.index < 0) 0 else ChannelHolder.index
        b.channels.scrollToPosition(idx)
        b.channels.post {
            val v = b.channels.layoutManager?.findViewByPosition(idx)
            if (v != null) v.requestFocus() else b.channels.requestFocus()
        }
    }

    // ---------------------------------------------------------------- ციფრებით გადართვა

    private fun pushDigit(d: Int) {
        if (digitBuf.length >= 4) digitBuf.setLength(0)
        digitBuf.append(d)
        showDigits()
    }

    private fun backspaceDigit() {
        if (digitBuf.isNotEmpty()) digitBuf.setLength(digitBuf.length - 1)
        showDigits()
    }

    private fun showDigits() {
        h.removeCallbacks(digitR)
        if (digitBuf.isEmpty()) {
            b.numPad.visibility = View.GONE
            return
        }
        b.numPad.text = digitBuf.toString()
        b.numPad.visibility = View.VISIBLE
        h.postDelayed(digitR, 1500)
    }

    private fun commitDigits() {
        val n = digitBuf.toString().toIntOrNull()
        digitBuf.setLength(0)
        b.numPad.visibility = View.GONE
        if (n == null) return
        if (n in 1..ChannelHolder.list.size) {
            playIndex(n - 1)
            b.channels.scrollToPosition(n - 1)
        } else {
            hud("არხი $n არ არსებობს")
        }
    }

    // ---------------------------------------------------------------- პულტი და ღილაკები

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (::b.isInitialized && event.action == KeyEvent.ACTION_DOWN && handleKey(event)) return true
        return super.dispatchKeyEvent(event)
    }

    private fun handleKey(event: KeyEvent): Boolean {
        val k = event.keyCode
        val rep = event.repeatCount
        if (currentFocus is EditText && k != KeyEvent.KEYCODE_BACK && k != KeyEvent.KEYCODE_ESCAPE) return false
        val panelOpen = !compact && panel != Panel.NONE

        /*
         * პულტების ღილაკები (Toshiba CT-8054 და შავი STB პულტი):
         *  CH+/CH-, P^/Pv, Pg+/Pg-   -> არხი +/-          0..9         -> არხის ნომერი
         *  LAST/DEL                  -> წინა არხი          FAV          -> რჩეულების სია
         *  MENU / წითელი             -> არხების სია        GUIDE/EPG / მწვანე -> ტელეპროგრამა
         *  INFO / i+                 -> ინფო პანელი        ყვითელი      -> რჩეულებში დამატება/წაშლა
         *  AUDIO                     -> ხმის ტრეკი         SUB.T/SUBTITLE -> სუბტიტრი
         *  ლურჯი / ეკრანის ფორმატი   -> ეკრანის მორგება    SEARCH       -> ძებნა სიაში
         *  PLAY/PAUSE/STOP           -> პაუზა              REW/FF       -> გადახვევა
         *  OK / ისრები               -> სია / არხი+/-      EXIT / BACK  -> დახურვა / გასვლა
         */
        when (k) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                step(1, rep)
                return true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                step(-1, rep)
                return true
            }
            KeyEvent.KEYCODE_LAST_CHANNEL -> {
                if (rep == 0) lastChannel()
                return true
            }
            KeyEvent.KEYCODE_DEL, KeyEvent.KEYCODE_FORWARD_DEL -> {
                if (rep == 0) {
                    if (digitBuf.isNotEmpty()) backspaceDigit() else lastChannel()
                }
                return true
            }
            KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_PROG_GREEN -> {
                if (rep == 0) togglePanel(Panel.EPG)
                return true
            }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_PROG_RED -> {
                if (rep == 0) togglePanel(Panel.CHANNELS)
                return true
            }
            KeyEvent.KEYCODE_INFO -> {
                if (rep == 0) {
                    val ch = currentChannel()
                    if (ch != null) showInfo(ch, ChannelHolder.index)
                }
                return true
            }
            KeyEvent.KEYCODE_PROG_YELLOW -> {
                if (rep == 0) {
                    val ch = currentChannel()
                    if (ch != null) toggleFav(ch)
                }
                return true
            }
            KeyEvent.KEYCODE_BOOKMARK, KeyEvent.KEYCODE_STAR -> {   // FAV
                if (rep == 0) openFavorites()
                return true
            }
            KeyEvent.KEYCODE_PROG_BLUE, KeyEvent.KEYCODE_TV_ZOOM_MODE, KeyEvent.KEYCODE_ZOOM_IN -> {
                if (rep == 0) hud("ეკრანი: " + (engine?.cycleScale() ?: ""))
                return true
            }
            KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK, KeyEvent.KEYCODE_LANGUAGE_SWITCH -> {
                if (rep == 0) hud("ხმა: " + (engine?.cycleAudio() ?: ""))
                return true
            }
            KeyEvent.KEYCODE_CAPTIONS -> {
                if (rep == 0) hud("სუბტიტრი: " + (engine?.cycleSubtitle() ?: ""))
                return true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY,
            KeyEvent.KEYCODE_MEDIA_PAUSE, KeyEvent.KEYCODE_MEDIA_STOP -> {
                if (rep == 0) engine?.togglePause()
                return true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                seek(-10_000L)
                return true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                seek(10_000L)
                return true
            }
            KeyEvent.KEYCODE_SEARCH -> {
                if (rep == 0) openSearch()
                return true
            }
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                if (rep == 0) onBackKey()
                return true
            }
        }
        val digit = when {
            k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9 -> k - KeyEvent.KEYCODE_0
            k >= KeyEvent.KEYCODE_NUMPAD_0 && k <= KeyEvent.KEYCODE_NUMPAD_9 -> k - KeyEvent.KEYCODE_NUMPAD_0
            else -> -1
        }
        if (digit >= 0) {
            if (rep == 0) pushDigit(digit)
            return true
        }
        if (!panelOpen && !compact) {
            when (k) {
                KeyEvent.KEYCODE_DPAD_UP -> {
                    step(1, rep)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    step(-1, rep)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (rep == 0) togglePanel(Panel.CHANNELS)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (rep == 0) togglePanel(Panel.EPG)
                    return true
                }
            }
        }
        // მიუბმელი ღილაკი: ეკრანზე ვაჩვენებთ მის კოდს (პულტის ახალი ღილაკის მისაბმელად)
        if (rep == 0 && k !in IGNORED_KEYS && !KeyEvent.isModifierKey(k)) {
            hud("ღილაკი: " + KeyEvent.keyCodeToString(k).removePrefix("KEYCODE_") + " ($k)")
        }
        return false
    }

    private fun openFavorites() {
        if (compact) {
            selectGroup(G_FAV)
            return
        }
        selectGroup(G_FAV)
        showPanel(Panel.CHANNELS)
    }

    private fun openSearch() {
        if (compact) {
            b.search.requestFocus()
            return
        }
        showPanel(Panel.CHANNELS)
        b.search.requestFocus()
    }

    private fun seek(ms: Long) {
        val ok = engine?.seekBy(ms) ?: false
        if (!ok) hud("ამ არხზე გადახვევა შეუძლებელია (პირდაპირი ეთერი)")
    }

    private fun onBackKey() {
        if (b.search.hasFocus()) {
            b.search.clearFocus()
            return
        }
        if (!compact && panel != Panel.NONE) {
            showPanel(Panel.NONE)
            return
        }
        if (!isTv && !compact) {
            phoneFullscreen = false
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastBack < 2000L) {
            finish()
        } else {
            lastBack = now
            hud("გასასვლელად კიდევ ერთხელ დააჭირეთ")
        }
    }

    private fun logout() {
        Session.clear(this)
        ChannelHolder.clear()
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
