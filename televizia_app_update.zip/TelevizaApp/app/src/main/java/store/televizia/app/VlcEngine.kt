package store.televizia.app

import android.content.Context
import android.net.Uri
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

enum class PlayState { LOADING, PLAYING, ERROR, ENDED }

/** VLC ფლეიერი: ფორმატს (TS / HLS / MP4 / RTMP...) შიგთავსით ამოიცნობს, ბმულის დაბოლოებას არ უყურებს */
class VlcEngine(
    ctx: Context,
    layout: VLCVideoLayout,
    private val onState: (PlayState, Int) -> Unit
) {
    private val libVlc: LibVLC
    private val player: MediaPlayer
    private var released = false

    private val scales = arrayOf(
        MediaPlayer.ScaleType.SURFACE_BEST_FIT,
        MediaPlayer.ScaleType.SURFACE_FIT_SCREEN,
        MediaPlayer.ScaleType.SURFACE_FILL,
        MediaPlayer.ScaleType.SURFACE_16_9,
        MediaPlayer.ScaleType.SURFACE_4_3
    )
    private val scaleNames = arrayOf("ავტომატური", "ეკრანზე მორგება", "გაჭიმვა", "16:9", "4:3")
    private var scaleIdx = 0

    init {
        val opts = ArrayList<String>()
        opts.add("--http-reconnect")
        opts.add("--network-caching=2000")
        opts.add("--live-caching=2000")
        opts.add("--clock-jitter=0")
        opts.add("--clock-synchro=0")
        libVlc = LibVLC(ctx.applicationContext, opts)
        player = MediaPlayer(libVlc)
        player.attachViews(layout, null, false, false)
        player.setVideoScale(scales[0])
        player.setEventListener(object : MediaPlayer.EventListener {
            override fun onEvent(event: MediaPlayer.Event) {
                when (event.type) {
                    MediaPlayer.Event.Opening -> onState(PlayState.LOADING, 0)
                    MediaPlayer.Event.Buffering -> {
                        val pct = event.buffering.toInt()
                        if (pct >= 100) onState(PlayState.PLAYING, 100) else onState(PlayState.LOADING, pct)
                    }
                    MediaPlayer.Event.Playing -> onState(PlayState.PLAYING, 100)
                    MediaPlayer.Event.EncounteredError -> onState(PlayState.ERROR, 0)
                    MediaPlayer.Event.EndReached -> onState(PlayState.ENDED, 0)
                }
            }
        })
    }

    /** hw=true — აპარატული დეკოდერი; false — პროგრამული (სარეზერვო, ზოგ არხს ის უკეთ უმკლავდება) */
    fun play(url: String, hw: Boolean = true) {
        if (released) return
        onState(PlayState.LOADING, 0)
        val media = Media(libVlc, Uri.parse(url.trim()))
        media.setHWDecoderEnabled(hw, false)
        media.addOption(":network-caching=2000")
        media.addOption(":http-user-agent=VLC/3.0.18 LibVLC/3.0.18")
        media.addOption(":http-reconnect")
        player.setMedia(media)
        media.release()
        player.play()
    }

    fun togglePause() {
        if (released) return
        if (player.isPlaying) player.pause() else player.play()
    }

    /** true — გადახვევა შესაძლებელია (არქივი/ფილმი); ლაივ არხზე ჩვეულებრივ false */
    fun seekBy(ms: Long): Boolean {
        if (released || !player.isSeekable) return false
        val t = player.getTime() + ms
        player.setTime(if (t < 0L) 0L else t)
        return true
    }

    fun cycleAudio(): String {
        if (released) return ""
        val tracks = player.getAudioTracks() ?: return "ხმის ტრეკი არ არის"
        if (tracks.size < 2) return "სხვა ხმის ტრეკი არ არის"
        val cur = player.getAudioTrack()
        var idx = -1
        for (i in tracks.indices) if (tracks[i].id == cur) idx = i
        val next = tracks[(idx + 1) % tracks.size]
        player.setAudioTrack(next.id)
        return next.name ?: "ხმა"
    }

    fun cycleSubtitle(): String {
        if (released) return ""
        val tracks = player.getSpuTracks() ?: return "სუბტიტრი არ არის"
        if (tracks.size < 2) return "სუბტიტრი არ არის"
        val cur = player.getSpuTrack()
        var idx = -1
        for (i in tracks.indices) if (tracks[i].id == cur) idx = i
        val next = tracks[(idx + 1) % tracks.size]
        player.setSpuTrack(next.id)
        return next.name ?: "სუბტიტრი"
    }

    fun cycleScale(): String {
        if (released) return ""
        scaleIdx = (scaleIdx + 1) % scales.size
        player.setVideoScale(scales[scaleIdx])
        return scaleNames[scaleIdx]
    }

    fun release() {
        if (released) return
        released = true
        try { player.setEventListener(null) } catch (e: Exception) { }
        try { player.stop() } catch (e: Exception) { }
        try { player.detachViews() } catch (e: Exception) { }
        val p = player
        val l = libVlc
        Thread {
            try { p.release() } catch (e: Exception) { }
            try { l.release() } catch (e: Exception) { }
        }.start()
    }
}
