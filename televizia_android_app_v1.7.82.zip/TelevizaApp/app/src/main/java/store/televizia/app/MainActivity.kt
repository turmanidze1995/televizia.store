package store.televizia.app

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.KeyEvent
import android.graphics.Color
import android.view.View
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.media3.common.Player
import androidx.media3.ui.AspectRatioFrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import store.televizia.app.databinding.ActivityMainBinding

class MainActivity : BaseActivity() {
    companion object {
        const val ALL = Lang.ALL
    }
    private var autoPending = false
    private var gateDone = false

    private lateinit var b: ActivityMainBinding
    private val h = Handler(Looper.getMainLooper())
    private var clockR: Runnable? = null
    private var tickCount = 0
    private var groups: List<String> = emptyList()
    private var group = ALL
    private var current: Channel? = null
    private var started = false
    private var goingFullscreen = false
    private var prevChannel: Channel? = null
    private var offered = false

    // TV: სრული ეკრანი იმავე ეკრანზე (ვიდეოს ზედაპირი არსად გადადის -> გაყინვა არ არის)
    private var fs = false
    private var fsAt = 0L
    private val hideFsInfo = Runnable { b.fsBar?.visibility = View.GONE }   // საათი სრულ ეკრანზე მუდმივად რჩება
    private var loadAnim: android.animation.ValueAnimator? = null
    private var loadingNow = false
    private val autoFit = object : Player.Listener {
        override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
            applyAutoFit(videoSize.width, videoSize.height, videoSize.pixelWidthHeightRatio)
        }
    }

    private fun applyAutoFit(w: Int, hgt: Int, par: Float) {
        if (w <= 0 || hgt <= 0 || !::b.isInitialized) return
        val video = w * par / hgt
        if (video < 1.70f) {   // ვიწრო ნაკადი (4:3, 5:4) -> ეკრანის (სრულ ეკრანზე) ან 16:9 კადრის ფორმაზე იჭიმება
            val dm0 = resources.displayMetrics
            val scr = maxOf(dm0.widthPixels, dm0.heightPixels).toFloat() / minOf(dm0.widthPixels, dm0.heightPixels)
            b.preview.findViewById<AspectRatioFrameLayout>(resources.getIdentifier("exo_content_frame", "id", packageName))
                ?.setAspectRatio(if (fs || overlayTv) scr else 16f / 9f)
        }
        if (fs || overlayTv) {
            val dm = resources.displayMetrics
            val screen = dm.widthPixels.toFloat() / dm.heightPixels
            b.preview.resizeMode = if (Math.abs(video - screen) / screen < 0.12f) AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            else AspectRatioFrameLayout.RESIZE_MODE_FIT
        } else b.preview.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
    }

    private fun refit() {
        StreamHub.peek()?.player?.videoSize?.let { applyAutoFit(it.width, it.height, it.pixelWidthHeightRatio) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // TV: ვიდეო მუდამ მთელ ეკრანზეა, არხების სია და ტელეპროგრამა - მის ზემოდან (ნახევრად გამჭვირვალე პანელები)
    private var overlayTv = false
    private var epgOpen = false

    // ---------- TV: გადახვევის რეჟიმი (YouTube-ის მსგავსი ზოლი, ←/→ OK-ს გარშემო) ----------
    /** ჩართულია, როცა ტელეპროგრამიდან არქივის გადაცემა ჩავრთეთ; ←/→ მაშინ არხს კი არა, დროს ცვლის */
    private var seekMode = false
    private var seekOv: SeekOverlay? = null
    private var scrubTarget = -1L          // რეალური დრო (UTC, მწ), -1 = ახლა არ ვახვევთ
    private var scrubStart = 0L
    private var scrubEnd = 1L
    private var scrubTitle = ""
    private var scrubStreak = 0
    private var lastScrubAt = 0L
    private val applyScrub = Runnable { commitScrub() }
    private val hideSeekBar = Runnable { seekOv?.visibility = View.GONE }
    private val seekTick = object : Runnable {
        override fun run() {
            if (seekMode && seekOv?.visibility == View.VISIBLE && scrubTarget < 0) { refreshSeekBar(); h.postDelayed(this, 500) }
        }
    }

    private fun startSeekMode() {
        seekMode = true
        scrubTarget = -1L
        flash("◀ ▶  გადახვევა  ·  BACK — გამორთვა")
        showSeekBar()
        h.removeCallbacks(hideSeekBar); h.postDelayed(hideSeekBar, 5000)
    }

    /** გადახვევის რეჟიმის გამორთვა: ←/→ ისევ ჩვეულებრივად მუშაობს (არხის გადართვა) */
    private fun endSeekMode() {
        seekMode = false
        scrubTarget = -1L
        scrubStreak = 0
        h.removeCallbacks(applyScrub)
        h.removeCallbacks(hideSeekBar)
        h.removeCallbacks(seekTick)
        seekOv?.visibility = View.GONE
    }

    /** პროგრამის ფანჯარა, რომელსაც ზოლი ასახავს: გადაცემის დასაწყისი → დასასრული (ან ახლა) */
    private fun seekRange(wall: Long): Triple<Long, Long, String> = Timeshift.range(current, wall)

    private fun refreshSeekBar() {
        val ov = seekOv ?: return
        val scrubbing = scrubTarget >= 0
        val wall = if (scrubbing) scrubTarget else Timeshift.wallMs(StreamHub.peek())
        val (s, e0, title) = if (scrubbing) Triple(scrubStart, scrubEnd, scrubTitle) else seekRange(wall)
        val e = if (e0 <= s) s + 1 else e0
        val el = (wall - s).coerceIn(0L, e - s)
        ov.set(
            fraction = el.toFloat() / (e - s).toFloat(),
            scrubbing = scrubbing,
            bubble = Ui.mmss(el),
            left = (if (title.isNotBlank()) Ui.timeOf(s) + "  " + title else Ui.timeOf(s)),
            right = Ui.mmss(el) + " / " + Ui.mmss(e - s)
        )
    }

    private fun showSeekBar() {
        val ov = seekOv ?: return
        ov.visibility = View.VISIBLE
        refreshSeekBar()
        h.removeCallbacks(seekTick); h.postDelayed(seekTick, 500)
    }

    /** ←/→ გადახვევის რეჟიმში: ერთი დაჭერა ±10 წმ, გაჭერისას/სწრაფად — 30 წმ, შემდეგ 1 წთ (როგორც YouTube-ზე) */
    private fun scrubStep(dir: Int) {
        val t = android.os.SystemClock.uptimeMillis()
        if (t - lastScrubAt > 700) scrubStreak = 0
        lastScrubAt = t
        scrubStreak++
        if (scrubTarget < 0) {
            val w = Timeshift.wallMs(StreamHub.peek())
            val (s, e, title) = seekRange(w)
            scrubStart = s; scrubEnd = if (e <= s) s + 1 else e; scrubTitle = title
            scrubTarget = w.coerceIn(scrubStart, scrubEnd)
        }
        val step = when { scrubStreak < 4 -> 10_000L; scrubStreak < 10 -> 30_000L; else -> 60_000L }
        scrubTarget = (scrubTarget + dir * step).coerceIn(scrubStart, scrubEnd)
        h.removeCallbacks(hideSeekBar)
        showSeekBar()
        h.removeCallbacks(applyScrub)
        h.postDelayed(applyScrub, 900)   // ღილაკი რომ გავუშვით, ამ ადგილას გადადის (OK — მაშინვე)
    }

    private fun commitScrub() {
        h.removeCallbacks(applyScrub)
        val t = scrubTarget
        scrubTarget = -1L
        scrubStreak = 0
        if (t < 0) return
        if (!Timeshift.seekToWall(this, t)) flash(getString(R.string.seek_unavailable))
        else if (t >= System.currentTimeMillis() - 8_000) { flash("● LIVE"); endSeekMode(); return }
        showSeekBar()
        h.removeCallbacks(hideSeekBar); h.postDelayed(hideSeekBar, 3000)
    }

    /** BACK/EXIT გადახვევის რეჟიმში: ჯერ მოლოდინში მყოფი გადახვევა უქმდება, მერე რეჟიმი ითიშება */
    private fun seekBack() {
        if (scrubTarget >= 0) {
            scrubTarget = -1L; scrubStreak = 0
            h.removeCallbacks(applyScrub)
            refreshSeekBar()
            h.removeCallbacks(hideSeekBar); h.postDelayed(hideSeekBar, 1500)
        } else {
            endSeekMode()
            flash("გადახვევა გამორთულია")
        }
    }

    private fun setupTvOverlay() {
        val root = b.rootLand ?: run { setContentView(b.root); return }
        val left = b.leftCol ?: run { setContentView(b.root); return }
        val right = b.rightCol ?: run { setContentView(b.root); return }
        val pb = b.previewBox
        val frame = FrameLayout(this)
        frame.setBackgroundColor(Color.BLACK)
        (pb.parent as? ViewGroup)?.removeView(pb)
        root.removeAllViews()
        frame.addView(pb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        seekOv = SeekOverlay(this).also {
            it.visibility = View.GONE
            pb.addView(it, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190), Gravity.BOTTOM))
        }
        val w = resources.displayMetrics.widthPixels
        val pw = minOf(dp(480), (w * 0.42f).toInt())
        left.layoutParams = FrameLayout.LayoutParams(pw, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START)
        left.setBackgroundColor(0xE6101018.toInt())
        left.setPadding(dp(16), dp(16), dp(10), dp(16))
        right.layoutParams = FrameLayout.LayoutParams(pw, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START).apply { leftMargin = pw }
        right.setBackgroundColor(0xE0101018.toInt())
        right.setPadding(dp(14), dp(16), dp(16), dp(16))
        frame.addView(left)
        frame.addView(right)
        right.visibility = View.GONE
        setContentView(frame)
        overlayTv = true
    }

    private fun overlayEnterFs() {
        fs = true
        epgOpen = false
        fsAt = android.os.SystemClock.uptimeMillis()
        b.leftCol?.visibility = View.GONE
        b.rightCol?.visibility = View.GONE
        b.previewError.textSize = 20f
        val dm = resources.displayMetrics
        b.loadingLogo?.let { it.layoutParams = it.layoutParams.apply { width = minOf((520 * dm.density).toInt(), (dm.widthPixels * 0.55f).toInt()) } }
        refit()
        showFsInfo()
        b.fsClock?.visibility = View.VISIBLE
        applyLoadingUi()
    }

    private fun overlayExitFs() {
        endSeekMode()
        fs = false
        epgOpen = false
        digits.cancel()
        h.removeCallbacks(hideFsInfo)
        b.fsBar?.visibility = View.GONE
        b.fsNumBox?.visibility = View.GONE
        b.leftCol?.visibility = View.VISIBLE
        b.rightCol?.visibility = View.GONE
        refit()
        applyLoadingUi()
        updateEpg(current)
        focusCurrent(8)
    }

    private fun openEpgPanel() {
        if (!overlayTv) return
        epgOpen = true
        b.rightCol?.visibility = View.VISIBLE
    }

    private fun closeEpgPanel() {
        if (!overlayTv || !epgOpen) return
        epgOpen = false
        b.rightCol?.visibility = View.GONE
    }

    private fun enterFs() {
        if (overlayTv) { if (!fs && current != null) overlayEnterFs(); return }
        if (fs || current == null || b.leftCol == null) return
        fs = true
        fsAt = android.os.SystemClock.uptimeMillis()
        b.rootLand?.setPadding(0, 0, 0, 0)
        b.rootLand?.setBackgroundColor(Color.BLACK)
        b.leftCol?.visibility = View.GONE
        b.rightCol?.visibility = View.GONE
        (b.midCol?.layoutParams as? LinearLayout.LayoutParams)?.let { it.marginStart = 0; b.midCol?.layoutParams = it }
        b.previewError.textSize = 20f
        val dm = resources.displayMetrics
        b.loadingLogo?.let { it.layoutParams = it.layoutParams.apply { width = minOf((520 * dm.density).toInt(), (dm.widthPixels * 0.55f).toInt()) } }
        refit()
        showFsInfo()
        b.fsClock?.visibility = View.VISIBLE
        applyLoadingUi()
    }

    private fun exitFs() {
        if (!fs) return
        if (overlayTv) { overlayExitFs(); return }
        fs = false
        digits.cancel()
        h.removeCallbacks(hideFsInfo)
        b.fsBar?.visibility = View.GONE
        b.fsClock?.visibility = View.GONE
        b.fsNumBox?.visibility = View.GONE
        b.rootLand?.setPadding(dp(16), dp(16), dp(16), dp(16))
        b.rootLand?.setBackgroundColor(Color.parseColor("#0A0C14"))
        b.leftCol?.visibility = View.VISIBLE
        b.rightCol?.visibility = View.VISIBLE
        (b.midCol?.layoutParams as? LinearLayout.LayoutParams)?.let { it.marginStart = dp(12); b.midCol?.layoutParams = it }
        b.previewError.textSize = 14f
        refit()
        applyLoadingUi()
        updateEpg(current)
        focusCurrent(8)
    }

    private fun showFsInfo() {
        val ch = current ?: return
        val idx = ChannelHolder.list.indexOfFirst { it.url == ch.url }
        b.fsNum?.text = if (idx >= 0) (idx + 1).toString() else ""
        b.fsName?.text = ch.name
        b.fsLogo?.let { ImageLoader.show(ChannelHolder.logoOf(ch), it, ch.name) }
        val now = Epg.now(ch)
        val next = Epg.next(ch)
        b.fsNow?.text = when {
            now == null -> ""
            next == null -> "${Ui.timeOf(now.start)}  ${now.title}"
            else -> "${Ui.timeOf(now.start)}  ${now.title}  →  ${Ui.timeOf(next.start)}  ${next.title}"
        }
        val hasEpg = now != null
        b.fsNow?.visibility = if (hasEpg) View.VISIBLE else View.GONE
        b.fsProgress?.visibility = if (hasEpg) View.VISIBLE else View.GONE
        b.fsProgress?.progress = Ui.progressOf(now)
        b.fsClock?.text = b.clock.text
        b.fsBar?.visibility = View.VISIBLE
        b.fsClock?.visibility = View.VISIBLE
        h.removeCallbacks(hideFsInfo)
        h.postDelayed(hideFsInfo, 6000)
    }

    /** TELEVIZIA.STORE ლოგო სრულ ეკრანზე ჩატვირთვისას (ფერები იცვლება), სიაში - პატარა ინდიკატორი */
    private fun applyLoadingUi() {
        val logo = b.loadingLogo
        if (fs && loadingNow && logo != null) {
            b.previewLoading.visibility = View.GONE
            logo.visibility = View.VISIBLE
            if (loadAnim == null) {
                val cm = android.graphics.ColorMatrix()
                loadAnim = android.animation.ValueAnimator.ofFloat(0f, 360f).apply {
                    duration = 1800
                    repeatCount = android.animation.ValueAnimator.INFINITE
                    addUpdateListener { va ->
                        val d = va.animatedValue as Float
                        cm.setRotate(2, d * 0.3f)
                        logo.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
                        logo.alpha = 0.55f + 0.45f * Math.abs(Math.sin(Math.toRadians(d.toDouble()))).toFloat()
                    }
                    start()
                }
            }
        } else {
            loadAnim?.cancel(); loadAnim = null
            logo?.colorFilter = null
            logo?.alpha = 1f
            logo?.visibility = View.GONE
            b.previewLoading.visibility = if (loadingNow) View.VISIBLE else View.GONE
        }
    }

    private fun fsStep(delta: Int) { stepChannel(delta); showFsInfo() }

    /** სრულ ეკრანზე კატეგორიის შეცვლა (მორგებული ღილაკით): ახალი კატეგორიის პირველ არხზე გადადის */
    private fun fsGroupStep(delta: Int) {
        stepGroup(delta)
        flash(Lang.group(group))
        val first = ChannelHolder.list.firstOrNull() ?: return
        ChannelHolder.markPos(0)
        play(first)
        b.channels.scrollToPosition(0)
        showFsInfo()
    }

    /** TV სრული ეკრანი: ↑/→ შემდეგი, ↓/← წინა არხი, OK/BACK → სია, ციფრები → ნომრით */
    // ---------- პულტი: 1.7.30-ის ფუნქციები სრულ ეკრანზე ----------
    private var toast: Toast? = null
    private fun flash(msg: String) {
        toast?.cancel()
        toast = Toast.makeText(this, msg, Toast.LENGTH_SHORT).also { it.show() }
    }
    private fun openGuide() {
        exitFs()
        h.postDelayed({ if (alive()) focusEpg(8) }, 350)
    }
    private fun zapOrSeek(next: Boolean, rep: Boolean) {
        val pl = StreamHub.peek()?.player
        // გადახვევა მხოლოდ პაუზაზე და მხოლოდ თუ ნაკადი გადახვევადია; სხვა შემთხვევაში (მაგ. QR არხი) ყოველთვის არხი იცვლება
        val paused = pl?.playWhenReady == false && (pl.isCurrentMediaItemSeekable || current?.let { Catchup.has(it) } == true)
        if (paused) seekBy(if (next) 10_000 else -10_000)
        else if (!rep) fsStep(if (next) 1 else -1)
    }
    private fun togglePlay() {
        StreamHub.peek()?.player?.let {
            it.playWhenReady = !it.playWhenReady
            flash(if (it.playWhenReady) "▶" else "⏸ " + getString(R.string.pause))
        }
    }
    private fun seekBy(ms: Long) {
        if (!Timeshift.seekBy(this, ms)) { flash(getString(R.string.seek_unavailable)); return }
        flash(getString(if (ms < 0) R.string.seek_back else R.string.seek_fwd))
    }
    private fun trackName(g: androidx.media3.common.Tracks.Group): String {
        val f = g.getTrackFormat(0)
        val lang = f.language?.takeIf { it.isNotBlank() && it != "und" }
            ?.let { java.util.Locale.forLanguageTag(it).getDisplayLanguage(java.util.Locale.forLanguageTag(Lang.current())) }
            ?.takeIf { it.isNotBlank() }
        return f.label?.takeIf { it.isNotBlank() } ?: lang ?: getString(R.string.track_default)
    }
    private fun cycleSubtitles() {
        val p = StreamHub.peek()?.player ?: return
        val groups = p.currentTracks.groups.filter { it.type == androidx.media3.common.C.TRACK_TYPE_TEXT && it.isSupported }
        if (groups.isEmpty()) { flash(getString(R.string.subs_none)); return }
        val next = groups.indexOfFirst { it.isSelected } + 1
        val params = p.trackSelectionParameters.buildUpon()
        if (next >= groups.size) {
            params.setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
            flash(getString(R.string.subs_off))
        } else {
            params.setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
                .setOverrideForType(androidx.media3.common.TrackSelectionOverride(groups[next].mediaTrackGroup, 0))
            flash(getString(R.string.subs_fmt, trackName(groups[next])))
        }
        p.trackSelectionParameters = params.build()
    }
    private fun cycleAudio() {
        val p = StreamHub.peek()?.player ?: return
        val groups = p.currentTracks.groups.filter { it.type == androidx.media3.common.C.TRACK_TYPE_AUDIO && it.isSupported }
        if (groups.size < 2) { flash(getString(R.string.audio_none)); return }
        val next = (groups.indexOfFirst { it.isSelected }.coerceAtLeast(0) + 1) % groups.size
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setOverrideForType(androidx.media3.common.TrackSelectionOverride(groups[next].mediaTrackGroup, 0)).build()
        flash(getString(R.string.audio_fmt, trackName(groups[next])))
    }

    private fun fsKey(event: KeyEvent): Boolean {
        val k = event.keyCode
        if (k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN || k == KeyEvent.KEYCODE_VOLUME_MUTE) return false
        val handledUp = KeyMap.isDpad(k) || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER ||
            k == KeyEvent.KEYCODE_NUMPAD_ENTER || k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ESCAPE
        if (event.action != KeyEvent.ACTION_DOWN) return handledUp
        val rep = event.repeatCount > 0
        // გადახვევის რეჟიმი: ←/→ (და ◀◀ ▶▶) ცვლის დროს, OK ადასტურებს, BACK/EXIT ითიშება
        if (seekMode) {
            when (k) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> { scrubStep(-1); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { scrubStep(1); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER ->
                    if (scrubTarget >= 0) { commitScrub(); return true }
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> { seekBack(); return true }
            }
        }
        if (!KeyMap.isDpad(k)) {
            when (KeyMap.get(this, k)) {
                KeyMap.Act.NEXT_CH -> { if (!rep) fsStep(1); return true }
                KeyMap.Act.PREV_CH -> { if (!rep) fsStep(-1); return true }
                KeyMap.Act.LAST -> { if (!rep) prevChannel?.let { play(it); showFsInfo() }; return true }
                KeyMap.Act.INFO -> { if (!rep) fsInfoKey(); return true }
                KeyMap.Act.PANEL -> { if (!rep) exitFs(); return true }
                KeyMap.Act.GUIDE -> { if (!rep) openGuide(); return true }
                KeyMap.Act.SUBS -> { if (!rep) cycleSubtitles(); return true }
                KeyMap.Act.AUDIO -> { if (!rep) cycleAudio(); return true }
                KeyMap.Act.ASPECT -> return true
                KeyMap.Act.PAUSE -> { if (!rep) togglePlay(); return true }
                KeyMap.Act.SEEK_BACK -> { if (seekMode) scrubStep(-1) else seekBy(-10_000); return true }
                KeyMap.Act.SEEK_FWD -> { if (seekMode) scrubStep(1) else seekBy(10_000); return true }
                KeyMap.Act.FAV -> { if (!rep) current?.let { toggleFav(it) }; return true }
                KeyMap.Act.HIDE -> { if (!rep) current?.let { confirmHide(it) }; return true }
                KeyMap.Act.PREV_GROUP -> { if (!rep) fsGroupStep(-1); return true }
                KeyMap.Act.NEXT_GROUP -> { if (!rep) fsGroupStep(1); return true }
                KeyMap.Act.GROUP_MENU -> { if (!rep) { exitFs(); categoryMenu() }; return true }
                else -> {}
            }
        }
        when (k) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> { if (!rep) fsStep(1) }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { if (!rep) fsStep(-1) }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_RIGHT -> zapOrSeek(true, rep)
            KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT -> zapOrSeek(false, rep)
            KeyEvent.KEYCODE_MEDIA_STOP -> exitFs()
            KeyEvent.KEYCODE_MUTE -> StreamHub.peek()?.player?.let { it.volume = if (it.volume == 0f) 1f else 0f }
            KeyEvent.KEYCODE_PROG_BLUE -> exitFs()
            KeyEvent.KEYCODE_CAPTIONS -> cycleSubtitles()
            KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK -> cycleAudio()
            KeyEvent.KEYCODE_TV_ZOOM_MODE, KeyEvent.KEYCODE_ZOOM_IN -> {}
            KeyEvent.KEYCODE_LAST_CHANNEL -> prevChannel?.let { play(it); showFsInfo() }
            KeyEvent.KEYCODE_DEL -> if (digits.active) digits.cancel() else prevChannel?.let { play(it); showFsInfo() }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> togglePlay()
            KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_PROG_YELLOW -> if (!rep) fsInfoKey()
            KeyEvent.KEYCODE_BOOKMARK -> if (!rep) current?.let { toggleFav(it) }
            KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_BACK -> if (digits.active) digits.cancel() else finishAffinity()   // EXIT/BACK სრულ ეკრანზე: გასვლა
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (digits.active) digits.commit()
                else if (!rep && android.os.SystemClock.uptimeMillis() - fsAt > 700) { swallowKey = k; swallowAt = android.os.SystemClock.uptimeMillis(); exitFs() }
            }
            KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_PROG_GREEN, KeyEvent.KEYCODE_TV_DATA_SERVICE -> if (!rep) openGuide()
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_PROG_RED, KeyEvent.KEYCODE_TV_CONTENTS_MENU,
            KeyEvent.KEYCODE_SEARCH, KeyEvent.KEYCODE_SETTINGS -> if (!rep) exitFs()
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> digits.digit(k - KeyEvent.KEYCODE_0)
            in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> digits.digit(k - KeyEvent.KEYCODE_NUMPAD_0)
            else -> return false
        }
        return true
    }

    private val isTv: Boolean get() = Device.tv(this)
    private val landscape: Boolean by lazy {
        resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    /** TV: OK = არხი იწყება და იხსნება სრულ ეკრანზე. ტელეფონი: პირველი შეხება = გადართვა, ხელახლა იმავეზე = სრული ეკრანი */
    private val channelAdapter = ChannelAdapter { ch, p ->
        ChannelHolder.markPos(p)
        if (isTv) {
            play(ch)
            openFullscreen()
        } else if (ch.url == current?.url) {
            openFullscreen()
        } else {
            play(ch)
        }
    }
    private lateinit var groupAdapter: GroupAdapter
    private val programAdapter = ProgramAdapter(
        onClick = { onProgramClick(it) },
        canPlay = { p -> current?.let { Catchup.canPlay(it, p) } == true }
    )

    private val digits = DigitEntry(
        size = { ChannelHolder.list.size },
        nameAt = { ChannelHolder.list.getOrNull(it)?.name },
        onUpdate = { d, name, valid ->
            if (fs) {
                b.fsNumBox?.visibility = View.VISIBLE
                b.fsNumDigits?.text = d
                b.fsNumDigits?.setTextColor(if (valid) 0xFF00D9C0.toInt() else 0xFFFF5C72.toInt())
                b.fsNumName?.text = when {
                    name != null -> name
                    valid -> ""
                    else -> getString(R.string.no_such_channel)
                }
                // არხის ლოგო სახელის გვერდით — ციფრის აკრეფისთანავე
                val chn = if (valid) d.toIntOrNull()?.let { ChannelHolder.list.getOrNull(it - 1) } else null
                b.fsNumLogo?.let { lg ->
                    if (chn != null) { lg.visibility = View.VISIBLE; ImageLoader.show(ChannelHolder.logoOf(chn), lg, chn.name) }
                    else lg.visibility = View.GONE
                }
            }
            b.status.text = when {
                name != null -> "$d · $name"
                valid -> d
                else -> "$d · ${getString(R.string.no_such_channel)}"
            }
        },
        onCommit = { pos ->
            ChannelHolder.list.getOrNull(pos)?.let {
                ChannelHolder.markPos(pos)
                play(it)
                b.channels.scrollToPosition(pos)
                if (fs) showFsInfo()
            }
        },
        onClose = { b.status.text = statusText(); b.fsNumBox?.visibility = View.GONE }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AdGate.refresh(this)
        if (Session.token(this) == null) {
            goLogin()
            return
        }
        b = ActivityMainBinding.inflate(layoutInflater)
        if (isTv && b.leftCol != null && b.rightCol != null) setupTvOverlay() else setContentView(b.root)
        QrOverlay.attach(b.preview)   // პატარა QR (საიტი) ვიდეოს კუთხეში; იმართება სერვერიდან
        sizePreview()

        if (savedInstanceState == null) autoPending = true   // მხოლოდ TV: გახსნისას არხი სრულ ეკრანზე
        applyDeviceButtons()
        showPlan(Session.plan(this))
        refreshPlan()
        b.channels.layoutManager = LinearLayoutManager(this)
        b.channels.setHasFixedSize(true)
        b.channels.setItemViewCacheSize(10)
        b.channels.adapter = channelAdapter

        groupAdapter = GroupAdapter(landscape) { g -> selectGroup(g) }
        b.groups.layoutManager = if (landscape) LinearLayoutManager(this)
        else LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.groups.adapter = groupAdapter

        b.epgList.layoutManager = LinearLayoutManager(this)
        b.epgList.adapter = programAdapter

        // ტელეფონი ვერტიკალურად: ინფო ბლოკზე შეხებით იხსნება/იკეცება მთელი ტელეპროგრამა
        if (!landscape && !isTv) {
            applyEpgPanel()
            // შეხება = ტელეპროგრამის გახსნა/დაკეცვა; გადასმა (ზევით/ქვევით/გვერდზე) = შემდეგი/წინა არხი — ინფო ბლოკზეც
            b.infoBlock.setOnTouchListener(SwipeTouch(this, onTap = {
                if (programAdapter.itemCount > 0) { epgExpanded = !epgExpanded; applyEpgPanel() }
            }, onSwipe = { next -> stepChannel(if (next) 1 else -1) }))
            // არხების სიაზეც: გვერდზე (მარცხნივ/მარჯვნივ) გადასმა = შემდეგი/წინა არხი; ზევით-ქვევით კვლავ სიას ასქროლებს
            attachHorizontalZap(b.channels)
            attachHorizontalZap(b.epgList)
        }

        channelAdapter.onLong = { channelMenu(it) }
        b.groupPrev?.setOnClickListener { stepGroup(-1) }
        b.groupNext?.setOnClickListener { stepGroup(1) }
        b.btnKeys?.setOnClickListener { startActivity(Intent(this, KeysActivity::class.java)) }
        b.btnLang.visibility = View.GONE   // ენის არჩევა მხოლოდ შესვლის გვერდზეა

        b.btnFullscreen.setOnClickListener { openFullscreen() }
        // ვიდეოზე: შეხება = სრული ეკრანი, გადასმა = შემდეგი/წინა არხი
        b.preview.setOnTouchListener(SwipeTouch(this, onTap = { openFullscreen() }, onSwipe = { next ->
            stepChannel(if (next) 1 else -1)
        }))
        b.btnLogout.setOnClickListener {
            StreamHub.release()
            Session.clear(this)
            Store.clear(this)
            ChannelHolder.reset()
            Epg.attach(emptyList())
            goLogin()
        }
        if (ChannelHolder.all.isEmpty()) ChannelHolder.group = Store.lastGroup(this) ?: ALL
        loadChannels()
        // განახლების/შეტყობინების ფანჯარა სრულ ეკრანს არ უნდა დაეფაროს: ჯერ ველოდებით სერვერის პასუხს (მაქს. 3 წმ)
        Gate.check(this, { shown ->
            gateDone = true
            if (shown) autoPending = false else maybeAutoOpen()
        }) { }
        h.postDelayed({ gateDone = true; maybeAutoOpen() }, 3000)
    }

    private fun showPlan(text: String) {
        b.planInfo.text = text
        b.planInfo.visibility = if (text.isBlank()) View.GONE else View.VISIBLE
    }

    private fun refreshPlan() {
        val token = Session.token(this) ?: return
        val app = applicationContext
        Thread {
            val t = Api.planText(token)
            if (t != null) {
                Session.setPlan(app, t)
                runOnUiThread { if (alive()) showPlan(t) }
            }
        }.start()
    }

    /** TV-ზე "პულტი / სრული ეკრანი" არ ჩანს — მხოლოდ მობილურზე */
    private fun applyDeviceButtons() {
        val v = if (isTv) View.GONE else View.VISIBLE
        b.btnLogout.visibility = View.VISIBLE   // TV-ზეც: გასვლა მთავარ ეკრანზე (OK-ით)
        b.btnKeys?.visibility = v
        b.btnFullscreen.visibility = v
        if (isTv) {   // კატეგორიების პანელი მთლიანად ფოკუსირდება: ↑ არხების სიიდან, ←/→ ცვლის კატეგორიას, OK — კატეგორიების სია
            b.groupPrev?.isFocusable = false
            b.groupNext?.isFocusable = false
            b.groupHeader?.let { hd ->
                hd.isFocusable = true
                hd.isClickable = true
                hd.setOnClickListener { categoryMenu() }
            }
        }
    }

    /** TV: ფოკუსი "გასვლა" ღილაკზე */
    private fun focusLogout() {
        if (b.btnLogout.visibility == View.VISIBLE) b.btnLogout.requestFocus()
    }

    /** ბოლო არხი სრულ ეკრანზე გაიხსნას აპლიკაციის ჩართვისას */
    private fun maybeAutoOpen() {
        if (autoPending && gateDone && started && current != null && alive()) {
            if (!isTv) { autoPending = false; return }
            autoPending = false
            openFullscreen()
        }
    }

    /** TV: ფოკუსი მიმდინარე არხზე (და არა კატეგორიის ისრებზე) */
    private fun focusCurrent(retries: Int) {
        if (!isTv || !::b.isInitialized) return
        focusPosition(ChannelHolder.list.indexOfFirst { it.url == current?.url }, retries)
    }

    private var tvPendPos = -1
    private var tvPendAt = 0L

    /** ფოკუსის გადატანა არხზე t: ჯერ ვხატავთ (scrollToPosition), შემდეგ ფოკუსს ვაძლევთ; ყოველი ახალი დაჭერა წინას ანაცვლებს */
    private fun tvMoveTo(t: Int, retries: Int) {
        if (!::b.isInitialized) return
        b.channels.scrollToPosition(t)
        b.channels.post {
            if (!alive() || tvPendPos != t) return@post   // ამასობაში უფრო ახალი დაჭერა მოვიდა
            val v = b.channels.findViewHolderForAdapterPosition(t)?.itemView
            if (v != null) {
                v.requestFocus()
                if (v.hasFocus()) tvPendPos = -1
                else if (retries > 0) b.channels.postDelayed({ tvMoveTo(t, retries - 1) }, 20)
            } else if (retries > 0) b.channels.postDelayed({ tvMoveTo(t, retries - 1) }, 20)
            else tvPendPos = -1
        }
    }

    private fun focusPosition(pos: Int, retries: Int) {
        if (pos < 0 || !::b.isInitialized) return
        b.channels.scrollToPosition(pos)
        b.channels.postDelayed({
            if (!alive()) return@postDelayed
            val v = b.channels.findViewHolderForAdapterPosition(pos)?.itemView
            v?.requestFocus()
            // სიის ხელახლა აგებისას ფოკუსი ისრებზე გადადიოდა — ვამოწმებთ და საჭიროებისას ვიმეორებთ
            if ((v == null || !v.hasFocus()) && retries > 0) focusPosition(pos, retries - 1)
        }, 120)
    }

    /** TV: ფოკუსი ტელეპროგრამაზე (მიმდინარე გადაცემაზე) */
    private fun focusEpg(retries: Int) {
        if (!::b.isInitialized || (b.epgList.adapter?.itemCount ?: 0) == 0) return
        openEpgPanel()
        val idx = programAdapter.liveIndex().coerceAtLeast(0)
        b.epgList.scrollToPosition(idx)
        b.epgList.postDelayed({
            if (!alive()) return@postDelayed
            val v = b.epgList.findViewHolderForAdapterPosition(idx)?.itemView
            v?.requestFocus()
            if ((v == null || !v.hasFocus()) && retries > 0) focusEpg(retries - 1)
        }, 120)
    }

    /** TV: ფოკუსი კატეგორიების პანელზე (ყველა / ფავორიტები / ...) */
    private fun focusHeader() {
        b.groupHeader?.requestFocus()
    }

    /**
     * TV: წრიული ნავიგაცია: [კატეგორიების პანელი] → არხი 1 → ... → ბოლო არხი → გასვლა → [კატეგორიების პანელი].
     * პანელზე: ←/→ წინა/შემდეგი კატეგორია ან ფავორიტები, ↓ პირველი არხი, ↑ გასვლა/ბოლო არხი, OK — კატეგორიების სია.
     * არხებზე: → ტელეპროგრამა. true = დამუშავდა
     */
    private var tvZone = -1          // 0 = კატეგორიები, 1 = არხები, 2 = ტელეპროგრამა, 3 = გასვლა
    private var tvLastMoveAt = 0L
    private var epgPendPos = -1

    /** ტელეპროგრამის სიაში ფოკუსის გადატანა (იგივე პრინციპი, რაც არხებზე: ჯერ ვხატავთ, მერე ფოკუსს ვაძლევთ) */
    private fun tvMoveToEpg(t: Int, retries: Int) {
        if (!::b.isInitialized) return
        b.epgList.scrollToPosition(t)
        b.epgList.post {
            if (!alive() || epgPendPos != t) return@post
            val v = b.epgList.findViewHolderForAdapterPosition(t)?.itemView
            if (v != null) {
                v.requestFocus()
                if (v.hasFocus()) epgPendPos = -1
                else if (retries > 0) b.epgList.postDelayed({ tvMoveToEpg(t, retries - 1) }, 20)
            } else if (retries > 0) b.epgList.postDelayed({ tvMoveToEpg(t, retries - 1) }, 20)
            else epgPendPos = -1
        }
    }

    private fun tvListKey(k: Int, rc: Int = 0): Boolean {
        if (!isTv) return false
        val now = android.os.SystemClock.uptimeMillis()
        val f = currentFocus
        val attached = f != null && f.isAttachedToWindow
        // ფოკუსი დროებით \"დაკარგულია\" (ძველი ელემენტი გადახატვისას ამოვარდა, ახალი ჯერ არ არის დახატული):
        // ბოლო ზონაში ვრჩებით და სტანდარტულ ძებნას არ ვუშვებთ — სწორედ ის ახტუნებდა ფოკუსს პანელებს შორის
        val zone = when {
            f === b.groupHeader -> 0
            f === b.btnLogout -> 3
            attached && f!!.parent === b.channels -> 1
            attached && f!!.parent === b.epgList -> 2
            (f == null || !attached) && tvZone in 1..2 && now - tvLastMoveAt < 1500 -> tvZone
            else -> return false
        }
        tvZone = zone
        val n = ChannelHolder.list.size
        val hasLogout = b.btnLogout.visibility == View.VISIBLE
        val vertical = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN
        // ღილაკის გამეორება არაუმეტეს ~14 ნაბიჯისა წამში: ნელ TV-ზე დაგროვილი დაჭერები თავისით ჩქარა აღარ „გარბის“
        if (vertical && (zone == 1 || zone == 2) && rc > 0 && now - tvLastMoveAt < 70) return true

        when (zone) {
            0 -> {
                when (k) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> stepGroup(-1)
                    KeyEvent.KEYCODE_DPAD_RIGHT -> stepGroup(1)
                    KeyEvent.KEYCODE_DPAD_DOWN -> if (n > 0) focusPosition(0, 8) else if (hasLogout) focusLogout()
                    KeyEvent.KEYCODE_DPAD_UP -> if (hasLogout) focusLogout() else if (n > 0) focusPosition(n - 1, 8)
                    else -> return false
                }
                return true
            }
            3 -> {   // გასვლიდან ↑ — არხების სიის ბოლოში, ↓ — კატეგორიების პანელზე (წრე)
                if (k == KeyEvent.KEYCODE_DPAD_UP) { if (n > 0) focusPosition(n - 1, 8) else focusHeader(); return true }
                if (k == KeyEvent.KEYCODE_DPAD_DOWN) { focusHeader(); return true }
                return false
            }
            2 -> {   // ტელეპროგრამა: ↑/↓ პანელის შიგნით რჩება (არც არხებზე, არც კატეგორიებზე არ გადადის), ← არხებზე ბრუნდება
                val m = b.epgList.adapter?.itemCount ?: 0
                when (k) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> { epgPendPos = -1; closeEpgPanel(); tvZone = 1; focusCurrent(8); return true }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> return true
                    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                        if (m == 0) return true
                        val pos = if (attached) b.epgList.getChildAdapterPosition(f!!) else -1
                        val base = when {
                            epgPendPos in 0 until m && now - tvLastMoveAt < 500 -> epgPendPos
                            pos >= 0 -> pos
                            else -> programAdapter.liveIndex().coerceIn(0, m - 1)
                        }
                        val t = (if (k == KeyEvent.KEYCODE_DPAD_UP) base - 1 else base + 1).coerceIn(0, m - 1)
                        tvLastMoveAt = now
                        epgPendPos = t
                        tvMoveToEpg(t, 6)
                        return true
                    }
                }
                return false
            }
        }
        // zone == 1: არხები
        if (n == 0) return false
        val pos = if (attached) b.channels.getChildAdapterPosition(f!!) else -1
        when (k) {
            // ↑/↓ ვამუშავებთ თვითონ: ღილაკის გაჩერების გარეშე ჩქარ ჩამორბენაზე სტანდარტული ფოკუსის ძებნა ხტუნავდა (ახალი ელემენტი ჯერ არ იყო დახატული)
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                val base = when {
                    tvPendPos in 0 until n && now - tvPendAt < 500 -> tvPendPos
                    pos >= 0 -> pos
                    else -> ChannelHolder.list.indexOfFirst { it.url == current?.url }.coerceAtLeast(0)
                }
                val t = if (k == KeyEvent.KEYCODE_DPAD_UP) base - 1 else base + 1
                tvPendAt = now
                tvLastMoveAt = now
                if (t < 0) { tvPendPos = -1; tvZone = 0; focusHeader(); return true }
                if (t > n - 1) { tvPendPos = -1; if (hasLogout) { tvZone = 3; focusLogout() } else { tvZone = 0; focusHeader() }; return true }
                tvPendPos = t
                tvMoveTo(t, 6)
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> return true   // კატეგორიას პანელზე ←/→ ცვლის (↑-ით ავდივართ), ან წითელი / მწვანე ღილაკი
            KeyEvent.KEYCODE_DPAD_RIGHT -> { tvZone = 2; focusEpg(8); return true }
        }
        return false
    }

    /** გადახედვის სიმაღლე: 16:9, მაგრამ დაბალ ეკრანზე არა უმეტეს 34%-ისა — სია ყოველთვის საკმარისად ჩანს */
    private fun sizePreview() {
        if (landscape) return
        val dm = resources.displayMetrics
        val byWidth = dm.widthPixels * 9 / 16
        val cap = (dm.heightPixels * 0.34f).toInt()
        val lp = b.previewBox.layoutParams
        lp.height = minOf(byWidth, cap)
        b.previewBox.layoutParams = lp
    }

    override fun onStart() {
        super.onStart()
        if (!::b.isInitialized) return
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)   // ეკრანმზოგი არ ჩაირთოს ყურებისას
        started = true
        goingFullscreen = false
        clockR = Ui.startClock(b.clock, h) {
            b.fsClock?.text = b.clock.text
            // ყოველ წუთს გადაცემების სახელები და პროგრესი ახლდება
            if (++tickCount % 6 == 0) {
                channelAdapter.refresh()
                updateEpg(current)
            }
        }
        val sc = StreamHub.get(this)
        sc.listen(
            this,
            loading = {
                loadingNow = true
                applyLoadingUi()
                b.previewError.visibility = View.GONE
            },
            playing = {
                loadingNow = false
                applyLoadingUi()
                b.previewError.visibility = View.GONE
                b.status.text = statusText()
            },
            failed = {
                loadingNow = false
                applyLoadingUi()
                b.previewError.visibility = View.VISIBLE
            }
        )
        sc.detachVideo()
        b.preview.player = sc.ensurePlayer()
        sc.host = b.preview
        sc.player?.addListener(autoFit)
        sc.onRebuilt = { np -> b.preview.player = np; np.addListener(autoFit); refit() }
        refit()
        syncFromHolder()
        current?.let { sc.play(it.url) }
        applyDeviceButtons()
        focusCurrent(5)
        maybeAutoOpen()
        scheduleAutoRefresh()
    }

    override fun onStop() {
        super.onStop()
        started = false
        if (::b.isInitialized) endSeekMode()
        h.removeCallbacks(autoRefreshRunnable)
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        clockR?.let { h.removeCallbacks(it) }
        clockR = null
        if (!::b.isInitialized) return
        digits.cancel()
        StreamHub.peek()?.player?.removeListener(autoFit)
        loadAnim?.cancel(); loadAnim = null
        b.preview.player = null
        StreamHub.peek()?.releaseHost(b.preview)
        StreamHub.peek()?.unlisten(this)
        // სრულ ეკრანზე გადასვლისას ან ეკრანის შებრუნებისას ფლეიერი რჩება; სხვა შემთხვევაში (Home) ვთიშავთ
        if (!goingFullscreen && !isChangingConfigurations) StreamHub.release()
    }

    // ---------- არხების ავტომატური განახლება (აპლიკაციიდან გაუსვლის გარეშე) ----------

    /** ინტერვალი წუთებში: app.auto_refresh_min სერვერის კონფიგიდან (ნაგულისხმევი 3; 0 = გამორთული) */
    private fun autoRefreshMs(): Long = RemoteConfig.i("app.auto_refresh_min", 3).coerceIn(0, 60) * 60_000L

    private var liveCfgSig = ""
    private val autoRefreshRunnable = Runnable { autoRefreshNow() }

    private fun scheduleAutoRefresh() {
        h.removeCallbacks(autoRefreshRunnable)
        val ms = autoRefreshMs()
        if (ms > 0 && started) h.postDelayed(autoRefreshRunnable, ms)
    }

    /** სერვერიდან სიას ვიღებთ; თუ არხი დაემატა/წაიშალა/შეიცვალა — სია ახლდება მიმდინარე დაკვრის შეწყვეტის გარეშე */
    private fun autoRefreshNow() {
        if (!alive() || !started) return
        // აპლიკაციის განახლება, შეტყობინებები, QR/რეკლამის პარამეტრები — ყველაფერი გამოსვლის გარეშე ახლდება
        if (!AdGate.showing) {
            Gate.check(this, {}) { val sig = RemoteConfig.json.toString(); if (sig != liveCfgSig) { liveCfgSig = sig; QrOverlay.attach(b.preview) } }
            AdGate.refresh(this, force = true)
        }
        val token = Session.token(this) ?: return
        val app = applicationContext
        Thread {
            try {
                val res = Api.playlist(token)
                if (res.ok && res.body.isNotBlank()) {
                    val parsed = M3u.parse(res.body)
                    if (parsed.isNotEmpty()) {
                        val old = ChannelHolder.all
                        val same = old.size == parsed.size && old.indices.all {
                            old[it].url == parsed[it].url && old[it].name == parsed[it].name &&
                                old[it].logo == parsed[it].logo && old[it].group == parsed[it].group
                        }
                        if (!same) {
                            Store.saveM3u(app, res.body)
                            Epg.attach(parsed)
                            ChannelHolder.all = parsed
                            runOnUiThread {
                                if (alive() && started && !AdGate.showing) {
                                    // მიმდინარე არხს ახალ სიაში იგივე არხით ვცვლით, დაკვრას არ ვაჩერებთ
                                    showChannels(startPlayback = false)
                                }
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                runOnUiThread { if (alive()) scheduleAutoRefresh() }
            }
        }.start()
    }

    // ---------- არხების ჩატვირთვა ----------

    private fun alive() = !isFinishing && !isDestroyed

    /** 1) მყისიერად: მეხსიერებიდან ან დისკის ქეშიდან  2) ფონურად: სერვერიდან განახლება */
    private fun loadChannels() {
        val token = Session.token(this) ?: run { goLogin(); return }
        val app = applicationContext

        if (ChannelHolder.all.isNotEmpty()) {
            showChannels(startPlayback = ChannelHolder.current == null)
        } else {
            b.status.text = getString(R.string.channels_loading)
        }

        Thread {
            var m3uText: String? = null
            // ქეშირებული სია ახალია (ნაგულისხმევად <15 წთ): დიდ სიას ქსელიდან ხელახლა აღარ ვტვირთავთ — აპლიკაცია უფრო სწრაფად იხსნება. ხელით: app.playlist_fresh_min
            val freshMs = RemoteConfig.i("app.playlist_fresh_min", 15).coerceIn(0, 240) * 60_000L
            val age = Store.m3uAgeMs(app)
            val fresh = freshMs > 0 && age in 0 until freshMs
            if (ChannelHolder.all.isEmpty()) {
                val cached = Store.loadM3u(app)
                if (cached != null) {
                    val parsed = M3u.parse(cached)
                    if (parsed.isNotEmpty()) {
                        Epg.attach(parsed)
                        ChannelHolder.all = parsed
                        m3uText = cached
                        runOnUiThread { if (alive()) showChannels(startPlayback = true) }
                    }
                }
            }

            if (fresh && ChannelHolder.all.isNotEmpty()) {
                startEpg(m3uText ?: Store.loadM3u(app))
                return@Thread
            }
            val res = Api.playlist(token)
            if (res.ok && res.body.isNotBlank()) {
                Store.saveM3u(app, res.body)
                val parsed = M3u.parse(res.body)
                if (parsed.isNotEmpty()) {
                    m3uText = res.body
                    val old = ChannelHolder.all
                    val same = old.size == parsed.size &&
                        old.indices.all { old[it].url == parsed[it].url && old[it].name == parsed[it].name && old[it].logo == parsed[it].logo }
                    if (!same) {
                        Epg.attach(parsed)
                        ChannelHolder.all = parsed
                        runOnUiThread { if (alive()) showChannels(startPlayback = ChannelHolder.current == null) }
                    }
                }
            } else if (res.denied) {
                // სერვერმა უარი თქვა (პაკეტი/ვადა) — ძველ სიას აღარ ვტოვებთ
                Store.clear(app)
                ChannelHolder.all = emptyList()
                ChannelHolder.list = emptyList()
                runOnUiThread {
                    if (alive()) {
                        StreamHub.release()
                        channelAdapter.submit(emptyList())
                        b.status.text = res.message
                    }
                }
                return@Thread
            } else if (ChannelHolder.all.isEmpty()) {
                runOnUiThread { if (alive()) b.status.text = res.message }
            }

            startEpg(m3uText)
        }.start()
    }

    /** EPG ცალკე ფონურად (პროცესზე ერთხელ); დასრულებისას სია და პროგრამა ახლდება */
    private fun startEpg(m3uText: String?) {
        if (ChannelHolder.epgStarted) return
        ChannelHolder.epgStarted = true
        val app = applicationContext
        val urls = if (m3uText != null) M3u.epgUrls(m3uText) else emptyList()
        // ავტომატური განმეორება: ქსელის/სერვერის დროებითი შეცდომისას 3-ჯერ ვცდით (20 და 60 წმ-ის შემდეგ)
        // დაბალი პრიორიტეტი: დიდი XML-ის დამუშავება ვიდეოს/ინტერფეისს არ უნდა ართმევდეს პროცესორს
        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND) } catch (e: Exception) {}
        // EPG ეგრევე იწყება (როგორც Televizo-ში), მაგრამ არხს 3 წმ ვაცლით პირველ შეერთებას; დამუშავება ფონურია და ბაზაში იწერება
        val wait = { try { Thread.sleep(3_000L) } catch (e: InterruptedException) {} }
        var ok = Epg.load(app, urls, ChannelHolder.all, wait)
        var attempt = 0
        while (!ok && attempt < 2 && alive()) {
            try { Thread.sleep(if (attempt == 0) 20_000L else 60_000L) } catch (e: InterruptedException) { break }
            ok = Epg.load(app, urls, ChannelHolder.all, wait)
            attempt++
        }
        if (ok) {
            runOnUiThread {
                if (alive()) {
                    channelAdapter.refresh()
                    updateEpg(current)
                }
            }
        } else {
            ChannelHolder.epgStarted = false   // შემდეგ გახსნაზე ისევ ვცადოთ
        }
    }

    private fun showChannels(startPlayback: Boolean) {
        // სია სერვერიდან ახლით შეიცვალა (ბმულები სხვა იყო) — მიმდინარე არხს ახალ სიაში იგივე არხზე ვაჩერებთ
        ChannelHolder.current?.let { c ->
            ChannelHolder.equivalentIn(c, ChannelHolder.all)?.let { if (it !== c) ChannelHolder.current = it }
        }
        val all = visibleChannels()
        groups = listOf(ALL, Lang.FAV) + all.map { it.group }.distinct()
        group = if (ChannelHolder.group in groups) ChannelHolder.group else ALL
        groupAdapter.submit(groups, group)
        applyFilter()
        if (startPlayback) {
            val last = Store.lastUrl(this)
            val ch = ChannelHolder.list.firstOrNull { it.url == last }
                ?: all.firstOrNull { it.url == last }
                ?: ChannelHolder.list.firstOrNull()
            if (ch != null) {
                play(ch)
                val pos = ChannelHolder.list.indexOfFirst { it.url == ch.url }
                if (pos >= 0) b.channels.scrollToPosition(pos)
                // მობილური: გახსნისას სია ბოლოს ნანახ არხზე უნდა იდგეს (ადრე სიის დასაწყისში რჩებოდა და ჩანდა, თითქოს 1-ელ არხზე ხარ)
                if (pos >= 0 && !landscape && !isTv) {
                    val off = (60 * resources.displayMetrics.density).toInt()
                    b.channels.post { (b.channels.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(pos, off) }
                    b.channels.postDelayed({ if (alive()) (b.channels.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(pos, off) }, 400)
                }
                focusCurrent(5)
                maybeAutoOpen()
            }
        } else {
            syncFromHolder()
        }
    }

    private fun selectGroup(g: String) {
        if (g != group) ChannelHolder.markPos(-1)   // ძველი კატეგორიის პოზიცია ახალ სიას არ ეკუთვნის
        group = g
        ChannelHolder.group = g
        Store.setLastGroup(this, g)
        groupAdapter.submit(groups, group)
        applyFilter()
    }

    private fun applyFilter() {
        ChannelHolder.group = group
        val base = visibleChannels()
        val shown = when (group) {
            ALL -> base
            Lang.FAV -> base.filter { UserLists.isFav(this, it) }
            else -> base.filter { it.group == group }
        }
        ChannelHolder.list = shown
        updateGroupHeader()
        channelAdapter.submit(shown)
        current?.let { channelAdapter.select(it.url) }
        b.status.text = statusText()
    }

    private fun statusText(): String {
        val n = ChannelHolder.list.size
        if (group == Lang.FAV && n == 0) return "ფავორიტები ცარიელია: არხზე გრძელი OK ან INFO (i)"
        return if (landscape) {
            getString(R.string.status_land, n, groups.indexOf(group).coerceAtLeast(0) + 1, groups.size.coerceAtLeast(1))
        } else {
            getString(R.string.status_portrait, Lang.group(group), n)
        }
    }

    /** ლანდშაფტში: კატეგორიის სახელი გადამრთველში */
    private fun updateGroupHeader() {
        b.groupTitle?.text = Lang.group(group)
    }

    private fun stepGroup(delta: Int) {
        if (groups.isEmpty()) return
        val i = Math.floorMod(groups.indexOf(group) + delta, groups.size)
        selectGroup(groups[i])
    }

    /** სიაზე (RecyclerView) მკაფიოდ ჰორიზონტალური გადასმა არხს ცვლის; ვერტიკალური გადახვევა და შეხება არ იცვლება */
    private fun attachHorizontalZap(rv: androidx.recyclerview.widget.RecyclerView) {
        val dm = resources.displayMetrics
        val minDist = 60 * dm.density
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var horizontal = false
        rv.addOnItemTouchListener(object : androidx.recyclerview.widget.RecyclerView.OnItemTouchListener {
            override fun onInterceptTouchEvent(r: androidx.recyclerview.widget.RecyclerView, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; horizontal = false }
                    MotionEvent.ACTION_MOVE -> if (!horizontal) {
                        val dx = Math.abs(e.x - downX)
                        val dy = Math.abs(e.y - downY)
                        if (dx > slop * 2 && dx > dy * 2) horizontal = true
                    }
                }
                return horizontal
            }

            override fun onTouchEvent(r: androidx.recyclerview.widget.RecyclerView, e: MotionEvent) {
                if (!horizontal) return
                when (e.actionMasked) {
                    MotionEvent.ACTION_UP -> {
                        val dx = e.x - downX
                        horizontal = false
                        if (Math.abs(dx) > minDist) stepChannel(if (dx < 0) 1 else -1)
                    }
                    MotionEvent.ACTION_CANCEL -> horizontal = false
                }
            }

            override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {}
        })
    }

    /** მობილური (ვერტიკალური): ტელეპროგრამის სია გახსნილია თუ არა (მომხმარებლის არჩევანი) */
    private var epgExpanded = false

    /**
     * მობილური (ვერტიკალური): ტელეპროგრამის პანელი იხსნება მხოლოდ თუ არხს გადაცემები აქვს.
     * არ აქვს → გაწელილი ცარიელი პანელის ნაცვლად, "ტელეპროგრამის" ქვემოთ ჩანს მოკლე წარწერა.
     */
    private fun applyEpgPanel() {
        if (landscape || isTv || !::b.isInitialized) return
        val has = programAdapter.itemCount > 0
        b.epgList.visibility = if (epgExpanded && has) View.VISIBLE else View.GONE
        b.epgEmpty?.visibility = if (!has && current != null) View.VISIBLE else View.GONE
        updateEpgHint()
    }

    /** ტელეფონი ვერტიკალურად: წარწერა "▾ ტელეპროგრამა" არხის ქვემოთ (ღია პროგრამაზე ▴ და გამოყოფილია) */
    private fun updateEpgHint() {
        val hint = b.epgHint ?: return
        val open = b.epgList.visibility == View.VISIBLE
        hint.text = (if (open) "▴ " else "▾ ") + getString(R.string.programs_hint)
        hint.isSelected = open
        hint.setTextColor(if (open) 0xFFFFFFFF.toInt() else 0xFF00F0D4.toInt())
    }

    private fun nameLabel(ch: Channel): String =
        if (landscape) getString(R.string.programs_title, ch.name) else ch.name

    // ---------- დაკვრა ----------

    private val epgRunnable = Runnable { if (alive() && !fs) current?.let { updateEpg(it) } }

    private fun play(ch: Channel) {
        // არხი ამჟამინდელ კატეგორიაში არ არის (მაგ. ციფრებით/ბოლო არხით) → ვაჩვენებთ ყველა არხს, რომ სია და ისრები ამ არხიდან დაიწყოს
        if (ChannelHolder.list.none { it.url == ch.url } && ChannelHolder.all.any { it.url == ch.url }) {
            group = ALL
            applyFilter()
        }
        val old = current
        if (old != null && old.url != ch.url) prevChannel = old
        current = ch
        ChannelHolder.current = ch
        Timeshift.clear()   // არხზე გადასვლა ყოველთვის პირდაპირ ეთერზე
        endSeekMode()
        Store.setLastUrl(this, ch.url)
        b.nowName.text = nameLabel(ch)
        channelAdapter.select(ch.url)
        b.btnFullscreen.isEnabled = true
        if (!fs) { h.removeCallbacks(epgRunnable); h.postDelayed(epgRunnable, 300) }   // სწრაფი გადართვისას ტელეპროგრამას მხოლოდ ბოლო არხისთვის ვხატავთ (ადრე ყოველ არხზე — ჭედავდა)
        if (started) AdGate.run(this, ch.url) { StreamHub.get(this).play(ch.url) }
    }

    /** გადაცემაზე დაჭერა: გასული — არქივი, მიმდინარე — პირდაპირ ეთერი */
    private fun onProgramClick(p: Program) {
        val ch = current ?: return
        val t = System.currentTimeMillis()
        when {
            t >= p.start && t < p.stop -> { Timeshift.clear(); endSeekMode(); b.nowName.text = nameLabel(ch); StreamHub.get(this).play(ch.url); if (isTv) openFullscreen() }
            p.start > t -> Toast.makeText(this, "ეს გადაცემა ჯერ არ დაწყებულა", Toast.LENGTH_SHORT).show()
            Catchup.canPlay(ch, p) -> {
                b.nowName.text = "📼 ${ch.name} · ${Ui.timeOf(p.start)} ${p.title}"
                Timeshift.playProgram(this, ch, p)
                if (isTv) { openFullscreen(); startSeekMode() }   // გასული გადაცემა მთელ ეკრანზე + ←/→ გადახვევა (YouTube-ის ზოლით)
            }
            else -> Toast.makeText(this, "ამ გადაცემის არქივი მიუწვდომელია", Toast.LENGTH_SHORT).show()
        }
    }

    /** პროგრამის სია იხსნება მიმდინარე გადაცემაზე; გასული გადაცემები ზემოთ გადასახვევია */
    private fun scrollProgramsToLive() {
        val i = programAdapter.liveIndex()
        (b.epgList.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager)
            ?.scrollToPositionWithOffset(i, 0)
    }

    /** გადაცემა ახლა / შემდეგ და მთელი პროგრამა */
    private fun updateEpg(ch: Channel?) {
        if (ch == null) return
        val now = Epg.now(ch)
        if (now != null) {
            b.epgNow.text = "${Ui.timeOf(now.start)}–${Ui.timeOf(now.stop)}  ${now.title}"
            b.epgNow.visibility = View.VISIBLE
            b.epgProgress.progress = Ui.progressOf(now)
            b.epgProgress.visibility = View.VISIBLE
            val nx = Epg.next(ch)
            if (nx != null) {
                b.epgNext.text = getString(R.string.next_fmt, Ui.timeOf(nx.start), nx.title)
                b.epgNext.visibility = View.VISIBLE
            } else b.epgNext.visibility = View.GONE
        } else {
            b.epgNow.visibility = View.GONE
            b.epgProgress.visibility = View.GONE
            b.epgNext.visibility = View.GONE
        }
        // TV: მომხმარებელი ტელეპროგრამას ათვალიერებს → სიას არ ვაახლებთ და მიმდინარე გადაცემაზე არ ვხტებით (ეს ფოკუსს აგდებდა)
        if (!(isTv && epgOpen && programAdapter.itemCount > 0)) {
            programAdapter.submit(Epg.schedule(ch))
            scrollProgramsToLive()
        }
        applyEpgPanel()
    }

    private fun openFullscreen() {
        val ch = current ?: return
        if (isTv && b.leftCol != null) { enterFs(); return }
        ChannelHolder.current = ch
        goingFullscreen = true
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", ch.url))
    }

    /** სრულ ეკრანიდან დაბრუნებისას ან ეკრანის შებრუნებისას — მიმდინარე არხის სინქრონიზაცია */
    private fun syncFromHolder() {
        val ch = ChannelHolder.current ?: return
        current = ch
        b.nowName.text = nameLabel(ch)
        channelAdapter.select(ch.url)
        b.btnFullscreen.isEnabled = true
        updateEpg(ch)
        val pos = ChannelHolder.list.indexOfFirst { it.url == ch.url }
        if (pos >= 0 && !b.channels.canScrollVertically(-1) && pos > 3) b.channels.scrollToPosition(pos)
    }

    // ---------- ფავორიტები და არხის წაშლა (მხოლოდ აპლიკაციაში) ----------
    private fun visibleChannels(): List<Channel> = ChannelHolder.all.filter { !UserLists.isHidden(this, it) }

    /** არხზე მოქმედებები: ფავორიტი / წაშლა სიიდან (საიტზე არაფერი იცვლება) */
    private fun channelMenu(ch: Channel) {
        if (!alive()) return
        val fav = UserLists.isFav(this, ch)
        val items = arrayOf(if (fav) "★ ამოღება ფავორიტებიდან" else "☆ ფავორიტებში დამატება", "🗑 არხის წაშლა სიიდან", "დახურვა")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> toggleFav(ch)
                    1 -> confirmHide(ch)
                }
            }.show()
    }

    private fun toggleFav(ch: Channel) {
        val added = UserLists.toggleFav(this, ch)
        flash(if (added) "★ დაემატა ფავორიტებში" else "ამოიღეთ ფავორიტებიდან")
        val pos = ChannelHolder.list.indexOfFirst { it.url == ch.url }
        applyFilter()
        if (isTv && pos >= 0) focusPosition(pos.coerceAtMost((ChannelHolder.list.size - 1).coerceAtLeast(0)), 8)
    }

    private fun confirmHide(ch: Channel) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("წაიშალოს „" + ch.name + "“?")
            .setMessage("არხი მხოლოდ ამ აპლიკაციაში დაიმალება. საიტზე და სხვა მოწყობილობებზე არაფერი შეიცვლება. აღდგენა: MENU → კატეგორიები → აღდგენა.")
            .setPositiveButton("წაშლა") { _, _ ->
                val pos = ChannelHolder.list.indexOfFirst { it.url == ch.url }
                UserLists.hide(this, ch)
                val wasCurrent = current?.url == ch.url
                showChannels(startPlayback = false)
                if (wasCurrent) ChannelHolder.list.getOrNull(pos.coerceAtLeast(0).coerceAtMost((ChannelHolder.list.size - 1).coerceAtLeast(0)))?.let { play(it) }
                if (isTv && pos >= 0) focusPosition(pos.coerceAtMost((ChannelHolder.list.size - 1).coerceAtLeast(0)), 8)
                flash("არხი წაიშალა")
            }
            .setNegativeButton("არა", null)
            .show()
    }

    /** კატეგორიის არჩევა სიიდან (პულტზე ფერადი ღილაკების გარეშეც): MENU / ⚙ */
    private fun categoryMenu() {
        if (!alive()) return
        val labels = groups.map { Lang.group(it) }.toTypedArray()
        val b0 = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("კატეგორია")
            .setSingleChoiceItems(labels, groups.indexOf(group).coerceAtLeast(0)) { dlg, which ->
                selectGroup(groups[which])
                dlg.dismiss()
                if (isTv) focusCurrent(8)
            }
        val hc = UserLists.hiddenCount(this)
        if (hc > 0) b0.setNeutralButton("წაშლილების აღდგენა ($hc)") { _, _ ->
            UserLists.unhideAll(this)
            showChannels(startPlayback = false)
            flash("არხები აღდგა")
        }
        b0.setNegativeButton("დახურვა", null)
        b0.show()
    }

    /** არხი, რომელზეც ფოკუსია (სიაში) ან მიმდინარე */
    private fun focusedChannel(): Channel? {
        val f = currentFocus
        if (f != null && f.parent === b.channels) {
            val pos = b.channels.getChildAdapterPosition(f)
            ChannelHolder.list.getOrNull(pos)?.let { return it }
        }
        return current
    }

    private var lastInfoAt = 0L
    private fun fsInfoKey() {
        val now = android.os.SystemClock.uptimeMillis()
        if (now - lastInfoAt < 3000 && b.fsBar?.visibility == View.VISIBLE) { lastInfoAt = 0; current?.let { channelMenu(it) } }
        else { lastInfoAt = now; showFsInfo() }
    }

    private fun stepChannel(delta: Int) {
        val list = ChannelHolder.list
        if (list.isEmpty()) return
        // ჭეშმარიტების წყარო — ChannelHolder.current (ბმულის განახლებისას Activity-ს ძველი ობიექტი რჩებოდა)
        ChannelHolder.current?.let { current = it }
        // მიმდინარე არხი ამ კატეგორიაში არ არის (კატეგორია შეიცვალა) → CH+ პირველზე, CH− ბოლოზე.
        // ბმულის შეცვლა (dkey) აღარ ითვლება \"არხი სიაში არ არის\"-ად — ადრე სწორედ ამიტომ ხტებოდა 1-ელ არხზე (QR)
        val ex = ChannelHolder.exactIndex
        val lp = ChannelHolder.lastPos()
        // წრიული გადართვა: 1-ლი არხიდან უკან → ბოლო არხი, ბოლო არხიდან წინ → 1-ლი არხი
        val pos = when {
            ex >= 0 -> Math.floorMod(ex + delta, list.size)
            lp in list.indices -> Math.floorMod(lp + delta, list.size)
            delta > 0 -> 0
            else -> list.size - 1
        }
        ChannelHolder.markPos(pos)
        play(list[pos])
        b.channels.scrollToPosition(pos)
    }

    /**
     * პულტი (TV): CH+/CH− (P▲/P▼), ციფრები 0–9, LAST/DEL → წინა არხი, ⏯ → სრული ეკრანი,
     * RED/GREEN → წინა/შემდეგი კატეგორია (FAV-იც → შემდეგი), YELLOW → ენა, BLUE → სრული ეკრანი,
     * EXIT → გასვლა, OK → არხი სრულ ეკრანზე.
     */
    private var swallowKey = 0
    private var swallowAt = 0L
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        Device.noteKey(this, event)
        if (AdGate.showing) return AdGate.key(event)
        // OK-მ სრული ეკრანი დახურა: იმავე დაჭერის გაგრძელება/აშვება სიის არხს არ უნდა "დააჭიროს"
        if (swallowKey != 0 && android.os.SystemClock.uptimeMillis() - swallowAt > 3000) swallowKey = 0
        if (swallowKey != 0 && event.keyCode == swallowKey) {
            if (event.action == KeyEvent.ACTION_UP) swallowKey = 0
            return true
        }
        if (fs && ::b.isInitialized && fsKey(event)) return true
        if (overlayTv && !fs && ::b.isInitialized && (event.keyCode == KeyEvent.KEYCODE_BACK || event.keyCode == KeyEvent.KEYCODE_ESCAPE) && current != null && !digits.active) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                // EXIT/BACK: ჯერ ღია პანელი იხურება (ტელეპროგრამა → არხების სია → სრული ეკრანი), სრულ ეკრანზე — გასვლა
                if (epgOpen) { closeEpgPanel(); focusCurrent(8) }
                else enterFs()
            }
            return true
        }
        if (event.action == KeyEvent.ACTION_DOWN && ::b.isInitialized) {
            val k = event.keyCode
            offerKeysOnce()
            if (tvListKey(event.keyCode, event.repeatCount)) return true
            // მორგებული ღილაკები (↑↓←→ მთავარზე ფოკუსისთვისაა და არ გამოიყენება)
            if (!KeyMap.isDpad(k)) {
                when (KeyMap.get(this, k)) {
                    KeyMap.Act.NEXT_CH -> { if (event.repeatCount == 0) stepChannel(1); return true }
                    KeyMap.Act.PREV_CH -> { if (event.repeatCount == 0) stepChannel(-1); return true }
                    KeyMap.Act.LAST -> {
                        if (event.repeatCount == 0) prevChannel?.let {
                            play(it)
                            val pos = ChannelHolder.list.indexOfFirst { c -> c.url == it.url }
                            if (pos >= 0) b.channels.scrollToPosition(pos)
                        }
                        return true
                    }
                    KeyMap.Act.FAV -> { if (event.repeatCount == 0) focusedChannel()?.let { toggleFav(it) }; return true }
                    KeyMap.Act.HIDE -> { if (event.repeatCount == 0) focusedChannel()?.let { confirmHide(it) }; return true }
                    KeyMap.Act.PREV_GROUP -> { if (event.repeatCount == 0) stepGroup(-1); return true }
                    KeyMap.Act.NEXT_GROUP -> { if (event.repeatCount == 0) stepGroup(1); return true }
                    KeyMap.Act.GROUP_MENU -> { if (event.repeatCount == 0) categoryMenu(); return true }
                    else -> {}
                }
            }
            when (k) {
                KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_TV_DATA_SERVICE -> { focusEpg(8); return true }
                KeyEvent.KEYCODE_CAPTIONS -> { cycleSubtitles(); return true }
                KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK -> { cycleAudio(); return true }
                KeyEvent.KEYCODE_MUTE -> { StreamHub.peek()?.player?.let { it.volume = if (it.volume == 0f) 1f else 0f }; return true }
                KeyEvent.KEYCODE_MEDIA_STOP -> { return true }
            }
            when {
                k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_PAGE_UP -> {
                    stepChannel(1)
                    return true
                }
                k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_PAGE_DOWN -> {
                    stepChannel(-1)
                    return true
                }
                // ◀◀ ▶▶ და ⏮ ⏭ — წინა / შემდეგი არხი (გამეორებას ვუგულებელვყოფთ)
                k == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || k == KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    if (event.repeatCount == 0) stepChannel(1)
                    return true
                }
                k == KeyEvent.KEYCODE_MEDIA_REWIND || k == KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    if (event.repeatCount == 0) stepChannel(-1)
                    return true
                }
                k == KeyEvent.KEYCODE_MEDIA_PLAY || k == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || k == KeyEvent.KEYCODE_PROG_BLUE -> {
                    if (current != null) {
                        openFullscreen()
                        return true
                    }
                }
                k == KeyEvent.KEYCODE_PROG_RED -> {
                    stepGroup(-1)
                    return true
                }
                k == KeyEvent.KEYCODE_PROG_GREEN -> {
                    stepGroup(1)
                    return true
                }
                k == KeyEvent.KEYCODE_PROG_YELLOW -> {
                    focusLogout()   // TV: სწრაფად "გასვლა" ღილაკზე
                    return true
                }
                // ფერადი ღილაკების გარეშე პულტები: MENU / ⚙ = კატეგორიების სია
                k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_SETTINGS || k == KeyEvent.KEYCODE_TV_CONTENTS_MENU -> {
                    if (event.repeatCount == 0) categoryMenu()
                    return true
                }
                // INFO (i) = არხის მენიუ (ფავორიტი / წაშლა); FAV = ფავორიტში დამატება/ამოღება
                k == KeyEvent.KEYCODE_INFO -> {
                    if (event.repeatCount == 0) focusedChannel()?.let { channelMenu(it) }
                    return true
                }
                k == KeyEvent.KEYCODE_BOOKMARK -> {
                    if (event.repeatCount == 0) focusedChannel()?.let { toggleFav(it) }
                    return true
                }
                k == KeyEvent.KEYCODE_LAST_CHANNEL || (k == KeyEvent.KEYCODE_DEL && !digits.active) -> {
                    prevChannel?.let {
                        play(it)
                        val pos = ChannelHolder.list.indexOfFirst { c -> c.url == it.url }
                        if (pos >= 0) b.channels.scrollToPosition(pos)
                    }
                    return true
                }
                k in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                    digits.digit(k - KeyEvent.KEYCODE_0)
                    return true
                }
                k in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> {
                    digits.digit(k - KeyEvent.KEYCODE_NUMPAD_0)
                    return true
                }
                (k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER) && digits.active -> {
                    digits.commit()
                    return true
                }
                (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_DEL) && digits.active -> {
                    digits.cancel()
                    return true
                }
                k == KeyEvent.KEYCODE_ESCAPE -> {   // EXIT
                    if (digits.active) digits.cancel() else finish()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    /** პულტის პირველივე ღილაკზე ერთხელ შევთავაზოთ ღილაკების მორგება (მხოლოდ თუ პულტითაა და ჯერ არ მოუგვარებია) */
    private fun offerKeysOnce() {
        if (!Device.remoteSeen || offered) return
        val prefs = getSharedPreferences("tv_keys", MODE_PRIVATE)
        if (prefs.getBoolean("offered", false) || !KeyMap.isEmpty(this)) { offered = true; return }
        offered = true
        prefs.edit().putBoolean("offered", true).apply()
        h.post {
            if (isFinishing || isDestroyed) return@post
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(R.string.keys_offer_title)
                .setMessage(R.string.keys_offer_msg)
                .setPositiveButton(R.string.keys_offer_yes) { _, _ -> startActivity(Intent(this, KeysActivity::class.java)) }
                .setNegativeButton(R.string.later_btn, null)
                .show()
        }
    }

    private fun goLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
