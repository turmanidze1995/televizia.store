package store.televizia.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

const val BASE_URL = "https://televizia.store"

/** შესვლის მდგომარეობა (ტოკენი SharedPreferences-ში) */
object Session {
    private const val PREFS = "tv_session"

    fun save(ctx: Context, token: String, name: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("token", token).putString("name", name).apply()
    }

    fun token(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("token", null)

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}

/** სერვერთან კავშირი (HttpURLConnection, ფონურ ნაკადში გამოიძახება) */
object Api {
    class LoginResult(val ok: Boolean, val message: String, val token: String? = null, val name: String = "")
    class PlaylistResult(val ok: Boolean, val message: String, val body: String = "", val denied: Boolean = false)

    fun login(email: String, password: String): LoginResult = try {
        val body = "email=" + URLEncoder.encode(email, "UTF-8") +
                "&password=" + URLEncoder.encode(password, "UTF-8")
        val conn = (URL("$BASE_URL/api/app.php?action=login").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        }
        conn.outputStream.use { it.write(body.toByteArray()) }
        val text = readAll(conn)
        val j = JSONObject(text)
        if (j.optBoolean("ok")) LoginResult(true, "", j.getString("token"), j.optString("name"))
        else LoginResult(false, loginError(j.optString("error")))
    } catch (e: Exception) {
        LoginResult(false, Lang.s(R.string.err_connection))
    }

    /** მომხმარებლის არხების სია (M3U). denied=true → სერვერმა პირდაპირ უარი თქვა (ვადა გაუვიდა და ა.შ.) */
    fun playlist(token: String): PlaylistResult = try {
        val url = "$BASE_URL/playlist/m3u.php?token=" + URLEncoder.encode(token, "UTF-8")
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 20000
        }
        val text = readAll(conn)
        if (conn.responseCode in 200..299) PlaylistResult(true, "", text)
        else PlaylistResult(false, text.ifBlank { Lang.s(R.string.pkg_inactive) }, denied = true)
    } catch (e: Exception) {
        PlaylistResult(false, Lang.s(R.string.err_connection))
    }

    private fun readAll(conn: HttpURLConnection): String {
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        return stream?.bufferedReader()?.use { it.readText() } ?: ""
    }

    private fun loginError(code: String): String = when (code) {
        "bad_credentials" -> Lang.s(R.string.err_bad_credentials)
        "no_active_package" -> Lang.s(R.string.err_no_package)
        "no_token" -> Lang.s(R.string.err_no_token)
        else -> Lang.s(R.string.err_login_failed)
    }
}

/**
 * XMLTV პროგრამის სია (EPG).
 * ცარიელი დატოვეთ, თუ არხების სია (M3U) თავად შეიცავს url-tvg="..." ბმულს — მაშინ აპლიკაცია მას თავისით აიღებს.
 * სხვა შემთხვევაში ჩასვით თქვენი პროვაიდერის XMLTV ბმული (.xml ან .xml.gz), მაგ.: "https://example.com/epg.xml.gz"
 */
const val EPG_URL = ""

/** საიტის საადმინო პანელის ნაგულისხმევი მისამართი (აპლიკაციაში შეიძლება შეიცვალოს: ადმინ-ეკრანი → ⚙) */
const val ADMIN_URL = "$BASE_URL/admin/"

/** ლოკალური მეხსიერება: არხების სიის ქეში (აპლიკაცია მყისიერად იხსნება) და ბოლო არხი/პარამეტრები */
object Store {
    private const val PREFS = "tv_state"
    private const val M3U = "playlist.m3u"

    fun saveM3u(ctx: Context, text: String) {
        try { java.io.File(ctx.filesDir, M3U).writeText(text) } catch (e: Exception) { }
    }

    fun loadM3u(ctx: Context): String? = try {
        val f = java.io.File(ctx.filesDir, M3U)
        if (f.exists() && f.length() > 0) f.readText() else null
    } catch (e: Exception) {
        null
    }

    fun clear(ctx: Context) {
        try { java.io.File(ctx.filesDir, M3U).delete() } catch (e: Exception) { }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun lastUrl(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("last_url", null)

    fun setLastUrl(ctx: Context, url: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("last_url", url).apply()
    }

    fun lastGroup(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("last_group", null)

    fun setLastGroup(ctx: Context, g: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("last_group", g).apply()
    }

    /** ვიდეოს მორგების რეჟიმი სრულ ეკრანზე: 0 = ჩატევა, 1 = გაშლა (zoom), 2 = გაჭიმვა */
    fun resizeMode(ctx: Context): Int =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("resize", 0)

    fun setResizeMode(ctx: Context, v: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("resize", v).apply()
    }
}
