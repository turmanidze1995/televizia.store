package store.televizia.app

data class Channel(val name: String, val logo: String, val url: String, val group: String, val epgId: String = "") {
    /** XMLTV არხის ID, რომელსაც ეს არხი დაუკავშირდა (ივსება Epg.attach-ით) */
    @Volatile var epgKey: String = ""
}

/** M3U სიის წამკითხველი: სახელი, ლოგო, ჯგუფი (group-title), tvg-id და სტრიმის ლინკი */
object M3u {
    private val logoRegex = Regex("""tvg-logo\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val groupRegex = Regex("""group-title\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val idRegex = Regex("""tvg-id\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val tvgNameRegex = Regex("""tvg-name\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val epgRegex = Regex("""(?:url-tvg|x-tvg-url)\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>(512)
        var name = ""
        var logo = ""
        var group = ""
        var epgId = ""
        for (raw in text.lineSequence()) {
            val line = raw.trim().removePrefix("\uFEFF")
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF")) {
                name = if (line.contains(',')) line.substringAfterLast(',').trim() else ""
                if (name.isEmpty()) name = tvgNameRegex.find(line)?.groupValues?.get(1)?.trim() ?: ""
                logo = logoRegex.find(line)?.groupValues?.get(1) ?: ""
                group = groupRegex.find(line)?.groupValues?.get(1) ?: ""
                epgId = idRegex.find(line)?.groupValues?.get(1) ?: ""
            } else if (!line.startsWith("#")) {
                out.add(Channel(name.ifEmpty { Lang.s(R.string.channel_default) }, logo, line, group.ifBlank { Lang.OTHER }, epgId))
                name = ""; logo = ""; group = ""; epgId = ""
            }
        }
        return out
    }

    /** სიის პირველ ხაზში მითითებული EPG ბმულები: #EXTM3U url-tvg="a.xml,b.xml" */
    fun epgUrls(text: String): List<String> {
        val head = text.lineSequence().take(5).firstOrNull { it.trim().removePrefix("\uFEFF").startsWith("#EXTM3U") }
            ?: return emptyList()
        val m = epgRegex.find(head) ?: return emptyList()
        return m.groupValues[1].split(',').map { it.trim() }.filter { it.startsWith("http") }
    }
}
