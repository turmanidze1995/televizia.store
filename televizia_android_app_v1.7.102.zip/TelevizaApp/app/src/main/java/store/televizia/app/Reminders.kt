package store.televizia.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * ტელეპროგრამის შეხსენებები (v1.7.97).
 *  - გადაცემის მონიშვნა (ტელეპროგრამაში დაჭერით) ან მთელი არხის „ყოველი ახალი გადაცემა“.
 *  - დაწყების წუთზე: აპი ღიაა → ფანჯარა ეკრანზე; აპი დახურულია → სისტემური შეტყობინება (+ფანჯარა, თუ TV-ზე/„სხვა აპებზე ჩვენება“ ნებართვაა).
 *  - ჩართვა/გამორთვა სერვერიდან: features.reminders (ადმინ-ეკრანი).
 * შეხსენებები ინახება მოწყობილობაზე; ალარმები მეორდება გადატვირთვის (BOOT) შემდეგ.
 */
object Reminders {
    data class Item(val url: String, val name: String, val title: String, val start: Long, val auto: Boolean)

    private const val PREFS = "reminders"
    private const val CH_ID = "reminders"
    const val EXTRA_URL = "remind_url"
    const val ACTION_FIRE = "store.televizia.app.REMINDER_FIRE"
    private const val MAX_AHEAD_MS = 36L * 3600_000L
    @Volatile var foreground = 0
    private var lastSync = 0L

    fun enabled(): Boolean = RemoteConfig.b("features.reminders", true)

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------- შენახვა ----------
    @Synchronized private fun load(ctx: Context): MutableList<Item> {
        val out = ArrayList<Item>()
        try {
            val a = JSONArray(sp(ctx).getString("items", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Item(o.getString("u"), o.optString("n"), o.optString("t"), o.getLong("s"), o.optBoolean("a")))
            }
        } catch (_: Exception) {}
        return out
    }

    @Synchronized private fun save(ctx: Context, l: List<Item>) {
        val a = JSONArray()
        for (it in l.sortedBy { x -> x.start }.takeLast(400)) a.put(JSONObject().put("u", it.url).put("n", it.name).put("t", it.title).put("s", it.start).put("a", it.auto))
        sp(ctx).edit().putString("items", a.toString()).apply()
    }

    fun has(ctx: Context, url: String, start: Long): Boolean = load(ctx).any { it.url == url && it.start == start }

    // ---------- გადაცემის მონიშვნა ----------
    /** true = დაემატა, false = მოიხსნა */
    fun toggle(ctx: Context, ch: Channel, p: Program): Boolean {
        val l = load(ctx)
        val ex = l.firstOrNull { it.url == ch.url && it.start == p.start }
        return if (ex != null) {
            l.remove(ex); cancel(ctx, ex); save(ctx, l); false
        } else {
            val it = Item(ch.url, ch.name, p.title, p.start, false)
            l.add(it); save(ctx, l); schedule(ctx, it); true
        }
    }

    // ---------- მთელი არხი ----------
    fun following(ctx: Context, url: String): Boolean = sp(ctx).getStringSet("follow", emptySet())?.contains(url) == true

    fun toggleFollow(ctx: Context, ch: Channel): Boolean {
        val set = HashSet(sp(ctx).getStringSet("follow", emptySet()) ?: emptySet())
        val on = if (set.contains(ch.url)) { set.remove(ch.url); false } else { set.add(ch.url); true }
        sp(ctx).edit().putStringSet("follow", set).apply()
        if (!on) {
            val l = load(ctx)
            val drop = l.filter { it.url == ch.url && it.auto }
            drop.forEach { cancel(ctx, it) }
            l.removeAll(drop.toSet()); save(ctx, l)
        } else sync(ctx, true)
        return on
    }

    /** მონიშნული არხების მომავალი გადაცემები → ალარმები (იძახება აპის გახსნისას/ტელეპროგრამის განახლებისას) */
    fun sync(ctx: Context, force: Boolean = false) {
        if (!enabled()) return
        val now = System.currentTimeMillis()
        if (!force && now - lastSync < 10 * 60_000L) return
        val follow = sp(ctx).getStringSet("follow", emptySet()) ?: emptySet()
        val l = load(ctx)
        var changed = l.removeAll { it.start < now - 120_000L }
        for (url in follow) {
            val ch = ChannelHolder.all.firstOrNull { it.url == url } ?: continue
            val sched = Epg.schedule(ch)
            if (sched.isEmpty()) continue
            lastSync = now
            for (p in sched) {
                if (p.start <= now + 5_000L || p.start > now + MAX_AHEAD_MS) continue
                if (l.any { it.url == url && it.start == p.start }) continue
                val it = Item(url, ch.name, p.title, p.start, true)
                l.add(it); schedule(ctx, it); changed = true
            }
        }
        if (changed) save(ctx, l)
    }

    // ---------- ალარმი ----------
    private fun pi(ctx: Context, it: Item, create: Boolean): PendingIntent? {
        val i = Intent(ctx, ReminderReceiver::class.java).setAction(ACTION_FIRE)
            .setData(Uri.parse("rem://" + (it.url + "|" + it.start).hashCode()))
            .putExtra("u", it.url).putExtra("s", it.start)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return if (create) PendingIntent.getBroadcast(ctx, 0, i, flags)
        else PendingIntent.getBroadcast(ctx, 0, i, flags or PendingIntent.FLAG_NO_CREATE)
    }

    fun schedule(ctx: Context, it: Item) {
        if (it.start <= System.currentTimeMillis()) return
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val p = pi(ctx, it, true) ?: return
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (Build.VERSION.SDK_INT >= 23) {
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, it.start, p)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, it.start, p)
            } else am.setExact(AlarmManager.RTC_WAKEUP, it.start, p)
        } catch (_: Exception) {}
    }

    private fun cancel(ctx: Context, it: Item) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            pi(ctx, it, false)?.let { p -> am.cancel(p); p.cancel() }
        } catch (_: Exception) {}
    }

    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        val l = load(ctx)
        l.removeAll { it.start < now - 120_000L }
        save(ctx, l)
        l.forEach { schedule(ctx, it) }
    }

    // ---------- ნებართვები ----------
    /** შეტყობინებების ნებართვა (Android 13+) — პირველი მონიშვნისას */
    fun askPermissions(a: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7201)
        } catch (_: Exception) {}
    }

    fun canOverlay(ctx: Context): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    /** „სხვა აპებზე ჩვენება“ — რომ დახურულ აპზეც (განსაკუთრებით TV-ზე) ფანჯარა ამოვარდეს */
    fun openOverlaySettings(a: Activity): Boolean {
        return try {
            a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))); true
        } catch (_: Exception) { false }
    }

    // ---------- არხის გახსნა შეხსენებიდან ----------
    fun openIntent(ctx: Context, url: String): Intent =
        Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(EXTRA_URL, url)

    fun setPending(ctx: Context, url: String) { sp(ctx).edit().putString("pending", url).putLong("pending_at", System.currentTimeMillis()).apply() }
    fun takePending(ctx: Context): String? {
        val u = sp(ctx).getString("pending", null) ?: return null
        val at = sp(ctx).getLong("pending_at", 0L)
        sp(ctx).edit().remove("pending").apply()
        return if (System.currentTimeMillis() - at < 2 * 60_000L) u else null   // ძველი მოთხოვნა აღარ სრულდება
    }

    // ---------- გაშვება (ალარმი) ----------
    fun fire(ctx: Context, url: String, start: Long) {
        val l = load(ctx)
        val it = l.firstOrNull { x -> x.url == url && x.start == start } ?: return   // უცხო/გაუქმებული ალარმი
        l.remove(it); save(ctx, l)
        if (!enabled()) return
        val late = System.currentTimeMillis() - start
        if (late > 10 * 60_000L) return   // 10 წუთზე მეტით დაგვიანებული აღარ აინტერესებს
        val tv = Device.tv(ctx)
        val showWindow = foreground > 0 || canOverlay(ctx)
        notify(ctx, it, tv && !showWindow)
        if (showWindow) {
            try {
                ctx.startActivity(Intent(ctx, ReminderActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    .putExtra("u", it.url).putExtra("n", it.name).putExtra("t", it.title))
            } catch (_: Exception) {}
        }
    }

    private fun notify(ctx: Context, it: Item, fullScreen: Boolean) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH_ID) == null) {
                val c = NotificationChannel(CH_ID, "ტელეპროგრამის შეხსენებები", NotificationManager.IMPORTANCE_HIGH)
                nm.createNotificationChannel(c)
            }
            if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val open = PendingIntent.getActivity(ctx, (it.url + it.start).hashCode(), openIntent(ctx, it.url), flags)
            val b = NotificationCompat.Builder(ctx, CH_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("🔔 დაიწყო: " + it.title)
                .setContentText(it.name)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setContentIntent(open)
            if (fullScreen) b.setFullScreenIntent(open, true)
            nm.notify((it.url + it.start).hashCode(), b.build())
        } catch (_: Exception) {}
    }

    /** აპის წინა პლანზე ყოფნის მთვლელი (Application.ActivityLifecycleCallbacks) */
    fun trackForeground(app: Application) {
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(a: Activity) { if (a !is ReminderActivity) foreground++ }
            override fun onActivityStopped(a: Activity) { if (a !is ReminderActivity && foreground > 0) foreground-- }
            override fun onActivityCreated(a: Activity, s: Bundle?) {}
            override fun onActivityResumed(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, o: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, "android.intent.action.QUICKBOOT_POWERON" -> Reminders.rescheduleAll(ctx)
            Reminders.ACTION_FIRE -> Reminders.fire(ctx, intent.getStringExtra("u") ?: return, intent.getLongExtra("s", 0L))
        }
    }
}

/** ფანჯარა „დაიწყო: გადაცემა“ — ღილაკები „ყურება“ / „დახურვა“ (პულტითაც მუშაობს) */
class ReminderActivity : Activity() {
    private var dlg: android.app.AlertDialog? = null
    private val h = android.os.Handler(android.os.Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        show(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent); show(intent)
    }

    private fun show(i: Intent) {
        dlg?.dismiss()
        val url = i.getStringExtra("u") ?: run { finish(); return }
        val d = android.app.AlertDialog.Builder(this)
            .setTitle("🔔 დაიწყო")
            .setMessage((i.getStringExtra("t") ?: "") + "\n" + (i.getStringExtra("n") ?: ""))
            .setPositiveButton("ყურება") { _, _ ->
                try { startActivity(Reminders.openIntent(this, url)) } catch (_: Exception) {}
                finish()
            }
            .setNegativeButton("დახურვა") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        dlg = d
        d.show()
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ if (!isFinishing) finish() }, 90_000L)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { dlg?.dismiss() } catch (_: Exception) {}
        super.onDestroy()
    }
}
