package store.televizia.app

/**
 * არქივი (catch-up): გასული გადაცემის ნახვა.
 *  - არხს არქივი აქვს, თუ M3U-ში წერია tvg-rec="დღეები" (ან catchup-days)
 *  - ბმული აიგება შაბლონით (ადმინ-ეკრანი → 🔗 მისამართები → არქივის შაბლონი). ცვლადები:
 *      {url} — არხის სრული ბმული, {base} — ბმული ბოლო "/"-მდე (index.m3u8-ის გარეშე),
 *      {utc} / {start} — გადაცემის დაწყება (წამები, UTC), {end} — დასრულება, {duration} — ხანგრძლივობა წამებში,
 *      {lutc} / {now} — ახლანდელი დრო (წამები)
 */
object Catchup {
    const val DEFAULT = "{url}?utc={utc}&end={end}&lutc={lutc}"

    fun enabled(): Boolean = RemoteConfig.b("features.catchup", true)

    private fun template(): String = RemoteConfig.s("urls.catchup").ifBlank { DEFAULT }

    /** ამ გადაცემის არქივი ხელმისაწვდომია? (უკვე დაწყებულია და არხის არქივის ვადაში ჯდება) */
    fun canPlay(ch: Channel, p: Program): Boolean {
        if (!enabled() || ch.recDays <= 0) return false
        val now = System.currentTimeMillis()
        return p.start < now && p.start > now - ch.recDays * 86_400_000L
    }

    fun url(ch: Channel, p: Program): String {
        val now = System.currentTimeMillis() / 1000
        val start = p.start / 1000
        val end = p.stop / 1000
        var t = template()
        // ბმულს უკვე აქვს პარამეტრები — "?" ცვლის "&"
        if (t.startsWith("{url}?") && ch.url.contains('?')) t = "{url}&" + t.removePrefix("{url}?")
        return t
            .replace("{url}", ch.url)
            .replace("{base}", ch.url.substringBefore('?').substringBeforeLast('/'))
            .replace("{utc}", start.toString())
            .replace("{start}", start.toString())
            .replace("{end}", end.toString())
            .replace("{duration}", (end - start).toString())
            .replace("{lutc}", now.toString())
            .replace("{now}", now.toString())
    }
}
