package store.televizia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.Toast
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.VideoView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * რეკლამა არხის ჩართვამდე (ბანერი ან ვიდეო). სერვერი (api/app_ads.php) წყვეტს, ვის ეჩვენება (მაგ. მხოლოდ სატესტოს).
 * ყოველ მე-N არხზე ერთხელ; გამოტოვება X წამის შემდეგ. ნებისმიერი შეცდომისას რეკლამა გამოტოვდება და არხი ჩვეულებრივად ირთვება.
 */
object AdGate {
    private class Ad(val kind: String, val url: String, val link: String)

    private val ui = Handler(Looper.getMainLooper())
    private var ads: List<Ad> = emptyList()
    private var enabled = false
    private var every = 3
    private var skipSec = 5
    private var imgSec = 8
    private var gotoText = "რეკლამაზე გადასვლა"
    private var fetchedAt = 0L
    @Volatile private var fetching = false

    private var counter = 0
    private var lastUrl = ""
    private var rot = 0
    @Volatile var showing = false
        private set
    private var overlay: View? = null
    private var skipView: View? = null
    private var gotoView: TextView? = null
    private var curLink = ""
    private var curAct: Activity? = null
    private var sel = 0   // პულტით არჩეული ღილაკი: 0 = გამოტოვება, 1 = რეკლამაზე გადასვლა
    private var onFinish: (() -> Unit)? = null

    /** პარამეტრების განახლება სერვერიდან (ფონურ ნაკადში; 20 წუთში ერთხელ) */
    fun refresh(ctx: android.content.Context, force: Boolean = false) {
        val tok = Session.token(ctx) ?: return
        if (fetching || (!force && System.currentTimeMillis() - fetchedAt < 20 * 60_000L && fetchedAt != 0L)) return
        fetching = true
        Thread {
            try {
                val c = (URL("$BASE_URL/api/app_ads.php?token=" + URLEncoder.encode(tok, "UTF-8")).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 6000; readTimeout = 6000
                }
                val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val arr = j.optJSONArray("ads")
                val list = ArrayList<Ad>()
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val u = o.optString("url")
                    if (u.startsWith("http")) list.add(Ad(o.optString("kind"), u, o.optString("link")))
                }
                every = j.optInt("every", 3).coerceAtLeast(1)
                skipSec = j.optInt("skip", 5).coerceIn(0, 30)
                imgSec = j.optInt("img_sec", 8).coerceIn(3, 60)
                gotoText = j.optString("goto_text", "").trim().ifEmpty { "რეკლამაზე გადასვლა" }
                ads = list
                enabled = j.optBoolean("enabled") && list.isNotEmpty()
                fetchedAt = System.currentTimeMillis()
            } catch (_: Exception) {
                fetchedAt = System.currentTimeMillis() - 15 * 60_000L   // შეცდომისას 5 წუთში ხელახლა ვცდით
            } finally { fetching = false }
        }.start()
    }

    /** არხის გაშვება: ან მაშინვე go(), ან რეკლამის დასრულების შემდეგ */
    fun run(a: Activity, channelUrl: String, go: () -> Unit) {
        if (showing && overlay?.isAttachedToWindow != true) showing = false
        if (!enabled || ads.isEmpty() || showing || a.isFinishing || a.isDestroyed) { go(); return }
        if (channelUrl == lastUrl) { go(); return }
        val first = lastUrl.isEmpty()
        lastUrl = channelUrl
        if (first) { go(); return }                    // აპლიკაციის გახსნისას ბოლო არხი რეკლამის გარეშე ირთვება
        if (++counter % every != 0) { go(); return }
        val ad = ads[rot++ % ads.size]
        show(a, ad, go)
    }

    private fun dp(a: Activity, v: Int) = (v * a.resources.displayMetrics.density).toInt()

    private fun show(a: Activity, ad: Ad, go: () -> Unit) {
        val root = a.findViewById<ViewGroup>(android.R.id.content) ?: run { go(); return }
        showing = true
        try { StreamHub.peek()?.player?.playWhenReady = false } catch (_: Exception) {}
        val box = FrameLayout(a).apply {
            setBackgroundColor(Color.BLACK)
            isClickable = true
            elevation = 100f
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        val label = TextView(a).apply {
            text = "რეკლამა"; setTextColor(Color.WHITE); textSize = 13f
            setBackgroundColor(0x99000000.toInt()); setPadding(dp(a, 10), dp(a, 5), dp(a, 10), dp(a, 5))
        }
        box.addView(label, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(a, 12), dp(a, 12), 0, 0) })
        val skip = TextView(a).apply {
            setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
            setPadding(dp(a, 16), dp(a, 10), dp(a, 16), dp(a, 10))
            visibility = View.GONE
        }
        skipView = skip
        box.addView(skip, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(a, 16), dp(a, 24)) })

        // „რეკლამაზე გადასვლა“ — მხოლოდ თუ რეკლამას ბმული აქვს
        curLink = ad.link; curAct = a; sel = 0
        val hasLink = ad.link.startsWith("http")
        val gt = TextView(a).apply {
            text = "$gotoText  ↗"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
            setPadding(dp(a, 16), dp(a, 10), dp(a, 16), dp(a, 10))
            visibility = View.GONE
        }
        gotoView = gt
        box.addView(gt, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(a, 16), 0, 0, dp(a, 24)) })
        paintButtons(a)

        var done = false
        var tick: Runnable? = null
        fun finish() {
            if (done) return
            done = true
            tick?.let { ui.removeCallbacks(it) }
            (box.parent as? ViewGroup)?.removeView(box)
            overlay = null; onFinish = null; showing = false; gotoView = null; skipView = null; curAct = null
            try { go() } catch (_: Exception) {}
        }
        onFinish = { finish() }

        var left = skipSec
        var started = false
        fun startCountdown(total: Int) {
            if (started) return
            started = true
            var elapsed = 0
            skip.visibility = View.VISIBLE
            if (hasLink) gt.visibility = View.VISIBLE   // პულტზე ნაგულისხმევად არჩეულია „გამოტოვება“ (OK, როგორც ადრე); ← ღილაკით ირჩევა „რეკლამაზე გადასვლა“
            paintButtons(a)
            tick = object : Runnable {
                override fun run() {
                    left = skipSec - elapsed
                    skip.text = if (left > 0) "გამოტოვება $left" else "გამოტოვება ›"
                    skip.tag = left <= 0
                    if (total > 0 && elapsed >= total) { finish(); return }
                    elapsed++
                    ui.postDelayed(this, 1000)
                }
            }.also { ui.post(it) }
        }
        skip.setOnClickListener { if (skip.tag == true) finish() }
        gt.setOnClickListener { openLink(a, ad.link) }
        box.setOnClickListener { openLink(a, ad.link) }
        box.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {}
            override fun onViewDetachedFromWindow(v: View) { if (!done) { done = true; tick?.let { ui.removeCallbacks(it) }; overlay = null; showing = false } }
        })
        root.addView(box)
        overlay = box

        if (ad.kind == "video") {
            val vv = VideoView(a)
            box.addView(vv, 0, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            vv.setOnPreparedListener { it.isLooping = false; vv.start(); startCountdown(75) }
            vv.setOnCompletionListener { finish() }
            vv.setOnErrorListener { _, _, _ -> finish(); true }
            try { vv.setVideoURI(Uri.parse(ad.url)) } catch (_: Exception) { finish(); return }
            ui.postDelayed({ if (!started) finish() }, 9000)   // 9 წამში არ ჩაიტვირთა — გამოტოვება
        } else {
            val iv = ImageView(a).apply { scaleType = ImageView.ScaleType.FIT_CENTER; adjustViewBounds = true }
            box.addView(iv, 0, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            Thread {
                var bmp: Bitmap? = null
                try {
                    val c = (URL(ad.url).openConnection() as HttpURLConnection).apply { connectTimeout = 6000; readTimeout = 8000 }
                    bmp = BitmapFactory.decodeStream(c.inputStream)
                } catch (_: Exception) {}
                ui.post {
                    if (done) return@post
                    if (bmp == null) { finish(); return@post }
                    iv.setImageBitmap(bmp)
                    startCountdown(imgSec)
                }
            }.start()
            ui.postDelayed({ if (!started) finish() }, 9000)
        }
    }

    private fun openLink(a: Activity, link: String) {
        if (!link.startsWith("http")) return
        try { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { try { Toast.makeText(a, link, Toast.LENGTH_LONG).show() } catch (_: Exception) {} }   // ტელევიზორზე ბრაუზერი არ არის — ბმული ეკრანზე ჩანს
    }

    /** არჩეული ღილაკი ჩარჩოთი გამოიყოფა (პულტისთვის) */
    private fun paintButtons(a: Activity) {
        fun bg(selected: Boolean, base: Int) = GradientDrawable().apply {
            setColor(base); cornerRadius = dp(a, 6).toFloat()
            if (selected) setStroke(dp(a, 3), 0xFF00F0D4.toInt()) else setStroke(dp(a, 1), 0x55FFFFFF)
        }
        val hasGo = gotoView?.visibility == View.VISIBLE
        skipView?.background = bg(sel == 0 || !hasGo, 0xCC222222.toInt())
        gotoView?.background = bg(sel == 1 && hasGo, 0xCC0B5C52.toInt())
    }

    /** პულტი/ღილაკები რეკლამის დროს: ←/→ ღილაკებს შორის გადართვა; OK — არჩეული ღილაკი (გადასვლა / გამოტოვება); BACK — გამოტოვება; დანარჩენი იბლოკება */
    fun key(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
            val hasGo = gotoView?.visibility == View.VISIBLE
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> if (hasGo) { sel = 1; curAct?.let { paintButtons(it) } }
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (hasGo) { sel = 0; curAct?.let { paintButtons(it) } }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_SPACE -> {
                    if (hasGo && sel == 1) curAct?.let { openLink(it, curLink) }
                    else if (skipView?.tag == true) onFinish?.invoke()
                }
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> if (skipView?.tag == true) onFinish?.invoke()
            }
        }
        // ხმის ღილაკები ჩვეულებრივად მუშაობს
        return e.keyCode != KeyEvent.KEYCODE_VOLUME_UP && e.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN && e.keyCode != KeyEvent.KEYCODE_VOLUME_MUTE
    }
}
