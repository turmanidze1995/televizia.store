package store.televizia.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AlertDialog
import androidx.core.content.pm.PackageInfoCompat

/**
 * დისტანციური პარამეტრების გამოყენება ეკრანზე: ტექნიკური სამუშაოები, იძულებითი / ახალი ვერსია,
 * შეტყობინება მომხმარებლებისთვის, ფუნქციების ჩართვა-გამორთვა.
 */
object Gate {
    private var dlg: AlertDialog? = null
    private var updateDeclined = false

    fun dismiss() {
        try { dlg?.dismiss() } catch (_: Exception) {}
        dlg = null
    }

    /** ჯერ ქეშირებული პარამეტრები მყისიერად, შემდეგ სერვერიდან განახლებული */
    fun check(a: BaseActivity, done: (Boolean) -> Unit = {}, features: () -> Unit) {
        features()
        val app = a.applicationContext
        Thread {
            RemoteConfig.fetch(app)
            a.runOnUiThread {
                if (a.isFinishing || a.isDestroyed) return@runOnUiThread
                features()
                done(show(a))   // true = ფანჯარა გამოჩნდა
            }
        }.start()
    }

    fun versionCode(ctx: Context): Long = try {
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
    } catch (e: Exception) { 0L }

    /** განახლების ღილაკი: პირდაპირი APK-ის ბმულზე — განახლება აპლიკაციაში; სხვა ბმულზე — ბრაუზერი */
    private fun doUpdate(a: BaseActivity, url: String) {
        val path = url.substringBefore('?').lowercase()
        if (RemoteConfig.b("update.in_app", false) || path.endsWith(".apk")) {
            Updater.start(a, url, RemoteConfig.s("update.sha256"), RemoteConfig.i("update.size", 0).toLong())
        } else open(a, url)
    }

    private fun open(a: Context, url: String) {
        try { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    private fun show(a: BaseActivity): Boolean {
        val cur = versionCode(a)
        val updUrl = RemoteConfig.s("update.url")
        val updMsg = RemoteConfig.s("update.message").ifBlank { a.getString(R.string.update_default) }
        val force = RemoteConfig.i("update.force_below", 0)
        val latest = RemoteConfig.i("update.latest_code", 0)

        if (RemoteConfig.b("maintenance.on", false)) {
            blocking(a, a.getString(R.string.maintenance_title),
                RemoteConfig.s("maintenance.message").ifBlank { a.getString(R.string.maintenance_default) },
                a.getString(R.string.close_btn)) { a.finishAffinity() }
            return true
        }
        if (force > 0 && cur < force) {
            blocking(a, a.getString(R.string.update_title), updMsg,
                a.getString(if (updUrl.isNotBlank()) R.string.update_btn else R.string.close_btn)) {
                if (updUrl.isNotBlank()) doUpdate(a, updUrl) else a.finishAffinity()
            }
            return true
        }
        // სხვა დროს ვაჩვენებთ ხელახლა მხოლოდ თუ ბლოკი მოიხსნა
        if (dlg?.isShowing == true) dismiss()

        val name = RemoteConfig.s("update.latest_name")
        val curName = try { a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        val sameName = name.isNotBlank() && name.trim() == curName.trim()
        if (latest > cur && !updateDeclined && !sameName) {
            val b = AlertDialog.Builder(a)
                .setTitle(a.getString(R.string.update_title) + if (name.isNotBlank()) " $name" else "")
                .setMessage(updMsg)
                .setPositiveButton(if (updUrl.isNotBlank()) R.string.update_btn else android.R.string.ok) { _, _ ->
                    if (updUrl.isNotBlank()) doUpdate(a, updUrl)
                }
                .setNegativeButton(R.string.later_btn) { _, _ -> updateDeclined = true }
            dlg = b.show()
            return true
        }

        if (RemoteConfig.b("announcement.on", false)) {
            val title = RemoteConfig.s("announcement.title")
            val text = RemoteConfig.s("announcement.text")
            val url = RemoteConfig.s("announcement.url")
            if (title.isBlank() && text.isBlank()) return false
            val id = (title + "|" + text + "|" + url).hashCode().toString()
            val prefs = a.getSharedPreferences("tv_remote", Context.MODE_PRIVATE)
            if (prefs.getString("seen_ann", "") == id) return false
            val b = AlertDialog.Builder(a)
                .setTitle(title.ifBlank { a.getString(R.string.announcement_title) })
                .setMessage(text)
                .setPositiveButton(android.R.string.ok) { _, _ -> prefs.edit().putString("seen_ann", id).apply() }
                .setOnCancelListener { prefs.edit().putString("seen_ann", id).apply() }
            if (url.isNotBlank()) b.setNeutralButton(R.string.open_btn) { _, _ ->
                prefs.edit().putString("seen_ann", id).apply()
                open(a, url)
            }
            dlg = b.show()
            return true
        }
        return false
    }

    /** დაუხურავი ფანჯარა: ღილაკი ფანჯარას არ ხურავს (მხოლოდ მოქმედებას ასრულებს) */
    private fun blocking(a: BaseActivity, title: String, msg: String, btn: String, action: () -> Unit) {
        dismiss()
        val d = AlertDialog.Builder(a).setTitle(title).setMessage(msg).setCancelable(false)
            .setPositiveButton(btn, null).create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { action() }
        dlg = d
    }
}
