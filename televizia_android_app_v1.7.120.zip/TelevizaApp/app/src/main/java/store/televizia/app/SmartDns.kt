package store.televizia.app

import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.InetAddress
import java.net.URLEncoder
import java.net.UnknownHostException
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * v1.7.113: ჭკვიანი DNS არხების ჩასართავად.
 *
 * პრობლემა: ზოგ Wi-Fi/ოპერატორზე ინტერნეტის DNS ნელია, არასწორ მისამართს აბრუნებს ან მომწოდებლის დომენს ბლოკავს —
 * არხი „ტრიალებს და ტრიალებს“, სხვა ინტერნეტზე კი მაშინვე იხსნება.
 *
 * მუშაობს ასე:
 *  1) ჯერ ინტერნეტის საკუთარი (სისტემური) DNS — მაქსიმუმ 2 წმ (ის იძლევა ყველაზე ახლო სერვერს);
 *  2) თუ ვერ უპასუხა / დაბლოკილი მისამართი დააბრუნა (0.0.0.0, 127.x) — პარალელურად ვკითხავთ Cloudflare 1.1.1.1-ს და Google 8.8.8.8-ს
 *     (DNS-over-HTTPS, 443 პორტი — ოპერატორი ვერ ჩაერევა); პირველი პასუხი იმარჯვებს;
 *  3) თუ სისტემური DNS ერთხელ დაგვიანდა — 2 წუთით პირდაპირ 2-ზე გადავდივართ (ყოველ დომენზე 2 წმ არ ვკარგავთ);
 *  4) პასუხები 5 წუთით ინახება; ორივე წყარო თუ ჩავარდა, ძველი შენახული მისამართი გამოიყენება (24 საათამდე).
 * გამორთვა სერვერიდან: player.smart_dns = 0
 */
object SmartDns : Dns {
    private class Hit(val addrs: List<InetAddress>, val at: Long)

    private val cache = ConcurrentHashMap<String, Hit>()
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "smartdns").apply { isDaemon = true } }
    @Volatile private var sysBadUntil = 0L

    // IP-მისამართებით ვუკავშირდებით (ამ დროს DNS საერთოდ არ გვჭირდება), ამიტომ ეს კლიენტი არასოდეს ჩაიკეტება DNS-ზე
    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(2500, TimeUnit.MILLISECONDS)
            .readTimeout(2500, TimeUnit.MILLISECONDS)
            .callTimeout(3500, TimeUnit.MILLISECONDS)
            .build()
    }

    override fun lookup(hostname: String): List<InetAddress> {
        if (!RemoteConfig.b("player.smart_dns", true)) return Dns.SYSTEM.lookup(hostname)
        if (hostname.isEmpty()) throw UnknownHostException("empty host")
        val now = System.currentTimeMillis()
        val c = cache[hostname]
        if (c != null && now - c.at < 300_000L) return c.addrs

        var res: List<InetAddress>? = null
        if (now >= sysBadUntil) {
            try {
                val l = pool.submit(Callable { Dns.SYSTEM.lookup(hostname) }).get(2000, TimeUnit.MILLISECONDS)
                if (l.isNotEmpty() && !l.all { it.isAnyLocalAddress || it.isLoopbackAddress }) res = l
            } catch (e: TimeoutException) {
                sysBadUntil = now + 120_000L
            } catch (e: Exception) {
                // UnknownHostException და სხვა — გადავდივართ DoH-ზე
            }
        }
        if (res == null) res = viaDoh(hostname)
        if (res != null && res.isNotEmpty()) {
            cache[hostname] = Hit(res, System.currentTimeMillis())
            return res
        }
        if (c != null && now - c.at < 86_400_000L) return c.addrs
        throw UnknownHostException(hostname)
    }

    /** Cloudflare და Google პარალელურად; პირველი წარმატებული პასუხი */
    private fun viaDoh(host: String): List<InetAddress>? {
        val jobs = listOf(
            Callable { dohBoth("https://1.1.1.1/dns-query", host) },
            Callable { dohBoth("https://8.8.8.8/resolve", host) }
        )
        return try {
            pool.invokeAny(jobs, 4, TimeUnit.SECONDS)
        } catch (e: Exception) {
            null
        }
    }

    private fun dohBoth(base: String, host: String): List<InetAddress> {
        val a = doh(base, host, "A")
        if (a.isNotEmpty()) return a
        val aaaa = doh(base, host, "AAAA")
        if (aaaa.isNotEmpty()) return aaaa
        throw UnknownHostException(host)   // invokeAny-ს სხვა წყაროს პასუხს დაველოდოთ
    }

    private fun doh(base: String, host: String, type: String): List<InetAddress> {
        val url = base + "?name=" + URLEncoder.encode(host, "UTF-8") + "&type=" + type
        val req = Request.Builder().url(url).header("accept", "application/dns-json").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return emptyList()
            val body = r.body?.string() ?: return emptyList()
            val arr = JSONObject(body).optJSONArray("Answer") ?: return emptyList()
            val out = ArrayList<InetAddress>()
            for (i in 0 until arr.length()) {
                val a = arr.getJSONObject(i)
                val t = a.optInt("type")
                if (t != 1 && t != 28) continue          // მხოლოდ A / AAAA (CNAME-ს ვტოვებთ)
                val d = a.optString("data")
                if (d.isEmpty() || !(d[0].isDigit() || d.contains(':'))) continue
                try { out.add(InetAddress.getByName(d)) } catch (_: Exception) {}   // IP-ლიტერალზე DNS არ სრულდება
            }
            return out
        }
    }
}
