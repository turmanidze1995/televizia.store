package store.televizia.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * მრგვალი ჩატვირთვის ინდიკატორი TELEVIZIA.STORE-ის გრადიენტული ფერებით (ტიალი → ლურჯ-ნაცრისფერი → ვარდისფერი).
 * თავისით ბრუნავს, სანამ ხილულია; დამალვისას ანიმაცია ჩერდება.
 */
class GradientSpinner @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x22FFFFFF
    }
    private val rect = RectF()
    private var angle = 0f
    private var sweepAnim = 0f
    private var rotator: ValueAnimator? = null
    private var hueShift = 0f

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val stroke = minOf(w, h) * 0.11f
        arcPaint.strokeWidth = stroke
        trackPaint.strokeWidth = stroke
        val pad = stroke / 2f + dp(1f)
        rect.set(pad, pad, w - pad, h - pad)
        rebuildShader()
    }

    /** ყველა ფერი გრადიენტში: რკალზე მთელი ფერთა სპექტრია, ტრიალისას ფერები თანდათან იცვლება */
    private fun rebuildShader() {
        if (width == 0 || height == 0) return
        val n = 9
        val colors = IntArray(n + 1)
        val pos = FloatArray(n + 1)
        for (i in 0 until n) {
            val hue = (hueShift + i * 300f / (n - 1)) % 360f
            colors[i] = Color.HSVToColor(floatArrayOf(hue, 0.80f, 1f))
            pos[i] = i * 0.75f / (n - 1)
        }
        colors[n] = colors[n - 1] and 0x00FFFFFF
        pos[n] = 0.76f
        arcPaint.shader = SweepGradient(width / 2f, height / 2f, colors, pos)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val def = dp(36f).toInt() // ზომა როგორც ძველ ინდიკატორზე
        val w = resolveSize(def, widthMeasureSpec)
        val h = resolveSize(def, heightMeasureSpec)
        val s = minOf(w, h)
        setMeasuredDimension(s, s)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawOval(rect, trackPaint)
        canvas.save()
        canvas.rotate(angle, width / 2f, height / 2f)
        canvas.drawArc(rect, 0f, 270f, false, arcPaint)
        canvas.restore()
    }

    private fun startSpin() {
        if (rotator != null) return
        rotator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                angle = it.animatedValue as Float
                hueShift = (hueShift + 2.4f) % 360f   // ~2.5 წმ-ში მთელი სპექტრი
                rebuildShader()
                invalidate()
            }
            start()
        }
    }

    private fun stopSpin() {
        rotator?.cancel()
        rotator = null
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) startSpin() else stopSpin()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (visibility == VISIBLE && windowVisibility == VISIBLE) startSpin()
    }

    override fun onDetachedFromWindow() {
        stopSpin()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE && this.visibility == VISIBLE) startSpin() else stopSpin()
    }
}
