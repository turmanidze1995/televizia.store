package store.televizia.app

data class Channel(
    val name: String, val logo: String, val url: String, val group: String, val epgId: String = "", val recDays: Int = 0,
    /** M3U: catchup="flussonic|default|append|shift|xc|…" (ცარიელი = shift) */
    val cuType: String = "",
    /** M3U: catchup-source="…" */
    val cuSource: String = ""
) {
    /** XMLTV არხის ID, რომელსაც ეს არხი დაუკავშირდა (ივსება Epg.attach-ით) */
    @Volatile var epgKey: String = ""
}

/** M3U სიის წამკითხველი: სახელი, ლოგო, ჯგუფი (group-title), tvg-id და სტრიმის ლინკი */
object M3u {
    private val logoRegex = Regex("""tvg-logo\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val groupRegex = Regex("""group-title\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val idRegex = Regex("""tvg-id\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val recRegexes = listOf("tvg-rec", "catchup-days", "timeshift")
        .map { Regex("""(?<![\w-])$it\s*=\s*["']?(\d+)""", RegexOption.IGNORE_CASE) }
    private val cuTypeRegex = Regex("""(?<![\w-])catchup(?:-type)?\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val cuSourceRegex = Regex("""catchup-source\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val tvgNameRegex = Regex("""tvg-name\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val epgRegex = Regex("""(?:url-tvg|x-tvg-url)\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)

    /** სწრაფი ატრიბუტის ამოკითხვა (key="value"); null — თუ ამ ხაზში ასეთი ატრიბუტი არ არის ან ფორმატი უჩვეულოა (მაშინ regex-ს ვიყენებთ) */
    private fun attr(line: String, key: String, fallback: Regex): String {
        val i = line.indexOf(key, 0, ignoreCase = true)
        if (i < 0) return ""
        var j = i + key.length
        while (j < line.length && line[j] == ' ') j++
        if (j < line.length && line[j] == '=') {
            j++
            while (j < line.length && line[j] == ' ') j++
            if (j < line.length && (line[j] == '"' || line[j] == '\'')) {
                j++
                var k = j
                while (k < line.length && line[k] != '"' && line[k] != '\'') k++
                if (k < line.length) return line.substring(j, k)
            }
        }
        return fallback.find(line)?.groupValues?.get(1) ?: ""
    }

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>(512)
        var name = ""
        var logo = ""
        var group = ""
        var epgId = ""
        var rec = 0
        var cuType = ""
        var cuSrc = ""
        val hdr = LinkedHashMap<String, String>()   // #EXTVLCOPT / #EXTHTTP / #KODIPROP სათაურები შემდეგი არხისთვის
        for (raw in text.lineSequence()) {
            val line = raw.trim().removePrefix("\uFEFF")
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF")) {
                name = if (line.contains(',')) line.substringAfterLast(',').trim() else ""
                if (name.isEmpty()) name = attr(line, "tvg-name", tvgNameRegex).trim()
                logo = attr(line, "tvg-logo", logoRegex)
                group = attr(line, "group-title", groupRegex)
                epgId = attr(line, "tvg-id", idRegex)
                // არქივის დღეები: tvg-rec / catchup-days / timeshift — რომელიც მეტია (სერვერზე ხშირად ერთი მათგანია მითითებული)
                rec = 0
                for (r in recRegexes) { val v = r.find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 0; if (v > rec) rec = v }
                cuType = cuTypeRegex.find(line)?.groupValues?.get(1)?.trim()?.lowercase() ?: ""
                cuSrc = cuSourceRegex.find(line)?.groupValues?.get(1) ?: ""
            } else if (line.startsWith("#")) {
                readHeaderLine(line, hdr)
            } else {
                val u = if (hdr.isNotEmpty() && !line.contains('|')) line + "|" + hdr.entries.joinToString("&") { it.key + "=" + java.net.URLEncoder.encode(it.value, "UTF-8") } else line
                out.add(Channel(name.ifEmpty { Lang.s(R.string.channel_default) }, logo, u, group.ifBlank { Lang.OTHER }, epgId, rec, cuType, cuSrc))
                name = ""; logo = ""; group = ""; epgId = ""; rec = 0; cuType = ""; cuSrc = ""
                hdr.clear()
            }
        }
        return out
    }

    /** #EXTVLCOPT:http-user-agent=… / http-referrer=… / http-origin=… / http-cookie=…, #EXTHTTP:{"User-Agent":"…"}, #KODIPROP:inputstream.adaptive.stream_headers=K=V&K=V */
    private fun readHeaderLine(line: String, hdr: MutableMap<String, String>) {
        try {
            if (line.startsWith("#EXTVLCOPT", true)) {
                val body = line.substringAfter(':', "")
                val k = body.substringBefore('=').trim().lowercase()
                val v = body.substringAfter('=', "").trim().trim('"')
                if (v.isEmpty()) return
                when (k) {
                    "http-user-agent" -> hdr["User-Agent"] = v
                    "http-referrer", "http-referer" -> hdr["Referer"] = v
                    "http-origin" -> hdr["Origin"] = v
                    "http-cookie" -> hdr["Cookie"] = v
                }
            } else if (line.startsWith("#EXTHTTP", true)) {
                val j = org.json.JSONObject(line.substringAfter(':', "").trim())
                val it = j.keys()
                while (it.hasNext()) { val k = it.next(); val v = j.optString(k); if (v.isNotEmpty()) hdr[normHeader(k)] = v }
            } else if (line.startsWith("#KODIPROP", true) && line.contains("stream_headers", true)) {
                for (p in line.substringAfter("stream_headers=", "").split('&')) {
                    val k = p.substringBefore('=').trim(); val v = p.substringAfter('=', "").trim()
                    if (k.isNotEmpty() && v.isNotEmpty()) hdr[normHeader(k)] = v
                }
            }
        } catch (_: Exception) {}
    }

    private fun normHeader(k: String): String = when (k.lowercase()) {
        "user-agent" -> "User-Agent"; "referer", "referrer" -> "Referer"; "origin" -> "Origin"; "cookie" -> "Cookie"; else -> k
    }

    /** არხის ბმული "url|User-Agent=…&Referer=…" → (სუფთა ბმული, სათაურები) */
    fun split(u: String): Pair<String, Map<String, String>> {
        val i = u.indexOf('|')
        if (i < 0) return Pair(u, emptyMap())
        val m = LinkedHashMap<String, String>()
        for (p in u.substring(i + 1).split('&')) {
            val k = p.substringBefore('=').trim()
            if (k.isEmpty() || !p.contains('=')) continue
            val raw = p.substringAfter('=')
            val v = try { java.net.URLDecoder.decode(raw.replace("+", "%2B"), "UTF-8") } catch (_: Exception) { raw }
            m[normHeader(k)] = v.trim()
        }
        return Pair(u.substring(0, i), m)
    }

    /** სიის პირველ ხაზში მითითებული EPG ბმულები: #EXTM3U url-tvg="a.xml,b.xml" */
    fun epgUrls(text: String): List<String> {
        val head = text.lineSequence().take(5).firstOrNull { it.trim().removePrefix("\uFEFF").startsWith("#EXTM3U") }
            ?: return emptyList()
        val m = epgRegex.find(head) ?: return emptyList()
        return m.groupValues[1].split(',').map { it.trim() }.filter { it.startsWith("http") }
    }
}
