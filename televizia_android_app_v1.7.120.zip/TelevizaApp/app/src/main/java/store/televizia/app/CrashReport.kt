package store.televizia.app

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build

/**
 * v1.7.115: ჩავარდნის/გაყინვის (ANR) დიაგნოსტიკა.
 * აპის წინა სესიის დასრულების მიზეზს ოპერაციული სისტემა ინახავს (Android 11+). შემდეგ გახსნისას ვკითხულობთ და სერვერს ვუგზავნით,
 * ადმინის „მოვლენებში“ რომ ზუსტად ჩანდეს, რა იყინება (ANR-ის შემთხვევაში — მთავარი ნაკადის სტეკიც) და რომელ მოწყობილობაზე.
 * ახალი ინფორმაცია მხოლოდ ერთხელ იგზავნება. ანგარიშის მონაცემები და არხები არ იგზავნება.
 */
object CrashReport {
    private const val PREFS = "crash_report"

    /** ახალი (ჯერ გაუგზავნელი) ჩავარდნების ტექსტი; ცარიელი = არაფერია გასაგზავნი */
    fun collect(ctx: Context): String {
        val sb = StringBuilder()
        val sp = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val lastTs = sp.getLong("last_ts", 0L)
                var maxTs = lastTs
                val list = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 6)
                for (i in list) {
                    if (i.timestamp <= lastTs) continue
                    val name = when (i.reason) {
                        ApplicationExitInfo.REASON_ANR -> "ANR (გაყინვა)"
                        ApplicationExitInfo.REASON_CRASH -> "CRASH (Java)"
                        ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH (native)"
                        ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "INIT FAILURE"
                        ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW MEMORY"
                        ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "EXCESSIVE RESOURCE USAGE"
                        else -> null
                    } ?: continue
                    if (i.timestamp > maxTs) maxTs = i.timestamp
                    // v1.7.119: LOW MEMORY ხშირად ჩვეულებრივი ფონური გათიშვაა (აპი ფონზე იყო და სისტემამ მეხსიერება გაათავისუფლა) — ეს ჩავარდნა არაა.
                    // ვაგზავნით მხოლოდ მაშინ, როცა აპი ეკრანზე/წინა პლანზე იყო (importance <= 200).
                    if (i.reason == ApplicationExitInfo.REASON_LOW_MEMORY && i.importance > 200) continue
                    sb.append("• ").append(name).append(" · ").append(java.text.SimpleDateFormat("dd.MM HH:mm:ss", java.util.Locale.US).format(java.util.Date(i.timestamp)))
                    sb.append(" · rss ").append(i.rss / 1024).append(" MB · imp ").append(i.importance).append("\n")
                    val d = i.description
                    if (!d.isNullOrEmpty()) sb.append("  ").append(d.take(300)).append('\n')
                    if (i.reason == ApplicationExitInfo.REASON_ANR) {
                        val tr = try { i.traceInputStream?.bufferedReader()?.use { it.readText() } } catch (_: Throwable) { null }
                        if (!tr.isNullOrEmpty()) {
                            val at = tr.indexOf("\"main\" prio")
                            sb.append(tr.substring(if (at >= 0) at else 0).take(2600)).append('\n')
                        }
                    }
                }
                if (maxTs > lastTs) sp.edit().putLong("last_ts", maxTs).apply()
            }
        } catch (_: Throwable) {}
        try {
            // v1.7.119: მთავარი ნაკადის გაყინვის სტეკები (Watchdog) — ზუსტად ჩანს, რომელი კოდი ბლოკავს ღილაკზე დაჭერას
            val st = Watchdog.take(ctx)
            if (st.isNotEmpty()) sb.append("• MAIN THREAD STALL (სად ჭედავს):\n").append(st.take(2400)).append('\n')
        } catch (_: Throwable) {}
        try {
            // Java ჩავარდნის სტეკი (ადგილობრივად ინახება DeviceProfile-ში) — მხოლოდ ახალი
            val lc = DeviceProfile.lastCrash()
            if (lc.isNotEmpty() && lc.hashCode().toString() != sp.getString("last_java", "")) {
                sb.append("• Java stack:\n").append(lc.take(1800)).append('\n')
                sp.edit().putString("last_java", lc.hashCode().toString()).apply()
            }
        } catch (_: Throwable) {}
        return sb.toString().take(5800)
    }
}
