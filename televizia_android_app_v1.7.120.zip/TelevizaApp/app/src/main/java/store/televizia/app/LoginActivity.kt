package store.televizia.app

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.BarcodeFormat
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import store.televizia.app.databinding.ActivityLoginBinding

/**
 * შესვლის სამი გზა:
 *  1) ელფოსტა + პაროლი
 *  2) QR სკანირება ტელეფონით (კაბინეტის QR-დან)
 *  3) TV კოდი: TV აჩვენებს QR-ს და კოდს, ტელეფონით დადასტურება საიტზე
 */
class LoginActivity : BaseActivity() {
    private lateinit var b: ActivityLoginBinding
    private val h = Handler(Looper.getMainLooper())
    private var pollR: Runnable? = null
    private var socialCode: String? = null
    private var socialNeedsConfirm = false
    private var handoffCode: String? = null

    private val scanner = registerForActivityResult(ScanContract()) { result ->
        val raw = result.contents ?: return@registerForActivityResult
        val code = Uri.parse(raw).getQueryParameter("code") ?: raw.trim()
        claimCode(code)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // საიტის აპლიკაციიდან გადმოსვლა: televizia://login?code=... — ავტომატური შესვლა
        val handoff = intent?.data?.takeIf { it.scheme == "televizia" }?.getQueryParameter("code")?.takeIf { it.isNotBlank() }
        if (handoff == null && Session.token(this) != null) {
            openMain()
            return
        }
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)
        if (handoff != null) { handoffCode = handoff; claimCode(handoff) }

        val hasCamera = packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
        b.btnScan.visibility = if (hasCamera) View.VISIBLE else View.GONE

        b.btnLogin.setOnClickListener { doLogin() }
        b.btnScan.setOnClickListener {
            scanner.launch(
                ScanOptions()
                    .setPrompt(getString(R.string.qr_prompt))
                    .setBeepEnabled(false)
                    .setOrientationLocked(false)
            )
        }
        b.btnTv.setOnClickListener { startTvPairing() }
        b.btnGoogle.setOnClickListener { startSocial("google") }
        b.btnYandex.setOnClickListener { startSocial("yandex") }
        b.btnTelegram.setOnClickListener { startSocial("telegram") }
        b.btnAdmin.setOnClickListener { startActivity(Intent(this, AdminActivity::class.java)) }
        b.btnLang.text = "\uD83C\uDF10 " + Lang.names[Lang.codes.indexOf(Lang.current()).coerceAtLeast(0)]
        b.btnLang.setOnClickListener { showLanguageDialog() }

        Gate.check(this) { applyFeatures(hasCamera) }
    }

    /** ფუნქციების ჩართვა/გამორთვა და შეტყობინება — სერვერიდან (ადმინ-ეკრანი → აპლიკაცია) */
    private fun applyFeatures(hasCamera: Boolean) {
        fun vis(on: Boolean) = if (on) View.VISIBLE else View.GONE
        b.btnScan.visibility = vis(hasCamera && RemoteConfig.b("features.qr_login", true))
        b.btnTv.visibility = vis(RemoteConfig.b("features.tv_login", true))
        b.socialBox.visibility = vis(RemoteConfig.b("features.social_login", true))
        b.btnLang.visibility = vis(RemoteConfig.b("features.lang_button", true))
        b.btnAdmin.visibility = vis(RemoteConfig.b("features.admin_button", true))
        val notice = RemoteConfig.s("texts.login_notice")
        b.notice.text = notice
        b.notice.visibility = vis(notice.isNotBlank())
    }

    override fun onDestroy() {
        stopPolling()
        super.onDestroy()
    }

    private fun doLogin() {
        val email = b.email.text.toString().trim()
        val password = b.password.text.toString()
        if (email.isEmpty() || password.isEmpty()) {
            b.status.text = getString(R.string.fill_all)
            return
        }
        b.btnLogin.isEnabled = false
        b.status.text = getString(R.string.checking)
        Thread {
            val res = Api.login(email, password)
            runOnUiThread {
                b.btnLogin.isEnabled = true
                if (res.ok && res.token != null) {
                    Session.save(this, res.token, res.name)
                    openMain()
                } else {
                    b.status.text = res.message
                }
            }
        }.start()
    }

    private fun claimCode(code: String) {
        b.status.text = getString(R.string.checking)
        Thread {
            val res = PairApi.check(code)
            runOnUiThread {
                if (res.state == PairState.OK && res.token != null) {
                    Session.save(this, res.token, res.name)
                    openMain()
                } else if (handoffCode == code && Session.token(this) != null) {
                    openMain()
                } else {
                    b.status.text = res.message.ifEmpty { getString(R.string.code_not_confirmed) }
                }
            }
        }.start()
    }

    private fun startTvPairing() {
        stopPolling()
        b.tvPanel.visibility = View.VISIBLE
        b.tvStatus.text = getString(R.string.code_preparing)
        // QR სათაურის ქვემოთაა (ზევით) — ეკრანი ზევით ავაგოთ, რომ მაშინვე ჩანდეს
        (b.root as? android.widget.ScrollView)?.post { (b.root as android.widget.ScrollView).smoothScrollTo(0, 0) }
        Thread {
            val start = PairApi.start()
            runOnUiThread {
                if (!start.ok) {
                    b.tvStatus.text = start.message
                    return@runOnUiThread
                }
                try {
                    val url = "$BASE_URL/public/pair.php?code=${start.code}"
                    b.qrImage.setImageBitmap(BarcodeEncoder().encodeBitmap(url, BarcodeFormat.QR_CODE, 520, 520))
                } catch (e: Exception) {
                    b.tvStatus.text = getString(R.string.qr_failed)
                    return@runOnUiThread
                }
                b.tvCode.text = start.code.chunked(4).joinToString("-")
                b.tvStatus.text = getString(R.string.qr_scan_hint)
                startPolling(start.code)
            }
        }.start()
    }

    /** Google/Yandex/Telegram: შესვლა ბრაუზერში (Google WebView-ს კრძალავს), დაბრუნებისას კოდი დასტურდება და აპლიკაცია თვითონ შედის */
    private fun startSocial(provider: String) {
        b.status.text = getString(R.string.code_preparing)
        Thread {
            val start = PairApi.start()
            runOnUiThread {
                if (!start.ok) {
                    b.status.text = start.message
                    return@runOnUiThread
                }
                socialCode = start.code
                socialNeedsConfirm = true
                b.status.text = getString(R.string.social_hint)
                openBrowser("$BASE_URL/public/social_login.php?provider=$provider&pair=${start.code}")
                startPolling(start.code)
            }
        }.start()
    }

    private fun openBrowser(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            // TV-ზე ბრაუზერი შეიძლება არ იყოს — QR/კოდით შესვლა ყოველთვის მუშაობს
            b.status.text = getString(R.string.no_browser_tv)
            stopPolling()
        }
    }

    /** საიტი აბრუნებს აპლიკაციაში (televizia://login) — კოდის შემოწმება მაშინვე */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val deep = intent.data?.takeIf { it.scheme == "televizia" }?.getQueryParameter("code")?.takeIf { it.isNotBlank() }
        if (deep != null && ::b.isInitialized) { handoffCode = deep; claimCode(deep); return }
        val code = socialCode ?: return
        if (::b.isInitialized && intent.data?.scheme == "televizia") { socialNeedsConfirm = false; claimCode(code) }
    }

    private fun startPolling(code: String) {
        stopPolling()
        pollR = Runnable {
            Thread {
                val res = PairApi.check(code)
                runOnUiThread {
                    when (res.state) {
                        PairState.OK -> {
                            stopPolling()
                            Session.save(this, res.token!!, res.name)
                            openMain()
                        }
                        PairState.PENDING -> pollR?.let { h.postDelayed(it, 3000) }
                        PairState.ERROR -> {
                            stopPolling()
                            b.tvStatus.text = res.message
                        }
                    }
                }
            }.start()
        }
        pollR?.let { h.post(it) }
    }

    private fun stopPolling() {
        pollR?.let { h.removeCallbacks(it) }
        pollR = null
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java).apply { if (handoffCode != null) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK) })
        finish()
    }
}
