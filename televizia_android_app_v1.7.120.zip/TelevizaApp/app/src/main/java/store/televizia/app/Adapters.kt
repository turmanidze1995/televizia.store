package store.televizia.app

import android.graphics.Color
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import store.televizia.app.databinding.ItemChannelBinding
import store.televizia.app.databinding.ItemProgramBinding

/** არხების სია: ნომერი, ლოგო, სახელი, ამჟამინდელი და შემდეგი გადაცემა (EPG) */
class ChannelAdapter(private val onClick: (Channel, Int) -> Unit) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    private var items: List<Channel> = emptyList()
    private var selectedUrl: String? = null
    /** გრძელი დაჭერა (OK / შეხება) — არხის მენიუ: ფავორიტი / წაშლა */
    var onLong: (Channel) -> Unit = {}

    class VH(val b: ItemChannelBinding) : RecyclerView.ViewHolder(b.root)

    private companion object {
        const val SEL = "sel"
        const val EPG = "epg"
    }

    fun submit(list: List<Channel>) {
        items = list
        notifyDataSetChanged()
    }

    /** მხოლოდ ორი ელემენტი ახლდება (ძველი და ახალი არჩეული) — მთელი სია თავიდან აღარ იხატება */
    fun select(url: String) {
        if (url == selectedUrl) return
        val old = items.indexOfFirst { it.url == selectedUrl }
        selectedUrl = url
        val new = items.indexOfFirst { it.url == url }
        if (old >= 0) notifyItemChanged(old, SEL)
        if (new >= 0) notifyItemChanged(new, SEL)
    }

    /** ტელეპროგრამის ტექსტი/პროგრესი ახლდება მხოლოდ — ლოგოები და დანარჩენი თავიდან აღარ იხატება */
    /**
     * v1.7.119 (ANR-ის გასწორება): ადრე მთელი სია (18 000+ არხი) ერთბაშად „იცვლებოდა“ — RecyclerView-ს (AdapterHelper.applyUpdate →
     * updatePositionWithPostponed) თითო პოზიციაზე უწევდა გადამოწმება და მთავარ ნაკადს 5+ წამით ბლოკავდა (პულტის ღილაკზე — ANR).
     * ახლა ახლდება მხოლოდ ეკრანზე ხილული არხები (+ მცირე მარაგი); დანარჩენი გადახვევისას ისედაც ახალი გადაცემით იხატება.
     */
    fun refresh(rv: RecyclerView? = null) {
        if (items.isEmpty()) return
        val lm = rv?.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager
        if (lm == null) { notifyItemRangeChanged(0, minOf(items.size, 60), EPG); return }
        val first = lm.findFirstVisibleItemPosition()
        val last = lm.findLastVisibleItemPosition()
        if (first < 0 || last < 0) return
        val start = maxOf(0, first - 12)
        val end = minOf(items.size - 1, last + 12)
        notifyItemRangeChanged(start, end - start + 1, EPG)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val vh = VH(ItemChannelBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        vh.b.root.setOnClickListener {
            val pos = vh.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClick(items[pos], pos)
        }
        vh.b.root.setOnLongClickListener {
            val pos = vh.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) { onLong(items[pos]); true } else false
        }
        return vh
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty()) {
            val ch = items[position]
            h.b.root.isSelected = ch.url == selectedUrl
            if (payloads.contains(EPG)) bindEpg(h, ch)
            return
        }
        super.onBindViewHolder(h, position, payloads)
    }

    private fun bindEpg(h: VH, ch: Channel) {
        val nowP = Epg.now(ch)
        h.b.epgBadge.visibility = if (nowP != null) View.VISIBLE else View.GONE
        h.b.epgArrow.visibility = if (nowP != null && Device.tv(h.b.root.context)) View.VISIBLE else View.GONE
        if (nowP != null) {
            h.b.now.text = "${Ui.timeOf(nowP.start)}  ${nowP.title}"
            h.b.now.visibility = View.VISIBLE
            h.b.prog.progress = Ui.progressOf(nowP)
            h.b.prog.visibility = View.VISIBLE
            val nx = Epg.next(ch)
            if (nx != null) {
                h.b.next.text = "▸ ${Ui.timeOf(nx.start)}  ${nx.title}"
                h.b.next.visibility = View.VISIBLE
            } else h.b.next.visibility = View.GONE
        } else {
            h.b.now.visibility = View.GONE
            h.b.next.visibility = View.GONE
            h.b.prog.visibility = View.GONE
        }
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val ch = items[position]
        h.b.num.text = (position + 1).toString()
        h.b.name.text = if (UserLists.isFav(h.b.root.context, ch)) "★ " + ch.name else ch.name
        bindEpg(h, ch)
        ImageLoader.show(ChannelHolder.logoOf(ch), h.b.logo, ch.name)
        h.b.root.isSelected = ch.url == selectedUrl
    }
}

/** კატეგორიების ღილაკები */
class GroupAdapter(private val vertical: Boolean, private val onClick: (String) -> Unit) : RecyclerView.Adapter<GroupAdapter.VH>() {
    private var items: List<String> = emptyList()
    private var selected: String = ""

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    fun submit(list: List<String>, sel: String) {
        items = list
        selected = sel
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val d = parent.resources.displayMetrics.density
        val tv = TextView(parent.context).apply {
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundResource(if (vertical) R.drawable.item_bg else R.drawable.chip_bg)
            isFocusable = true
            isClickable = true
            gravity = if (vertical) Gravity.START or Gravity.CENTER_VERTICAL else Gravity.CENTER
            layoutParams = if (vertical) {
                ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { setMargins(0, 0, 0, (4 * d).toInt()) }
            } else {
                ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { setMargins(0, 0, (8 * d).toInt(), 0) }
            }
        }
        val vh = VH(tv)
        tv.setOnClickListener {
            val pos = vh.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClick(items[pos])
        }
        return vh
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val g = items[position]
        h.tv.text = Lang.group(g)
        h.tv.isSelected = g == selected
    }
}

/** პროგრამის სია (EPG): დრო, სათაური; მიმდინარე გადაცემა გამოყოფილია და აქვს "ახლა" ბეჯი */
class ProgramAdapter(
    private val onClick: ((Program) -> Unit)? = null,
    private val canPlay: ((Program) -> Boolean)? = null,
    /** v1.7.97: შეხსენება მონიშნულია (🔔) */
    private val marked: ((Program) -> Boolean)? = null
) : RecyclerView.Adapter<ProgramAdapter.VH>() {
    private var items: List<Program> = emptyList()

    class VH(val b: ItemProgramBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(list: List<Program>) {
        items = list
        notifyDataSetChanged()
    }

    /** მიმდინარე გადაცემის ადგილი სიაში (სიის გადასახვევად); გასული გადაცემები მასზე ზემოთაა */
    fun liveIndex(): Int {
        val t = System.currentTimeMillis()
        val i = items.indexOfFirst { t >= it.start && t < it.stop }
        return if (i >= 0) i else items.indexOfFirst { it.start > t }.coerceAtLeast(0)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val vh = VH(ItemProgramBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        if (onClick != null) {
            vh.b.root.isClickable = true
            vh.b.root.isFocusable = true
            vh.b.root.setOnClickListener {
                val pos = vh.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onClick.invoke(items[pos])
            }
        }
        return vh
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = items[position]
        val t = System.currentTimeMillis()
        val live = t >= p.start && t < p.stop
        h.b.pTime.text = Ui.timeOf(p.start)
        h.b.pTitle.text = if (t >= p.stop && canPlay?.invoke(p) == true) "📼 " + p.title
        else if (t < p.start && marked?.invoke(p) == true) "🔔 " + p.title else p.title
        h.b.pBadge.visibility = if (live) View.VISIBLE else View.GONE
        h.b.root.setBackgroundResource(if (live) R.drawable.program_live_bg else R.drawable.item_bg)
        val past = t >= p.stop
        h.b.root.alpha = if (past) 0.55f else 1f
        h.b.pTime.setTextColor(if (live) Color.WHITE else Color.parseColor("#9AA3C2"))
        h.b.pTitle.setTypeface(null, if (live) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
    }
}
