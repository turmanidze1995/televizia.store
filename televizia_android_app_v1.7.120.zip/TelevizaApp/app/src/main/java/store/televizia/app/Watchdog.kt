package store.televizia.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Process
import java.util.concurrent.atomic.AtomicBoolean

/**
 * v1.7.119: მთავარი ნაკადის „გაყინვის“ დამკვირვებელი.
 * ANR-ის ანგარიშში მთავარი ნაკადის სტეკი ხშირად არ მოდის და ვერ ვხედავთ, რა ბლოკავს ღილაკზე დაჭერას.
 * ეს ნაკადი ყოველ ~3 წმ-ში მთავარ ნაკადს უგზავნის მცირე დავალებას; თუ 2,5 წმ-ში არ შესრულდა, იღებს მთავარი ნაკადის სტეკს
 * (სად „ჭედავს“ კოდი) და ინახავს. შემდეგ გაშვებაზე CrashReport ამას სერვერს უგზავნის (ადმინი → მოვლენები). ტვირთი უმნიშვნელოა.
 */
object Watchdog {
    private const val PREFS = "crash_report"
    private const val KEY = "stall"
    @Volatile private var started = false

    fun start(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        val handler = Handler(Looper.getMainLooper())
        val mainThread = Looper.getMainLooper().thread
        Thread {
            try { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) } catch (_: Throwable) {}
            while (true) {
                try {
                    val seen = AtomicBoolean(false)
                    handler.post { seen.set(true) }
                    var waited = 0L
                    while (!seen.get() && waited < 12_000L) {
                        Thread.sleep(500L)
                        waited += 500L
                        if (waited == 2_500L || waited == 5_000L) capture(app, mainThread, waited)
                    }
                    Thread.sleep(2_500L)
                } catch (_: InterruptedException) {
                    return@Thread
                } catch (_: Throwable) {
                    try { Thread.sleep(5_000L) } catch (_: InterruptedException) { return@Thread }
                }
            }
        }.apply { name = "stall-watchdog"; isDaemon = true }.start()
    }

    private fun capture(app: Context, main: Thread, waitedMs: Long) {
        try {
            val st = main.stackTrace
            if (st.isEmpty()) return
            val sb = StringBuilder()
            sb.append("[").append(java.text.SimpleDateFormat("dd.MM HH:mm:ss", java.util.Locale.US).format(java.util.Date()))
                .append("] main ").append(waitedMs).append("ms არ პასუხობს:\n")
            // ზედა ფრეიმები (სად ჩერდება) + ჩვენი კოდის ფრეიმები (რომელი ფუნქცია იძახებს)
            val shown = HashSet<Int>()
            for (i in 0 until minOf(st.size, 10)) { shown.add(i); sb.append("  at ").append(st[i]).append('\n') }
            var extra = 0
            for (i in st.indices) {
                if (i in shown) continue
                if (st[i].className.startsWith("store.televizia") && extra < 8) { sb.append("  at ").append(st[i]).append('\n'); extra++ }
            }
            val sp = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val old = sp.getString(KEY, "") ?: ""
            // ერთი და იგივე გაყინვის ორი ნიმუშიდან მხოლოდ ბოლო, და მაქს. ~3 ჩანაწერი
            val parts = old.split("\u0001").filter { it.isNotBlank() }.toMutableList()
            parts.add(sb.toString())
            while (parts.size > 3) parts.removeAt(0)
            sp.edit().putString(KEY, parts.joinToString("\u0001")).apply()
        } catch (_: Throwable) {}
    }

    /** შენახული გაყინვის სტეკები (ტექსტი) და გასუფთავება; ცარიელი = არაფერია */
    fun take(ctx: Context): String {
        return try {
            val sp = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val s = sp.getString(KEY, "") ?: ""
            if (s.isNotEmpty()) sp.edit().remove(KEY).apply()
            s.replace("\u0001", "\n")
        } catch (_: Throwable) { "" }
    }
}
