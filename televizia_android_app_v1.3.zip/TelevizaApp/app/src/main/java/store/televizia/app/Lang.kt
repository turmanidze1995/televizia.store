package store.televizia.app

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

/** აპლიკაციის კლასი: ენის პარამეტრი იტვირთება გაშვებისთანავე */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Lang.init(this)
    }
}

/**
 * ინტერფეისის ენა: ქართული (ka, ნაგულისხმევი), რუსული (ru), ინგლისური (en).
 * არჩევანი ინახება ტელეფონში და გასვლისას (logout) არ იშლება.
 */
object Lang {
    val codes = arrayOf("ka", "ru", "en")
    val names = arrayOf("ქართული", "Русский", "English")

    private const val PREFS = "tv_lang"
    private lateinit var app: Context
    @Volatile private var code = "ka"
    @Volatile private var cached: Context? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        val saved = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("code", "ka") ?: "ka"
        code = if (saved in codes) saved else "ka"
        cached = null
    }

    fun current(): String = code

    fun set(c: String) {
        if (c !in codes) return
        code = c
        cached = null
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("code", c).apply()
    }

    /** კონტექსტი არჩეული ენით (ეკრანებისთვის) */
    fun wrap(base: Context): Context {
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(Locale.forLanguageTag(code))
        return base.createConfigurationContext(cfg)
    }

    private fun ctx(): Context = cached ?: wrap(app).also { cached = it }

    /** ტექსტი ეკრანის გარეთ (სერვერის შეცდომები და ა.შ.) */
    fun s(@StringRes id: Int): String = ctx().getString(id)

    fun f(@StringRes id: Int, vararg args: Any): String = ctx().getString(id, *args)

    /** კატეგორიების შიდა გასაღებები (M3U-ის group-title ან სტანდარტული) */
    const val ALL = "ყველა"
    const val OTHER = "სხვა"

    /** კატეგორიის დასახელება არჩეულ ენაზე */
    fun group(g: String): String = when (g) {
        ALL -> s(R.string.all)
        OTHER -> s(R.string.other)
        else -> g
    }
}

/** ყველა ეკრანის საერთო საფუძველი: არჩეული ენა */
open class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun applyOverrideConfiguration(overrideConfiguration: Configuration?) {
        if (overrideConfiguration != null) {
            val uiMode = overrideConfiguration.uiMode
            baseContext?.let { overrideConfiguration.setTo(it.resources.configuration) }
            overrideConfiguration.uiMode = uiMode
        }
        super.applyOverrideConfiguration(overrideConfiguration)
    }

    /** ენის არჩევის ფანჯარა; არჩევის შემდეგ ეკრანი თავიდან იხატება */
    fun showLanguageDialog() {
        val cur = Lang.codes.indexOf(Lang.current()).coerceAtLeast(0)
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.language)
            .setSingleChoiceItems(Lang.names, cur) { d, which ->
                d.dismiss()
                if (Lang.codes[which] != Lang.current()) {
                    Lang.set(Lang.codes[which])
                    recreate()
                }
            }
            .show()
    }
}
