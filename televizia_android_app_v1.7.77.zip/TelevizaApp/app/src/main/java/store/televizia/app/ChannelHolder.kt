package store.televizia.app

import android.os.Handler
import android.os.Looper

/** აპლიკაციის საერთო მდგომარეობა: ყველა არხი, ამჟამინდელი (გაფილტრული) სია და მიმდინარე არხი */
object ChannelHolder {
    var all: List<Channel> = emptyList()
    var list: List<Channel> = emptyList()
    var group: String = Lang.ALL
    var current: Channel? = null
    @Volatile var epgStarted = false

    /** ბოლოს ცნობილი პოზიცია სიაში (არხზე დაჭერისას/გადართვისას ვინახავთ) — ერთნაირი ბმულის მქონე არხები ერთმანეთში აღარ ერევა */
    @Volatile private var pos = -1

    fun markPos(i: Int) { pos = i }

    /**
     * მიმდინარე არხის ზუსტი ნომერი ამჟამინდელ სიაში (0-დან), ან -1 თუ ამ სიაში არ არის.
     * ბმული არხის სანდო იდენტიფიკატორი არ არის: სერვერი ბმულში მოწყობილობის გასაღებს (dkey) აქცევს და ის შეიძლება შეიცვალოს
     * (IP-ის შეცვლა, სიის განახლება) — მაშინ ბმულით ძებნა ვერაფერს პოულობდა და CH+ ყოველთვის სიის პირველ არხზე
     * (QR კოდის არხზე) გადადიოდა. ახლა ძებნა ხდება: პოზიცია → იგივე ობიექტი → სახელი+ბმული → tvg-id+სახელი → სახელი+კატეგორია → ბმული → სახელი.
     */
    val exactIndex: Int
        get() {
            val cur = current ?: return -1
            val l = list
            if (l.isEmpty()) return -1
            if (pos in l.indices && l[pos].url == cur.url && l[pos].name == cur.name) return pos
            var i = l.indexOfFirst { it === cur }
            if (i < 0) i = l.indexOfFirst { it.url == cur.url && it.name == cur.name }
            if (i < 0 && cur.epgId.isNotBlank()) i = l.indexOfFirst { it.epgId == cur.epgId && it.name == cur.name }
            if (i < 0) i = l.indexOfFirst { it.name == cur.name && it.group == cur.group }
            if (i < 0) i = l.indexOfFirst { it.url == cur.url }
            if (i < 0) i = l.indexOfFirst { it.name == cur.name }
            if (i >= 0) pos = i
            return i
        }

    /** როგორც exactIndex, მაგრამ თუ არხი ვერ მოიძებნა — ბოლო ცნობილ პოზიციას აბრუნებს (ან -1) */
    val index: Int
        get() {
            val i = exactIndex
            if (i >= 0) return i
            return if (pos in list.indices) pos else -1
        }

    fun lastPos(): Int = pos

    /** იგივე არხი ახალ სიაში (ბმული შეიძლება შეცვლილიყო) */
    fun equivalentIn(cur: Channel, l: List<Channel>): Channel? =
        l.firstOrNull { it.url == cur.url && it.name == cur.name }
            ?: (if (cur.epgId.isNotBlank()) l.firstOrNull { it.epgId == cur.epgId && it.name == cur.name } else null)
            ?: l.firstOrNull { it.name == cur.name && it.group == cur.group }
            ?: l.firstOrNull { it.name == cur.name }

    // ---------- ლოგოს რეზერვი: იგივე სახელის არხს თუ აქვს ლოგო ----------
    private var logoSrc: List<Channel>? = null
    private var logoMap: Map<String, String> = emptyMap()
    private fun logoKey(n: String): String =
        n.lowercase().replace(Regex("""\[.*?]|\(.*?\)"""), " ")
            .replace(Regex("""\b(hd|fhd|uhd|sd|4k|ge|geo)\b"""), " ")
            .replace(Regex("""[^\p{L}\p{N}]+"""), "")

    /** არხის ლოგო; თუ არ აქვს — იგივე სახელის სხვა არხისა (ან ცარიელი) */
    fun logoOf(ch: Channel): String {
        if (ch.logo.isNotBlank()) return ch.logo
        val a = all
        if (logoSrc !== a) {
            val m = HashMap<String, String>()
            for (c in a) if (c.logo.isNotBlank()) m.getOrPut(logoKey(c.name)) { c.logo }
            logoMap = m; logoSrc = a
        }
        return logoMap[logoKey(ch.name)] ?: ""
    }

    fun reset() {
        all = emptyList(); list = emptyList(); group = Lang.ALL; current = null; epgStarted = false; pos = -1
    }
}

/**
 * არხის ნომრის ციფრებით აკრეფა (პულტით): ყოველი ციფრი ეკრანზე ჩანს ამ ნომრის არხის სახელითურთ.
 *  - არხზე გადადის 1 წამის შემდეგ, ან მაშინვე თუ ნომერი ცალსახაა (მაგ. 5, როცა 50+ არხი არ არის), ან OK-ზე დაჭერისას
 *  - ორ-სამნიშნა ნომრისთვის: 1, შემდეგ 2 → 12
 */
class DigitEntry(
    private val size: () -> Int,
    private val nameAt: (Int) -> String?,
    private val onUpdate: (digits: String, name: String?, valid: Boolean) -> Unit,
    private val onCommit: (Int) -> Unit,
    private val onClose: () -> Unit
) {
    private val h = Handler(Looper.getMainLooper())
    private val sb = StringBuilder()
    private val timeout = Runnable { commit() }

    val active: Boolean get() = sb.isNotEmpty()

    fun digit(d: Int) {
        if (sb.length >= 4) sb.setLength(0)
        sb.append(d)
        val n = sb.toString().toIntOrNull() ?: 0
        val max = size()
        val valid = n in 1..max
        onUpdate(sb.toString(), if (valid) nameAt(n - 1) else null, valid)
        h.removeCallbacks(timeout)
        if (valid && n * 10 > max) {
            h.postDelayed(timeout, 350)   // ცალსახაა — თითქმის მაშინვე გადავდივართ
        } else {
            h.postDelayed(timeout, 1200)
        }
    }

    fun commit() {
        h.removeCallbacks(timeout)
        if (sb.isEmpty()) return
        val n = sb.toString().toIntOrNull()
        sb.setLength(0)
        onClose()
        if (n != null && n in 1..size()) onCommit(n - 1)
    }

    fun cancel() {
        h.removeCallbacks(timeout)
        if (sb.isEmpty()) return
        sb.setLength(0)
        onClose()
    }
}
