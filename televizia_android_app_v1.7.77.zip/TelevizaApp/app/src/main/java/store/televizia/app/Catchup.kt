package store.televizia.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * არქივი (catch-up): გასული გადაცემის ნახვა.
 *  - არხს არქივი აქვს, თუ M3U-ში წერია tvg-rec / catchup-days / timeshift = "დღეები" (მეტი მათგანიდან),
 *    ან მხოლოდ catchup="…" (მაშინ ნაგულისხმევი 3 დღე) — ზუსტად როგორც საიტის /tv გვერდზე და Televizo-ში.
 *  - ბმული:
 *      1) ადმინ-ეკრანში მითითებული შაბლონი (urls.catchup), თუ ცარიელი არაა;
 *      2) არხი საიტის დაცულ ბმულზეა (…/playlist/s.php/…) — ვუგზავნით utc/end პარამეტრებს და სერვერი თვითონ აგებს
 *         მომწოდებლის სწორ ბმულს (flussonic / xc / shift / append / default);
 *      3) პირდაპირი ბმული — იგივე წესით აპშივე ვაგებთ (catchup / catchup-source ატრიბუტების მიხედვით).
 *    შაბლონის ცვლადები: {url} {base} {utc}/{start} {end} {duration} {lutc}/{now} {offset} {Y}{m}{d}{H}{M}{S}
 */
object Catchup {
    const val DEFAULT = "{url}?utc={utc}&end={end}&lutc={lutc}"
    private const val DEFAULT_DAYS = 3

    fun enabled(): Boolean = RemoteConfig.b("features.catchup", true)

    private fun template(): String = RemoteConfig.s("urls.catchup")

    /** არხის არქივის სიღრმე დღეებში (0 = არქივი არ აქვს) */
    fun days(ch: Channel): Int = when {
        ch.recDays > 0 -> ch.recDays
        ch.cuType.isNotBlank() -> DEFAULT_DAYS
        else -> 0
    }

    /** ამ გადაცემის არქივი ხელმისაწვდომია? (უკვე დაწყებულია და არხის არქივის ვადაში ჯდება) */
    fun canPlay(ch: Channel, p: Program): Boolean {
        val d = days(ch)
        if (!enabled() || d <= 0) return false
        val now = System.currentTimeMillis()
        return p.start < now && p.start > now - d * 86_400_000L
    }

    /** არხს საერთოდ აქვს არქივი? */
    fun has(ch: Channel): Boolean = enabled() && days(ch) > 0

    /** გადაცემის არქივის ბმული */
    fun url(ch: Channel, p: Program): String = urlAt(ch, p.start / 1000, p.stop / 1000)

    /** არქივის ბმული თვითნებური დროისთვის (წამები, UTC) — გადახვევისას გადაცემის შუაში გადასასვლელად */
    fun urlAt(ch: Channel, startSec: Long, endSec: Long): String {
        val now = System.currentTimeMillis() / 1000
        val end = if (endSec > startSec) endSec else startSec + 3600
        val custom = template()
        if (custom.isNotBlank()) return fill(custom, ch.url, startSec, end, now, withUrlJoin = true)
        if (ch.url.contains("/playlist/s.php/")) return fill(DEFAULT, ch.url, startSec, end, now, withUrlJoin = true)
        return direct(ch, startSec, end, now)
    }

    private fun fill(tpl: String, live: String, st: Long, en: Long, now: Long, withUrlJoin: Boolean): String {
        var t = tpl
        // ბმულს უკვე აქვს პარამეტრები — "?" ცვლის "&"
        if (withUrlJoin && t.startsWith("{url}?") && live.contains('?')) t = "{url}&" + t.removePrefix("{url}?")
        val f = SimpleDateFormat("yyyy|MM|dd|HH|mm|ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val parts = f.format(Date(st * 1000)).split('|')
        return t
            .replace("{url}", live)
            .replace("{base}", live.substringBefore('?').substringBeforeLast('/'))
            .replace("{utc}", st.toString()).replace("{start}", st.toString())
            .replace("{end}", en.toString()).replace("{utcend}", en.toString())
            .replace("{duration}", (en - st).toString())
            .replace("{lutc}", now.toString()).replace("{now}", now.toString()).replace("{timestamp}", now.toString())
            .replace("{offset}", (now - st).toString())
            .replace("{Y}", parts[0]).replace("{m}", parts[1]).replace("{d}", parts[2])
            .replace("{H}", parts[3]).replace("{M}", parts[4]).replace("{S}", parts[5])
    }

    /** საიტის wepg_catchup_url()-ის (PHP) ზუსტი ანალოგი */
    private fun direct(ch: Channel, st: Long, en: Long, now: Long): String {
        val live = ch.url
        val dur = en - st
        val sep = if (live.contains('?')) "&" else "?"
        val ty = ch.cuType.ifBlank { "shift" }
        val src = ch.cuSource
        fun f(t: String) = fill(t.replace("\${", "{"), live, st, en, now, withUrlJoin = false)
        return when (ty) {
            "default" -> if (Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(src)) f(src) else if (src.isNotEmpty()) live + f(src) else "$live${sep}utc=$st&lutc=$now"
            "append" -> if (src.isEmpty()) "$live${sep}utc=$st&lutc=$now" else { val t = f(src); live + (if (live.contains('?') && t.startsWith("?")) "&" + t.substring(1) else t) }
            "shift", "timeshift" -> "$live${sep}utc=$st&lutc=$now"
            "flussonic", "fs", "flussonic-hls", "flussonic-index", "flussonic-mono" -> {
                val m = Regex("^([^?#]*?)/(?:index\\.m3u8|video\\.m3u8|mono\\.m3u8|mpegts)(\\?.*)?$", RegexOption.IGNORE_CASE).find(live)
                if (m == null) "$live${sep}utc=$st&lutc=$now"
                else {
                    val w = when (ty) { "flussonic-index" -> "index"; "flussonic-mono" -> "mono"; else -> "archive" }
                    m.groupValues[1] + "/" + w + "-" + st + "-" + dur + ".m3u8" + m.groupValues[2]
                }
            }
            "offset" -> "$live${sep}offset=${now - st}"
            "xc", "xtream" -> {
                val m = Regex("^(https?://[^/]+)/(?:live/)?([^/]+)/([^/]+)/(\\d+)(?:\\.\\w+)?(?:\\?.*)?$", RegexOption.IGNORE_CASE).find(live)
                if (m == null) "$live${sep}utc=$st&lutc=$now"
                else {
                    val d = fill("{Y}-{m}-{d}:{H}-{M}", live, st, en, now, false)
                    m.groupValues[1] + "/timeshift/" + m.groupValues[2] + "/" + m.groupValues[3] + "/" + ((dur + 59) / 60) + "/" + d + "/" + m.groupValues[4] + ".m3u8"
                }
            }
            else -> "$live${sep}utc=$st&lutc=$now"
        }
    }
}
