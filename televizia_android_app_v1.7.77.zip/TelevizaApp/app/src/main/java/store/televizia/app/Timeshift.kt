package store.televizia.app

import androidx.media3.common.C
import androidx.media3.common.Timeline

/**
 * გადახვევა Televizo-სავით: ნახვის „რეალური დრო“ და არქივზე გადასვლა.
 *  - პირდაპირ ეთერზე: ახლა − (რამდენით ვართ უკან ნაკადის ფანჯარაში)
 *  - არქივში: არქივის დასაწყისი + დაკვრის პოზიცია
 *  - უკან გადახვევისას, თუ არხს არქივი აქვს (tvg-rec / catchup-days / timeshift / catchup) და ეთერის ფანჯარა არ ჰყოფნის,
 *    იგივე წუთიდან იხსნება არქივი — ეკრანზე „გაყინული“ ჩატვირთვის ლოგო აღარ რჩება
 */
object Timeshift {
    @Volatile private var url = ""
    @Volatile private var chUrl = ""
    @Volatile private var liveUrl = ""
    @Volatile private var baseMs = 0L
    /** არქივის დაგეგმილი დასასრული (UTC, მწ); 0 = უცნობი */
    @Volatile private var endMs = 0L

    /** ახლა ამ ბმულით არქივი თამაშდება? */
    fun isArchive(currentUrl: String): Boolean = url.isNotEmpty() && currentUrl == url

    /** ამ არხის არქივის ბმული (თუ ახლა არქივში ვართ) */
    fun activeFor(ch: Channel): String? = if (url.isNotEmpty() && chUrl == ch.url) url else null

    fun liveUrl(): String = liveUrl

    fun mark(ch: Channel, archiveUrl: String, startMs: Long, stopMs: Long = 0L) {
        url = archiveUrl; chUrl = ch.url; liveUrl = ch.url; baseMs = startMs; endMs = stopMs
    }

    fun clear() { url = ""; chUrl = ""; liveUrl = ""; baseMs = 0L; endMs = 0L }

    /** არქივი ბოლომდე მივიდა: თუ ეთერამდე ჯერ შორსაა, იგივე არქივი გრძელდება მომდევნო წუთიდან; null → ეთერზე გადასვლა */
    fun continuation(): String? {
        val ch = ChannelHolder.current ?: return null
        if (url.isEmpty() || ch.url != chUrl || endMs <= 0L) return null
        val from = endMs
        if (from > System.currentTimeMillis() - 90_000) return null
        val u = archiveUrlAt(ch, from) ?: return null
        mark(ch, u, from)
        endMs = System.currentTimeMillis()
        return u
    }

    /** რამდენით ვართ პირდაპირი ეთერის ფანჯრის ბოლოდან უკან (მწ) */
    fun behindLiveMs(p: androidx.media3.exoplayer.ExoPlayer): Long {
        if (!p.isCurrentMediaItemLive) return 0
        val tl = p.currentTimeline
        if (tl.isEmpty) return 0
        val w = tl.getWindow(p.currentMediaItemIndex, Timeline.Window())
        if (w.defaultPositionMs == C.TIME_UNSET) return 0
        return (w.defaultPositionMs - p.currentPosition).coerceAtLeast(0)
    }

    /** ახლა ეკრანზე ნაჩვენები კადრის რეალური დრო (UTC, მწ) */
    fun wallMs(sc: StreamController?): Long {
        if (sc == null) return System.currentTimeMillis()
        val p = sc.player ?: return System.currentTimeMillis()
        return if (isArchive(sc.currentUrl)) baseMs + p.currentPosition.coerceAtLeast(0)
        else System.currentTimeMillis() - behindLiveMs(p)
    }

    /** დროზე tMs-ზე არქივის დაკვრა. აბრუნებს ახალ ბმულს ან null-ს, თუ არხს არქივი არ აქვს / დრო ვადაზე ადრეა */
    fun archiveUrlAt(ch: Channel, tMs: Long): String? {
        if (!Catchup.has(ch)) return null
        val now = System.currentTimeMillis()
        if (tMs >= now || tMs < now - Catchup.days(ch) * 86_400_000L) return null
        return Catchup.urlAt(ch, tMs / 1000, now / 1000)
    }

    /** გადაცემა, რომელშიც ეს დრო ხვდება */
    fun programAt(ch: Channel?, tMs: Long): Program? {
        if (ch == null) return null
        val l = Epg.schedule(ch)
        if (l.isEmpty()) return null
        var best: Program? = null
        for (pr in l) { if (tMs >= pr.start && tMs < pr.stop) { best = pr } else if (pr.start > tMs) break }
        return best
    }

    /** გადახვევის ზოლის დიაპაზონი: გადაცემა, რომელშიც wall დროა (დასაწყისი, დასასრული ან ახლა, სახელი); EPG-ის გარეშე — ბოლო 2 საათი */
    fun range(ch: Channel?, wall: Long): Triple<Long, Long, String> {
        val now = System.currentTimeMillis()
        val pr = programAt(ch, wall)
        return if (pr != null) Triple(pr.start, minOf(pr.stop, now), pr.title)
        else Triple(now - 2 * 3_600_000L, now, ch?.name ?: "")
    }

    /** დაკვრის დაწყება არქივიდან tMs დროით. false — არხს არქივი არ აქვს ან დრო ვადას სცილდება */
    fun playArchiveAt(ctx: android.content.Context, ch: Channel, tMs: Long): Boolean {
        val u = archiveUrlAt(ch, tMs) ?: return false
        mark(ch, u, tMs, System.currentTimeMillis())
        StreamHub.get(ctx).play(u)
        return true
    }

    /** გადაცემის არქივი თავიდან (გადაცემაზე დაჭერა) */
    fun playProgram(ctx: android.content.Context, ch: Channel, p: Program) {
        val u = Catchup.url(ch, p)
        mark(ch, u, p.start, p.stop)
        StreamHub.get(ctx).play(u)
    }

    /** პირდაპირ ეთერზე დაბრუნება */
    fun goLive(ctx: android.content.Context) {
        val ch = ChannelHolder.current
        val hub = StreamHub.peek()
        if (hub != null && isArchive(hub.currentUrl) && ch != null) {
            clear()
            StreamHub.get(ctx).play(ch.url)
            return
        }
        clear()
        hub?.player?.let { it.seekToDefaultPosition(); it.playWhenReady = true }
    }

    /**
     * გადასვლა რეალურ დროზე (UTC, მწ): პატარა გადახვევა — ეთერის საკუთარ ფანჯარაში, დიდი (ან ფანჯარა თუ არ ჰყოფნის) — არქივიდან.
     * აბრუნებს false-ს, თუ გადახვევა შეუძლებელია (არხს არქივი არ აქვს და ნაკადი გადახვევადი არ არის).
     */
    fun seekToWall(ctx: android.content.Context, target: Long): Boolean {
        val hub = StreamHub.peek() ?: return false
        val p = hub.player ?: return false
        val ch = ChannelHolder.current ?: return false
        val now = System.currentTimeMillis()
        if (target >= now - 8_000) { goLive(ctx); return true }
        if (isArchive(hub.currentUrl)) {
            // არქივი უკვე გახსნილია: თუ საჭირო წუთი მის შიგნითაა, უბრალოდ გადავდივართ
            val pos = p.currentPosition + (target - wallMs(hub))
            val dur = p.duration
            if (p.isCurrentMediaItemSeekable && dur != C.TIME_UNSET && dur > 0 && pos in 0 until (dur - 3_000)) { p.seekTo(pos); return true }
            return playArchiveAt(ctx, ch, target)
        }
        val needBehind = (now - target).coerceAtLeast(0)
        if (p.isCurrentMediaItemSeekable && p.isCurrentMediaItemLive && (!Catchup.has(ch) || needBehind < 25_000)) {
            val tl = p.currentTimeline
            if (!tl.isEmpty) {
                val w = tl.getWindow(p.currentMediaItemIndex, Timeline.Window())
                if (w.defaultPositionMs != C.TIME_UNSET) { p.seekTo((w.defaultPositionMs - needBehind).coerceAtLeast(0)); return true }
            }
        }
        return playArchiveAt(ctx, ch, target)
    }

    /** ±ms გადახვევა (ღილაკები / პულტი) */
    fun seekBy(ctx: android.content.Context, ms: Long): Boolean {
        val hub = StreamHub.peek() ?: return false
        val p = hub.player ?: return false
        if (!isArchive(hub.currentUrl) && !p.isCurrentMediaItemLive && p.isCurrentMediaItemSeekable) {
            p.seekTo((p.currentPosition + ms).coerceAtLeast(0))   // ჩვეულებრივი ფაილი (არა ეთერი)
            return true
        }
        return seekToWall(ctx, wallMs(hub) + ms)
    }
}
