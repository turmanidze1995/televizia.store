package store.televizia.app

data class Channel(
    val name: String, val logo: String, val url: String, val group: String, val epgId: String = "", val recDays: Int = 0,
    /** M3U: catchup="flussonic|default|append|shift|xc|…" (ცარიელი = shift) */
    val cuType: String = "",
    /** M3U: catchup-source="…" */
    val cuSource: String = ""
) {
    /** XMLTV არხის ID, რომელსაც ეს არხი დაუკავშირდა (ივსება Epg.attach-ით) */
    @Volatile var epgKey: String = ""
}

/** M3U სიის წამკითხველი: სახელი, ლოგო, ჯგუფი (group-title), tvg-id და სტრიმის ლინკი */
object M3u {
    private val logoRegex = Regex("""tvg-logo\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val groupRegex = Regex("""group-title\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val idRegex = Regex("""tvg-id\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val recRegexes = listOf("tvg-rec", "catchup-days", "timeshift")
        .map { Regex("""(?<![\w-])$it\s*=\s*["']?(\d+)""", RegexOption.IGNORE_CASE) }
    private val cuTypeRegex = Regex("""(?<![\w-])catchup(?:-type)?\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val cuSourceRegex = Regex("""catchup-source\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val tvgNameRegex = Regex("""tvg-name\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val epgRegex = Regex("""(?:url-tvg|x-tvg-url)\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)

    /** სწრაფი ატრიბუტის ამოკითხვა (key="value"); null — თუ ამ ხაზში ასეთი ატრიბუტი არ არის ან ფორმატი უჩვეულოა (მაშინ regex-ს ვიყენებთ) */
    private fun attr(line: String, key: String, fallback: Regex): String {
        val i = line.indexOf(key, 0, ignoreCase = true)
        if (i < 0) return ""
        var j = i + key.length
        while (j < line.length && line[j] == ' ') j++
        if (j < line.length && line[j] == '=') {
            j++
            while (j < line.length && line[j] == ' ') j++
            if (j < line.length && (line[j] == '"' || line[j] == '\'')) {
                j++
                var k = j
                while (k < line.length && line[k] != '"' && line[k] != '\'') k++
                if (k < line.length) return line.substring(j, k)
            }
        }
        return fallback.find(line)?.groupValues?.get(1) ?: ""
    }

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>(512)
        var name = ""
        var logo = ""
        var group = ""
        var epgId = ""
        var rec = 0
        var cuType = ""
        var cuSrc = ""
        for (raw in text.lineSequence()) {
            val line = raw.trim().removePrefix("\uFEFF")
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF")) {
                name = if (line.contains(',')) line.substringAfterLast(',').trim() else ""
                if (name.isEmpty()) name = attr(line, "tvg-name", tvgNameRegex).trim()
                logo = attr(line, "tvg-logo", logoRegex)
                group = attr(line, "group-title", groupRegex)
                epgId = attr(line, "tvg-id", idRegex)
                // არქივის დღეები: tvg-rec / catchup-days / timeshift — რომელიც მეტია (სერვერზე ხშირად ერთი მათგანია მითითებული)
                rec = 0
                for (r in recRegexes) { val v = r.find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 0; if (v > rec) rec = v }
                cuType = cuTypeRegex.find(line)?.groupValues?.get(1)?.trim()?.lowercase() ?: ""
                cuSrc = cuSourceRegex.find(line)?.groupValues?.get(1) ?: ""
            } else if (!line.startsWith("#")) {
                out.add(Channel(name.ifEmpty { Lang.s(R.string.channel_default) }, logo, line, group.ifBlank { Lang.OTHER }, epgId, rec, cuType, cuSrc))
                name = ""; logo = ""; group = ""; epgId = ""; rec = 0; cuType = ""; cuSrc = ""
            }
        }
        return out
    }

    /** სიის პირველ ხაზში მითითებული EPG ბმულები: #EXTM3U url-tvg="a.xml,b.xml" */
    fun epgUrls(text: String): List<String> {
        val head = text.lineSequence().take(5).firstOrNull { it.trim().removePrefix("\uFEFF").startsWith("#EXTM3U") }
            ?: return emptyList()
        val m = epgRegex.find(head) ?: return emptyList()
        return m.groupValues[1].split(',').map { it.trim() }.filter { it.startsWith("http") }
    }
}
