package store.televizia.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.trackselection.AdaptiveTrackSelection
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector

/**
 * საერთო ფლეიერი ორივე ეკრანისთვის (სია და სრული ეკრანი). ერთი და იგივე ExoPlayer გადადის ეკრანიდან
 * ეკრანზე, ამიტომ "სრულ ეკრანზე" გახსნისას არხი თავიდან აღარ იტვირთება — ვიდეო წყვეტის გარეშე გრძელდება.
 *
 * არხს რამდენიმე გზით ცდილობს გახსნას:
 *  - http <-> https გადამისამართებებს მიჰყვება
 *  - ფორმატს ბმულიდან ხვდება, ხოლო თუ ვერ გაიხსნა — სცდის სხვა ფორმატებს (HLS, TS, ავტომატური)
 *  - ბოლოს სცდის ბრაუზერის User-Agent-ით
 *  - ცდას წყვეტს, თუ არხი 12 წამში არ ჩაირთო
 *  - ყველა ცდის შემდეგ უბრალოდ იძახებს onFailed — სხვა არხზე თავისით არასოდეს გადადის
 *
 * სისწრაფე: მცირე საწყისი ბუფერი (1 წმ), HLS-ის "chunkless" მომზადება, ეკრანის ზომაზე მორგებული
 * ხარისხი (4K ნაკადს ტელეფონზე ტყუილად არ ვტვირთავთ).
 */
class StreamController(private val ctx: Context) {
    companion object {
        private const val UA_VLC = "VLC/3.0.18 LibVLC/3.0.18"
        private const val UA_BROWSER =
            "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0 Safari/537.36"
        private const val START_TIMEOUT_MS = 22000L
        /** ბოლოს წარმატებული ვარიანტი (ფორმატი/UA) თითო ბმულზე: შემდეგ ჩართვაზე პირდაპირ ის ვარიანტი იწყება, წარუმატებელი ცდები აღარ იკარგება */
        /** არხები, რომლებსაც ჩვეულებრივი IDR კადრი არ აქვთ და მხოლოდ "არა-IDR დაწყებით" იხსნება */
        private val nonIdrOk = HashSet<String>()
        private val okAttempt = object : LinkedHashMap<String, Int>(64, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Int>?): Boolean = size > 400
        }
        /** არხები, რომლებიც VLC-ზე წარმატებით ირთვება (ინახება მოწყობილობაზე) და რომლებზეც VLC უკვე ჩავარდა (ამ სესიაში აღარ ვცდით) */
        private val vlcOk = HashSet<String>()
        private val vlcTried = HashSet<String>()
        private var vlcLoaded = false
        private val TS_REGEX = Regex("""\.ts($|[?/#])""")
        private const val RETRY_MS = 3000L
        private const val LOADING = 0
        private const val PLAYING = 1
        private const val FAILED = 2
    }

    var player: ExoPlayer? = null
        private set
    var currentUrl: String = ""
        private set

    private var owner: Any? = null
    private var onLoading: () -> Unit = {}
    private var onPlaying: () -> Unit = {}
    private var onFailed: () -> Unit = {}
    /** ფლეიერი ახლით შეიცვალა (დეკოდერის "დაღლილობის" გამო) — ეკრანმა ახალი ობიექტი უნდა მიიმაგროს */
    var onRebuilt: ((ExoPlayer) -> Unit)? = null
    private var zaps = 0
    private var lastRebuild = 0L
    private var fpsSince = 0L
    private var fpsCount = -1L

    private val h = Handler(Looper.getMainLooper())

    // ---------- სარეზერვო ფლეიერი (VLC) ----------
    private var vlc: VlcFallback? = null
    private var vlcActive = false
    private var hostFrame: android.widget.FrameLayout? = null
    private var hostView: androidx.media3.ui.PlayerView? = null
    private val vlcWatch = Runnable { vlcFailed() }

    /** ვიდეოს ეკრანი (PlayerView): VLC-ის ზედაპირი მასში იდება. ეკრანები მას თვითონ ანიჭებენ */
    var host: androidx.media3.ui.PlayerView?
        get() = hostView
        set(v) {
            hostView = v
            hostFrame = v?.overlayFrameLayout
            vlc?.setHost(hostFrame)
        }
    /** ეკრანის დახურვისას host-ს ვასუფთავებთ მხოლოდ თუ ის ისევ ჩვენია (ახალმა ეკრანმა შეიძლება უკვე გადაიბაროს) */
    fun releaseHost(v: androidx.media3.ui.PlayerView) { if (hostView === v) host = null }

    init {
        // თუ ამ მოწყობილობაზე უკვე არის VLC-ით მომუშავე არხები, VLC წინასწარ ფონურად ემზადება — არხი უფრო სწრაფად ჩაირთვება
        try { vlcLoad(); if (vlcOk.isNotEmpty() && vlcEnabled()) ensureVlc().warmUp() } catch (_: Throwable) {}
    }

    private fun vlcPrefs() = ctx.getSharedPreferences("player_pref", Context.MODE_PRIVATE)
    private fun vlcLoad() {
        if (vlcLoaded) return
        vlcLoaded = true
        try { vlcOk.addAll(vlcPrefs().getStringSet("vlc_urls", emptySet()) ?: emptySet()) } catch (_: Exception) {}
    }
    private fun vlcSave() {
        try { vlcPrefs().edit().putStringSet("vlc_urls", HashSet(vlcOk.toList().takeLast(300))).apply() } catch (_: Exception) {}
    }
    private fun vlcEnabled() = RemoteConfig.i("player.vlc_fallback", 1) == 1

    /** ეს არხი თავიდანვე VLC-ზე უნდა ირთვებოდეს? (დამახსოვრებული / სერვერის სია player.vlc_match / ყველა: player.vlc_all=1) */
    private fun vlcWanted(url: String): Boolean {
        if (!vlcEnabled() || vlcTried.contains(url)) return false
        vlcLoad()
        if (RemoteConfig.i("player.vlc_all", 0) == 1) return true
        if (vlcOk.contains(url)) return true
        val m = RemoteConfig.s("player.vlc_match", "")
        if (m.isNotBlank()) for (part in m.split(',', '\n', ';')) { val t = part.trim(); if (t.length >= 3 && url.contains(t, true)) return true }
        return false
    }

    private fun ensureVlc(): VlcFallback = vlc ?: VlcFallback(
        ctx,
        onPlaying = { h.post { vlcPlaying() } },
        onBuffering = { h.post { if (vlcActive && state != PLAYING) { state = LOADING; onLoading() } } },
        onError = { h.post { vlcFailed() } }
    ).also { vlc = it; it.setHost(hostFrame) }

    private fun cancelExoTimers() {
        h.removeCallbacks(watchdog); h.removeCallbacks(retry); h.removeCallbacks(frameGuard)
        h.removeCallbacks(delayedStart); h.removeCallbacks(idrGuard); h.removeCallbacks(bufSpinner); h.removeCallbacks(noAudioCheck)
        awaitFrame = false
    }

    private fun startVlc() {
        val u = currentUrl
        if (u.isEmpty()) return
        cancelExoTimers()
        try { player?.stop() } catch (_: Exception) {}
        vlcActive = true
        retrying = false
        state = LOADING
        onLoading()
        val v = ensureVlc()
        v.setVolume(player?.volume ?: 1f)
        v.start(u)
        if (player?.playWhenReady == false) v.setPaused(true)
        h.removeCallbacks(vlcWatch)
        h.postDelayed(vlcWatch, 20000)
    }

    private fun vlcPlaying() {
        if (!vlcActive) return
        h.removeCallbacks(vlcWatch)
        val u = currentUrl
        if (u.isNotEmpty() && !vlcOk.contains(u)) { vlcLoad(); vlcOk.add(u); vlcSave() }   // ამ არხზე შემდეგ ჯერზე პირდაპირ VLC
        everPlayed = true
        retrying = false
        if (state != PLAYING) { state = PLAYING; onPlaying() }
    }

    private fun stopVlc() {
        h.removeCallbacks(vlcWatch)
        if (vlcActive) { vlcActive = false; try { vlc?.stop() } catch (_: Exception) {} }
    }

    /** VLC-მაც ვერ გახსნა: დავიმახსოვროთ და ჩვეულებრივ ექსოპლეიერზე დავბრუნდეთ */
    private fun vlcFailed() {
        if (!vlcActive) return
        val u = currentUrl
        stopVlc()
        vlcTried.add(u)
        if (vlcOk.remove(u)) vlcSave()
        attempt = 0
        everPlayed = false
        retrying = false
        state = LOADING
        onLoading()
        start()
    }

    /** ძირითადმა ფლეიერმა არხი ვერ გახსნა / ხმა ან ვიდეო მხარდაუჭერელია → ვცდით VLC-ს. true = გადავედით */
    private val noAudioCheck = Runnable {
        val p = player
        if (p != null && !vlcActive && state == PLAYING && p.playWhenReady) {
            val g = p.currentTracks.groups
            val hasVideo = g.any { it.type == androidx.media3.common.C.TRACK_TYPE_VIDEO }
            val audioOk = g.any { it.type == androidx.media3.common.C.TRACK_TYPE_AUDIO && it.isSelected }
            if (hasVideo && !audioOk) tryVlc()
        }
    }

    private fun tryVlc(): Boolean {
        if (!vlcEnabled() || vlcActive || currentUrl.isEmpty() || vlcTried.contains(currentUrl)) return false
        startVlc()
        return true
    }
    private var attempt = 0
    private var everPlayed = false
    private var state = LOADING
    private val watchdog = Runnable { handleError(null) }
    private var retrying = false
    private var awaitFrame = false
    /** ამ არხის პირველი კადრი უკვე გამოჩნდა — მერე ბუფერიზაციისას ლოგოს აღარ ვაჩვენებთ (ვიდეო არ იფარება) */
    private var frameShown = false
    private var cycles = 0
    private var lastCode = 0
    private var retryAfterMs = 0L
    private var lastErr = ""
    private var guardStage = 0
    private val frameGuard = Runnable { runGuard() }

    private fun runGuard() {
        if (vlcActive) return
        // ხმა/დრო მიდის, მაგრამ ახალ ზედაპირზე კადრი არ დახატულა (გაყინული სურათი)
        if (awaitFrame && state == PLAYING && player != null && currentUrl.isNotEmpty()) {
            if (guardStage == 0) {
                // ჯერ მსუბუქად: პირდაპირ ეთერზე ვხტებით (ახალი გასაღები-კადრი), ქსელს თავიდან არ ვტვირთავთ
                guardStage = 1
                player?.seekToDefaultPosition()
                h.postDelayed(frameGuard, 3500)
            } else {
                awaitFrame = false
                restartSame()
            }
        }
    }

    // --- ეთერში გაყინვის მეთვალყურე: მუშაობს ყველა ეკრანზე (სრულ ეკრანზეც), OK-ის დაჭერა საჭირო აღარ არის ---
    private var monLastCount = -1L
    private var lowFpsHits = 0
    private var monSince = 0L
    private var bufSince = 0L
    private val monitor = object : Runnable {
        override fun run() {
            try { tick() } catch (_: Exception) {}
            if (player != null) h.postDelayed(this, 500)
        }
        private fun tick() {
            val p = player ?: return
            val now = System.currentTimeMillis()
            if (vlcActive) { monLastCount = -1; bufSince = 0; fpsCount = -1; return }
            if (currentUrl.isEmpty() || retrying || state == FAILED) { monLastCount = -1; bufSince = 0; return }
            // 1) ბუფერიზაციაში გაიჭედა თამაშის შემდეგ
            if (p.playbackState == Player.STATE_BUFFERING && p.playWhenReady) {
                if (bufSince == 0L) bufSince = now
                if (now - bufSince > 25000) { bufSince = 0; monLastCount = -1; forceRefresh() }   // ნელ ქსელზე თავიდან დაკავშირება დახმარებას არ გვცემს (ბუფერს კარგავს) — ვუცდით მინიმუმ 25 წმ
                return
            }
            bufSince = 0
            // 2) ხმა/დრო მიდის, მაგრამ ახალი კადრები აღარ იხატება
            if (p.playbackState == Player.STATE_READY && p.playWhenReady && p.videoFormat != null) {
                val c = p.videoDecoderCounters ?: return
                c.ensureUpdated()
                val n = c.renderedOutputBufferCount.toLong()
                if (n != monLastCount) { monLastCount = n; monSince = now }
                else if (now - monSince > 6000) { monLastCount = -1; forceRefresh() }
                // 3) კადრები იხატება, მაგრამ ძალიან იშვიათად (დეკოდერი "დაიღალა") — ფლეიერს ვანახლებთ
                if (fpsCount < 0 || now - fpsSince > 6000) {
                    if (fpsCount >= 0) {
                        val perSec = (n - fpsCount) * 1000.0 / (now - fpsSince)
                        val fr = p.videoFormat?.frameRate?.takeIf { it > 0f } ?: 25f
                        if (perSec < minOf(10.0, fr * 0.4)) { if (++lowFpsHits >= 2) { lowFpsHits = 0; rebuildPlayer() } } else lowFpsHits = 0   // ფლეიერს ვანახლებთ მხოლოდ თუ 2 ზედიზედ შემოწმებაზე (12 წმ) კადრები იშვიათია
                    }
                    fpsCount = n; fpsSince = now
                }
            } else { monLastCount = -1; fpsCount = -1 }
        }
    }

    /** ნაკადი გაიჭედა: ბმულს ვანახლებთ სიიდან და იგივე არხს თავიდან ვუკავშირდებით */
    private var lastForce = 0L
    private fun forceRefresh() {
        val now = System.currentTimeMillis()
        if (now - lastForce < 20000) return   // სერვერს ზედმეტად არ ვტვირთავთ (429)
        lastForce = now
        h.removeCallbacks(retry)
        retry.run()
    }

    /** ფლეიერს თავიდან ვქმნით (იგივეა, რაც აპლიკაციის გადატვირთვა) და იგივე არხს ვუშვებთ */
    private fun rebuildPlayer(restart: Boolean = true) {
        val now = System.currentTimeMillis()
        if (restart && now - lastRebuild < 15000) return
        lastRebuild = now
        zaps = 0; fpsCount = -1; monLastCount = -1
        h.removeCallbacks(watchdog)
        try { player?.clearVideoSurface() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        val np = ensurePlayer()
        onRebuilt?.invoke(np)
        if (restart && currentUrl.isNotEmpty()) {
            retrying = false; attempt = 0; everPlayed = false; state = LOADING
            onLoading()
            start()
        }
    }

    /** ვიდეოს ზედაპირს ვწყვეტთ ახალ ეკრანზე გადასვლამდე: დეკოდერი თავიდან ინიციალიზდება და სურათი არ ეჭედება */
    fun detachVideo() {
        try { player?.clearVideoSurface() } catch (_: Exception) {}
    }

    /** ფლეიერი ახალ PlayerView-ზე გადავიდა: თუ 2.5 წმ-ში კადრი არ გამოჩნდა, ვაახლებთ */
    private fun armFrameGuard() {
        h.removeCallbacks(frameGuard)
        if (vlcActive) { awaitFrame = false; return }
        if (state != PLAYING) { awaitFrame = false; return }
        awaitFrame = true
        guardStage = 0
        h.postDelayed(frameGuard, 3500)
    }
    /** ბმულის განახლება (არხი ვერ ჩაირთო): ძველი ბმული -> ახალი ბმული ან null */
    var refresher: ((String) -> String?)? = null

    private fun restartSame() {
        if (player != null && currentUrl.isNotEmpty()) {
            attempt = okAttempt[currentUrl] ?: 0
            everPlayed = false
            start()
        }
    }

    private val retry = Runnable {
        if (player == null || currentUrl.isEmpty()) return@Runnable
        val r = refresher
        if (r == null) { restartSame(); return@Runnable }
        val old = currentUrl
        Thread {
            val nu = try { r(old) } catch (e: Exception) { null }
            h.post {
                if (player == null || currentUrl != old) return@post   // ამასობაში სხვა არხი ჩაირთო
                if (nu != null && nu.isNotBlank()) currentUrl = nu.trim()
                restartSame()
            }
        }.start()
    }

    /** ეკრანი ("owner") ცვლის მოვლენების მიმღებს; unlisten(owner) მხოლოდ მაშინ ასუფთავებს, თუ ის ჯერ კიდევ მფლობელია */
    fun listen(owner: Any, loading: () -> Unit, playing: () -> Unit, failed: () -> Unit) {
        this.owner = owner
        onLoading = loading; onPlaying = playing; onFailed = failed
    }

    fun unlisten(owner: Any) {
        if (this.owner === owner) {
            this.owner = null
            onRebuilt = null
            onLoading = {}; onPlaying = {}; onFailed = {}
        }
    }

    /** სიჩქარის საზომი: საწყისი შეფასება ქსელის ტიპით (Wi-Fi/4G/3G…) ავტომატურად; სურვილისამებრ ხელით: player.initial_kbps */
    private fun bandwidthMeter(): DefaultBandwidthMeter {
        val b = DefaultBandwidthMeter.Builder(ctx)
        val kbps = RemoteConfig.i("player.initial_kbps", 0)
        if (kbps > 0) b.setInitialBitrateEstimate(kbps * 1000L)
        return b.build()
    }

    /** ქმნის ფლეიერს (თუ ჯერ არ არის); PlayerView-ს მიამაგრეთ დაბრუნებული ობიექტი */
    fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        val renderers = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)
        // ხარისხის ზედა ზღვარი (0 = ლიმიტის გარეშე). ნელი ინტერნეტისთვის სერვერიდან: api/app_config.json -> player.max_height (მაგ. 720 ან 480)
        val maxH = RemoteConfig.i("player.max_height", 0).coerceIn(0, 2160)
        // ავტომატური ხარისხი ინტერნეტის სიჩქარით (მრავალხარისხიანი HLS-ისთვის): გაზომილი სიჩქარის ~70%-ზე ირჩევს ვარიანტს,
        // სიჩქარის ვარდნისას სწრაფად ჩამოდის დაბალ ხარისხზე, გაუმჯობესებისას ნელა და სტაბილურად ადის.
        val upMs = RemoteConfig.i("player.abr_up_ms", 10_000).coerceIn(2_000, 60_000)
        val downMs = RemoteConfig.i("player.abr_down_ms", 12_000).coerceIn(2_000, 60_000)
        val fraction = (RemoteConfig.i("player.abr_fraction_pct", 70).coerceIn(30, 95)) / 100f
        val abr = AdaptiveTrackSelection.Factory(upMs, downMs, AdaptiveTrackSelection.DEFAULT_MIN_DURATION_TO_RETAIN_AFTER_DISCARD_MS, fraction)
        val selector = DefaultTrackSelector(ctx, abr).apply {
            val pb = buildUponParameters().setViewportSizeToPhysicalDisplaySize(ctx, true)
            if (maxH > 0) pb.setMaxVideoSize(Int.MAX_VALUE, maxH)
            setParameters(pb)
        }
        // ბუფერი: უფრო დიდი რეზერვი = ნელ/ცვალებად ინტერნეტზე ნაკლები გაჩერება. მნიშვნელობები შეიძლება შეიცვალოს სერვერიდან (player.buf_*)
        val bStart = RemoteConfig.i("player.buf_start_ms", 1_500).coerceIn(1_000, 10_000)
        val bRebuf = RemoteConfig.i("player.buf_rebuffer_ms", 6_000).coerceIn(bStart, 20_000)
        val bMin = RemoteConfig.i("player.buf_min_ms", 20_000).coerceIn(5_000, 60_000).coerceAtLeast(bRebuf)
        val bMax = RemoteConfig.i("player.buf_max_ms", 50_000).coerceIn(5_000, 120_000).coerceAtLeast(bMin)
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(bMin, bMax, bStart, bRebuf)
            .build()
        val p = ExoPlayer.Builder(ctx, renderers)
            .setTrackSelector(selector)
            .setLoadControl(load)
            .setWakeMode(androidx.media3.common.C.WAKE_MODE_NETWORK)   // ეკრანი/Wi-Fi არ დაიძინოს დაკვრისას
            .setAudioAttributes(androidx.media3.common.AudioAttributes.Builder().setUsage(androidx.media3.common.C.USAGE_MEDIA).setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
            .setBandwidthMeter(bandwidthMeter())
            .build()
        p.volume = 1f
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> {
                        h.removeCallbacks(bufSpinner)
                        h.removeCallbacks(watchdog)
                        h.removeCallbacks(retry)
                        retrying = false
                        everPlayed = true
                        if (currentUrl.isNotEmpty()) okAttempt[currentUrl] = attempt
                        state = PLAYING
                        onPlaying()
                    }
                    Player.STATE_BUFFERING -> {
                        if (!retrying && !(frameShown && state == PLAYING)) {
                            state = LOADING
                            onLoading()
                        } else if (!retrying) {
                            // კადრი გაჩერდა ბუფერის ამოწურვის გამო: 1.2 წმ-ზე მეტხანს თუ გაგრძელდა, ლოდინის ანიმაცია გამოჩნდეს
                            h.removeCallbacks(bufSpinner)
                            h.postDelayed(bufSpinner, 1200)
                        }
                    }
                    Player.STATE_ENDED -> {
                        // არქივი ბოლომდე მივიდა → პირდაპირ ეთერზე გადავდივართ (და არა იგივე არქივის თავიდან ცდა)
                        val lu = Timeshift.liveUrl()
                        if (Timeshift.isArchive(currentUrl) && lu.isNotEmpty()) {
                            val next = Timeshift.continuation()   // გადაცემა დასრულდა → არქივი მომდევნო გადაცემით გრძელდება
                            if (next != null) h.post { play(next) } else { Timeshift.clear(); h.post { play(lu) } }
                        } else handleError(null)
                    }
                }
            }

            override fun onVolumeChanged(volume: Float) { if (vlcActive) vlc?.setVolume(volume) }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { if (vlcActive) vlc?.setPaused(!playWhenReady) }

            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                // ხმა ან ვიდეო ტელეფონის დეკოდერს არ აქვს (AC3/DTS და ა.შ.) → უხმო/გაუხსნელი არხი: ვცდით VLC-ს
                if (!vlcActive && tracks.groups.isNotEmpty()) {
                    val a = tracks.groups.filter { it.type == androidx.media3.common.C.TRACK_TYPE_AUDIO }
                    val v = tracks.groups.filter { it.type == androidx.media3.common.C.TRACK_TYPE_VIDEO }
                    if ((a.isNotEmpty() && a.none { it.isSupported }) || (v.isNotEmpty() && v.none { it.isSupported })) { h.post { tryVlc() } }
                    // ვიდეო არის, ხმის ტრეკი საერთოდ არ ჩანს (უცნობი აუდიო ფორმატი) ან არჩეული არ არის → 2.5 წმ-ის შემდეგ, თუ ისევ ასეა, VLC
                    else if (v.isNotEmpty()) { h.removeCallbacks(noAudioCheck); h.postDelayed(noAudioCheck, 2500) }
                }
                // დიაგნოსტიკა ხმა/ვიდეოს კოდეკებზე — მხოლოდ თუ სერვერზე ჩართულია player.debug_toast = 1 (ნაგულისხმევად გამორთულია)
                if (RemoteConfig.i("player.debug_toast", 0) != 1) return
                val sb = StringBuilder()
                for (g in tracks.groups) {
                    if (g.length < 1) continue
                    if (g.type == androidx.media3.common.C.TRACK_TYPE_AUDIO || g.type == androidx.media3.common.C.TRACK_TYPE_VIDEO) {
                        val f = g.getTrackFormat(0)
                        sb.append(if (g.type == androidx.media3.common.C.TRACK_TYPE_AUDIO) "A:" else "V:")
                            .append(f.sampleMimeType).append(if (g.isSupported) "" else " (UNSUPPORTED)").append("   ")
                    }
                }
                if (sb.isNotEmpty()) h.post { android.widget.Toast.makeText(ctx, sb.toString(), android.widget.Toast.LENGTH_LONG).show() }
            }

            override fun onRenderedFirstFrame() {
                frameShown = true
                h.removeCallbacks(idrGuard)
                awaitFrame = false
                h.removeCallbacks(frameGuard)
            }

            override fun onPlayerError(error: PlaybackException) {
                handleError(error)
            }
        })
        player = p
        h.removeCallbacks(monitor)
        h.postDelayed(monitor, 500)
        return p
    }

    /** იგივე არხზე განმეორებითი გამოძახება არხს თავიდან აღარ იტვირთავს (თუ არ ჩაშლილა) */
    fun play(newUrl: String) {
        val u = newUrl.trim()
        ensurePlayer()
        if (u == currentUrl && state != FAILED) {
            dispatchState()
            armFrameGuard()
            return
        }
        if (++zaps >= 60) rebuildPlayer(false)   // იშვიათად (ყოველ 60 გადართვაზე) დეკოდერი სუფთავდება; ყოველ 8-ზე ფლეიერის თავიდან შექმნა სწორედ კადრს აჭედებდა
        stopVlc()
        currentUrl = u
        cycles = 0
        lastErr = ""
        h.removeCallbacks(retry)
        retrying = false
        attempt = okAttempt[u] ?: 0   // ადრე წარმატებული ვარიანტიდან ვიწყებთ
        everPlayed = false
        state = LOADING
        onLoading()
        // სწრაფი გადართვისას (ღილაკის ხშირი დაჭერა) შუალედურ არხებს ქსელში აღარ ვტვირთავთ — მხოლოდ ბოლოს ვიწყებთ
        val t = android.os.SystemClock.uptimeMillis()
        h.removeCallbacks(delayedStart)
        if (t - lastPlayAt < 600) h.postDelayed(delayedStart, 220) else start()
        lastPlayAt = t
    }

    private var lastPlayAt = 0L
    private val delayedStart = Runnable { if (player != null && currentUrl.isNotEmpty()) start() }

    /** ახალ ეკრანს ვუცხადებთ, რა მდგომარეობაშია ფლეიერი ახლა */
    fun dispatchState() {
        when (state) {
            PLAYING -> onPlaying()
            FAILED -> onFailed()
            else -> onLoading()
        }
    }

    fun release() {
        h.removeCallbacks(watchdog)
        h.removeCallbacks(retry)
        h.removeCallbacks(frameGuard)
        h.removeCallbacks(monitor)
        h.removeCallbacks(delayedStart)
        h.removeCallbacks(idrGuard)
        h.removeCallbacks(bufSpinner)
        stopVlc()
        try { vlc?.release() } catch (_: Exception) {}
        vlc = null
        retrying = false
        owner = null
        onLoading = {}; onPlaying = {}; onFailed = {}
        player?.release()
        player = null
        currentUrl = ""
        state = LOADING
    }

    /** ფორმატების რიგი ბმულის მიხედვით: null = ავტომატური ამოცნობა */
    private fun formats(): List<String?> {
        val l = currentUrl.lowercase()
        return when {
            l.contains("m3u8") -> listOf(MimeTypes.APPLICATION_M3U8, null, MimeTypes.VIDEO_MP2T)
            TS_REGEX.containsMatchIn(l) -> listOf(MimeTypes.VIDEO_MP2T, MimeTypes.APPLICATION_M3U8, null)
            else -> listOf(null, MimeTypes.APPLICATION_M3U8, MimeTypes.VIDEO_MP2T)
        }
    }

    private fun spec(a: Int): Pair<String?, String?> {
        val f = formats()
        return when (a) {
            0 -> Pair(f[0], UA_VLC)
            1 -> Pair(f[1], UA_VLC)
            2 -> Pair(f[2], UA_VLC)
            3 -> Pair(f[0], UA_BROWSER)
            else -> Pair(null, null)   // ავტომატური ფორმატი + ExoPlayer-ის სტანდარტული User-Agent (როგორც სხვა IPTV ფლეიერებში)
        }
    }

    private var useNonIdr = false
    private val bufSpinner = Runnable {
        val p = player
        if (p != null && !retrying && p.playbackState == Player.STATE_BUFFERING && p.playWhenReady) {
            state = LOADING
            onLoading()
        }
    }
    private val idrGuard = Runnable {
        if (player != null && currentUrl.isNotEmpty() && !frameShown && !useNonIdr && !retrying && state == LOADING) {
            nonIdrOk.add(currentUrl)
            start()
        }
    }

    private fun start() {
        val p = player ?: return
        if (vlcWanted(currentUrl)) { startVlc(); return }
        if (vlcActive) stopVlc()
        frameShown = false
        val (fmt, ua) = spec(attempt)
        val builder = MediaItem.Builder().setUri(currentUrl)
        if (fmt != null) builder.setMimeType(fmt)
        val item = builder.build()
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8000)
            .setReadTimeoutMs(12000)
        if (ua != null) http.setUserAgent(ua)
        val dsf = DefaultDataSource.Factory(ctx, http)
        // დროებითი ჩავარდნები (ქსელის წამიერი შეფერხება, ერთი სეგმენტის შეცდომა) 8-ჯერ თავისით მეორდება ნაკადის თავიდან დაწყების გარეშე
        val policy = DefaultLoadErrorHandlingPolicy(8)
        // IPTV-ის TS ნაკადები: არა-IDR გასაღები კადრები და წვდომის ერთეულების ამოცნობა — უფრო სწრაფი დაწყება და ნაკლები „გაყინული“ კადრი
        // არა-IDR დაწყება სწრაფია, მაგრამ წინა არხის „აჩრდილს“/გამოსვრილ კადრებს იძლევა. ამიტომ ჯერ სუფთა დაწყებას (IDR) ვცდით;
        // თუ 4.5 წმ-ში კადრი არ გამოჩნდა, ამ არხზე ვრთავთ არა-IDR რეჟიმს და ვიმახსოვრებთ. ნაგულისხმევად (player.ts_non_idr = 1) სწრაფი რეჟიმი ყველა არხზე; 0 = ჯერ სუფთა დაწყება
        // ტელეფონზე ნაგულისხმევად სუფთა დაწყება (წინა არხის „აჩრდილი“ აპარატურულ დეკოდერზე ჩანდა), ტელევიზორზე — სწრაფი. ხელით: player.ts_non_idr = 1 / 0
        val idrCfg = RemoteConfig.i("player.ts_non_idr", -1)
        useNonIdr = (if (idrCfg >= 0) idrCfg == 1 else Device.tv(ctx)) || nonIdrOk.contains(currentUrl)
        var tsFlags = DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
        if (useNonIdr) tsFlags = tsFlags or DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES
        val source: MediaSource = if (fmt == MimeTypes.APPLICATION_M3U8) {
            HlsMediaSource.Factory(dsf)
                .setAllowChunklessPreparation(true)
                .setExtractorFactory(DefaultHlsExtractorFactory(tsFlags, false))
                .setLoadErrorHandlingPolicy(policy)
                .createMediaSource(item)
        } else {
            DefaultMediaSourceFactory(dsf, DefaultExtractorsFactory().setTsExtractorFlags(tsFlags))
                .setLoadErrorHandlingPolicy(policy)
                .createMediaSource(item)
        }
        h.removeCallbacks(idrGuard)
        if (!useNonIdr) h.postDelayed(idrGuard, 3000)
        p.setMediaSource(source)
        p.prepare()
        p.playWhenReady = true
        h.removeCallbacks(watchdog)
        h.postDelayed(watchdog, if (attempt == 0) RemoteConfig.i("player.start_timeout_ms", 16_000).coerceIn(8_000, 40_000).toLong() else 12000L)   // პირველ ცდას მეტი დრო, მომდევნო ვარიანტებს — ნაკლები
    }

    private fun isParseError(e: PlaybackException?): Boolean {
        if (e == null) return false
        return e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED
    }

    /** 429/503: ვაცდით სერვერს (Retry-After ან 6, 12, 24, 30 წმ); სხვა შეცდომა: 3 წმ */
    private fun retryDelay(): Long {
        if (lastCode != 429 && lastCode != 503) return RETRY_MS
        if (retryAfterMs > 0) return retryAfterMs.coerceIn(3000L, 60000L)
        return (6000L shl (cycles - 1).coerceIn(0, 2)).coerceAtMost(30000L)
    }

    private fun handleError(e: PlaybackException?) {
        h.removeCallbacks(watchdog)
        lastCode = 0; retryAfterMs = 0L
        (e?.cause as? androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException)?.let { c ->
            lastCode = c.responseCode
            val ra = c.headerFields.entries.firstOrNull { it.key.equals("Retry-After", true) }?.value?.firstOrNull()
            retryAfterMs = (ra?.trim()?.toLongOrNull() ?: 0L) * 1000L
        }
        lastErr = if (e == null) "ვადა გავიდა" else {
            val c = e.cause
            val http = if (c is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) " HTTP " + c.responseCode else ""
            e.errorCodeName.removePrefix("ERROR_CODE_") + http
        }
        val p = player ?: return
        if (e != null && e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            p.seekToDefaultPosition()
            p.prepare()
            h.postDelayed(watchdog, START_TIMEOUT_MS)
            return
        }
        if (everPlayed) {
            // ნაკადი გაჩერდა, მაგრამ აქამდე თამაშობდა — ერთხელ თავიდან ვუკავშირდებით
            everPlayed = false
            start()
            return
        }
        // დამახსოვრებული ვარიანტი აღარ მუშაობს: დავივიწყოთ და სრული რიგი თავიდან გავიაროთ
        if (attempt > 0 && okAttempt[currentUrl] == attempt) {
            okAttempt.remove(currentUrl)
            attempt = 0
            start()
            return
        }
        // ფორმატის შეცდომისას ვცდით შემდეგ ფორმატს; კავშირის/სერვერის შეცდომისას — ბრაუზერის სათაურს
        val next = when {
            attempt >= 4 -> -1
            lastCode == 429 || lastCode == 503 -> -1   // სერვერი ზღუდავს მოთხოვნებს: ზედმეტ მოთხოვნას აღარ ვუშვებთ
            isParseError(e) && attempt < 2 -> attempt + 1
            attempt == 3 -> 4
            else -> 3
        }
        if (next < 0) {
            if (tryVlc()) return
            try { p.stop() } catch (ex: Exception) { }
            state = FAILED
            cycles++
            retrying = true
            onFailed()
            // იგივე არხს რამდენიმე წამში თავიდან ვცდით; სხვა არხზე არასოდეს გადადის
            h.removeCallbacks(retry)
            h.postDelayed(retry, retryDelay())
            return
        }
        attempt = next
        start()
    }
}

/** ერთი საერთო ფლეიერი მთელ აპლიკაციაზე */
object StreamHub {
    private var c: StreamController? = null

    fun get(ctx: Context): StreamController =
        c ?: StreamController(ctx.applicationContext).also {
            val app = ctx.applicationContext
            it.refresher = { u -> ChannelRefresher.refresh(app, u) }
            c = it
        }

    fun peek(): StreamController? = c

    fun release() {
        c?.release()
        c = null
    }
}
