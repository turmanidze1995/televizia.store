package store.televizia.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/**
 * TV გადახვევის ზოლი YouTube-ის მსგავსად: ქვემოთ თხელი ზოლი (ვარდისფერი = ნანახი, ნაცრისფერი = დარჩენილი),
 * ბოლოში წრე (სახელური), ზემოთ დროის ბუშტი, მარცხნივ გადაცემის სახელი, მარჯვნივ „დრო / საერთო“.
 * გადახვევისას (scrubbing) ზოლი და წრე იზრდება, ისევე როგორც YouTube-ზე.
 */
class SeekOverlay(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val sp = resources.displayMetrics.scaledDensity

    private val shade = Paint().apply { isAntiAlias = true }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FFFFFF }
    private val played = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2E7E.toInt() }
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2E7E.toInt() }
    private val bubbleBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6101018.toInt() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color_WHITE; textSize = 20 * sp; typeface = Typeface.DEFAULT_BOLD
    }
    private val txtSmall = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFD5D9EA.toInt(); textSize = 17 * sp }
    private val rect = RectF()

    /** 0..1 */
    private var frac = 0f
    private var scrubbing = false
    private var bubble = ""
    private var left = ""
    private var right = ""

    fun set(fraction: Float, scrubbing: Boolean, bubble: String, left: String, right: String) {
        this.frac = fraction.coerceIn(0f, 1f)
        this.scrubbing = scrubbing
        this.bubble = bubble
        this.left = left
        this.right = right
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val hgt = height.toFloat()
        // ქვემოდან ზემოთ ნაზი ჩრდილი, რომ წარწერები ვიდეოზე იკითხებოდეს
        shade.shader = android.graphics.LinearGradient(0f, hgt * 0.35f, 0f, hgt, 0x00000000, 0xCC000000.toInt(), android.graphics.Shader.TileMode.CLAMP)
        c.drawRect(0f, hgt * 0.35f, w, hgt, shade)

        val pad = 28 * d
        val barH = (if (scrubbing) 8 else 5) * d
        val cy = hgt - 46 * d
        val x0 = pad
        val x1 = w - pad
        val xp = x0 + (x1 - x0) * frac

        rect.set(x0, cy - barH / 2, x1, cy + barH / 2)
        c.drawRoundRect(rect, barH / 2, barH / 2, track)
        rect.set(x0, cy - barH / 2, xp, cy + barH / 2)
        c.drawRoundRect(rect, barH / 2, barH / 2, played)

        val r = (if (scrubbing) 11 else 8) * d
        c.drawCircle(xp, cy, r, thumb)

        // ბუშტი დროით — წრის თავზე (YouTube-ის გადახედვის ადგილას)
        if (scrubbing && bubble.isNotEmpty()) {
            val tw = txt.measureText(bubble)
            val bw = tw + 28 * d
            val bh = 40 * d
            var bx = xp - bw / 2
            bx = bx.coerceIn(x0, x1 - bw)
            val by = cy - r - 14 * d - bh
            rect.set(bx, by, bx + bw, by + bh)
            c.drawRoundRect(rect, 10 * d, 10 * d, bubbleBg)
            c.drawText(bubble, bx + 14 * d, by + bh / 2 + txt.textSize * 0.35f, txt)
        }

        // ქვემოთ: მარცხნივ გადაცემა, მარჯვნივ დრო
        val ty = cy + r + 26 * d
        if (left.isNotEmpty()) {
            val maxW = (x1 - x0) * 0.68f
            val s = android.text.TextUtils.ellipsize(left, android.text.TextPaint(txtSmall), maxW, android.text.TextUtils.TruncateAt.END).toString()
            c.drawText(s, x0, ty, txtSmall)
        }
        if (right.isNotEmpty()) c.drawText(right, x1 - txtSmall.measureText(right), ty, txtSmall)
    }

    companion object {
        private const val Color_WHITE = 0xFFFFFFFF.toInt()
    }
}
