package store.televizia.app

import android.content.Context
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

data class Program(val start: Long, val stop: Long, val title: String)

/**
 * XMLTV ტელეპროგრამა (EPG).
 *  - ბმული: EPG_URL (Config.kt) ან არხების სიის url-tvg
 *  - .xml და .xml.gz ორივე იკითხება; რედირექტებს (http<->https) მიჰყვება
 *  - არხი უკავშირდება tvg-id-ით, ხოლო თუ ის არ ემთხვევა — არხის სახელით (display-name)
 *  - ინახება [ახლა-24სთ .. ახლა+48სთ] — გასული გადაცემებიც ჩანს და კომპაქტური ქეშის სახით დისკზე — მეორე გახსნისას მყისიერია
 */
object Epg {
    private const val CACHE = "epg_cache.bin"
    private const val VERSION = 4
    private const val FRESH_MS = 3 * 3600_000L
    private const val PAST_MS = 24 * 3600_000L
    private const val FUTURE_MS = 48 * 3600_000L

    @Volatile private var map: Map<String, List<Program>> = emptyMap()
    @Volatile private var names: Map<String, String> = emptyMap()

    val hasData: Boolean get() = map.isNotEmpty()

    /** true = მონაცემები ჩაიტვირთა (ქეშიდან ან ქსელიდან) */
    fun load(ctx: Context, playlistUrls: List<String>, channels: List<Channel>): Boolean {
        // Televizo-ს მსგავსად: ჯერ ფლეილისტის საკუთარი EPG (#EXTM3U url-tvg), შემდეგ საიტის საერთო EPG — ორივე ერთად
        // (ადრე საერთო EPG-ის მითითებისას ფლეილისტის საკუთარი EPG საერთოდ არ იკითხებოდა)
        val urls = (playlistUrls + listOf(RemoteConfig.epgUrl())).map { it.trim() }.filter { it.startsWith("http") }
            .groupBy { it.substringAfter("://").lowercase() }.map { g -> g.value.firstOrNull { it.startsWith("https", true) } ?: g.value.first() }   // http/https დუბლიკატი ერთხელ
        if (urls.isEmpty()) return false
        val hash = urls.joinToString("|").hashCode()
        val file = File(ctx.filesDir, CACHE)

        if (readCache(file, hash, freshOnly = true)) { attach(channels); return true }

        val tmpMap = HashMap<String, MutableList<Program>>()
        val tmpNames = HashMap<String, String>()
        var ok = false
        val now = System.currentTimeMillis()
        for (u in urls) {
            try {
                open(u).use { parseInto(it, tmpMap, tmpNames, now) }
                ok = true
            } catch (e: Exception) {
                // ერთი ბმული ვერ ჩაიტვირთა — დანარჩენს მაინც ვცდით
            }
        }
        if (ok && tmpMap.isNotEmpty()) {
            // დუბლიკატების მოშორება (ერთი და იგივე გადაცემა ორ წყაროში / ორჯერ ფაილში) + დროით დალაგება
            for (e in tmpMap.entries) {
                val seen = HashSet<String>()
                val l = e.value
                l.sortBy { it.start }
                val it2 = l.iterator()
                while (it2.hasNext()) { val pr = it2.next(); if (!seen.add("${pr.start}|${pr.title}")) it2.remove() }
            }
            map = tmpMap
            names = tmpNames
            writeCache(file, hash)
            attach(channels)
            return true
        }
        // ქსელი ვერ მუშაობს — ძველი ქეში სჯობს არაფერს
        if (readCache(file, hash, freshOnly = false)) { attach(channels); return true }
        return false
    }

    /** არხების დაკავშირება EPG-სთან (გამოიძახეთ ყოველ ჯერზე, როცა არხების სია იცვლება) */
    fun attach(channels: List<Channel>) {
        val m = map
        val nm = names
        // tvg-id რეგისტრის გარეშე + სახელის ვარიანტები ("GE: Digi+ Hits HD" -> "Digi+ Hits HD" და ა.შ.)
        val lower = HashMap<String, String>()
        for (k in m.keys) lower.putIfAbsent(k.lowercase(), k)
        for (c in channels) {
            var key = ""
            if (c.epgId.isNotBlank()) key = if (m.containsKey(c.epgId)) c.epgId else (lower[c.epgId.lowercase()] ?: nm[norm(c.epgId)] ?: "")
            if (key.isEmpty()) {
                for (v in nameVariants(c.name)) {
                    val k = nm[v]
                    if (k != null) { key = k; break }
                    val k2 = lower[v]
                    if (k2 != null) { key = k2; break }
                }
            }
            c.epgKey = key
        }
    }

    /** არხის სახელის შესადარებელი ვარიანტები: სრული, ქვეყნის პრეფიქსის ("GE:", "RU |") გარეშე, ფრჩხილების გარეშე */
    private fun nameVariants(name: String): List<String> {
        val out = LinkedHashSet<String>()
        out.add(norm(name))
        val noPrefix = name.replace(Regex("^\\s*[A-Za-z]{2,3}\\s*[:|\\-]\\s*"), "")
        out.add(norm(noPrefix))
        val noParen = noPrefix.replace(Regex("[\\(\\[][^\\)\\]]*[\\)\\]]"), "")
        out.add(norm(noParen))
        // "Imedi TV" / "TV Imedi" / "Imedi Channel" ↔ "Imedi"
        for (v in out.toList()) {
            for (suf in arrayOf("tv", "channel", "ge", "geo")) if (v.length > suf.length + 2 && v.endsWith(suf)) out.add(v.dropLast(suf.length))
            for (pre in arrayOf("tv", "ge", "geo")) if (v.length > pre.length + 2 && v.startsWith(pre)) out.add(v.drop(pre.length))
        }
        out.remove("")
        return out.toList()
    }

    /** სიაში (start-ით დალაგებული) ბოლო გადაცემის ინდექსი, რომელიც t-მდე დაიწყო; ორობითი ძებნა — სიის გადახვევა აღარ ჭედავს */
    private fun idxAt(l: List<Program>, t: Long): Int {
        var lo = 0; var hi = l.size - 1; var r = -1
        while (lo <= hi) {
            val m = (lo + hi) ushr 1
            if (l[m].start <= t) { r = m; lo = m + 1 } else hi = m - 1
        }
        return r
    }

    private fun nowIdx(l: List<Program>, t: Long): Int {
        val i = idxAt(l, t)
        if (i >= 0 && t < l[i].stop) return i
        if (i > 0 && t < l[i - 1].stop) return i - 1   // გადაფარვა
        return -1
    }

    fun now(ch: Channel): Program? {
        val l = map[ch.epgKey] ?: return null
        val i = nowIdx(l, System.currentTimeMillis())
        return if (i >= 0) l[i] else null
    }

    fun next(ch: Channel): Program? {
        val l = map[ch.epgKey] ?: return null
        val i = nowIdx(l, System.currentTimeMillis())
        if (i < 0) return null
        val stop = l[i].stop
        var j = i + 1
        while (j < l.size && l[j].start < stop) j++
        return if (j < l.size) l[j] else null
    }

    /** მიმდინარე და მომდევნო გადაცემები */
    fun upcoming(ch: Channel?, count: Int): List<Program> {
        if (ch == null) return emptyList()
        val l = map[ch.epgKey] ?: return emptyList()
        val t = System.currentTimeMillis()
        return l.filter { it.stop > t }.take(count)
    }

    /** მთელი პროგრამა (გასული გადაცემებიც): ბოლო 24 სთ + მომავალი 48 სთ, დროის მიხედვით */
    fun schedule(ch: Channel?): List<Program> {
        if (ch == null) return emptyList()
        return map[ch.epgKey] ?: emptyList()
    }

    // ---------- ქსელი და დამუშავება ----------

    private fun open(url: String): InputStream {
        var u = url
        for (hop in 0..6) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/110 Mobile Safari/537.36")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw IOException("redirect")
                c.disconnect()
                u = URL(URL(u), loc).toString()
                continue
            }
            if (code !in 200..299) {
                c.disconnect()
                throw IOException("http $code")
            }
            val raw = BufferedInputStream(c.inputStream, 64 * 1024)
            raw.mark(2)
            val b0 = raw.read()
            val b1 = raw.read()
            raw.reset()
            return if (b0 == 0x1f && b1 == 0x8b) GZIPInputStream(raw, 64 * 1024) else raw
        }
        throw IOException("too many redirects")
    }

    private fun parseInto(
        stream: InputStream,
        outMap: HashMap<String, MutableList<Program>>,
        outNames: HashMap<String, String>,
        now: Long
    ) {
        val p = Xml.newPullParser()
        p.setInput(stream, null)
        val minStop = now - PAST_MS
        val maxStart = now + FUTURE_MS
        val sb = StringBuilder()
        var chId = ""
        var inDisp = false
        var inTitle = false
        var inProg = false
        var progCh = ""
        var start = 0L
        var stop = 0L
        var title = ""
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "channel" -> chId = p.getAttributeValue(null, "id") ?: ""
                    "display-name" -> if (chId.isNotEmpty() && !inProg) { inDisp = true; sb.setLength(0) }
                    "programme" -> {
                        inProg = true
                        progCh = p.getAttributeValue(null, "channel") ?: ""
                        start = parseTime(p.getAttributeValue(null, "start"))
                        stop = parseTime(p.getAttributeValue(null, "stop"))
                        title = ""
                    }
                    "title" -> if (inProg && title.isEmpty()) { inTitle = true; sb.setLength(0) }
                }
                XmlPullParser.TEXT -> if (inDisp || inTitle) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "display-name" -> if (inDisp) {
                        val n = norm(sb.toString())
                        if (n.isNotEmpty() && !outNames.containsKey(n)) outNames[n] = chId
                        inDisp = false
                    }
                    "channel" -> chId = ""
                    "title" -> if (inTitle) { title = sb.toString().trim(); inTitle = false }
                    "programme" -> {
                        inProg = false
                        if (progCh.isNotEmpty() && stop > minStop && start < maxStart && title.isNotEmpty()) {
                            outMap.getOrPut(progCh) { ArrayList() }.add(Program(start, stop, title))
                        }
                    }
                }
            }
            ev = p.next()
        }
    }

    /** არხის სახელის გასასწორებლად: პატარა ასოები, მხოლოდ ასოები/ციფრები, HD/SD დაბოლოების გარეშე */
    fun norm(s: String): String {
        val b = StringBuilder()
        for (c in s.lowercase()) if (c.isLetterOrDigit()) b.append(c)
        var r = b.toString()
        for (suf in arrayOf("fhd", "uhd", "hd", "sd")) {
            if (r.length > suf.length + 1 && r.endsWith(suf)) { r = r.dropLast(suf.length); break }
        }
        return r
    }

    /** XMLTV დრო: 20261013120000 +0400 (SimpleDateFormat-ის გარეშე — ათიათასობით ჩანაწერზე ბევრად სწრაფია) */
    private fun parseTime(s: String?): Long {
        if (s == null) return 0L
        return try {
            val t = s.trim()
            val y = t.substring(0, 4).toInt()
            val mo = t.substring(4, 6).toInt()
            val d = t.substring(6, 8).toInt()
            val h = t.substring(8, 10).toInt()
            val mi = t.substring(10, 12).toInt()
            val se = if (t.length >= 14) t.substring(12, 14).toInt() else 0
            val days = daysFromCivil(y, mo, d)
            val base = (((days * 24 + h) * 60 + mi) * 60 + se) * 1000L
            val rest = if (t.length > 14) t.substring(14).trim() else ""
            val offMin = if (rest.length >= 5 && (rest[0] == '+' || rest[0] == '-')) {
                val oh = rest.substring(1, 3).toInt()
                val om = rest.substring(3, 5).toInt()
                (if (rest[0] == '+') 1 else -1) * (oh * 60 + om)
            } else 0
            base - offMin * 60_000L
        } catch (e: Exception) {
            0L
        }
    }

    private fun daysFromCivil(y0: Int, m: Int, d: Int): Long {
        val y = if (m <= 2) y0 - 1 else y0
        val era = (if (y >= 0) y else y - 399) / 400
        val yoe = y - era * 400
        val doy = (153 * (m + (if (m > 2) -3 else 9)) + 2) / 5 + d - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097L + doe - 719468L
    }

    // ---------- დისკის ქეში ----------

    private fun writeCache(file: File, hash: Int) {
        try {
            val tmp = File(file.parentFile, CACHE + ".tmp")
            DataOutputStream(BufferedOutputStream(FileOutputStream(tmp), 64 * 1024)).use { o ->
                o.writeInt(VERSION)
                o.writeInt(hash)
                o.writeLong(System.currentTimeMillis())
                val nm = names
                o.writeInt(nm.size)
                for ((k, v) in nm) { o.writeUTF(k); o.writeUTF(v) }
                val m = map
                o.writeInt(m.size)
                for ((id, list) in m) {
                    o.writeUTF(id)
                    o.writeInt(list.size)
                    for (pr in list) { o.writeLong(pr.start); o.writeLong(pr.stop); o.writeUTF(pr.title) }
                }
            }
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
        } catch (e: Exception) { }
    }

    private fun readCache(file: File, hash: Int, freshOnly: Boolean): Boolean {
        if (!file.exists()) return false
        return try {
            DataInputStream(BufferedInputStream(FileInputStream(file), 64 * 1024)).use { i ->
                if (i.readInt() != VERSION) return false
                if (i.readInt() != hash) return false
                val saved = i.readLong()
                if (freshOnly && System.currentTimeMillis() - saved > FRESH_MS) return false
                val nm = HashMap<String, String>()
                repeat(i.readInt()) { nm[i.readUTF()] = i.readUTF() }
                val m = HashMap<String, List<Program>>()
                repeat(i.readInt()) {
                    val id = i.readUTF()
                    val n = i.readInt()
                    val l = ArrayList<Program>(n)
                    repeat(n) { l.add(Program(i.readLong(), i.readLong(), i.readUTF())) }
                    m[id] = l
                }
                if (m.isEmpty()) return false
                names = nm
                map = m
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
