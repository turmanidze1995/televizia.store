package store.televizia.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * ტელეფონის გადახვევის ზოლი — ზუსტად ისეთივე, როგორიც TV-ზეა (SeekOverlay): თხელი ზოლი, ვარდისფერი ნანახი ნაწილი,
 * წრე და დროის ბუშტი. თითით გადაათრევ; გაშვებისას onCommit(წილი 0..1) გადადის ახალ ადგილას.
 * ზოლი იზრდება გადათრევისას (როგორც YouTube-ზე).
 */
class ScrubBar @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val d = resources.displayMetrics.density
    private val sp = resources.displayMetrics.scaledDensity
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FFFFFF }
    private val played = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2E7E.toInt() }
    private val bubbleBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6101018.toInt() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 15 * sp; typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()

    private var frac = 0f
    var dragging = false
        private set
    private var bubble = ""

    /** წილი → ბუშტის ტექსტი (მაგ. „12:40“) */
    var labelFor: (Float) -> String = { "" }
    var onStart: () -> Unit = {}
    var onCommit: (Float) -> Unit = {}

    fun setFraction(f: Float) {
        if (dragging) return
        frac = f.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(
            resolveSize(suggestedMinimumWidth, wSpec),
            resolveSize(((if (dragging) 96 else 48) * d).toInt(), hSpec)
        )
    }

    private val padX get() = 14 * d

    private fun fracAt(x: Float): Float = ((x - padX) / (width - 2 * padX)).coerceIn(0f, 1f)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                onStart()
                requestLayout()   // გადათრევისას ზედა ადგილი ბუშტისთვის იზრდება (ზოლი ადგილზე რჩება)
                frac = fracAt(e.x); bubble = labelFor(frac)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> { frac = fracAt(e.x); bubble = labelFor(frac); invalidate() }
            MotionEvent.ACTION_UP -> {
                frac = fracAt(e.x)
                dragging = false
                requestLayout()
                invalidate()
                onCommit(frac)
            }
            MotionEvent.ACTION_CANCEL -> { dragging = false; requestLayout(); invalidate() }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cy = height - 18 * d
        val x0 = padX
        val x1 = w - padX
        val xp = x0 + (x1 - x0) * frac
        val barH = (if (dragging) 8 else 5) * d
        rect.set(x0, cy - barH / 2, x1, cy + barH / 2)
        c.drawRoundRect(rect, barH / 2, barH / 2, track)
        rect.set(x0, cy - barH / 2, xp, cy + barH / 2)
        c.drawRoundRect(rect, barH / 2, barH / 2, played)
        val r = (if (dragging) 11 else 8) * d
        c.drawCircle(xp, cy, r, played)
        if (dragging && bubble.isNotEmpty()) {
            val bw = txt.measureText(bubble) + 24 * d
            val bh = 30 * d
            val bx = (xp - bw / 2).coerceIn(0f, w - bw)
            val by = cy - r - 8 * d - bh
            rect.set(bx, by, bx + bw, by + bh)
            c.drawRoundRect(rect, 8 * d, 8 * d, bubbleBg)
            c.drawText(bubble, bx + 12 * d, by + bh / 2 + txt.textSize * 0.35f, txt)
        }
    }
}
