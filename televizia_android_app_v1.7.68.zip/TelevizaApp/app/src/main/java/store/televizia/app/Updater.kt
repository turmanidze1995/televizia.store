package store.televizia.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * განახლება აპლიკაციის შიგნით: APK-ს ვტვირთავთ პროგრესით, ვამოწმებთ SHA-256-ს (თუ მითითებულია) და ვხსნით ანდროიდის დამყენებელს.
 * სრულიად უხმოდ დაყენება ანდროიდში შეუძლებელია — მომხმარებელი ერთხელ დაადასტურებს „დაყენებას“.
 */
object Updater {
    @Volatile private var running = false

    fun start(a: Activity, url: String, sha256: String, size: Long) {
        if (running) return
        // Android 8+: აპლიკაციას უნდა ჰქონდეს „უცნობი წყაროდან დაყენების“ ნებართვა
        if (Build.VERSION.SDK_INT >= 26 && !a.packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(a)
                .setTitle("საჭიროა ნებართვა")
                .setMessage("განახლების დასაყენებლად ჩართეთ ამ აპლიკაციისთვის „უცნობი წყაროდან დაყენება“. გაიხსნება პარამეტრები; ჩართვის შემდეგ დაბრუნდით აპლიკაციაში და თავიდან დააჭირეთ განახლებას.")
                .setPositiveButton("პარამეტრები") { _, _ ->
                    try {
                        a.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.packageName)))
                    } catch (_: Exception) { fallbackOpen(a, url) }
                }
                .setNegativeButton("გაუქმება", null)
                .show()
            return
        }
        running = true
        val d = a.resources.displayMetrics.density
        val bar = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; isIndeterminate = true }
        val label = TextView(a).apply { text = "ჩამოტვირთვა…"; textSize = 16f; gravity = Gravity.CENTER }
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            val p = (20 * d).toInt()
            setPadding(p, p, p, p)
            addView(label, LinearLayout.LayoutParams(-1, -2))
            addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (14 * d).toInt() })
        }
        val dlg = AlertDialog.Builder(a).setTitle("განახლება").setView(box).setCancelable(false).create()
        dlg.show()

        Thread {
            var err: String? = null
            var file: File? = null
            try {
                val dir = File(a.cacheDir, "updates").also { it.mkdirs() }
                dir.listFiles()?.forEach { try { it.delete() } catch (_: Exception) {} }
                val target = File(dir, "update.apk")
                file = target
                val c = URL(url).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = true
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.setRequestProperty("User-Agent", "TeleviziaApp")
                if (c.responseCode !in 200..299) throw RuntimeException("HTTP " + c.responseCode)
                val total = if (c.contentLengthLong > 0) c.contentLengthLong else size
                val md = MessageDigest.getInstance("SHA-256")
                var done = 0L
                var lastUi = 0L
                c.inputStream.use { input ->
                    target.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            md.update(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - lastUi > 200) {
                                lastUi = now
                                val pct = if (total > 0) (done * 100 / total).toInt().coerceIn(0, 100) else -1
                                val mb = String.format("%.1f", done / 1048576.0)
                                a.runOnUiThread {
                                    if (pct >= 0) { bar.isIndeterminate = false; bar.progress = pct; label.text = "ჩამოტვირთვა… $pct% ($mb MB)" }
                                    else label.text = "ჩამოტვირთვა… $mb MB"
                                }
                            }
                        }
                    }
                }
                if (done < 1_000_000) throw RuntimeException("ფაილი ძალიან მცირეა")
                if (size > 0 && done != size) throw RuntimeException("ფაილის ზომა არ ემთხვევა")
                val got = md.digest().joinToString("") { "%02x".format(it) }
                if (sha256.isNotBlank() && !got.equals(sha256.trim(), ignoreCase = true)) throw RuntimeException("ფაილის შემოწმება ვერ გაიარა (SHA-256)")
            } catch (e: Exception) {
                err = e.message ?: "შეცდომა"
            }
            val f = file
            a.runOnUiThread {
                running = false
                try { dlg.dismiss() } catch (_: Exception) {}
                if (a.isFinishing || a.isDestroyed) return@runOnUiThread
                if (err != null || f == null) {
                    AlertDialog.Builder(a)
                        .setTitle("განახლება ვერ ჩამოიტვირთა")
                        .setMessage(err ?: "")
                        .setPositiveButton("თავიდან") { _, _ -> start(a, url, sha256, size) }
                        .setNeutralButton("ბრაუზერით") { _, _ -> fallbackOpen(a, url) }
                        .setNegativeButton("გაუქმება", null)
                        .show()
                } else install(a, f, url)
            }
        }.start()
    }

    private fun install(a: Activity, f: File, url: String) {
        try {
            val uri = FileProvider.getUriForFile(a, a.packageName + ".fileprovider", f)
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            a.startActivity(i)
        } catch (e: Exception) {
            fallbackOpen(a, url)
        }
    }

    private fun fallbackOpen(a: Activity, url: String) {
        try { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }
}
