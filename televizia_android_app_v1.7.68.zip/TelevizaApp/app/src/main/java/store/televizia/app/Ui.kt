package store.televizia.app

import android.content.Context
import android.os.Handler
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object Ui {
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun timeOf(ms: Long): String = fmt.format(Date(ms))

    /** 83000 → "1:23" */
    fun mmss(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
        else "%d:%02d".format(s / 60, s % 60)
    }

    /** პროგრამის პროგრესი პროცენტებში (0..100) */
    fun progressOf(p: Program?): Int {
        if (p == null || p.stop <= p.start) return 0
        val t = System.currentTimeMillis()
        return (((t - p.start) * 100) / (p.stop - p.start)).toInt().coerceIn(0, 100)
    }

    /** საათი ეკრანის მარჯვენა ზედა კუთხეში; tick ყოველ 10 წამში */
    fun startClock(tv: TextView, h: Handler, tick: () -> Unit = {}): Runnable {
        val r = object : Runnable {
            override fun run() {
                tv.text = fmt.format(Date())
                tick()
                h.postDelayed(this, 10_000)
            }
        }
        h.post(r)
        return r
    }
}

/**
 * ხელის გადასმა და შეხება ვიდეოზე:
 *  - გადასმა ზევით/მარცხნივ → შემდეგი არხი, ქვევით/მარჯვნივ → წინა არხი
 *  - შეხება → onTap; ორმაგი შეხება → onDouble (თუ მითითებულია)
 */
class SwipeTouch(
    ctx: Context,
    onTap: () -> Unit,
    onDouble: (() -> Unit)? = null,
    onSwipe: (next: Boolean) -> Unit
) : View.OnTouchListener {
    private val minDist = 60 * ctx.resources.displayMetrics.density

    private var flung = false
    private var downX = 0f
    private var downY = 0f

    private val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            if (onDouble == null) { onTap(); return true }
            return false
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (onDouble != null) { onTap(); return true }
            return false
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            onDouble?.invoke()
            return onDouble != null
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (e1 == null) return false
            return swipe(e2.x - e1.x, e2.y - e1.y)
        }
    })

    private fun swipe(dx: Float, dy: Float): Boolean = when {
        abs(dy) > abs(dx) && abs(dy) > minDist -> { flung = true; onSwipe(dy < 0); true }
        abs(dx) > abs(dy) && abs(dx) > minDist -> { flung = true; onSwipe(dx < 0); true }
        else -> false
    }

    override fun onTouch(v: View, e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) { flung = false; downX = e.x; downY = e.y }
        detector.onTouchEvent(e)   // სწრაფი გადასმა (onFling) აქ მუშავდება
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            if (!flung) swipe(e.x - downX, e.y - downY)   // ნელი გადასმაც არხს ცვლის
            v.performClick()
        }
        return true
    }
}
