plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "store.televizia.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "store.televizia.app"
        minSdk = 21
        targetSdk = 34
        versionCode = 56
        versionName = "1.7.52"
    }

    // ერთიანი, მუდმივი ხელმოწერა: ყოველი ახალი ბილდი ძველზე "განახლებად" დაყენდება (GitHub-ის ყოველი ბილდი
    // სხვანაირად რომ არ მოეწეროს). debug და release ორივე ამავე გასაღებით იწერება.
    signingConfigs {
        getByName("debug") {
            storeFile = file("televizia.keystore")
            storePassword = "televizia-2026"
            keyAlias = "televizia"
            keyPassword = "televizia-2026"
        }
    }

    buildTypes {
        release {
            // სწრაფი (გამარტივებული) აპლიკაცია: R8 + რესურსების შემცირება. APK ამავე ტელეფონზე დაყენდება debug-ის გასაღებით
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-datasource:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
}
