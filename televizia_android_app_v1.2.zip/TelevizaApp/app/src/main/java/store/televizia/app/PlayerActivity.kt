package store.televizia.app

import android.animation.ValueAnimator
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Timeline
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * სრული ეკრანის ფლეიერი.
 * შეხება/გადასმა (ტელეფონი): შეხება → მართვა (გადახვევა, პაუზა, LIVE), ზევით/მარცხნივ გადასმა → შემდეგი არხი,
 *   ქვევით/მარჯვნივ → წინა არხი, ორმაგი შეხება → ეკრანზე მორგება (ჩატევა / გაშლა / გაჭიმვა).
 * პულტი: CH+/CH−, ციფრები 0–9 (ეკრანზე ჩანს აკრეფილი ნომერი და არხი), LAST → წინა არხი, MENU/RED → არხები,
 *   GUIDE/GREEN → პროგრამა, INFO/YELLOW → ინფო, BLUE → პანელების დახურვა, ◀◀ / ▶▶ და ←/→ → გადახვევა ±10 წმ,
 *   ⏯ → პაუზა, STOP → გასვლა, MUTE → ხმა, BACK → პანელი ან გასვლა, OK → არხების სია.
 */
class PlayerActivity : AppCompatActivity() {
    private val h = Handler(Looper.getMainLooper())
    private var clockR: Runnable? = null
    private var prevChannel: Channel? = null
    private var seeking = false
    private var resizeIdx = 0

    private val hideInfo = Runnable { infoBar.visibility = View.INVISIBLE }
    private val hideControls = Runnable { controls.visibility = View.GONE }
    private val seekTick = object : Runnable {
        override fun run() {
            if (controls.visibility == View.VISIBLE) {
                updateSeek()
                h.postDelayed(this, 500)
            }
        }
    }

    private lateinit var pv: PlayerView
    private lateinit var infoBar: View
    private lateinit var loadingLogo: ImageView
    private lateinit var playerError: TextView
    private var loadAnim: ValueAnimator? = null
    private lateinit var channelsWrap: View
    private lateinit var programsWrap: View
    private lateinit var programsEmpty: TextView
    private lateinit var drawer: RecyclerView
    private lateinit var programList: RecyclerView
    private lateinit var chNum: TextView
    private lateinit var chName: TextView
    private lateinit var chNow: TextView
    private lateinit var chLogo: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var controls: View
    private lateinit var seek: SeekBar
    private lateinit var liveTxt: TextView
    private lateinit var btnPlay: TextView
    private lateinit var numBox: View
    private lateinit var numDigits: TextView
    private lateinit var numName: TextView
    private lateinit var drawerAdapter: ChannelAdapter
    private val programAdapter = ProgramAdapter()
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val resizeNames = arrayOf("ეკრანზე ჩატევა", "ეკრანზე გაშლა", "გაჭიმვა")

    private val isTv: Boolean by lazy { packageManager.hasSystemFeature("android.software.leanback") }

    private val digits = DigitEntry(
        size = { ChannelHolder.list.size },
        nameAt = { ChannelHolder.list.getOrNull(it)?.name },
        onUpdate = { d, name, valid ->
            numBox.visibility = View.VISIBLE
            numDigits.text = d
            numDigits.setTextColor(if (valid) 0xFF00D9C0.toInt() else 0xFFFF5C72.toInt())
            numName.text = when {
                name != null -> name
                valid -> ""
                else -> "არხი არ არსებობს"
            }
        },
        onCommit = { pos -> ChannelHolder.list.getOrNull(pos)?.let { playChannel(it) } },
        onClose = { numBox.visibility = View.GONE }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ჭრილის (notch) ქვეშაც ვიდეო სრულ ეკრანზე
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_player)
        val url = intent.getStringExtra("url") ?: run { finish(); return }

        pv = findViewById(R.id.playerView)
        infoBar = findViewById(R.id.infoBar)
        loadingLogo = findViewById(R.id.loadingLogo)
        playerError = findViewById(R.id.playerError)
        channelsWrap = findViewById(R.id.channelsWrap)
        programsWrap = findViewById(R.id.programsWrap)
        programsEmpty = findViewById(R.id.programsEmpty)
        drawer = findViewById(R.id.drawer)
        programList = findViewById(R.id.programList)
        chNum = findViewById(R.id.chNum)
        chName = findViewById(R.id.chName)
        chNow = findViewById(R.id.chNow)
        chLogo = findViewById(R.id.chLogo)
        progress = findViewById(R.id.progress)
        controls = findViewById(R.id.controls)
        seek = findViewById(R.id.seek)
        liveTxt = findViewById(R.id.liveTxt)
        btnPlay = findViewById(R.id.btnPlay)
        numBox = findViewById(R.id.numBox)
        numDigits = findViewById(R.id.numDigits)
        numName = findViewById(R.id.numName)

        // ჭრილი / სისტემური ზოლები: ყველა წარწერა უსაფრთხო ზონაში ჩანს, ვიდეო კი მთელ ეკრანზეა
        val overlays = findViewById<View>(R.id.overlays)
        ViewCompat.setOnApplyWindowInsetsListener(overlays) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            insets
        }

        // ეკრანის ზომაზე მორგება (პატარა ტელეფონზეც ყველაფერი ეტევა)
        val dm = resources.displayMetrics
        loadingLogo.layoutParams = loadingLogo.layoutParams.apply { width = minOf((520 * dm.density).toInt(), (dm.widthPixels * 0.55f).toInt()) }
        val panelW = minOf((420 * dm.density).toInt(), (dm.widthPixels * 0.62f).toInt())
        channelsWrap.layoutParams = channelsWrap.layoutParams.apply { width = panelW }
        programsWrap.layoutParams = programsWrap.layoutParams.apply { width = panelW }

        resizeIdx = Store.resizeMode(this).coerceIn(0, 2)
        pv.resizeMode = resizeModes[resizeIdx]

        drawerAdapter = ChannelAdapter { ch, _ ->
            playChannel(ch)
            showPanel(null)
        }
        drawer.layoutManager = LinearLayoutManager(this)
        drawer.setHasFixedSize(true)
        drawer.adapter = drawerAdapter
        drawerAdapter.submit(ChannelHolder.list)
        programList.layoutManager = LinearLayoutManager(this)
        programList.adapter = programAdapter

        setupTouch()
        setupControls()

        // მიმდინარე არხი: უკვე არჩეული (სიიდან) ან მხოლოდ ბმული
        if (ChannelHolder.current == null || ChannelHolder.current?.url != url) {
            ChannelHolder.current = ChannelHolder.list.firstOrNull { it.url == url } ?: Channel("", "", url, "")
        }
        updateChannelUi(ChannelHolder.current!!)
        showInfo()
    }

    override fun onStart() {
        super.onStart()
        if (!::pv.isInitialized) return
        val ch = ChannelHolder.current ?: return
        val sc = StreamHub.get(this)
        sc.listen(
            this,
            loading = { startLoadAnim() },
            playing = {
                stopLoadAnim()
                playerError.visibility = View.GONE
                btnPlay.text = if (sc.player?.playWhenReady == false) "გაგრძელება" else "პაუზა"
            },
            failed = {
                // არხი ვერ გაიხსნა: მხოლოდ შეტყობინება, სხვა არხზე თავისით არ გადავდივართ
                stopLoadAnim()
                playerError.text = "არხი დროებით გამორთულია"
                playerError.visibility = View.VISIBLE
            }
        )
        pv.player = sc.ensurePlayer()
        sc.play(ch.url)   // იგივე არხი უკვე თამაშობს (სიიდან) → თავიდან აღარ იტვირთება
        clockR = Ui.startClock(findViewById<TextView>(R.id.clock), h) {
            if (infoBar.visibility == View.VISIBLE) showInfo()
        }
    }

    override fun onStop() {
        super.onStop()
        if (!::pv.isInitialized) return
        h.removeCallbacks(hideControls)
        h.removeCallbacks(seekTick)
        clockR?.let { h.removeCallbacks(it) }
        clockR = null
        digits.cancel()
        pv.player = null
        StreamHub.peek()?.unlisten(this)
        // Home-ზე გასვლისას ფლეიერს ვთიშავთ; უკან დაბრუნებისას (finish) ის სიას რჩება
        if (!isFinishing && !isChangingConfigurations) StreamHub.release()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ---------- შეხება და მართვა ----------

    private fun setupTouch() {
        pv.setOnTouchListener(SwipeTouch(this, onTap = {
            if (anyPanelVisible()) showPanel(null) else toggleControls()
        }, onDouble = { cycleResize() }, onSwipe = { next -> step(if (next) 1 else -1) }))
    }

    private fun setupControls() {
        findViewById<View>(R.id.btnBack).setOnClickListener { seekBy(-10_000); keepControls() }
        findViewById<View>(R.id.btnFwd).setOnClickListener { seekBy(10_000); keepControls() }
        findViewById<View>(R.id.btnLive).setOnClickListener { goLive(); keepControls() }
        btnPlay.setOnClickListener { togglePlay(); keepControls() }
        findViewById<View>(R.id.btnAspect).setOnClickListener { cycleResize(); keepControls() }
        findViewById<View>(R.id.btnChannels).setOnClickListener { hideControlsNow(); showPanel(channelsWrap) }
        findViewById<View>(R.id.btnGuide).setOnClickListener { hideControlsNow(); showPanel(programsWrap) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar?) {
                seeking = true
                h.removeCallbacks(hideControls)
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                seeking = false
                val p = StreamHub.peek()?.player
                if (p != null && p.isCurrentMediaItemSeekable) {
                    val dur = p.duration
                    if (dur != C.TIME_UNSET && dur > 0) p.seekTo(dur * seek.progress / 1000)
                }
                keepControls()
            }
        })
    }

    private fun showControls() {
        controls.visibility = View.VISIBLE
        updateSeek()
        h.removeCallbacks(seekTick)
        h.postDelayed(seekTick, 500)
        keepControls()
    }

    private fun keepControls() {
        h.removeCallbacks(hideControls)
        h.postDelayed(hideControls, 6000)
    }

    private fun hideControlsNow() {
        h.removeCallbacks(hideControls)
        controls.visibility = View.GONE
    }

    private fun toggleControls() {
        if (controls.visibility == View.VISIBLE) hideControlsNow() else showControls()
    }

    private fun cycleResize() {
        resizeIdx = (resizeIdx + 1) % resizeModes.size
        pv.resizeMode = resizeModes[resizeIdx]
        Store.setResizeMode(this, resizeIdx)
        Toast.makeText(this, resizeNames[resizeIdx], Toast.LENGTH_SHORT).show()
    }

    // ---------- გადახვევა ----------

    /** რამდენით ვართ "ცოცხალი" ეთერიდან უკან (მწ). HLS ლაივზე — ფანჯრის ბოლოდან */
    private fun behindLiveMs(p: androidx.media3.exoplayer.ExoPlayer): Long {
        if (!p.isCurrentMediaItemLive) return 0
        val tl = p.currentTimeline
        if (tl.isEmpty) return 0
        val w = tl.getWindow(p.currentMediaItemIndex, Timeline.Window())
        if (w.defaultPositionMs == C.TIME_UNSET) return 0
        return (w.defaultPositionMs - p.currentPosition).coerceAtLeast(0)
    }

    private fun updateSeek() {
        val p = StreamHub.peek()?.player ?: return
        val seekable = p.isCurrentMediaItemSeekable
        seek.isEnabled = seekable
        seek.alpha = if (seekable) 1f else 0.35f
        val behind = behindLiveMs(p)
        if (seekable && !seeking) {
            val dur = p.duration
            if (dur != C.TIME_UNSET && dur > 0) seek.progress = (p.currentPosition * 1000 / dur).toInt().coerceIn(0, 1000)
        }
        val live = behind < 4000
        liveTxt.text = if (live) "● LIVE" else "−" + Ui.mmss(behind)
        liveTxt.setTextColor(if (live) 0xFFFF5C72.toInt() else 0xFFFFFFFF.toInt())
        btnPlay.text = if (!p.playWhenReady) "გაგრძელება" else "პაუზა"
    }

    /** ლაივ ნაკადზე გადახვევა მუშაობს იმდენად, რამდენსაც არხის ნაკადი (HLS ფანჯარა / არქივი) იძლევა */
    private fun seekBy(ms: Long) {
        val p = StreamHub.peek()?.player ?: return
        if (!p.isCurrentMediaItemSeekable) {
            Toast.makeText(this, "ამ არხზე გადახვევა მიუწვდომელია", Toast.LENGTH_SHORT).show()
            return
        }
        val target = p.currentPosition + ms
        val tl = p.currentTimeline
        var def = C.TIME_UNSET
        if (!tl.isEmpty) def = tl.getWindow(p.currentMediaItemIndex, Timeline.Window()).defaultPositionMs
        if (p.isCurrentMediaItemLive && def != C.TIME_UNSET && target >= def) p.seekToDefaultPosition()
        else p.seekTo(target.coerceAtLeast(0))
        if (isTv) showControls()
    }

    private fun goLive() {
        val p = StreamHub.peek()?.player ?: return
        p.seekToDefaultPosition()
        p.playWhenReady = true
    }

    private fun togglePlay() {
        StreamHub.peek()?.player?.let {
            it.playWhenReady = !it.playWhenReady
            btnPlay.text = if (it.playWhenReady) "პაუზა" else "გაგრძელება"
        }
    }

    private fun toggleMute() {
        StreamHub.peek()?.player?.let { it.volume = if (it.volume == 0f) 1f else 0f }
    }

    // ---------- არხები ----------

    private fun step(delta: Int) {
        val list = ChannelHolder.list
        if (list.isEmpty()) return
        val pos = Math.floorMod(ChannelHolder.index + delta, list.size)
        playChannel(list[pos])
    }

    private fun playChannel(ch: Channel) {
        val cur = ChannelHolder.current
        if (cur != null && cur.url != ch.url) prevChannel = cur
        ChannelHolder.current = ch
        Store.setLastUrl(this, ch.url)
        playerError.visibility = View.GONE
        startLoadAnim()
        StreamHub.get(this).play(ch.url)
        updateChannelUi(ch)
        showInfo()
        flashInfo()
    }

    private fun updateChannelUi(ch: Channel) {
        drawerAdapter.select(ch.url)
        val list = Epg.upcoming(ch, 40)
        programAdapter.submit(list)
        programsEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        programList.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        findViewById<TextView>(R.id.programsTitle).text = "ტელეპროგრამა · " + ch.name
    }

    /** ჩატვირთვისას: TELEVIZIA.STORE ლოგო ფერებში ციმციმებს */
    private fun startLoadAnim() {
        loadingLogo.visibility = View.VISIBLE
        if (loadAnim != null) return
        val cm = ColorMatrix()
        loadAnim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { va ->
                val d = va.animatedValue as Float
                cm.setRotate(2, d * 0.3f)
                loadingLogo.colorFilter = ColorMatrixColorFilter(cm)
                loadingLogo.alpha = 0.55f + 0.45f * Math.abs(Math.sin(Math.toRadians(d.toDouble()))).toFloat()
            }
            start()
        }
    }

    private fun stopLoadAnim() {
        loadAnim?.cancel()
        loadAnim = null
        loadingLogo.colorFilter = null
        loadingLogo.alpha = 1f
        loadingLogo.visibility = View.GONE
    }

    private fun showPanel(panel: View?) {
        channelsWrap.visibility = if (panel === channelsWrap) View.VISIBLE else View.GONE
        programsWrap.visibility = if (panel === programsWrap) View.VISIBLE else View.GONE
        if (panel === channelsWrap) {
            drawerAdapter.select(ChannelHolder.current?.url ?: "")
            drawer.scrollToPosition(ChannelHolder.index.coerceAtLeast(0))
        }
        if (panel === programsWrap) {
            ChannelHolder.current?.let { updateChannelUi(it) }
        }
    }

    private fun togglePanel(panel: View) {
        showPanel(if (panel.visibility == View.VISIBLE) null else panel)
    }

    private fun anyPanelVisible() =
        channelsWrap.visibility == View.VISIBLE || programsWrap.visibility == View.VISIBLE

    private fun flashInfo() {
        infoBar.visibility = View.VISIBLE
        h.removeCallbacks(hideInfo)
        h.postDelayed(hideInfo, 6000)
    }

    private fun showInfo() {
        val ch = ChannelHolder.current ?: return
        val idx = ChannelHolder.index
        chNum.text = if (idx >= 0) (idx + 1).toString() else ""
        chName.text = ch.name
        ImageLoader.show(ch.logo, chLogo, ch.name)
        val now = Epg.now(ch)
        val next = Epg.next(ch)
        chNow.text = when {
            now == null -> ""
            next == null -> "${Ui.timeOf(now.start)}  ${now.title}"
            else -> "${Ui.timeOf(now.start)}  ${now.title}  →  ${Ui.timeOf(next.start)}  ${next.title}"
        }
        val hasEpg = now != null
        chNow.visibility = if (hasEpg) View.VISIBLE else View.GONE
        progress.visibility = if (hasEpg) View.VISIBLE else View.GONE
        progress.progress = Ui.progressOf(now)
        if (infoBar.visibility != View.VISIBLE) flashInfo()
    }

    // ---------- პულტი ----------

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val handled = when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                step(1); true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                step(-1); true
            }
            KeyEvent.KEYCODE_LAST_CHANNEL -> {
                prevChannel?.let { playChannel(it) }
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                togglePlay(); true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                seekBy(-10_000); true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                seekBy(10_000); true
            }
            KeyEvent.KEYCODE_MEDIA_STOP -> {
                finish(); true
            }
            KeyEvent.KEYCODE_MUTE -> {
                toggleMute(); true
            }
            KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_PROG_YELLOW -> {
                if (infoBar.visibility == View.VISIBLE) infoBar.visibility = View.INVISIBLE else { showInfo(); flashInfo() }
                true
            }
            KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_PROG_GREEN -> {
                togglePanel(programsWrap); true
            }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_PROG_RED -> {
                togglePanel(channelsWrap); true
            }
            KeyEvent.KEYCODE_PROG_BLUE -> {
                showPanel(null); true
            }
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                when {
                    digits.active -> digits.cancel()
                    anyPanelVisible() -> showPanel(null)
                    controls.visibility == View.VISIBLE -> hideControlsNow()
                    else -> finish()
                }
                true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (digits.active) digits.commit() else togglePanel(channelsWrap)
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (anyPanelVisible()) false else { seekBy(-10_000); true }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (anyPanelVisible()) false else { seekBy(10_000); true }
            }
            else -> when (keyCode) {
                in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> { digits.digit(keyCode - KeyEvent.KEYCODE_0); true }
                in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> { digits.digit(keyCode - KeyEvent.KEYCODE_NUMPAD_0); true }
                else -> false
            }
        }
        return handled || super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        if (::loadingLogo.isInitialized) stopLoadAnim()
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
