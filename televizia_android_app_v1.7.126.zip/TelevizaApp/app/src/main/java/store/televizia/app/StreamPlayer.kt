package store.televizia.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import okhttp3.OkHttpClient
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.trackselection.AdaptiveTrackSelection
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector

/**
 * საერთო ფლეიერი ორივე ეკრანისთვის (სია და სრული ეკრანი). ერთი და იგივე ExoPlayer გადადის ეკრანიდან
 * ეკრანზე, ამიტომ "სრულ ეკრანზე" გახსნისას არხი თავიდან აღარ იტვირთება — ვიდეო წყვეტის გარეშე გრძელდება.
 *
 * არხს რამდენიმე გზით ცდილობს გახსნას:
 *  - http <-> https გადამისამართებებს მიჰყვება
 *  - ფორმატს ბმულიდან ხვდება, ხოლო თუ ვერ გაიხსნა — სცდის სხვა ფორმატებს (HLS, TS, ავტომატური)
 *  - ბოლოს სცდის ბრაუზერის User-Agent-ით
 *  - ცდას წყვეტს, თუ არხი 12 წამში არ ჩაირთო
 *  - ყველა ცდის შემდეგ უბრალოდ იძახებს onFailed — სხვა არხზე თავისით არასოდეს გადადის
 *
 * სისწრაფე: მცირე საწყისი ბუფერი (1 წმ), HLS-ის "chunkless" მომზადება, ეკრანის ზომაზე მორგებული
 * ხარისხი (4K ნაკადს ტელეფონზე ტყუილად არ ვტვირთავთ).
 */
class StreamController(private val ctx: Context) {
    companion object {
        private const val UA_VLC = "VLC/3.0.18 LibVLC/3.0.18"
        private const val UA_BROWSER =
            "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0 Safari/537.36"
        private const val START_TIMEOUT_MS = 22000L
        /** ბოლოს წარმატებული ვარიანტი (ფორმატი/UA) თითო ბმულზე: შემდეგ ჩართვაზე პირდაპირ ის ვარიანტი იწყება, წარუმატებელი ცდები აღარ იკარგება */
        /** არხები, რომლებსაც ჩვეულებრივი IDR კადრი არ აქვთ და მხოლოდ "არა-IDR დაწყებით" იხსნება */
        private val nonIdrOk = HashSet<String>()
        private val okAttempt = object : LinkedHashMap<String, Int>(64, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Int>?): Boolean = size > 400
        }
        /** არხები, რომლებიც VLC-ზე წარმატებით ირთვება (ინახება მოწყობილობაზე) და რომლებზეც VLC უკვე ჩავარდა (ამ სესიაში აღარ ვცდით) */
        private val vlcOk = HashSet<String>()
        private val vlcTried = HashSet<String>()
        private var vlcLoaded = false
        private val TS_REGEX = Regex("""\.ts($|[?/#])""")
        private const val RETRY_MS = 3000L
        /** v1.7.109: საერთო OkHttp კლიენტი — კავშირები/TLS თავიდან არ იქმნება ყოველ არხზე (არხი უფრო სწრაფად იხსნება). გამორთვა სერვერიდან: player.okhttp = 0 */
        private val okClient: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .dns(SmartDns)   // v1.7.113: ჭკვიანი DNS (სისტემური → Cloudflare/Google DoH), გამორთვა: player.smart_dns = 0
                .connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(12, java.util.concurrent.TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)   // http <-> https გადამისამართებები, როგორც ადრე
                .retryOnConnectionFailure(true)
                .build()
        }
        private const val LOADING = 0
        private const val PLAYING = 1
        private const val FAILED = 2
    }

    var player: ExoPlayer? = null
        private set
    var currentUrl: String = ""
        private set

    private var owner: Any? = null
    private var onLoading: () -> Unit = {}
    private var onPlaying: () -> Unit = {}
    private var onFailed: () -> Unit = {}
    /** ფლეიერი ახლით შეიცვალა (დეკოდერის "დაღლილობის" გამო) — ეკრანმა ახალი ობიექტი უნდა მიიმაგროს */
    var onRebuilt: ((ExoPlayer) -> Unit)? = null
    private var zaps = 0
    private var lastRebuild = 0L
    private var fpsSince = 0L
    private var fpsCount = -1L

    private val h = Handler(Looper.getMainLooper())

    // ---------- სარეზერვო ფლეიერი (VLC) ----------
    private var vlc: VlcFallback? = null
    private var vlcActive = false
    private var hostFrame: android.widget.FrameLayout? = null
    private var hostView: androidx.media3.ui.PlayerView? = null
    private val vlcWatch = Runnable { vlcFailed() }

    /** ვიდეოს ეკრანი (PlayerView): VLC-ის ზედაპირი მასში იდება. ეკრანები მას თვითონ ანიჭებენ */
    var host: androidx.media3.ui.PlayerView?
        get() = hostView
        set(v) {
            hostView = v
            hostFrame = v?.overlayFrameLayout
            vlc?.setHost(hostFrame)
        }
    /** ეკრანის დახურვისას host-ს ვასუფთავებთ მხოლოდ თუ ის ისევ ჩვენია (ახალმა ეკრანმა შეიძლება უკვე გადაიბაროს) */
    fun releaseHost(v: androidx.media3.ui.PlayerView) { if (hostView === v) host = null }

    init {
        // თუ ამ მოწყობილობაზე უკვე არის VLC-ით მომუშავე არხები, VLC წინასწარ ფონურად ემზადება — არხი უფრო სწრაფად ჩაირთვება
        try { vlcLoad(); if (vlcOk.isNotEmpty() && vlcEnabled()) ensureVlc().warmUp() } catch (_: Throwable) {}
    }

    private fun vlcPrefs() = ctx.getSharedPreferences("player_pref", Context.MODE_PRIVATE)
    private fun vlcLoad() {
        if (vlcLoaded) return
        vlcLoaded = true
        try { vlcOk.addAll(vlcPrefs().getStringSet("vlc_urls", emptySet()) ?: emptySet()) } catch (_: Exception) {}
    }
    private fun vlcSave() {
        try { vlcPrefs().edit().putStringSet("vlc_urls", HashSet(vlcOk.toList().takeLast(300))).apply() } catch (_: Exception) {}
    }
    private fun vlcEnabled() = RemoteConfig.i("player.vlc_fallback", 1) == 1

    /** v1.7.95: წარმატებული ვარიანტი (ფორმატი/UA) ინახება მოწყობილობაზე — აპის გადატვირთვის შემდეგაც პირდაპირ ის ვარიანტი იწყება (ნელი „ცდების რიგი“ აღარ მეორდება) */
    private var okLoaded = false
    private fun okGet(u: String): Int {
        if (!okLoaded) {
            okLoaded = true
            try {
                for (e in vlcPrefs().getStringSet("ok_attempts", emptySet()) ?: emptySet()) {
                    val i = e.indexOf('|')
                    if (i > 0) { val a = e.substring(0, i).toIntOrNull(); if (a != null) okAttempt.putIfAbsent(e.substring(i + 1), a) }
                }
            } catch (_: Exception) {}
        }
        return okAttempt[u] ?: 0
    }
    private fun okSave() {
        try {
            val set = LinkedHashSet<String>()
            for ((u, a) in okAttempt) if (a > 0) set.add("$a|$u")
            vlcPrefs().edit().putStringSet("ok_attempts", HashSet(set.toList().takeLast(300))).apply()
        } catch (_: Exception) {}
    }

    /** არა-IDR რეჟიმის მქონე არხები ინახება მოწყობილობაზე: ყოველ გახსნაზე ტყუილად აღარ ვცდით და არ ვრესტარტებთ */
    private var nonIdrLoaded = false
    private fun nonIdrLoad() {
        if (nonIdrLoaded) return
        nonIdrLoaded = true
        try {
            // v1.7.98: დამახსოვრებული რეჟიმები (არა-IDR / წარმატებული ცდა) ახალ ვერსიაზე იწმინდება — ძველი, შეცდომით დამახსოვრებული არხი „გაფუჭებულ“ რეჟიმში არ დარჩეს
            @Suppress("DEPRECATION") val ver = ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode
            if (vlcPrefs().getInt("modes_ver", 0) != ver) {
                vlcPrefs().edit().remove("non_idr_urls").remove("ok_attempts").putInt("modes_ver", ver).apply()
                okAttempt.clear()
            }
            nonIdrOk.addAll(vlcPrefs().getStringSet("non_idr_urls", emptySet()) ?: emptySet())
        } catch (_: Exception) {}
    }
    private fun nonIdrSave() {
        try { vlcPrefs().edit().putStringSet("non_idr_urls", HashSet(nonIdrOk.toList().takeLast(300))).apply() } catch (_: Exception) {}
    }

    /** ეს არხი თავიდანვე VLC-ზე უნდა ირთვებოდეს? (დამახსოვრებული / სერვერის სია player.vlc_match / ყველა: player.vlc_all=1) */
    private fun vlcWanted(url: String): Boolean {
        if (!vlcEnabled() || vlcTried.contains(url) || DeviceProfile.vlcBanned(url)) return false
        vlcLoad()
        if (RemoteConfig.i("player.vlc_all", 0) == 1) return true
        if (vlcOk.contains(url)) return true
        val m = RemoteConfig.s("player.vlc_match", "")
        if (m.isNotBlank()) for (part in m.split(',', '\n', ';')) { val t = part.trim(); if (t.length >= 3 && url.contains(t, true)) return true }
        return false
    }

    private fun ensureVlc(): VlcFallback = vlc ?: VlcFallback(
        ctx,
        onPlaying = { h.post { vlcPlaying() } },
        onBuffering = { h.post { if (vlcActive && state != PLAYING) { state = LOADING; onLoading() } } },
        onError = { h.post { vlcFailed() } }
    ).also { vlc = it; it.setHost(hostFrame) }

    private fun cancelExoTimers() {
        h.removeCallbacks(watchdog); h.removeCallbacks(retry); h.removeCallbacks(frameGuard)
        h.removeCallbacks(delayedStart); h.removeCallbacks(idrGuard); h.removeCallbacks(bufSpinner); h.removeCallbacks(noAudioCheck)
        awaitFrame = false
    }

    private fun startVlc() {
        val u = currentUrl
        if (u.isEmpty()) return
        cancelExoTimers()
        try { player?.stop() } catch (_: Exception) {}
        vlcActive = true
        DeviceProfile.vlcStarted(u)
        retrying = false
        state = LOADING
        onLoading()
        val v = ensureVlc()
        v.setVolume(player?.volume ?: 1f)
        val (vu, vh) = M3u.split(u)
        v.start(vu, vh)
        if (player?.playWhenReady == false) v.setPaused(true)
        h.removeCallbacks(vlcWatch)
        h.postDelayed(vlcWatch, 20000)
    }

    private fun vlcPlaying() {
        if (!vlcActive) return
        h.removeCallbacks(vlcWatch)
        val u = currentUrl
        if (u.isNotEmpty() && !vlcOk.contains(u)) { vlcLoad(); vlcOk.add(u); vlcSave() }   // ამ არხზე შემდეგ ჯერზე პირდაპირ VLC
        everPlayed = true
        retrying = false
        if (state != PLAYING) { state = PLAYING; onPlaying() }
    }

    private fun stopVlc() {
        h.removeCallbacks(vlcWatch)
        if (vlcActive) { vlcActive = false; try { vlc?.stop() } catch (_: Exception) {}; DeviceProfile.vlcStopped() }
    }

    /** VLC-მაც ვერ გახსნა: დავიმახსოვროთ და ჩვეულებრივ ექსოპლეიერზე დავბრუნდეთ */
    private fun vlcFailed() {
        if (!vlcActive) return
        val u = currentUrl
        stopVlc()
        vlcTried.add(u)
        if (vlcOk.remove(u)) vlcSave()
        attempt = 0
        everPlayed = false
        retrying = false
        state = LOADING
        onLoading()
        start()
    }

    /** ძირითადმა ფლეიერმა არხი ვერ გახსნა / ხმა ან ვიდეო მხარდაუჭერელია → ვცდით VLC-ს. true = გადავედით */
    private val noAudioCheck: Runnable = Runnable {
        val p = player
        if (p != null && !vlcActive && state == PLAYING && p.playWhenReady) {
            val g = p.currentTracks.groups
            val hasVideo = g.any { it.type == androidx.media3.common.C.TRACK_TYPE_VIDEO }
            val audioOk = g.any { it.type == androidx.media3.common.C.TRACK_TYPE_AUDIO && it.isSelected }
            if (hasVideo && !audioOk) tryVlc()
        }
    }

    private fun tryVlc(): Boolean {
        if (!vlcEnabled() || vlcActive || currentUrl.isEmpty() || vlcTried.contains(currentUrl) || DeviceProfile.vlcBanned(currentUrl)) return false
        startVlc()
        return true
    }
    private var attempt = 0
    private var everPlayed = false
    private var state = LOADING
    private val watchdog = Runnable { handleError(null) }
    private var retrying = false
    private var awaitFrame = false
    /** ამ არხის პირველი კადრი უკვე გამოჩნდა — მერე ბუფერიზაციისას ლოგოს აღარ ვაჩვენებთ (ვიდეო არ იფარება) */
    private var frameShown = false
    private var cycles = 0
    private var lastCode = 0
    private var retryAfterMs = 0L
    private var lastErr = ""
    private var guardStage = 0
    private val frameGuard: Runnable = Runnable { runGuard() }

    private fun runGuard() {
        if (vlcActive) return
        // ხმა/დრო მიდის, მაგრამ ახალ ზედაპირზე კადრი არ დახატულა (გაყინული სურათი)
        if (awaitFrame && state == PLAYING && player != null && currentUrl.isNotEmpty()) {
            if (guardStage == 0) {
                // ჯერ მსუბუქად: პირდაპირ ეთერზე ვხტებით (ახალი გასაღები-კადრი), ქსელს თავიდან არ ვტვირთავთ
                guardStage = 1
                player?.seekToDefaultPosition()
                h.postDelayed(frameGuard, 3500)
            } else {
                awaitFrame = false
                restartSame()
            }
        }
    }

    // --- ეთერში გაყინვის მეთვალყურე: მუშაობს ყველა ეკრანზე (სრულ ეკრანზეც), OK-ის დაჭერა საჭირო აღარ არის ---
    private var monLastCount = -1L
    private var lowFpsHits = 0
    private var monSince = 0L
    private var bufSince = 0L
    private val monitor = object : Runnable {
        override fun run() {
            try { tick() } catch (_: Exception) {}
            if (player != null) h.postDelayed(this, 500)
        }
        private fun tick() {
            val p = player ?: return
            val now = System.currentTimeMillis()
            if (vlcActive) { monLastCount = -1; bufSince = 0; fpsCount = -1; return }
            if (currentUrl.isEmpty() || retrying || state == FAILED) { monLastCount = -1; bufSince = 0; return }
            // 1) ბუფერიზაციაში გაიჭედა თამაშის შემდეგ
            if (p.playbackState == Player.STATE_BUFFERING && p.playWhenReady) {
                if (bufSince == 0L) bufSince = now
                if (now - bufSince > 25000) { bufSince = 0; monLastCount = -1; forceRefresh() }   // ნელ ქსელზე თავიდან დაკავშირება დახმარებას არ გვცემს (ბუფერს კარგავს) — ვუცდით მინიმუმ 25 წმ
                return
            }
            bufSince = 0
            // 2) ხმა/დრო მიდის, მაგრამ ახალი კადრები აღარ იხატება
            if (p.playbackState == Player.STATE_READY && p.playWhenReady && p.videoFormat != null) {
                DeviceProfile.noteStable(500)
                val c = p.videoDecoderCounters ?: return
                c.ensureUpdated()
                val n = c.renderedOutputBufferCount.toLong()
                if (n != monLastCount) { monLastCount = n; monSince = now }
                else if (now - monSince > 6000) { monLastCount = -1; forceRefresh() }
                // 3) კადრები იხატება, მაგრამ ძალიან იშვიათად (დეკოდერი "დაიღალა") — ფლეიერს ვანახლებთ
                if (fpsCount < 0 || now - fpsSince > 6000) {
                    if (fpsCount >= 0) {
                        val perSec = (n - fpsCount) * 1000.0 / (now - fpsSince)
                        val fr = p.videoFormat?.frameRate?.takeIf { it > 0f } ?: 25f
                        if (perSec < minOf(10.0, fr * 0.4)) { if (++lowFpsHits >= 3) { lowFpsHits = 0; DeviceProfile.degrade("lowfps"); rebuildPlayer() } } else lowFpsHits = 0   // ფლეიერს ვანახლებთ მხოლოდ თუ 3 ზედიზედ შემოწმებაზე (18 წმ) კადრები იშვიათია
                    }
                    fpsCount = n; fpsSince = now
                }
            } else { monLastCount = -1; fpsCount = -1 }
        }
    }

    /** ნაკადი გაიჭედა: ბმულს ვანახლებთ სიიდან და იგივე არხს თავიდან ვუკავშირდებით */
    private var lastForce = 0L
    private fun forceRefresh() {
        val now = System.currentTimeMillis()
        if (now - lastForce < 20000) return   // სერვერს ზედმეტად არ ვტვირთავთ (429)
        lastForce = now
        h.removeCallbacks(retry)
        retry.run()
    }

    /** ფლეიერს თავიდან ვქმნით (იგივეა, რაც აპლიკაციის გადატვირთვა) და იგივე არხს ვუშვებთ */
    private fun rebuildPlayer(restart: Boolean = true) {
        val now = System.currentTimeMillis()
        if (restart && now - lastRebuild < 15000) return
        lastRebuild = now
        zaps = 0; fpsCount = -1; monLastCount = -1
        h.removeCallbacks(watchdog)
        try { player?.clearVideoSurface() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        val np = ensurePlayer()
        onRebuilt?.invoke(np)
        if (restart && currentUrl.isNotEmpty()) {
            retrying = false; attempt = 0; everPlayed = false; state = LOADING
            onLoading()
            start()
        }
    }

    /** ვიდეოს ზედაპირს ვწყვეტთ ახალ ეკრანზე გადასვლამდე: დეკოდერი თავიდან ინიციალიზდება და სურათი არ ეჭედება */
    fun detachVideo() {
        try { player?.clearVideoSurface() } catch (_: Exception) {}
    }

    /** ფლეიერი ახალ PlayerView-ზე გადავიდა: თუ 2.5 წმ-ში კადრი არ გამოჩნდა, ვაახლებთ */
    private fun armFrameGuard() {
        h.removeCallbacks(frameGuard)
        if (vlcActive) { awaitFrame = false; return }
        if (state != PLAYING) { awaitFrame = false; return }
        awaitFrame = true
        guardStage = 0
        h.postDelayed(frameGuard, 3500)
    }
    /** ბმულის განახლება (არხი ვერ ჩაირთო): ძველი ბმული -> ახალი ბმული ან null */
    var refresher: ((String) -> String?)? = null

    private fun restartSame() {
        if (player != null && currentUrl.isNotEmpty()) {
            attempt = okGet(currentUrl)
            everPlayed = false
            start()
        }
    }

    private val retry: Runnable = Runnable {
        if (player == null || currentUrl.isEmpty()) return@Runnable
        val r = refresher
        if (r == null) { restartSame(); return@Runnable }
        val old = currentUrl
        Thread {
            val nu = try { r(old) } catch (e: Exception) { null }
            h.post {
                if (player == null || currentUrl != old) return@post   // ამასობაში სხვა არხი ჩაირთო
                if (nu != null && nu.isNotBlank()) currentUrl = nu.trim()
                restartSame()
            }
        }.start()
    }

    /** ეკრანი ("owner") ცვლის მოვლენების მიმღებს; unlisten(owner) მხოლოდ მაშინ ასუფთავებს, თუ ის ჯერ კიდევ მფლობელია */
    fun listen(owner: Any, loading: () -> Unit, playing: () -> Unit, failed: () -> Unit) {
        this.owner = owner
        onLoading = loading; onPlaying = playing; onFailed = failed
    }

    fun unlisten(owner: Any) {
        if (this.owner === owner) {
            this.owner = null
            onRebuilt = null
            onLoading = {}; onPlaying = {}; onFailed = {}
        }
    }

    /** სიჩქარის საზომი: საწყისი შეფასება ქსელის ტიპით (Wi-Fi/4G/3G…) ავტომატურად; სურვილისამებრ ხელით: player.initial_kbps */
    private fun bandwidthMeter(): DefaultBandwidthMeter {
        val b = DefaultBandwidthMeter.Builder(ctx)
        // v1.7.114: სიჩქარის შეფასება უფრო სწრაფად რეაგირებს ცვლილებაზე (ნაგულისხმევი ფანჯარა 2000 იყო; ნაკლები = სწრაფი რეაქცია, მეტი = სტაბილური). სერვერიდან: player.bw_window
        b.setSlidingWindowMaxWeight(RemoteConfig.i("player.bw_window", 1000).coerceIn(300, 4000))
        val kbps = RemoteConfig.i("player.initial_kbps", 0)
        if (kbps > 0) b.setInitialBitrateEstimate(kbps * 1000L)
        return b.build()
    }

    /** ქმნის ფლეიერს (თუ ჯერ არ არის); PlayerView-ს მიამაგრეთ დაბრუნებული ობიექტი */
    fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        val renderers = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)
        // v1.7.125 (დიაგნოსტიკა): player.sw_h264 = true → H.264-ისთვის პროგრამული დეკოდერი ჯერ (მწვანე/ხმაურიანი კადრების მიზეზის დასადგენად).
        // თუ მწვანე გაქრა — ტელევიზორის აპარატურული დეკოდერია დამნაშავე. ნაგულისხმევი: გამორთულია (პროგრამული დეკოდერი უფრო მძიმეა პროცესორზე)
        if (RemoteConfig.b("player.sw_h264", false)) {
            renderers.setMediaCodecSelector { mime, secure, tunneling ->
                val l = androidx.media3.exoplayer.mediacodec.MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunneling)
                if (mime == MimeTypes.VIDEO_H264) l.sortedBy { if (it.softwareOnly) 0 else 1 } else l
            }
        }
        // v1.7.115: Android 14+ ტვ-ბოქსებზე (Amlogic და სხვ.) ასინქრონული MediaCodec ზოგჯერ აყინებს აპს — იქ სინქრონულ რეჟიმს ვიყენებთ (ოდნავ მეტი პროცესორი, მაგრამ უფრო სანდო).
        // სერვერიდან: player.sync_codec = 1/0 (ნაგულისხმევი: 1 — Android 14+ TV; 0 — დანარჩენი)
        if (RemoteConfig.b("player.sync_codec", android.os.Build.VERSION.SDK_INT >= 34 && Device.tv(ctx))) renderers.forceDisableMediaCodecAsynchronousQueueing()
        // ხარისხის ზედა ზღვარი (0 = ლიმიტის გარეშე). ნელი ინტერნეტისთვის სერვერიდან: api/app_config.json -> player.max_height (მაგ. 720 ან 480)
        val maxH = DeviceProfile.maxHeight().coerceIn(0, 2160)   // სუსტ მოწყობილობაზე ავტომატურად დაბალია (DeviceProfile)
        // ავტომატური ხარისხი ინტერნეტის სიჩქარით (მრავალხარისხიანი HLS-ისთვის): გაზომილი სიჩქარის ~70%-ზე ირჩევს ვარიანტს,
        // სიჩქარის ვარდნისას სწრაფად ჩამოდის დაბალ ხარისხზე, გაუმჯობესებისას ნელა და სტაბილურად ადის.
        val upMs = RemoteConfig.i("player.abr_up_ms", 10_000).coerceIn(2_000, 60_000)
        // v1.7.114: ხარისხი ეშვება, როცა ბუფერი ამ მნიშვნელობაზე ნაკლებია (12 წმ იყო = გვიან, ბუფერის თითქმის დაცარიელებისას; 25 წმ = ExoPlayer-ის სტანდარტი, ადრე და ჩაჭედვამდე)
        val downMs = RemoteConfig.i("player.abr_down_ms", 25_000).coerceIn(2_000, 60_000)
        val fraction = (RemoteConfig.i("player.abr_fraction_pct", 70).coerceIn(30, 95)) / 100f
        val abr = AdaptiveTrackSelection.Factory(upMs, downMs, AdaptiveTrackSelection.DEFAULT_MIN_DURATION_TO_RETAIN_AFTER_DISCARD_MS, fraction)
        val selector = DefaultTrackSelector(ctx, abr).apply {
            val pb = buildUponParameters().setViewportSizeToPhysicalDisplaySize(ctx, true)
            if (maxH > 0) pb.setMaxVideoSize(Int.MAX_VALUE, maxH)
            setParameters(pb)
        }
        // ბუფერი: უფრო დიდი რეზერვი = ნელ/ცვალებად ინტერნეტზე ნაკლები გაჩერება. მნიშვნელობები შეიძლება შეიცვალოს სერვერიდან (player.buf_*)
        // მნიშვნელობები მოწყობილობის პროფილიდან (DeviceProfile): სუსტზე ბუფერი მცირეა, ძლიერზე — როგორც ადრე
        val bStart = DeviceProfile.bufStartMs().coerceIn(1_000, 10_000)
        val bRebuf = DeviceProfile.bufRebufferMs().coerceIn(bStart, 20_000)
        val bMin = DeviceProfile.bufMinMs().coerceIn(5_000, 60_000).coerceAtLeast(bRebuf)
        val bMax = DeviceProfile.bufMaxMs().coerceIn(5_000, 120_000).coerceAtLeast(bMin)
        val lcb = DefaultLoadControl.Builder().setBufferDurationsMs(bMin, bMax, bStart, bRebuf)
        // ბუფერის ზომის ზღვარი (მბ): Java heap-ის გადავსების (OutOfMemory) თავიდან ასაცილებლად
        val maxMb = DeviceProfile.bufMaxMb()
        if (maxMb > 0) lcb.setTargetBufferBytes(maxMb * 1024 * 1024).setPrioritizeTimeOverSizeThresholds(false)
        val load = lcb.build()
        val p = ExoPlayer.Builder(ctx, renderers)
            .setTrackSelector(selector)
            .setLoadControl(load)
            .setWakeMode(androidx.media3.common.C.WAKE_MODE_NETWORK)   // ეკრანი/Wi-Fi არ დაიძინოს დაკვრისას
            .setAudioAttributes(androidx.media3.common.AudioAttributes.Builder().setUsage(androidx.media3.common.C.USAGE_MEDIA).setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
            .setBandwidthMeter(bandwidthMeter())
            .build()
        p.volume = 1f
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> {
                        h.removeCallbacks(bufSpinner)
                        h.removeCallbacks(watchdog)
                        h.removeCallbacks(retry)
                        retrying = false
                        everPlayed = true
                        if (currentUrl.isNotEmpty()) {
                            val prevOk = okGet(currentUrl)
                            okAttempt[currentUrl] = attempt
                            if (prevOk != attempt) okSave()
                        }
                        state = PLAYING
                        onPlaying()
                    }
                    Player.STATE_BUFFERING -> {
                        if (!retrying && !(frameShown && state == PLAYING)) {
                            state = LOADING
                            onLoading()
                        } else if (!retrying) {
                            // კადრი გაჩერდა ბუფერის ამოწურვის გამო: 1.2 წმ-ზე მეტხანს თუ გაგრძელდა, ლოდინის ანიმაცია გამოჩნდეს
                            h.removeCallbacks(bufSpinner)
                            h.postDelayed(bufSpinner, 1200)
                        }
                    }
                    Player.STATE_ENDED -> {
                        // არქივი ბოლომდე მივიდა → პირდაპირ ეთერზე გადავდივართ (და არა იგივე არქივის თავიდან ცდა)
                        val lu = Timeshift.liveUrl()
                        if (Timeshift.isArchive(currentUrl) && lu.isNotEmpty()) {
                            val next = Timeshift.continuation()   // გადაცემა დასრულდა → არქივი მომდევნო გადაცემით გრძელდება
                            if (next != null) h.post { play(next) } else { Timeshift.clear(); h.post { play(lu) } }
                        } else handleError(null)
                    }
                }
            }

            override fun onVolumeChanged(volume: Float) { if (vlcActive) vlc?.setVolume(volume) }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { if (vlcActive) vlc?.setPaused(!playWhenReady) }

            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                // ხმა ან ვიდეო ტელეფონის დეკოდერს არ აქვს (AC3/DTS და ა.შ.) → უხმო/გაუხსნელი არხი: ვცდით VLC-ს
                if (!vlcActive && tracks.groups.isNotEmpty()) {
                    val a = tracks.groups.filter { it.type == androidx.media3.common.C.TRACK_TYPE_AUDIO }
                    val v = tracks.groups.filter { it.type == androidx.media3.common.C.TRACK_TYPE_VIDEO }
                    if ((a.isNotEmpty() && a.none { it.isSupported }) || (v.isNotEmpty() && v.none { it.isSupported })) { h.post { tryVlc() } }
                    // ვიდეო არის, ხმის ტრეკი საერთოდ არ ჩანს (უცნობი აუდიო ფორმატი) ან არჩეული არ არის → 2.5 წმ-ის შემდეგ, თუ ისევ ასეა, VLC
                    else if (v.isNotEmpty()) { h.removeCallbacks(noAudioCheck); h.postDelayed(noAudioCheck, 2500) }
                }
                // დიაგნოსტიკა ხმა/ვიდეოს კოდეკებზე — მხოლოდ თუ სერვერზე ჩართულია player.debug_toast = 1 (ნაგულისხმევად გამორთულია)
                if (RemoteConfig.i("player.debug_toast", 0) != 1) return
                val sb = StringBuilder()
                for (g in tracks.groups) {
                    if (g.length < 1) continue
                    if (g.type == androidx.media3.common.C.TRACK_TYPE_AUDIO || g.type == androidx.media3.common.C.TRACK_TYPE_VIDEO) {
                        val f = g.getTrackFormat(0)
                        sb.append(if (g.type == androidx.media3.common.C.TRACK_TYPE_AUDIO) "A:" else "V:")
                            .append(f.sampleMimeType).append(if (g.isSupported) "" else " (UNSUPPORTED)").append("   ")
                    }
                }
                if (sb.isNotEmpty()) h.post { android.widget.Toast.makeText(ctx, sb.toString(), android.widget.Toast.LENGTH_LONG).show() }
            }

            override fun onRenderedFirstFrame() {
                frameShown = true
                h.removeCallbacks(idrGuard)
                awaitFrame = false
                h.removeCallbacks(frameGuard)
            }

            override fun onPlayerError(error: PlaybackException) {
                handleError(error)
            }
        })
        player = p
        h.removeCallbacks(monitor)
        h.postDelayed(monitor, 500)
        return p
    }

    /** იგივე არხზე განმეორებითი გამოძახება არხს თავიდან აღარ იტვირთავს (თუ არ ჩაშლილა) */
    fun play(newUrl: String) {
        val u = newUrl.trim()
        ensurePlayer()
        if (u == currentUrl && state != FAILED) {
            dispatchState()
            armFrameGuard()
            return
        }
        if (++zaps >= 60) rebuildPlayer(false)   // იშვიათად (ყოველ 60 გადართვაზე) დეკოდერი სუფთავდება; ყოველ 8-ზე ფლეიერის თავიდან შექმნა სწორედ კადრს აჭედებდა
        stopVlc()
        currentUrl = u
        cycles = 0
        lastErr = ""
        h.removeCallbacks(retry)
        retrying = false
        attempt = okGet(u)   // ადრე წარმატებული ვარიანტიდან ვიწყებთ
        everPlayed = false
        state = LOADING
        onLoading()
        // სწრაფი გადართვისას (ღილაკის ხშირი დაჭერა) შუალედურ არხებს ქსელში აღარ ვტვირთავთ — მხოლოდ ბოლოს ვიწყებთ
        // v1.7.114: ფანჯარა 0,6 → 2,5 წმ, დაცდა 0,22 → 0,35 წმ: მიყოლებით გადართვისას წყაროს (IPTV მომწოდებლის) კავშირების/მოთხოვნების ლიმიტს აღარ ვაჭარბებთ.
        // ხელით: player.zap_window_ms (0 = გამორთვა), player.zap_debounce_ms
        val t = android.os.SystemClock.uptimeMillis()
        val prevPlayAt = lastPlayAt
        h.removeCallbacks(delayedStart)
        val zapWin = RemoteConfig.i("player.zap_window_ms", 2500).coerceIn(0, 10_000)
        val zapDelay = RemoteConfig.i("player.zap_debounce_ms", 350).coerceIn(0, 1500).toLong()
        if (zapWin > 0 && t - prevPlayAt < zapWin) h.postDelayed(delayedStart, zapDelay) else start()
        lastPlayAt = t
        // მიყოლებით გადართვის შემდეგ არხი 10 წმ-ში თუ არ ჩაირთო (იშვიათი გაჭედვა), ფლეიერს თავიდან ვქმნით და იგივე არხს ვუშვებთ (ერთხელ)
        h.removeCallbacks(zapRescue)
        if (t - prevPlayAt < 30_000) h.postDelayed(zapRescue, RemoteConfig.i("player.zap_rescue_ms", 10_000).coerceIn(5_000, 40_000).toLong())
    }

    private val zapRescue = Runnable {
        if (player == null || currentUrl.isEmpty() || vlcActive || retrying) return@Runnable
        if (state == LOADING && !everPlayed) rebuildPlayer()
    }

    private var lastPlayAt = 0L
    private val delayedStart = Runnable { if (player != null && currentUrl.isNotEmpty()) start() }

    /** ახალ ეკრანს ვუცხადებთ, რა მდგომარეობაშია ფლეიერი ახლა */
    fun dispatchState() {
        when (state) {
            PLAYING -> onPlaying()
            FAILED -> onFailed()
            else -> onLoading()
        }
    }

    fun release() {
        h.removeCallbacks(watchdog)
        h.removeCallbacks(retry)
        h.removeCallbacks(frameGuard)
        h.removeCallbacks(monitor)
        h.removeCallbacks(delayedStart)
        h.removeCallbacks(zapRescue)
        h.removeCallbacks(idrGuard)
        h.removeCallbacks(bufSpinner)
        stopVlc()
        try { vlc?.release() } catch (_: Exception) {}
        vlc = null
        retrying = false
        owner = null
        onLoading = {}; onPlaying = {}; onFailed = {}
        player?.release()
        player = null
        currentUrl = ""
        state = LOADING
    }

    /** ფორმატების რიგი ბმულის მიხედვით: null = ავტომატური ამოცნობა */
    private fun formats(): List<String?> {
        val l = M3u.split(currentUrl).first.lowercase()
        return when {
            l.contains("m3u8") -> listOf(MimeTypes.APPLICATION_M3U8, null, MimeTypes.VIDEO_MP2T)
            TS_REGEX.containsMatchIn(l) -> listOf(MimeTypes.VIDEO_MP2T, MimeTypes.APPLICATION_M3U8, null)
            else -> listOf(null, MimeTypes.APPLICATION_M3U8, MimeTypes.VIDEO_MP2T)
        }
    }

    private fun spec(a: Int): Pair<String?, String?> {
        val f = formats()
        return when (a) {
            0 -> Pair(f[0], UA_VLC)
            1 -> Pair(f[1], UA_VLC)
            2 -> Pair(f[2], UA_VLC)
            3 -> Pair(f[0], UA_BROWSER)
            else -> Pair(null, null)   // ავტომატური ფორმატი + ExoPlayer-ის სტანდარტული User-Agent (როგორც სხვა IPTV ფლეიერებში)
        }
    }

    private var useNonIdr = false
    private val bufSpinner: Runnable = Runnable {
        val p = player
        if (p != null && !retrying && p.playbackState == Player.STATE_BUFFERING && p.playWhenReady) {
            state = LOADING
            onLoading()
        }
    }
    private var idrWaits = 0
    /**
     * პირველი კადრი ჯერ არ არის. ადრე 3 წმ-ში ყოველთვის ხდებოდა რესტარტი — ნელ წყაროზე ეს წამიერ „გადატვირთვას“ იწვევდა და
     * უკვე მიღებულ მონაცემებს კარგავდა. ახლა რესტარტი მხოლოდ მაშინ, როცა ნაკადი რეალურად მოდის (READY: ხმა/დრო მიდის),
     * მაგრამ 6 წმ-ის განმავლობაში ვიდეოს გასაღები კადრი არ მოსულა. სანამ მონაცემი იტვირთება — უბრალოდ ვუცდით.
     */
    private val idrGuard: Runnable = Runnable {
        val p = player
        if (p == null || currentUrl.isEmpty() || frameShown || useNonIdr || retrying || vlcActive || state != LOADING && state != PLAYING) return@Runnable
        idrWaits++
        // v1.7.94: ზოგ არხს (intra-refresh) IDR კადრი საერთოდ არ აქვს — ფლეიერი READY-ში ვერ გადადის, მაგრამ ვიდეოს ტრეკი უკვე ამოცნობილია. ესეც ნიშნავს, რომ ნაკადი მოდის
        val hasVideo = try { p.currentTracks.groups.any { it.type == androidx.media3.common.C.TRACK_TYPE_VIDEO } } catch (_: Exception) { false }
        // v1.7.95: შემოწმება 1 წმ-ში ერთხელ: ნაკადი მოდის (READY / ვიდეოს ტრეკი ცნობილია) → ≈3 წმ-ში გადავდივართ; სხვა შემთხვევაში ≈7 წმ-ში (მანამდე 6 წმ + 16 წმ მოლოდინი იყო)
        // v1.7.98: არა-IDR რეჟიმი (და მისი დამახსოვრება) მხოლოდ მაშინ, როცა მონაცემი რეალურად მოდის (≥4 წმ ბუფერი), მაგრამ გასაღები კადრი ≥4 წმ-ია არ მოსულა.
        // სუსტ TV-ზე ნელი დაწყება ტყუილად აღარ ჩაგვაგდებს არა-IDR რეჟიმში (ის ზოგ არხზე ზოლებიან/დაზიანებულ სურათს იძლეოდა).
        val buffered = try { p.totalBufferedDuration } catch (_: Exception) { 0L }
        // v1.7.122: ადრე ≈4 წმ-ში გასაღები კადრი რომ არ მოდიოდა, არხი სამუდამოდ არა-IDR რეჟიმში გადადიოდა — ეს ბლოკებს/„ფხვნილს“ იძლეოდა.
        // ბევრ არხს გასაღები კადრი 5–10 წმ-ში ერთხელ მოდის; ახლა ამდენ ხანს ვუცდით (ნაგულისხმევად 10 წმ), რომ სურათი სუფთა იყოს. სერვერიდან: player.idr_wait_s (4–20)
        val flipWait = RemoteConfig.i("player.idr_wait_s", 10).coerceIn(4, 20)
        if ((p.playbackState == Player.STATE_READY || hasVideo) && idrWaits >= flipWait && buffered >= 4000L) {
            nonIdrLoad(); nonIdrOk.add(currentUrl); nonIdrSave()
            idrWaits = 0
            start()
        } else if (idrWaits >= flipWait + 8) {
            nonIdrLoad(); nonIdrOk.add(currentUrl)   // მხოლოდ ამ სესიაში, შენახვის გარეშე
            idrWaits = 0
            start()
        } else if (idrWaits < flipWait + 8) {
            h.postDelayed(idrGuard, 1000)
        }
    }

    /** OkHttp (კავშირების გამოყენება, სწრაფი დაწყება); ნებისმიერი პრობლემისას ან player.okhttp=0 → ძველი DefaultHttpDataSource */
    private fun dataSourceFactory(ua: String?, extra: Map<String, String> = emptyMap()): DefaultDataSource.Factory {
        if (RemoteConfig.i("player.okhttp", 1) == 1) {
            try {
                val ok = OkHttpDataSource.Factory(okClient)
                ok.setUserAgent(ua ?: androidx.media3.common.util.Util.getUserAgent(ctx, "ExoPlayerLib"))
                if (extra.isNotEmpty()) ok.setDefaultRequestProperties(extra)
                return DefaultDataSource.Factory(ctx, ok)
            } catch (_: Throwable) {}
        }
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8000)
            .setReadTimeoutMs(12000)
        if (ua != null) http.setUserAgent(ua)
        if (extra.isNotEmpty()) http.setDefaultRequestProperties(extra)
        return DefaultDataSource.Factory(ctx, http)
    }

    private fun start() {
        val p = player ?: return
        if (vlcWanted(currentUrl)) { startVlc(); return }
        if (vlcActive) stopVlc()
        frameShown = false
        val (fmt, ua0) = spec(attempt)
        // playlist-ში მითითებული User-Agent/Referer/Origin/Cookie (#EXTVLCOPT, #EXTHTTP) — ყველა ცდაზე უპირატესია
        val (cleanUrl, hdrAll) = M3u.split(currentUrl)
        val ua = hdrAll["User-Agent"] ?: ua0
        val hdrExtra = hdrAll.filterKeys { !it.equals("User-Agent", true) }
        val builder = MediaItem.Builder().setUri(cleanUrl)
        if (fmt != null) builder.setMimeType(fmt)
        val item = builder.build()
        val dsf = dataSourceFactory(ua, hdrExtra)
        // დროებითი ჩავარდნები (ქსელის წამიერი შეფერხება, ერთი სეგმენტის შეცდომა) 8-ჯერ თავისით მეორდება ნაკადის თავიდან დაწყების გარეშე
        val policy = DefaultLoadErrorHandlingPolicy(8)
        // IPTV-ის TS ნაკადები: არა-IDR გასაღები კადრები და წვდომის ერთეულების ამოცნობა — უფრო სწრაფი დაწყება და ნაკლები „გაყინული“ კადრი
        // არა-IDR დაწყება სწრაფია, მაგრამ წინა არხის „აჩრდილს“/გამოსვრილ კადრებს იძლევა. ამიტომ ჯერ სუფთა დაწყებას (IDR) ვცდით;
        // თუ 4.5 წმ-ში კადრი არ გამოჩნდა, ამ არხზე ვრთავთ არა-IDR რეჟიმს და ვიმახსოვრებთ. ნაგულისხმევად (player.ts_non_idr = 1) სწრაფი რეჟიმი ყველა არხზე; 0 = ჯერ სუფთა დაწყება
        // ტელეფონზე ნაგულისხმევად სუფთა დაწყება (წინა არხის „აჩრდილი“ აპარატურულ დეკოდერზე ჩანდა), ტელევიზორზე — სწრაფი. ხელით: player.ts_non_idr = 1 / 0
        // v1.7.86: ნაგულისხმევად ყველგან სუფთა დაწყება (IDR) — არა-IDR დაწყება მწვანე/დამსხვრეულ კადრებს იძლეოდა (ტელევიზორზეც). ხელით: player.ts_non_idr = 1 ყველგან სწრაფი რეჟიმისთვის
        nonIdrLoad()
        val idrCfg = RemoteConfig.i("player.ts_non_idr", -1)
        // v1.7.109: სწრაფი დაწყება (გასაღები კადრის დაცდის გარეშე) ნაგულისხმევად ჩართულია საკმარისად ძლიერ მოწყობილობებზე (როგორც Televizia.Store TV აპში).
        // სუსტ მოწყობილობაზე (LOW პროფილი / OOM-ის შემდეგ) და როცა სერვერზე player.ts_non_idr = 0 — ძველი, სუფთა დაწყება. გამორთვა: player.fast_start = 0
        // v1.7.121: სწრაფი დაწყება (არა-IDR) ნაგულისხმევად ისევ გამორთულია — არხის ჩართვისას ის დეკოდერს გასაღები კადრის გარეშე იწყებს
        // და სურათი რამდენიმე წამს ბლოკებად/„ფხვნილად“ ჩანს, მერე კი (ზოგჯერ) სწორდება. სუფთა დაწყება (IDR) ოდნავ მეტ ხანს ელოდება, მაგრამ სურათი სუფთაა.
        // სერვერიდან ისევ ჩასართავად: player.fast_start = 1
        val fastDefault = idrCfg == -1 && RemoteConfig.i("player.fast_start", 0) == 1 && DeviceProfile.fastStartOk()
        useNonIdr = (idrCfg == 1) || nonIdrOk.contains(currentUrl) || fastDefault
        // v1.7.93: წვდომის ერთეულების ამოცნობა (FLAG_DETECT_ACCESS_UNITS) ნაგულისხმევად გამორთულია — ჩადერთული (interlaced) / სპეციფიკური H.264 ნაკადებზე
        // ის კადრებს არასწორად ყოფდა და დროის ნიშნულებს არევდა (კადრების „ხტუნვა“ და გადაფარვა). Televizo-სა და სტანდარტულ ExoPlayer-ში ის გამორთულია.
        // სერვერიდან ისევ ჩასართავად: player.ts_detect_au = 1
        // v1.7.94: არხებზე, რომლებსაც არა-IDR რეჟიმი სჭირდება, ან როცა პირველი ცდა ვერ გაიხსნა — ძველი, სრული რეჟიმი (წვდომის ერთეულების ამოცნობითაც): ისინი ასე იხსნებოდა
        var tsFlags = if (RemoteConfig.i("player.ts_detect_au", 0) == 1 || useNonIdr || attempt >= 1) DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS else 0
        if (useNonIdr) tsFlags = tsFlags or DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES
        val source: MediaSource = if (fmt == MimeTypes.APPLICATION_M3U8) {
            HlsMediaSource.Factory(dsf)
                .setAllowChunklessPreparation(true)
                .setExtractorFactory(DefaultHlsExtractorFactory(tsFlags, false))
                .setLoadErrorHandlingPolicy(policy)
                .createMediaSource(item)
        } else {
            DefaultMediaSourceFactory(dsf, DefaultExtractorsFactory().setTsExtractorFlags(tsFlags))
                .setLoadErrorHandlingPolicy(policy)
                .createMediaSource(item)
        }
        h.removeCallbacks(idrGuard)
        idrWaits = 0
        if (!useNonIdr) h.postDelayed(idrGuard, 1000)
        p.setMediaSource(source)
        p.prepare()
        p.playWhenReady = true
        h.removeCallbacks(watchdog)
        h.postDelayed(watchdog, if (attempt == 0) RemoteConfig.i("player.start_timeout_ms", 16_000).coerceIn(8_000, 40_000).toLong() else 12000L)   // პირველ ცდას მეტი დრო, მომდევნო ვარიანტებს — ნაკლები
    }

    private fun isParseError(e: PlaybackException?): Boolean {
        if (e == null) return false
        return e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED
    }

    /** 429/503: ვაცდით სერვერს (Retry-After ან 6, 12, 24, 30 წმ); სხვა შეცდომა: 3 წმ */
    private fun retryDelay(): Long {
        if (lastCode != 429 && lastCode != 503) return RETRY_MS
        if (retryAfterMs > 0) return retryAfterMs.coerceIn(3000L, 60000L)
        return (6000L shl (cycles - 1).coerceIn(0, 2)).coerceAtMost(30000L)
    }

    private fun handleError(e: PlaybackException?) {
        h.removeCallbacks(watchdog)
        lastCode = 0; retryAfterMs = 0L
        (e?.cause as? androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException)?.let { c ->
            lastCode = c.responseCode
            val ra = c.headerFields.entries.firstOrNull { it.key.equals("Retry-After", true) }?.value?.firstOrNull()
            retryAfterMs = (ra?.trim()?.toLongOrNull() ?: 0L) * 1000L
        }
        lastErr = if (e == null) "ვადა გავიდა" else {
            val c = e.cause
            val http = if (c is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) " HTTP " + c.responseCode else ""
            e.errorCodeName.removePrefix("ERROR_CODE_") + http
        }
        if (e != null && generateSequence<Throwable>(e) { it.cause }.any { it is OutOfMemoryError }) {
            // მეხსიერება გადაივსო: ბუფერს/ხარისხს ვამცირებთ და ფლეიერს ახალი პარამეტრებით ვქმნით
            DeviceProfile.degrade("oom", 0L)
            lastRebuild = 0L
            rebuildPlayer()
            return
        }
        val p = player ?: return
        if (e != null && e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            p.seekToDefaultPosition()
            p.prepare()
            h.postDelayed(watchdog, START_TIMEOUT_MS)
            return
        }
        if (everPlayed) {
            // ნაკადი გაჩერდა, მაგრამ აქამდე თამაშობდა — ერთხელ თავიდან ვუკავშირდებით
            everPlayed = false
            start()
            return
        }
        // დამახსოვრებული ვარიანტი აღარ მუშაობს: დავივიწყოთ და სრული რიგი თავიდან გავიაროთ
        if (attempt > 0 && okAttempt[currentUrl] == attempt) {
            okAttempt.remove(currentUrl); okSave()
            attempt = 0
            start()
            return
        }
        // ფორმატის შეცდომისას ვცდით შემდეგ ფორმატს; კავშირის/სერვერის შეცდომისას — ბრაუზერის სათაურს
        val next = when {
            attempt >= 4 -> -1
            lastCode == 429 || lastCode == 503 -> -1   // სერვერი ზღუდავს მოთხოვნებს: ზედმეტ მოთხოვნას აღარ ვუშვებთ
            isParseError(e) && attempt < 2 -> attempt + 1
            attempt == 3 -> 4
            else -> 3
        }
        if (next < 0) {
            if (tryVlc()) return
            try { p.stop() } catch (ex: Exception) { }
            state = FAILED
            cycles++
            retrying = true
            onFailed()
            // იგივე არხს რამდენიმე წამში თავიდან ვცდით; სხვა არხზე არასოდეს გადადის
            h.removeCallbacks(retry)
            h.postDelayed(retry, retryDelay())
            return
        }
        attempt = next
        start()
    }
}

/** ერთი საერთო ფლეიერი მთელ აპლიკაციაზე */
object StreamHub {
    private var c: StreamController? = null

    fun get(ctx: Context): StreamController =
        c ?: StreamController(ctx.applicationContext).also {
            val app = ctx.applicationContext
            it.refresher = { u -> ChannelRefresher.refresh(app, u) }
            c = it
        }

    fun peek(): StreamController? = c

    fun release() {
        c?.release()
        c = null
    }
}
