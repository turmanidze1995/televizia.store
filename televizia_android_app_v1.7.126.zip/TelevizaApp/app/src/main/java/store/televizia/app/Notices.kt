package store.televizia.app

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * v1.7.124: შეტყობინებები ადმინიდან (admin/app_notices.php). იღებს $BASE_URL/api/app_notice.php-დან და აჩვენებს ზუსტად ისე,
 * როგორც ამინდს: ტელეფონზე — სისტემური შეტყობინება, ტვ/ბოქსზე — ფანჯარა (WeatherActivity). იმავე ალარმით მოწმდება (WeatherNotify.arm).
 * ერთ მოწყობილობაზე თითო შეტყობინება ერთხელ ჩანს. ჩართვა/გამორთვა სერვერიდან: features.notices.
 */
object Notices {
    private const val PREFS = "notices"
    const val ACTION = "store.televizia.app.NOTICE_CHECK"

    /** შემოწმების ინტერვალი (წუთი). სერვერიდან: notices.check_min (1–60), ნაგულისხმევი 3 */
    private fun intervalMs() = RemoteConfig.i("notices.check_min", 3).coerceIn(1, 60) * 60_000L

    private fun pi(ctx: Context): PendingIntent {
        val i = Intent(ctx.applicationContext, WeatherReceiver::class.java).setAction(ACTION)
        val fl = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(ctx.applicationContext, 7391, i, fl)
    }

    /** ცალკე ალარმი შეტყობინებებისთვის (ამინდის 30-წუთიანისგან დამოუკიდებლად) — აპი დახურული იყოს თუ გახსნილი */
    fun arm(ctx: Context) {
        try {
            val am = ctx.applicationContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val p = pi(ctx)
            if (!on()) { am.cancel(p); return }
            val at = System.currentTimeMillis() + intervalMs()
            val canExact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (Build.VERSION.SDK_INT >= 23) {
                if (canExact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            } else am.set(AlarmManager.RTC_WAKEUP, at, p)
        } catch (_: Exception) {}
    }

    fun on(): Boolean = RemoteConfig.b("features.notices", true)
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** ბლოკავს — ფონურ ნაკადში გამოიძახეთ */
    @Synchronized
    fun check(ctx: Context) {
        if (!on()) return
        val app = ctx.applicationContext
        try {
            val p = sp(app)
            val first = !p.getBoolean("init", false)
            val last = p.getLong("last", 0L)
            val q = StringBuilder("since=").append(last)
                .append("&tv=").append(if (Device.tv(app)) 1 else 0)
                .append("&did=").append(URLEncoder.encode(ClientId.did, "UTF-8"))
            Session.token(app)?.let { q.append("&token=").append(URLEncoder.encode(it, "UTF-8")) }
            val conn = (URL("$BASE_URL/api/app_notice.php?$q").openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000; readTimeout = 10000
                setRequestProperty("User-Agent", ClientId.ua)
            }
            if (conn.responseCode !in 200..299) return
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            if (!j.optBoolean("ok")) return
            val latest = j.optLong("latest", 0L)
            if (first) {
                // ახალი ინსტალაცია: ძველ (უკვე გაგზავნილ) შეტყობინებებს არ ვაჩვენებთ, მხოლოდ დამახსოვრებთ
                p.edit().putBoolean("init", true).putLong("last", latest).apply()
                return
            }
            val items = j.optJSONArray("items")
            var mx = last
            if (items != null) for (i in 0 until items.length()) {
                val it = items.getJSONObject(i)
                val id = it.optLong("id", 0L)
                if (id <= last) continue
                WeatherNotify.postNotice(app, 9500 + (id % 400).toInt(), it.optString("title"), it.optString("text"), it.optInt("alert", 0) == 1)
                if (id > mx) mx = id
            }
            if (latest > mx) mx = latest
            if (mx != last) p.edit().putLong("last", mx).apply()
        } catch (_: Throwable) {}
    }

    /** Android 13+: შეტყობინების ნებართვა (სხვანაირად შეტყობინება ტელეფონზე ვერ გამოჩნდება). ერთხელ ვკითხულობთ. */
    fun askOnce(a: Activity) {
        try {
            val p = sp(a)
            if (p.getBoolean("asked", false)) return
            p.edit().putBoolean("asked", true).apply()
            WeatherNotify.askPermissions(a)
        } catch (_: Throwable) {}
    }
}
