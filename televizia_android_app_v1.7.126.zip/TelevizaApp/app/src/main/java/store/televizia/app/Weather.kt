package store.televizia.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar

/**
 * ამინდის შეტყობინებები (v1.7.105): დღეში 2 პროგნოზი (დილით — დღევანდელი, საღამოთი — ხვალინდელი)
 * და ცვლილებები: წვიმა იწყება/გადაიღებს, ჭექა-ქუხილი, თოვლი, მოიღრუბლება, გამოიდარებს.
 * v1.7.111: რეალური ამინდის ცვლილება (ახლანდელი მდგომარეობა წინასთან შედარებით) — შეტყობინება ყოველ ცვლილებაზე
 * (წვიმა/თოვლი/ჭექა-ქუხილი მაშინვე, მოღრუბლვა/გამოდარება 30 წთ-ში ერთხელ); შემოწმება ყოველ 10 წთ-ში (ზუსტი ალარმით);
 * ტვ/ბოქსზე ლოკაცია: საკუთარი → ტელეფონის (იგივე ანგარიში) → IP.
 * მონაცემები: $BASE_URL/api/app_weather.php. მუშაობს დახურულ აპზეც (AlarmManager). TV-ზე — ფანჯარა (როგორც შეხსენებები).
 * ჩართვა/გამორთვა სერვერიდან: features.weather; საათები: weather.morning_hour / weather.evening_hour; შემოწმება: weather.check_min.
 */
object WeatherNotify {
    private const val PREFS = "weather"
    private const val CH_INFO = "weather"
    private const val CH_ALERT = "weather_alert"
    private const val CH_N_INFO = "notice"          // v1.7.124: ადმინის შეტყობინებები
    private const val CH_N_ALERT = "notice_alert"
    const val ACTION = "store.televizia.app.WEATHER_CHECK"

    val cities = listOf(
        "tbilisi" to "თბილისი", "batumi" to "ბათუმი", "kutaisi" to "ქუთაისი", "rustavi" to "რუსთავი", "gori" to "გორი",
        "zugdidi" to "ზუგდიდი", "poti" to "ფოთი", "telavi" to "თელავი", "kobuleti" to "ქობულეთი", "ozurgeti" to "ოზურგეთი",
        "akhaltsikhe" to "ახალციხე", "ambrolauri" to "ამბროლაური", "mtskheta" to "მცხეთა", "sighnaghi" to "სიღნაღი",
        "mestia" to "მესტია", "gudauri" to "გუდაური", "borjomi" to "ბორჯომი", "zestaponi" to "ზესტაფონი", "samtredia" to "სამტრედია",
        "senaki" to "სენაკი", "khashuri" to "ხაშური", "marneuli" to "მარნეული", "tskaltubo" to "წყალტუბო", "chiatura" to "ჭიათურა",
        "lanchkhuti" to "ლანჩხუთი", "akhalkalaki" to "ახალქალაქი", "bakuriani" to "ბაკურიანი", "stepantsminda" to "სტეფანწმინდა"
    )

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun serverOn(): Boolean = RemoteConfig.b("features.weather", true)
    fun digestOn(ctx: Context) = sp(ctx).getBoolean("digest", true)
    fun changesOn(ctx: Context) = sp(ctx).getBoolean("changes", true)
    fun cityId(ctx: Context): String = sp(ctx).getString("city", "tbilisi") ?: "tbilisi"
    fun cityName(ctx: Context): String = cities.firstOrNull { it.first == cityId(ctx) }?.second ?: "თბილისი"

    // ---------- ლოკაცია ----------
    /** ავტო (ნაგულისხმევი): GPS/ქსელი მოწყობილობიდან; თუ ვერ — IP-დან (სერვერი); ხელით: არჩეული ქალაქი */
    fun auto(ctx: Context) = sp(ctx).getString("mode", "auto") == "auto"
    fun place(ctx: Context): String = sp(ctx).getString("place", "") ?: ""
    fun placeLabel(ctx: Context): String = if (auto(ctx)) ("📍 " + place(ctx).ifBlank { "ავტომატური ლოკაცია" }) else cityName(ctx)
    fun setAuto(ctx: Context) { sp(ctx).edit().putString("mode", "auto").remove("seen").apply() }
    fun hasLocationFeature(ctx: Context) = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_LOCATION)
    fun hasLocationPermission(ctx: Context): Boolean = Build.VERSION.SDK_INT < 23 ||
        ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun askLocationPermission(a: Activity) {
        try {
            if (!hasLocationPermission(a))   // v1.7.111: ტვ/ბოქსიც ცდილობს (FEATURE_LOCATION ხშირად არ არის, მაგრამ ქსელური ლოკაცია შეიძლება იყოს)
                a.requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 7202)
        } catch (_: Exception) {}
    }

    private fun storeLocation(ctx: Context, l: Location) {
        sp(ctx).edit().putString("lat", l.latitude.toString()).putString("lon", l.longitude.toString())
            .putLong("loc_at", System.currentTimeMillis()).apply()
        maybeUpload(ctx)
    }

    /** ტელეფონი: ლოკაცია ანგარიშზე ინახება (სერვერზე ~1 კმ სიზუსტით), რომ ტელევიზორმა/ბოქსმა (GPS-ის გარეშე) იგივე ადგილი გამოიყენოს */
    private fun maybeUpload(ctx: Context) {
        try {
            if (Device.tv(ctx)) return
            val token = Session.token(ctx) ?: return
            val p = sp(ctx)
            val lat = p.getString("lat", null)?.toDoubleOrNull() ?: return
            val lon = p.getString("lon", null)?.toDoubleOrNull() ?: return
            val ulat = p.getString("up_lat", null)?.toDoubleOrNull()
            val ulon = p.getString("up_lon", null)?.toDoubleOrNull()
            if (ulat != null && ulon != null && System.currentTimeMillis() - p.getLong("up_at", 0L) < 6 * 3600_000L) {
                val r = FloatArray(1)
                Location.distanceBetween(lat, lon, ulat, ulon, r)
                if (r[0] < 1000f) return
            }
            Thread {
                try {
                    val body = "token=" + URLEncoder.encode(token, "UTF-8") + "&lat=" + lat + "&lon=" + lon
                    val conn = (URL("$BASE_URL/api/app.php?action=weather_loc_set").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"; doOutput = true; connectTimeout = 8000; readTimeout = 8000
                        setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                        ClientId.apply(this)
                    }
                    conn.outputStream.use { it.write(body.toByteArray()) }
                    if (conn.responseCode in 200..299)
                        p.edit().putString("up_lat", lat.toString()).putString("up_lon", lon.toString()).putLong("up_at", System.currentTimeMillis()).apply()
                    conn.disconnect()
                } catch (_: Exception) {}
            }.start()
        } catch (_: Throwable) {}
    }

    /** ანგარიშზე შენახული ლოკაცია (ტელეფონიდან) — ტვ/ბოქსისთვის, რომელსაც საკუთარი ლოკაცია არ აქვს. ბლოკავს — ფონურ ნაკადში */
    private fun accountLoc(ctx: Context): Pair<String, String>? {
        val p = sp(ctx)
        val now = System.currentTimeMillis()
        val cl = p.getString("acc_lat", null)
        val cn = p.getString("acc_lon", null)
        if (cl != null && cn != null && now - p.getLong("acc_at", 0L) < 20 * 60_000L) return cl to cn
        val token = Session.token(ctx)
        if (token != null) {
            try {
                val conn = (URL("$BASE_URL/api/app.php?action=weather_loc_get&token=" + URLEncoder.encode(token, "UTF-8")).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 6000; readTimeout = 8000
                    ClientId.apply(this)
                }
                if (conn.responseCode in 200..299) {
                    val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    if (j.optBoolean("ok") && j.has("lat") && j.has("lon")) {
                        val la = j.optDouble("lat").toString()
                        val lo = j.optDouble("lon").toString()
                        p.edit().putString("acc_lat", la).putString("acc_lon", lo).putLong("acc_at", now).apply()
                        return la to lo
                    }
                }
            } catch (_: Exception) {}
        }
        return if (cl != null && cn != null) cl to cn else null
    }

    /**
     * მოწყობილობის ლოკაციის განახლება (აპის გახსნისას/პარამეტრებიდან). ბოლო ცნობილი ან ახალი ერთჯერადი განსაზღვრა
     * (ქსელი, შემდეგ GPS; 20 წმ). ფონურ რეჟიმში აპი ინახულ კოორდინატებს იყენებს. onDone — მთავარ ნაკადში.
     */
    fun refreshLocation(ctx: Context, onDone: (() -> Unit)? = null) {
        val app = ctx.applicationContext
        val main = Handler(Looper.getMainLooper())
        main.post {
            var finished = false
            fun done() { if (!finished) { finished = true; try { onDone?.invoke() } catch (_: Throwable) {} } }
            try {
                if (!auto(app) || !hasLocationPermission(app)) { done(); return@post }
                val lm = app.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                var best: Location? = null
                for (pv in lm.getProviders(true)) {
                    val l = (try { lm.getLastKnownLocation(pv) } catch (_: SecurityException) { null }) ?: continue
                    if (best == null || l.time > best.time) best = l
                }
                val b = best
                if (b != null) storeLocation(app, b)
                if (b != null && System.currentTimeMillis() - b.time < 15 * 60_000L) { done(); return@post }
                val prov = when {
                    lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                    lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                    else -> null
                }
                if (prov == null) { done(); return@post }
                val lis = object : LocationListener {
                    override fun onLocationChanged(l: Location) { storeLocation(app, l); try { lm.removeUpdates(this) } catch (_: Throwable) {}; done() }
                    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION") override fun onStatusChanged(p: String?, st: Int, e: Bundle?) {}
                    override fun onProviderEnabled(p: String) {}
                    override fun onProviderDisabled(p: String) {}
                }
                @Suppress("DEPRECATION")
                lm.requestSingleUpdate(prov, lis, Looper.getMainLooper())
                main.postDelayed({ try { lm.removeUpdates(lis) } catch (_: Throwable) {}; done() }, 20_000L)
            } catch (_: Throwable) { done() }
        }
    }

    fun setDigest(ctx: Context, on: Boolean) { sp(ctx).edit().putBoolean("digest", on).apply(); arm(ctx) }
    fun setChanges(ctx: Context, on: Boolean) { sp(ctx).edit().putBoolean("changes", on).apply(); arm(ctx) }
    fun setCity(ctx: Context, id: String) { sp(ctx).edit().putString("city", id).putString("mode", "city").remove("seen").apply() }

    // ---------- ალარმი ----------
    private fun pi(ctx: Context): PendingIntent {
        val i = Intent(ctx, WeatherReceiver::class.java).setAction(ACTION)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(ctx, 7301, i, flags)
    }

    private fun titleName(ctx: Context): String = if (auto(ctx)) place(ctx).ifBlank { "ამინდი" } else cityName(ctx)

    private fun slotMs(hour: Int, dayOffset: Int): Long {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, dayOffset)
        c.set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23)); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun morningH() = RemoteConfig.i("weather.morning_hour", 8)
    private fun eveningH() = RemoteConfig.i("weather.evening_hour", 20)
    private fun checkMs() = RemoteConfig.i("weather.check_min", 10).coerceIn(10, 180) * 60_000L

    /** შემდეგი გაღვიძება: ან მორიგი შემოწმება, ან დილის/საღამოს პროგნოზის დრო — რომელიც უფრო ახლოა */
    fun arm(ctx: Context) {
        try {
            val am = ctx.applicationContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val p = pi(ctx)
            // v1.7.124: ალარმი რჩება ჩართული, თუ ადმინის შეტყობინებები (Notices) ჩართულია, ამინდის გამორთვის შემთხვევაშიც
            if (!Notices.on() && (!serverOn() || (!digestOn(ctx) && !changesOn(ctx)))) { am.cancel(p); return }
            val now = System.currentTimeMillis()
            var at = now + checkMs()
            var exact = false
            if (digestOn(ctx)) {
                for (h in intArrayOf(morningH(), eveningH())) for (d in 0..1) {
                    val s = slotMs(h, d)
                    if (s > now + 5_000L && s < at) { at = s; exact = true }
                }
            }
            val canExact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (Build.VERSION.SDK_INT >= 23) {
                if (canExact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)   // v1.7.111: ყოველთვის ზუსტი (თუ ნებადართულია) — ცვლილება დაგვიანების გარეშე
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            } else am.set(AlarmManager.RTC_WAKEUP, at, p)
        } catch (_: Exception) {}
    }

    // ---------- მონაცემები ----------
    private fun fetch(ctx: Context): JSONObject? = try {
        val q = if (auto(ctx)) {
            // ლოკაცია: 1) ამ მოწყობილობის (GPS/ქსელი) 2) ანგარიშის — ტელეფონიდან (ტვ/ბოქსისთვის) 3) IP
            var lat = sp(ctx).getString("lat", null)
            var lon = sp(ctx).getString("lon", null)
            if (lat == null || lon == null) {
                val a = accountLoc(ctx)
                if (a != null) { lat = a.first; lon = a.second }
            }
            if (lat != null && lon != null) "lat=$lat&lon=$lon" else "ip=1"
        } else "city=" + cityId(ctx)
        val conn = (URL("$BASE_URL/api/app_weather.php?$q").openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 10000
        }
        if (conn.responseCode !in 200..299) null else {
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            if (j.optBoolean("ok")) {
                if (auto(ctx)) sp(ctx).edit().putString("place", j.optJSONObject("city")?.optString("name", "") ?: "").putString("src", j.optString("src")).apply()
                j
            } else null
        }
    } catch (_: Exception) { null }

    /** ბლოკავს — ფონურ ნაკადში გამოიძახეთ. force=true: პროგნოზს მაშინვე აჩვენებს (ტესტი მენიუდან) */
    fun check(ctx: Context, force: Boolean = false) {
        if (!force) { try { Notices.check(ctx) } catch (_: Throwable) {} }   // v1.7.124: ადმინის შეტყობინებები ამავე შემოწმებით
        if (!serverOn() && !force) return
        if (!force && !digestOn(ctx) && !changesOn(ctx)) return
        val j = fetch(ctx) ?: return
        val now = System.currentTimeMillis()
        val p = sp(ctx)
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)

        if (force) {
            post(ctx, 9001, "🌦 " + titleName(ctx) + " — დღეს", j.optString("text_today"), false, window = true)
            return
        }
        // დილის / საღამოს პროგნოზი: სლოტის დროიდან 3 საათში, დღეში ერთხელ თითოეული
        if (digestOn(ctx)) {
            val day = cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR)
            val slots = arrayOf(Triple("m", morningH(), "text_today"), Triple("e", eveningH(), "text_tomorrow"))
            for ((tag, h, field) in slots) {
                val s = slotMs(h, 0)
                val key = "$day$tag"
                if (now >= s && now < s + 3 * 3600_000L && p.getString("digest_$tag", "") != key) {
                    p.edit().putString("digest_$tag", key).apply()
                    val title = "🌦 " + titleName(ctx) + (if (tag == "m") " — დღეს" else " — ხვალ")
                    post(ctx, if (tag == "m") 9101 else 9102, title, j.optString(field), false, window = true)
                }
            }
        }
        // ცვლილებები
        if (changesOn(ctx)) {
            try { observe(ctx, j, hour) } catch (_: Throwable) {}   // v1.7.111: რეალური მდგომარეობის ცვლილება
            val seen = try { JSONObject(p.getString("seen", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
            val it0 = seen.keys().asSequence().toList()
            for (k in it0) if (now - seen.optLong(k) > 24 * 3600_000L) seen.remove(k)
            val ev = j.optJSONArray("events")
            if (ev != null) for (i in 0 until ev.length()) {
                val e = ev.getJSONObject(i)
                val key = e.optString("key")
                if (key.isEmpty() || seen.has(key)) continue
                val sev = e.optInt("sev", 0)
                if ((hour < 7 || hour >= 23) && sev < 2) continue   // ღამით მხოლოდ ჭექა-ქუხილი
                seen.put(key, now)
                post(ctx, 9200 + (key.hashCode() and 0xFFF), e.optString("title"), e.optString("text"), true, window = true)
            }
            p.edit().putString("seen", seen.toString()).apply()
        }
    }

    // ---------- v1.7.111: რეალური ამინდის ცვლილება ----------
    @Volatile private var lastRun = 0L

    /** აპის გახსნისას/დაბრუნებისას სწრაფი შემოწმება (2 წთ-ზე ხშირად არა) */
    fun checkSoon(ctx: Context) {
        val now = System.currentTimeMillis()
        if (now - lastRun < 120_000L) return
        lastRun = now
        val app = ctx.applicationContext
        Thread { try { check(app) } catch (_: Throwable) {} }.start()
    }

    private fun grp(cat: String): String = if (cat == "clear" || cat == "partly") "sun" else cat
    private fun wetG(g: String) = g == "rain" || g == "snow" || g == "storm"

    /**
     * ახლანდელი მდგომარეობა (მზე / მოღრუბლული / ნისლი / წვიმა / თოვლი / ჭექა-ქუხილი) ვადარებთ წინა შემოწმებისას დამახსოვრებულს.
     * ნალექი/ჭექა-ქუხილი — მაშინვე; მოღრუბლვა/გამოდარება/ნისლი — არაუმეტეს 1-ჯერ 30 წთ-ში (რომ ცვალებად ღრუბლიანობაზე არ „გაჩუმდეს“ აპი).
     * ღამით (23:00–07:00) მხოლოდ ჭექა-ქუხილი; მდგომარეობა ჩუმად ახლდება. ადგილის შეცვლისას შედარება თავიდან იწყება.
     */
    private fun observe(ctx: Context, j: JSONObject, hour: Int) {
        val nw = j.optJSONObject("now") ?: return
        val cat = nw.optString("cat", "")
        if (cat.isEmpty()) return
        val g = grp(cat)
        val p = sp(ctx)
        val now = System.currentTimeMillis()
        val prev = p.getString("obs_g", "") ?: ""
        val prevAt = p.getLong("obs_at", 0L)
        val prevLoc = p.getString("obs_loc", "") ?: ""
        val locKey = j.optJSONObject("city")?.optString("name", "") ?: ""
        p.edit().putString("obs_g", g).putLong("obs_at", now).putString("obs_loc", locKey).apply()
        if (prev.isEmpty() || prevLoc != locKey || prev == g) return
        if (now - prevAt > 12 * 3600_000L) return

        val place = titleName(ctx)
        val temp = nw.optInt("temp")
        val txt = nw.optString("text")
        val icon = nw.optString("icon")
        val day = nw.optInt("is_day", 1) == 1
        var title = ""
        var body = ""
        var soft = false
        when {
            g == "storm" -> { title = "⛈ $place: ჭექა-ქუხილი"; body = "ახლა ჭექა-ქუხილია ($txt), $temp°. იყავით ფრთხილად." }
            g == "rain" && prev == "storm" -> { title = "🌧 $place: ჭექა-ქუხილი დასრულდა"; body = "ახლა $icon $txt, $temp°." }
            g == "rain" -> { title = "🌧 $place: წვიმა დაიწყო"; body = "ახლა $icon $txt, $temp°. აიღეთ ქოლგა ☂️" }
            g == "snow" -> { title = "❄️ $place: თოვლი დაიწყო"; body = "ახლა $icon $txt, $temp°." }
            wetG(prev) -> {
                val what = when (prev) { "snow" -> "თოვა შეწყდა"; "storm" -> "ჭექა-ქუხილი დასრულდა"; else -> "წვიმა გადაიღო" }
                title = "🌤 $place: $what"; body = "ახლა $icon $txt, $temp°."
            }
            g == "fog" -> { soft = true; title = "🌫 $place: ნისლია"; body = "ახლა $icon $txt, $temp°." }
            g == "cloud" -> { soft = true; title = "☁️ $place: მოიღრუბლა"; body = "ახლა $icon $txt, $temp°." }
            else -> {
                soft = true
                if (day) { title = "☀️ $place: გამოიდარა"; body = "მზე გამოჩნდა — $icon $txt, $temp°." }
                else { title = "🌙 $place: გამოიდარა"; body = "ცა გამოიდარა — $icon $txt, $temp°." }
            }
        }
        if ((hour < 7 || hour >= 23) && g != "storm") return
        if (soft) {
            if (now - prevAt > 3 * 3600_000L) return
            val gap = RemoteConfig.i("weather.soft_gap_min", 30).coerceIn(0, 360) * 60_000L
            if (now - p.getLong("soft_at", 0L) < gap) return
            p.edit().putLong("soft_at", now).apply()
        }
        post(ctx, 9300, title, body, wetG(g), window = true)
    }

    // ---------- ჩვენება ----------
    /** ადმინის შეტყობინება — ზუსტად ისე ჩნდება, როგორც ამინდის (სისტემური შეტყობინება + ტვ-ზე ფანჯარა) */
    fun postNotice(ctx: Context, id: Int, title: String, text: String, alert: Boolean) = post(ctx, id, title, text, alert, window = true, notice = true)

    private fun post(ctx: Context, id: Int, title: String, text: String, alert: Boolean, window: Boolean, notice: Boolean = false) {
        if (text.isBlank()) return
        notify(ctx, id, title, text, alert, notice)
        if (window && Device.tv(ctx) && (Reminders.foreground > 0 || Reminders.canOverlay(ctx))) {
            try {
                ctx.startActivity(Intent(ctx, WeatherActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    .putExtra("t", title).putExtra("m", text))
            } catch (_: Exception) {}
        }
    }

    private fun notify(ctx: Context, id: Int, title: String, text: String, alert: Boolean, notice: Boolean = false) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                if (nm.getNotificationChannel(CH_INFO) == null) nm.createNotificationChannel(NotificationChannel(CH_INFO, "ამინდი (პროგნოზი)", NotificationManager.IMPORTANCE_DEFAULT))
                if (nm.getNotificationChannel(CH_ALERT) == null) nm.createNotificationChannel(NotificationChannel(CH_ALERT, "ამინდი (ცვლილებები, ჭექა-ქუხილი)", NotificationManager.IMPORTANCE_HIGH))
                if (nm.getNotificationChannel(CH_N_INFO) == null) nm.createNotificationChannel(NotificationChannel(CH_N_INFO, "TELEVIZIA.STORE შეტყობინებები", NotificationManager.IMPORTANCE_DEFAULT))
                if (nm.getNotificationChannel(CH_N_ALERT) == null) nm.createNotificationChannel(NotificationChannel(CH_N_ALERT, "TELEVIZIA.STORE მნიშვნელოვანი", NotificationManager.IMPORTANCE_HIGH))
            }
            if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
            val open = if (launch != null) PendingIntent.getActivity(ctx, 7302, launch, flags) else null
            val chId = if (notice) (if (alert) CH_N_ALERT else CH_N_INFO) else (if (alert) CH_ALERT else CH_INFO)
            val b = NotificationCompat.Builder(ctx, chId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(if (alert) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
                .setCategory(NotificationCompat.CATEGORY_RECOMMENDATION)
                .setAutoCancel(true)
            if (open != null) b.setContentIntent(open)
            nm.notify(id, b.build())
        } catch (_: Exception) {}
    }

    fun askPermissions(a: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7201)
        } catch (_: Exception) {}
    }

    /** პარამეტრების ფანჯარა (MENU → „ამინდის შეტყობინებები“) */
    fun showSettings(a: Activity) {
        val ctx = a.applicationContext
        val labels = arrayOf("🌦 დილის და საღამოს პროგნოზი (დღეს / ხვალ)", "⚡ ცვლილებები მაშინვე (წვიმა, ჭექა-ქუხილი, მოღრუბლვა, გამოდარება)")
        val checked = booleanArrayOf(digestOn(ctx), changesOn(ctx))
        androidx.appcompat.app.AlertDialog.Builder(a)
            .setTitle("ამინდი — " + placeLabel(ctx))
            .setMultiChoiceItems(labels, checked) { _, which, on -> checked[which] = on }
            .setPositiveButton("შენახვა") { _, _ ->
                setDigest(ctx, checked[0]); setChanges(ctx, checked[1])
                if (checked[0] || checked[1]) askPermissions(a)
                android.widget.Toast.makeText(a, if (checked[0] || checked[1]) "ამინდის შეტყობინებები ჩართულია" else "ამინდის შეტყობინებები გამორთულია", android.widget.Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("ადგილი…") { _, _ -> showCityPicker(a) }
            .setNegativeButton("ტესტი") { _, _ ->
                askPermissions(a)
                refreshLocation(ctx) { Thread { check(ctx, force = true) }.start() }
            }
            .show()
    }

    private fun showCityPicker(a: Activity) {
        val ctx = a.applicationContext
        val names = (listOf("📍 ავტომატური ლოკაცია (ჩემი ადგილმდებარეობა)") + cities.map { it.second }).toTypedArray()
        val cur = if (auto(ctx)) 0 else cities.indexOfFirst { it.first == cityId(ctx) } + 1
        androidx.appcompat.app.AlertDialog.Builder(a)
            .setTitle("ადგილმდებარეობა")
            .setSingleChoiceItems(names, cur.coerceAtLeast(0)) { d, which ->
                d.dismiss()
                if (which == 0) {
                    setAuto(ctx)
                    askLocationPermission(a)
                    refreshLocation(ctx)
                    val msg = if (Device.tv(ctx) || !hasLocationFeature(ctx)) "📍 ავტომატური: მოწყობილობის ლოკაცია, თუ არა — ტელეფონის (იგივე ანგარიშით), თუ არა — ინტერნეტით" else "📍 ლოკაცია ავტომატურია"
                    android.widget.Toast.makeText(a, msg, android.widget.Toast.LENGTH_LONG).show()
                } else {
                    setCity(ctx, cities[which - 1].first)
                    android.widget.Toast.makeText(a, "ქალაქი: " + cities[which - 1].second, android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("დახურვა", null)
            .show()
    }
}

class WeatherReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            Notices.ACTION -> {   // v1.7.126: ადმინის შეტყობინებების ცალკე ალარმი (ყოველ ~3 წუთში)
                val pr = goAsync()
                Thread {
                    try { Notices.check(ctx) } catch (_: Throwable) {}
                    try { Notices.arm(ctx) } catch (_: Throwable) {}
                    pr.finish()
                }.start()
            }
            WeatherNotify.ACTION -> {
                val pr = goAsync()
                Thread {
                    try { WeatherNotify.check(ctx) } catch (_: Throwable) {}
                    try { WeatherNotify.arm(ctx) } catch (_: Throwable) {}
                    pr.finish()
                }.start()
            }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, "android.intent.action.QUICKBOOT_POWERON" -> { WeatherNotify.arm(ctx); Notices.arm(ctx) }
        }
    }
}

/** ამინდის ფანჯარა ტელევიზორზე (პულტითაც იხურება; 25 წმ-ში თვითონ იხურება) */
class WeatherActivity : Activity() {
    private var dlg: android.app.AlertDialog? = null
    private val h = android.os.Handler(android.os.Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        show(intent)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); show(intent) }

    private fun show(i: Intent) {
        dlg?.dismiss()
        val d = android.app.AlertDialog.Builder(this)
            .setTitle(i.getStringExtra("t") ?: "🌦")
            .setMessage(i.getStringExtra("m") ?: "")
            .setPositiveButton("დახურვა") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        dlg = d
        d.show()
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ if (!isFinishing) finish() }, 25_000L)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { dlg?.dismiss() } catch (_: Exception) {}
        super.onDestroy()
    }
}
