package store.televizia.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import org.json.JSONObject
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog

/**
 * ერთი ადმინ-ეკრანი, ორი განყოფილება:
 *  🌐 საიტი — საიტის არსებული ადმინ-გვერდი (WebView), შესვლა საიტის ფორმით (იგივე ლოგინი/პაროლი),
 *      ამიტომ მფლობელის/ადმინისტრატორის ყველა ფუნქცია მუშაობს. მისამართი იცვლება ⚙ ღილაკით.
 *  📱 აპლიკაცია — აპლიკაციის მართვა: ტექნიკური სამუშაოები, შეტყობინება, ვერსია/განახლება, მისამართები,
 *      ფუნქციების ჩართვა-გამორთვა. პარამეტრები ინახება საიტზე (api/app_config.php) ადმინ-გასაღებით.
 */
class AdminActivity : BaseActivity() {
    private lateinit var web: WebView
    private lateinit var bar: ProgressBar
    private lateinit var titleTv: TextView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private lateinit var appPane: View
    private lateinit var lockPane: View
    private lateinit var formPane: View
    private lateinit var lockKey: EditText
    private lateinit var lockStatus: TextView
    private lateinit var form: LinearLayout
    private lateinit var formStatus: TextView
    private var appTab = false
    private val fields = LinkedHashMap<String, View>()
    private val numeric = HashSet<String>()
    private val prefs by lazy { getSharedPreferences("tv_admin", Context.MODE_PRIVATE) }

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)
        web = findViewById(R.id.web)
        bar = findViewById(R.id.webProgress)
        titleTv = findViewById(R.id.adminTitle)

        appPane = findViewById(R.id.appPane)
        lockPane = findViewById(R.id.lockPane)
        formPane = findViewById(R.id.formPane)
        lockKey = findViewById(R.id.lockKey)
        lockStatus = findViewById(R.id.lockStatus)
        findViewById<View>(R.id.lockGo).setOnClickListener { verifyKey(lockKey.text.toString().trim()) }
        lockKey.setOnEditorActionListener { _, _, _ -> verifyKey(lockKey.text.toString().trim()); true }
        form = findViewById(R.id.appForm)
        formStatus = findViewById(R.id.formStatus)
        buildForm()
        findViewById<View>(R.id.tabSite).setOnClickListener { selectTab(false) }
        findViewById<View>(R.id.tabApp).setOnClickListener { selectTab(true) }
        findViewById<View>(R.id.cfgLoad).setOnClickListener { loadConfig() }
        findViewById<View>(R.id.cfgSave).setOnClickListener { saveConfig() }
        findViewById<View>(R.id.cfgKey).setOnClickListener {
            prefs.edit().remove("key").apply()
            showLock("")
        }

        findViewById<View>(R.id.adminBack).setOnClickListener { goBackOrClose() }
        findViewById<View>(R.id.adminReload).setOnClickListener {
            if (!appTab) web.reload() else if (formPane.visibility == View.VISIBLE) loadConfig()
        }
        findViewById<View>(R.id.adminHome).setOnClickListener { web.loadUrl(adminUrl(this)) }
        findViewById<View>(R.id.adminUrl).setOnClickListener { askUrl() }
        findViewById<View>(R.id.adminClose).setOnClickListener { finish() }

        val siteHost = Uri.parse(BASE_URL).host
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = true
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                if (u.host == siteHost && (u.scheme == "https" || u.scheme == "http")) return false
                // სხვა საიტი, tel:, mailto: — გარე აპლიკაციაში
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }

            override fun onPageStarted(v: WebView, url: String?, favicon: Bitmap?) {
                bar.visibility = View.VISIBLE
            }

            override fun onPageFinished(v: WebView, url: String?) {
                bar.visibility = View.GONE
                titleTv.text = v.title?.takeIf { it.isNotBlank() } ?: getString(R.string.admin_title)
            }

            override fun onReceivedError(v: WebView, req: WebResourceRequest, err: android.webkit.WebResourceError) {
                if (req.isForMainFrame) titleTv.text = getString(R.string.err_connection_short)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                bar.progress = p
            }

            // ფაილის ატვირთვა (ლოგო, სურათები, M3U და ა.შ. საიტის ფორმებიდან)
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    chooser.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
        }
        web.setDownloadListener { url, _, _, _, _ ->
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goBackOrClose()
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(adminUrl(this))
        selectTab(savedInstanceState?.getBoolean("appTab") ?: false)
    }

    private fun goBackOrClose() {
        if (!appTab && web.canGoBack()) web.goBack() else finish()
    }

    // ---------- ჩანართები ----------

    private fun selectTab(app: Boolean) {
        appTab = app
        web.visibility = if (app) View.GONE else View.VISIBLE
        appPane.visibility = if (app) View.VISIBLE else View.GONE
        findViewById<View>(R.id.tabSite).isSelected = !app
        findViewById<View>(R.id.tabApp).isSelected = app
        findViewById<View>(R.id.adminHome).visibility = if (app) View.GONE else View.VISIBLE
        findViewById<View>(R.id.adminUrl).visibility = if (app) View.GONE else View.VISIBLE
        titleTv.text = getString(if (app) R.string.admin_app_title else R.string.admin_title)
        if (app) {
            // ფორმა იხსნება მხოლოდ სწორი გასაღების დადასტურების შემდეგ
            val saved = prefs.getString("key", "") ?: ""
            if (saved.isEmpty()) showLock("") else verifyKey(saved)
        }
    }

    private fun showLock(msg: String) {
        formPane.visibility = View.GONE
        lockPane.visibility = View.VISIBLE
        lockKey.setText("")
        lockStatus.text = msg
        lockKey.requestFocus()
    }

    private fun verifyKey(key: String) {
        if (key.isEmpty()) { showLock(""); return }
        lockPane.visibility = View.VISIBLE
        formPane.visibility = View.GONE
        lockStatus.text = getString(R.string.checking)
        Thread {
            val r = RemoteConfig.adminCheck(key)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (r.ok) {
                    prefs.edit().putString("key", key).apply()
                    lockPane.visibility = View.GONE
                    formPane.visibility = View.VISIBLE
                    loadConfig()
                } else {
                    prefs.edit().remove("key").apply()
                    showLock(r.message)
                }
            }
        }.start()
    }

    // ---------- აპლიკაციის მართვის ფორმა ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun section(t: String) {
        form.addView(TextView(this).apply {
            text = t
            setTextColor(0xFF00F0D4.toInt())
            textSize = 17f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(22), 0, dp(2))
        })
    }

    private fun hint(t: String) {
        form.addView(TextView(this).apply {
            text = t
            setTextColor(0xFF9AA3C2.toInt())
            textSize = 13f
            setPadding(0, dp(4), 0, dp(2))
        })
    }

    private fun sw(key: String, label: String) {
        val s = SwitchCompat(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 15f
            minHeight = dp(52)
        }
        fields[key] = s
        form.addView(s)
    }

    private fun et(key: String, label: String, number: Boolean = false, multi: Boolean = false, url: Boolean = false) {
        hint(label)
        val e = EditText(this).apply {
            setBackgroundResource(R.drawable.edit_bg)
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = when {
                number -> InputType.TYPE_CLASS_NUMBER
                multi -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                url -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                else -> InputType.TYPE_CLASS_TEXT
            }
            if (multi) { minLines = 3; gravity = Gravity.TOP or Gravity.START }
        }
        if (number) numeric.add(key)
        fields[key] = e
        form.addView(e)
    }

    private fun buildForm() {
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        hint("ამ ტელეფონზე დაყენებული ვერსია: $ver (კოდი ${Gate.versionCode(this)})")

        section("🛠 ტექნიკური სამუშაოები")
        sw("maintenance.on", "ჩართვა — მომხმარებლებს აპლიკაცია არ გაეხსნებათ")
        et("maintenance.message", "შეტყობინება მომხმარებლებისთვის", multi = true)

        section("📢 შეტყობინება მომხმარებლებისთვის")
        sw("announcement.on", "ჩართვა (ყოველ ახალ ტექსტზე ერთხელ ჩანს)")
        et("announcement.title", "სათაური")
        et("announcement.text", "ტექსტი", multi = true)
        et("announcement.url", "ბმული (არასავალდებულო — გამოჩნდება ღილაკი „გახსნა“)", url = true)

        section("⬆ ვერსია და განახლება")
        et("update.latest_code", "უახლესი ვერსიის კოდი (versionCode build.gradle-დან; მასზე ძველებს შეახსენებს)", number = true)
        et("update.latest_name", "უახლესი ვერსიის სახელი (მაგ. 1.6)")
        et("update.url", "APK / გვერდის ბმული (GitHub Release და ა.შ.)", url = true)
        et("update.force_below", "იძულებითი განახლება: ამ კოდზე ძველი ვერსია აღარ გაიხსნება (0 = გამორთულია)", number = true)
        et("update.message", "განახლების ტექსტი", multi = true)

        section("🔗 მისამართები")
        et("urls.epg", "ტელეპროგრამის (EPG) ბმული — ცარიელი = არხების სიიდან", url = true)
        et("urls.admin", "საიტის საადმინო პანელის მისამართი — ცარიელი = ნაგულისხმევი", url = true)

        section("🎛 ფუნქციები შესვლის ეკრანზე / მთავარზე")
        sw("features.qr_login", "QR კოდის სკანირებით შესვლა")
        sw("features.tv_login", "TV-ზე შესვლა კოდით")
        sw("features.lang_button", "ენის ღილაკი")
        sw("features.admin_button", "„ადმინისტრატორი“ ღილაკი შესვლის ეკრანზე")

        section("✉ შესვლის ეკრანი")
        et("texts.login_notice", "ტექსტი ლოგოს ქვეშ (ცარიელი = არ ჩანს)", multi = true)
        form.addView(View(this), LinearLayout.LayoutParams(1, dp(24)))
    }

    private fun applyJson(cfg: JSONObject) {
        for ((path, v) in fields) {
            val p = path.split('.')
            var o: JSONObject? = cfg
            for (i in 0 until p.size - 1) o = o?.optJSONObject(p[i])
            val k = p.last()
            val has = o != null && o.has(k) && !o.isNull(k)
            when (v) {
                is SwitchCompat -> v.isChecked = has && o!!.optBoolean(k)
                is EditText -> v.setText(if (!has) "" else if (path in numeric) o!!.optInt(k).toString() else o!!.optString(k))
            }
        }
    }

    private fun collect(): JSONObject {
        val root = JSONObject()
        for ((path, v) in fields) {
            val p = path.split('.')
            var o = root
            for (i in 0 until p.size - 1) {
                val next = o.optJSONObject(p[i]) ?: JSONObject().also { o.put(p[i], it) }
                o = next
            }
            when (v) {
                is SwitchCompat -> o.put(p.last(), v.isChecked)
                is EditText -> {
                    val t = v.text.toString().trim()
                    if (path in numeric) o.put(p.last(), t.toIntOrNull() ?: 0) else o.put(p.last(), t)
                }
            }
        }
        return root
    }

    private fun status(t: String, ok: Boolean? = null) {
        formStatus.text = t
        formStatus.setTextColor(when (ok) { true -> 0xFF00F0D4.toInt(); false -> 0xFFFF5C72.toInt(); else -> 0xFFC9CEE4.toInt() })
    }

    private fun loadConfig() {
        status(getString(R.string.checking))
        Thread {
            val r = RemoteConfig.adminGet()
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (r.ok && r.config != null) { applyJson(r.config); status("✓ სერვერიდან ჩაიტვირთა", true) }
                else status(r.message, false)
            }
        }.start()
    }

    private fun saveConfig() {
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty()) { showLock(""); return }
        val cfg = collect()
        status(getString(R.string.checking))
        Thread {
            val r = RemoteConfig.adminSet(key, cfg)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (r.ok) {
                    r.config?.let { applyJson(it); RemoteConfig.store(applicationContext, it) }
                    status("✓ შენახულია — აპლიკაციები ახალ პარამეტრებს გახსნისას მიიღებენ", true)
                } else if (r.message.contains("გასაღები")) {
                    prefs.edit().remove("key").apply()
                    showLock(r.message)
                } else status(r.message, false)
            }
        }.start()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
        outState.putBoolean("appTab", appTab)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    override fun onDestroy() {
        fileCb?.onReceiveValue(null)
        fileCb = null
        if (::web.isInitialized) {
            (web.parent as? android.view.ViewGroup)?.removeView(web)
            web.destroy()
        }
        super.onDestroy()
    }

    companion object {
        fun adminUrl(ctx: Context): String =
            ctx.getSharedPreferences("tv_admin", Context.MODE_PRIVATE).getString("url", null)
                ?: RemoteConfig.s("urls.admin").takeIf { it.isNotBlank() && Uri.parse(it).host == Uri.parse(BASE_URL).host }
                ?: ADMIN_URL
    }
}
