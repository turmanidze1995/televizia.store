package store.televizia.app

import android.os.Handler
import android.os.Looper

/** აპლიკაციის საერთო მდგომარეობა: ყველა არხი, ამჟამინდელი (გაფილტრული) სია და მიმდინარე არხი */
object ChannelHolder {
    var all: List<Channel> = emptyList()
    var list: List<Channel> = emptyList()
    var group: String = Lang.ALL
    var current: Channel? = null
    @Volatile var epgStarted = false

    /** ბოლოს ცნობილი პოზიცია სიაში — თუ URL-ით ვერ ვიპოვეთ, შემდეგი/წინა არხი მაინც სწორი იყოს */
    @Volatile private var lastIndex = -1

    /** მიმდინარე არხის ნომერი ამჟამინდელ სიაში (0-დან), ან -1 */
    val index: Int
        get() {
            val c = current ?: return -1
            val l = list
            var i = l.indexOfFirst { it.url == c.url }
            if (i < 0) i = l.indexOfFirst { it.name == c.name && it.group == c.group }
            if (i < 0) i = l.indexOfFirst { it.name == c.name }
            if (i < 0 && lastIndex in l.indices) i = lastIndex
            if (i >= 0) lastIndex = i
            return i
        }

    fun reset() {
        all = emptyList(); list = emptyList(); group = Lang.ALL; current = null; epgStarted = false; lastIndex = -1
    }
}

/**
 * არხის ნომრის ციფრებით აკრეფა (პულტით): ყოველი ციფრი ეკრანზე ჩანს ამ ნომრის არხის სახელითურთ.
 *  - არხზე გადადის 1 წამის შემდეგ, ან მაშინვე თუ ნომერი ცალსახაა (მაგ. 5, როცა 50+ არხი არ არის), ან OK-ზე დაჭერისას
 *  - ორ-სამნიშნა ნომრისთვის: 1, შემდეგ 2 → 12
 */
class DigitEntry(
    private val size: () -> Int,
    private val nameAt: (Int) -> String?,
    private val onUpdate: (digits: String, name: String?, valid: Boolean) -> Unit,
    private val onCommit: (Int) -> Unit,
    private val onClose: () -> Unit
) {
    private val h = Handler(Looper.getMainLooper())
    private val sb = StringBuilder()
    private val timeout = Runnable { commit() }

    val active: Boolean get() = sb.isNotEmpty()

    fun digit(d: Int) {
        if (sb.length >= 4) sb.setLength(0)
        sb.append(d)
        val n = sb.toString().toIntOrNull() ?: 0
        val max = size()
        val valid = n in 1..max
        onUpdate(sb.toString(), if (valid) nameAt(n - 1) else null, valid)
        h.removeCallbacks(timeout)
        if (valid && n * 10 > max) {
            h.postDelayed(timeout, 350)   // ცალსახაა — თითქმის მაშინვე გადავდივართ
        } else {
            h.postDelayed(timeout, 1200)
        }
    }

    fun commit() {
        h.removeCallbacks(timeout)
        if (sb.isEmpty()) return
        val n = sb.toString().toIntOrNull()
        sb.setLength(0)
        onClose()
        if (n != null && n in 1..size()) onCommit(n - 1)
    }

    fun cancel() {
        h.removeCallbacks(timeout)
        if (sb.isEmpty()) return
        sb.setLength(0)
        onClose()
    }
}
