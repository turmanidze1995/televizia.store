package store.televizia.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory

/**
 * ერთი არხის დამკვრელი, რომელიც არხს რამდენიმე გზით ცდილობს გახსნას:
 *  - http <-> https გადამისამართებებს მიჰყვება (ExoPlayer-ის სტანდარტი ამას არ აკეთებს, ამიტომ
 *    ბევრი არხი არ იხსნებოდა)
 *  - ფორმატს ბმულიდან ხვდება, ხოლო თუ ვერ გაიხსნა — სცდის სხვა ფორმატებს (HLS, TS, ავტომატური)
 *  - ბოლოს სცდის ბრაუზერის User-Agent-ით
 *  - თუ არხი 15 წამში არ ჩაირთო, ამ ცდას წყვეტს და შემდეგზე გადადის
 *  - ყველა ცდის შემდეგ უბრალოდ იძახებს onFailed — სხვა არხზე თავისით არასოდეს გადადის
 */
class StreamController(
    private val ctx: Context,
    private val onLoading: () -> Unit,
    private val onPlaying: () -> Unit,
    private val onFailed: () -> Unit
) {
    companion object {
        private const val UA_VLC = "VLC/3.0.18 LibVLC/3.0.18"
        private const val UA_BROWSER =
            "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0 Safari/537.36"
        private const val START_TIMEOUT_MS = 15000L
        private val TS_REGEX = Regex("""\.ts($|[?/#])""")
    }

    var player: ExoPlayer? = null
        private set

    private val h = Handler(Looper.getMainLooper())
    private var url = ""
    private var attempt = 0
    private var everPlayed = false
    private val watchdog = Runnable { handleError(null) }

    /** ქმნის ფლეიერს; PlayerView-ს მიამაგრეთ დაბრუნებული ობიექტი */
    fun attach(): ExoPlayer {
        release()
        val renderers = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(ctx, renderers).build()
        p.volume = 1f
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> {
                        h.removeCallbacks(watchdog)
                        everPlayed = true
                        onPlaying()
                    }
                    Player.STATE_BUFFERING -> onLoading()
                    Player.STATE_ENDED -> handleError(null)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                handleError(error)
            }
        })
        player = p
        return p
    }

    fun play(newUrl: String) {
        url = newUrl.trim()
        attempt = 0
        everPlayed = false
        onLoading()
        start()
    }

    fun release() {
        h.removeCallbacks(watchdog)
        player?.release()
        player = null
    }

    /** ფორმატების რიგი ბმულის მიხედვით: null = ავტომატური ამოცნობა */
    private fun formats(): List<String?> {
        val l = url.lowercase()
        return when {
            l.contains("m3u8") -> listOf(MimeTypes.APPLICATION_M3U8, null, MimeTypes.VIDEO_MP2T)
            TS_REGEX.containsMatchIn(l) -> listOf(MimeTypes.VIDEO_MP2T, MimeTypes.APPLICATION_M3U8, null)
            else -> listOf(null, MimeTypes.APPLICATION_M3U8, MimeTypes.VIDEO_MP2T)
        }
    }

    private fun spec(a: Int): Pair<String?, String> {
        val f = formats()
        return when (a) {
            0 -> Pair(f[0], UA_VLC)
            1 -> Pair(f[1], UA_VLC)
            2 -> Pair(f[2], UA_VLC)
            else -> Pair(f[0], UA_BROWSER)
        }
    }

    private fun start() {
        val p = player ?: return
        val (fmt, ua) = spec(attempt)
        val builder = MediaItem.Builder().setUri(url)
        if (fmt != null) builder.setMimeType(fmt)
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10000)
            .setReadTimeoutMs(15000)
        val source = DefaultMediaSourceFactory(DefaultDataSource.Factory(ctx, http))
            .createMediaSource(builder.build())
        p.setMediaSource(source)
        p.prepare()
        p.playWhenReady = true
        h.removeCallbacks(watchdog)
        h.postDelayed(watchdog, START_TIMEOUT_MS)
    }

    private fun isParseError(e: PlaybackException?): Boolean {
        if (e == null) return false
        return e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED
    }

    private fun handleError(e: PlaybackException?) {
        h.removeCallbacks(watchdog)
        val p = player ?: return
        if (e != null && e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            p.seekToDefaultPosition()
            p.prepare()
            h.postDelayed(watchdog, START_TIMEOUT_MS)
            return
        }
        if (everPlayed) {
            // ნაკადი გაჩერდა, მაგრამ აქამდე თამაშობდა — ერთხელ თავიდან ვუკავშირდებით
            everPlayed = false
            start()
            return
        }
        // ფორმატის შეცდომისას ვცდით შემდეგ ფორმატს; კავშირის/სერვერის შეცდომისას — ბრაუზერის სათაურს
        val next = when {
            attempt >= 3 -> -1
            isParseError(e) && attempt < 2 -> attempt + 1
            else -> 3
        }
        if (next < 0) {
            try { p.stop() } catch (ex: Exception) { }
            onFailed()
            return
        }
        attempt = next
        start()
    }
}
