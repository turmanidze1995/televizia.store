package store.televizia.app

import android.os.Handler
import android.os.Looper

/** ამჟამინდელი არხების სია, პოზიცია და ციფრებით შეყვანა (მაგ. 1, 2 → არხი 12) */
object ChannelHolder {
    var list: List<Channel> = emptyList()
    var index: Int = -1
    private val digits = StringBuilder()
    private val handler = Handler(Looper.getMainLooper())

    fun digit(d: Int, onJump: (Int) -> Unit) {
        digits.append(d)
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            val n = digits.toString().toIntOrNull()
            digits.setLength(0)
            if (n != null && n in 1..list.size) onJump(n - 1)
        }, 1200)
    }
}
