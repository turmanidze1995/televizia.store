package store.televizia.app

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

data class Program(val start: Long, val stop: Long, val title: String)

/** XMLTV პროგრამის სია: ამჟამინდელი და მომავალი გადაცემები არხების მიხედვით */
object Epg {
    @Volatile private var map: Map<String, List<Program>> = emptyMap()

    fun load() {
        if (EPG_URL.isBlank()) return
        try {
            val conn = (URL(EPG_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 60000
            }
            conn.inputStream.use { stream ->
                val p = Xml.newPullParser()
                p.setInput(stream, null)
                val tmp = HashMap<String, MutableList<Program>>()
                var ch = ""
                var start = 0L
                var stop = 0L
                var title = ""
                var inTitle = false
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    when (ev) {
                        XmlPullParser.START_TAG -> when (p.name) {
                            "programme" -> {
                                ch = p.getAttributeValue(null, "channel") ?: ""
                                start = parseTime(p.getAttributeValue(null, "start"))
                                stop = parseTime(p.getAttributeValue(null, "stop"))
                                title = ""
                            }
                            "title" -> inTitle = true
                        }
                        XmlPullParser.TEXT -> if (inTitle) title += p.text
                        XmlPullParser.END_TAG -> when (p.name) {
                            "title" -> inTitle = false
                            "programme" -> tmp.getOrPut(ch) { mutableListOf() }
                                .add(Program(start, stop, title.trim()))
                        }
                    }
                    ev = p.next()
                }
                tmp.values.forEach { list -> list.sortBy { it.start } }
                map = tmp
            }
        } catch (e: Exception) {
            // EPG ვერ ჩაიტვირთა — არხები მაინც მუშაობს
        }
    }

    fun now(epgId: String): Program? {
        if (epgId.isBlank()) return null
        val t = System.currentTimeMillis()
        return map[epgId]?.firstOrNull { t >= it.start && t < it.stop }
    }

    fun upcoming(epgId: String, count: Int): List<Program> {
        if (epgId.isBlank()) return emptyList()
        val t = System.currentTimeMillis()
        return map[epgId].orEmpty().filter { it.stop > t }.take(count)
    }

    /** XMLTV დრო: 20261013120000 +0400 */
    private fun parseTime(s: String?): Long {
        if (s == null) return 0L
        val t = s.trim()
        val fmt = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val base = try { fmt.parse(t.take(14))?.time ?: 0L } catch (e: Exception) { 0L }
        val rest = t.drop(14).trim()
        val offsetMin = if (rest.length >= 5 && (rest[0] == '+' || rest[0] == '-')) {
            val h = rest.substring(1, 3).toInt()
            val m = rest.substring(3, 5).toInt()
            (if (rest[0] == '+') 1 else -1) * (h * 60 + m)
        } else 0
        return base - offsetMin * 60_000L
    }
}
