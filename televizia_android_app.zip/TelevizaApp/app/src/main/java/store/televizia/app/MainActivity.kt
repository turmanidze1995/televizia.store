package store.televizia.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import store.televizia.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.list.layoutManager = LinearLayoutManager(this)
        b.btnLogout.setOnClickListener {
            Session.clear(this)
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
        loadChannels()
    }

    private fun loadChannels() {
        val token = Session.token(this)
        if (token == null) {
            goLogin()
            return
        }
        b.status.text = "არხები იტვირთება…"
        Thread {
            val res = Api.playlist(token)
            runOnUiThread {
                if (!res.ok) {
                    b.status.text = res.message
                    return@runOnUiThread
                }
                val channels = M3u.parse(res.body)
                b.status.text = "არხები: ${channels.size}"
                b.list.adapter = ChannelAdapter(channels) { ch -> play(ch) }
            }
        }.start()
    }

    private fun play(ch: Channel) {
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", ch.url).putExtra("name", ch.name))
    }

    private fun goLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private class ChannelAdapter(
        private val items: List<Channel>,
        private val onClick: (Channel) -> Unit
    ) : RecyclerView.Adapter<ChannelAdapter.VH>() {

        class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): VH {
            val tv = TextView(parent.context).apply {
                layoutParams = RecyclerView.LayoutParams(
                    RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT)
                setBackgroundResource(android.R.drawable.list_selector_background)
                setPadding(32, 32, 32, 32)
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 17f
                isFocusable = true
                isClickable = true
            }
            return VH(tv)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val ch = items[position]
            holder.tv.text = ch.name
            holder.tv.setOnClickListener { onClick(ch) }
        }
    }
}
