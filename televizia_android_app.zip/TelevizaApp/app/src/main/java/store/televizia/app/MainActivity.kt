package store.televizia.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import store.televizia.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    companion object {
        const val ALL = "ყველა"
    }

    private lateinit var b: ActivityMainBinding
    private var player: ExoPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private var clockR: Runnable? = null
    private var all: List<Channel> = emptyList()
    private var groups: List<String> = emptyList()
    private var group = ALL
    private var current: Channel? = null

    /** OK / დაჭერა სიაში: არხი იწყება და იხსნება სრულ ეკრანზე */
    private val channelAdapter = ChannelAdapter { ch, _ ->
        play(ch)
        openFullscreen()
    }
    private lateinit var groupAdapter: GroupAdapter
    private val isTv: Boolean by lazy { packageManager.hasSystemFeature("android.software.leanback") }
    private val programAdapter = ProgramAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.token(this) == null) {
            goLogin()
            return
        }
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.channels.layoutManager = LinearLayoutManager(this)
        b.channels.adapter = channelAdapter
        groupAdapter = GroupAdapter(isTv) { g -> selectGroup(g) }
        b.groups.layoutManager = if (isTv) LinearLayoutManager(this)
            else LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.groups.adapter = groupAdapter
        b.epgList.layoutManager = LinearLayoutManager(this)
        b.epgList.adapter = programAdapter
        b.btnFullscreen.setOnClickListener { openFullscreen() }
        b.btnLogout.setOnClickListener {
            Session.clear(this)
            goLogin()
        }
        loadChannels()
    }

    override fun onStart() {
        super.onStart()
        if (!::b.isInitialized) return
        clockR = Ui.startClock(b.clock, h)
        if (player == null) {
            syncFromHolder()
            player = ExoPlayer.Builder(this).build().also { p ->
            b.preview.player = p
            p.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    b.status.text = "არხი დროებით გამორთულია"
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == androidx.media3.common.Player.STATE_READY) b.status.text = "$group · ${ChannelHolder.list.size} არხი"
                }
            })
        }
            current?.let { playUrl(it.url) }
        }
    }

    override fun onStop() {
        super.onStop()
        clockR?.let { h.removeCallbacks(it) }
        clockR = null
        if (!::b.isInitialized) return
        b.preview.player = null
        player?.release()
        player = null
    }

    private fun loadChannels() {
        val token = Session.token(this) ?: run { goLogin(); return }
        b.status.text = "არხები იტვირთება…"
        Thread {
            val res = Api.playlist(token)
            runOnUiThread {
                if (!res.ok) {
                    b.status.text = res.message
                    return@runOnUiThread
                }
                all = M3u.parse(res.body)
                groups = listOf(ALL) + all.map { it.group }.distinct()
                groupAdapter.submit(groups, group)
                applyFilter()
                all.firstOrNull()?.let { play(it) }
                // EPG ცალკე ფონურად (თუ EPG_URL არის მითითებული)
                Thread {
                    Epg.load()
                    runOnUiThread {
                        channelAdapter.refresh()
                        current?.let { programAdapter.submit(Epg.upcoming(it.epgId, 12)) }
                    }
                }.start()
            }
        }.start()
    }

    private fun selectGroup(g: String) {
        group = g
        groupAdapter.submit(groups, group)
        applyFilter()
    }

    private fun applyFilter() {
        val shown = if (group == ALL) all else all.filter { it.group == group }
        channelAdapter.submit(shown)
        ChannelHolder.list = shown
        ChannelHolder.index = shown.indexOfFirst { it.url == current?.url }
        b.status.text = "$group · ${shown.size} არხი"
    }

    private fun play(ch: Channel) {
        current = ch
        ChannelHolder.index = ChannelHolder.list.indexOfFirst { it.url == ch.url }
        b.nowName.text = ch.name
        channelAdapter.select(ch.url)
        b.btnFullscreen.isEnabled = true
        programAdapter.submit(Epg.upcoming(ch.epgId, 12))
        playUrl(ch.url)
    }

    private fun playUrl(url: String) {
        val p = player ?: return
        p.setMediaItem(MediaItem.fromUri(url))
        p.prepare()
        p.playWhenReady = true
    }

    private fun openFullscreen() {
        val ch = current ?: return
        ChannelHolder.index = ChannelHolder.list.indexOfFirst { it.url == ch.url }
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", ch.url))
    }

    /** სრულ ეკრანიდან დაბრუნებისას ან ფლეიერის გახსნისას — მიმდინარე არხის სინქრონიზაცია */
    private fun syncFromHolder() {
        val list = ChannelHolder.list
        val i = ChannelHolder.index
        if (i !in list.indices) return
        val ch = list[i]
        current = ch
        b.nowName.text = ch.name
        channelAdapter.select(ch.url)
        b.btnFullscreen.isEnabled = true
        programAdapter.submit(Epg.upcoming(ch.epgId, 12))
    }

    private fun stepChannel(delta: Int) {
        val list = ChannelHolder.list
        if (list.isEmpty()) return
        val pos = Math.floorMod(ChannelHolder.index + delta, list.size)
        play(list[pos])
        b.channels.scrollToPosition(pos)
    }

    /** პულტის CH+/CH- და ციფრები (1..9, 0) */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && ::b.isInitialized) {
            val k = event.keyCode
            when {
                k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_PAGE_UP -> {
                    stepChannel(1)
                    return true
                }
                k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_PAGE_DOWN -> {
                    stepChannel(-1)
                    return true
                }
                k == KeyEvent.KEYCODE_MEDIA_PLAY || k == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (current != null) {
                        openFullscreen()
                        return true
                    }
                }
                k in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                    ChannelHolder.digit(k - KeyEvent.KEYCODE_0) { pos ->
                        play(ChannelHolder.list[pos])
                        b.channels.scrollToPosition(pos)
                    }
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun goLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
