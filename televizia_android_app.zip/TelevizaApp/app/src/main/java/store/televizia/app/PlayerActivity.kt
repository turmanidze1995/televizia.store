package store.televizia.app

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** სრული ეკრანის ფლეიერი: CH+/CH-, ციფრები, −10/+10, წინა/შემდეგი, არხების პანელი, EPG ინფო */
class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private var clockR: Runnable? = null
    private lateinit var drawerWrap: View
    private lateinit var drawer: RecyclerView
    private lateinit var drawerAdapter: ChannelAdapter
    private lateinit var chNum: TextView
    private lateinit var chName: TextView
    private lateinit var chNow: TextView
    private lateinit var chLogo: ImageView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        val url = intent.getStringExtra("url") ?: run { finish(); return }

        chNum = findViewById(R.id.chNum)
        chName = findViewById(R.id.chName)
        chNow = findViewById(R.id.chNow)
        chLogo = findViewById(R.id.chLogo)
        progress = findViewById(R.id.progress)
        drawerWrap = findViewById(R.id.drawerWrap)
        drawer = findViewById(R.id.drawer)
        drawerAdapter = ChannelAdapter { _, pos ->
            playAt(pos)
            toggleDrawer(false)
        }
        drawer.layoutManager = LinearLayoutManager(this)
        drawer.adapter = drawerAdapter
        drawerAdapter.submit(ChannelHolder.list)

        val view = findViewById<PlayerView>(R.id.playerView)
        player = ExoPlayer.Builder(this).build().also {
            view.player = it
            it.volume = 1f
        }

        findViewById<Button>(R.id.btnBack).setOnClickListener { seekBy(-10_000) }
        findViewById<Button>(R.id.btnForward).setOnClickListener { seekBy(10_000) }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { step(-1) }
        findViewById<Button>(R.id.btnNext).setOnClickListener { step(1) }
        findViewById<Button>(R.id.btnPlayPause).setOnClickListener {
            player?.let { p -> p.playWhenReady = !p.playWhenReady }
        }
        findViewById<Button>(R.id.btnChannels).setOnClickListener {
            toggleDrawer(drawerWrap.visibility != View.VISIBLE)
        }

        val idx = ChannelHolder.index
        if (idx in ChannelHolder.list.indices) playAt(idx) else playUrl(url)
        clockR = Ui.startClock(findViewById<TextView>(R.id.clock), h) { showInfo() }
    }

    private fun playAt(pos: Int) {
        val list = ChannelHolder.list
        if (pos !in list.indices) return
        ChannelHolder.index = pos
        val ch = list[pos]
        playUrl(ch.url)
        drawerAdapter.select(ch.url)
        showInfo()
    }

    private fun playUrl(url: String) {
        player?.apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }

    private fun step(delta: Int) {
        val n = ChannelHolder.list.size
        if (n == 0) return
        playAt(Math.floorMod(ChannelHolder.index + delta, n))
    }

    /** ლაივ არხზე წინ/უკან გადახვევა მხოლოდ იმ ნაკადზე მუშაობს, რომელსაც DVR ფანჯარა აქვს */
    private fun seekBy(ms: Long) {
        player?.let { it.seekTo(maxOf(0L, it.currentPosition + ms)) }
    }

    private fun toggleDrawer(show: Boolean) {
        drawerWrap.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            drawerAdapter.select(ChannelHolder.list.getOrNull(ChannelHolder.index)?.url ?: "")
            drawer.scrollToPosition(ChannelHolder.index.coerceAtLeast(0))
            drawer.requestFocus()
        }
    }

    private fun showInfo() {
        val ch = ChannelHolder.list.getOrNull(ChannelHolder.index) ?: return
        chNum.text = (ChannelHolder.index + 1).toString()
        chName.text = ch.name
        ImageLoader.show(ch.logo, chLogo)
        val now = Epg.now(ch.epgId)
        chNow.text = now?.let { "${Ui.timeOf(it.start)} – ${Ui.timeOf(it.stop)}   ${it.title}" } ?: ""
        progress.progress = Ui.progressOf(now)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && drawerWrap.visibility == View.VISIBLE) {
            toggleDrawer(false)
            return true
        }
        when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                step(1)
                return true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                step(-1)
                return true
            }
            KeyEvent.KEYCODE_MENU -> {
                toggleDrawer(drawerWrap.visibility != View.VISIBLE)
                return true
            }
        }
        if (keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9) {
            ChannelHolder.digit(keyCode - KeyEvent.KEYCODE_0) { pos -> playAt(pos) }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        clockR?.let { h.removeCallbacks(it) }
        player?.release()
        player = null
        super.onDestroy()
    }
}
