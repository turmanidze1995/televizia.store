package store.televizia.app

import android.animation.ValueAnimator
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * სრული ეკრანის ფლეიერი. პულტის ღილაკები:
 *  CH+/CH− და PAGE, ციფრები 0–9, LAST → წინა არხი, MENU/RED → არხები,
 *  GUIDE/GREEN → პროგრამა (EPG), INFO/YELLOW → ინფო, BLUE → პანელების დახურვა,
 *  ◀◀ / ▶▶ → −10 / +10 წამი, ⏯ (PLAY/PAUSE) → პაუზა, STOP → გასვლა, MUTE → ხმა,
 *  BACK/EXIT → პანელი ან გასვლა, OK → პაუზა (თუ ღილაკი არ არის ფოკუსში).
 */
class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private var clockR: Runnable? = null
    private var lastIndex = -1
    private val hideInfo = Runnable { infoBar.visibility = View.INVISIBLE }

    private lateinit var infoBar: View
    private lateinit var loadingLogo: ImageView
    private lateinit var playerError: TextView
    private var loadAnim: ValueAnimator? = null
    private val autoSkip = Runnable { step(1) }
    private lateinit var channelsWrap: View
    private lateinit var programsWrap: View
    private lateinit var drawer: RecyclerView
    private lateinit var programList: RecyclerView
    private lateinit var chNum: TextView
    private lateinit var chName: TextView
    private lateinit var chNow: TextView
    private lateinit var chLogo: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var drawerAdapter: ChannelAdapter
    private val programAdapter = ProgramAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        val url = intent.getStringExtra("url") ?: run { finish(); return }

        infoBar = findViewById(R.id.infoBar)
        loadingLogo = findViewById(R.id.loadingLogo)
        playerError = findViewById(R.id.playerError)
        channelsWrap = findViewById(R.id.channelsWrap)
        programsWrap = findViewById(R.id.programsWrap)
        drawer = findViewById(R.id.drawer)
        programList = findViewById(R.id.programList)
        chNum = findViewById(R.id.chNum)
        chName = findViewById(R.id.chName)
        chNow = findViewById(R.id.chNow)
        chLogo = findViewById(R.id.chLogo)
        progress = findViewById(R.id.progress)

        drawerAdapter = ChannelAdapter { _, pos ->
            playAt(pos)
            showPanel(null)
        }
        drawer.layoutManager = LinearLayoutManager(this)
        drawer.adapter = drawerAdapter
        drawerAdapter.submit(ChannelHolder.list)
        programList.layoutManager = LinearLayoutManager(this)
        programList.adapter = programAdapter

        val pv = findViewById<PlayerView>(R.id.playerView)
        val mediaSourceFactory = DefaultMediaSourceFactory(this)
        player = ExoPlayer.Builder(this).setMediaSourceFactory(mediaSourceFactory).build().also { p ->
            pv.player = p
            p.volume = 1f
            p.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        Player.STATE_READY -> {
                            stopLoadAnim()
                            playerError.visibility = View.GONE
                            h.removeCallbacks(autoSkip)
                        }
                        Player.STATE_BUFFERING -> startLoadAnim()
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    stopLoadAnim()
                    playerError.text = "არხი დროებით გამორთულია\nმე-2 წამში შემდეგ არხზე გადავალ"
                    playerError.visibility = View.VISIBLE
                    h.removeCallbacks(autoSkip)
                    h.postDelayed(autoSkip, 2000)
                }
            })
        }

        val idx = ChannelHolder.index
        if (idx in ChannelHolder.list.indices) playAt(idx) else playUrl(url)
        clockR = Ui.startClock(findViewById<TextView>(R.id.clock), h) { showInfo() }
    }

    private fun playAt(pos: Int) {
        flashInfo()
        val list = ChannelHolder.list
        if (pos !in list.indices) return
        if (ChannelHolder.index != pos && ChannelHolder.index >= 0) lastIndex = ChannelHolder.index
        ChannelHolder.index = pos
        val ch = list[pos]
        playUrl(ch.url)
        drawerAdapter.select(ch.url)
        programAdapter.submit(Epg.upcoming(ch.epgId, 30))
        showInfo()
    }

    private fun playUrl(url: String) {
        playerError.visibility = View.GONE
        startLoadAnim()
        val builder = MediaItem.Builder().setUri(url)
        val lower = url.lowercase()
        when {
            lower.contains(".m3u8") -> builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            lower.contains(".ts") -> builder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        player?.apply {
            setMediaItem(builder.build())
            prepare()
            playWhenReady = true
        }
    }

    /** ჩატვირთვისას: TELEVIZIA.STORE ლოგო ფერებში ციმციმებს (ფერის ციკლი + ნათება) */
    private fun startLoadAnim() {
        loadingLogo.visibility = View.VISIBLE
        if (loadAnim != null) return
        loadAnim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { va ->
                val d = va.animatedValue as Float
                val cm = ColorMatrix()
                cm.setRotate(0, d)
                cm.setRotate(1, d * 0.6f)
                cm.setRotate(2, d * 0.3f)
                loadingLogo.colorFilter = ColorMatrixColorFilter(cm)
                loadingLogo.alpha = 0.55f + 0.45f * Math.abs(Math.sin(Math.toRadians(d.toDouble()))).toFloat()
            }
            start()
        }
    }

    private fun stopLoadAnim() {
        loadAnim?.cancel()
        loadAnim = null
        loadingLogo.colorFilter = null
        loadingLogo.alpha = 1f
        loadingLogo.visibility = View.GONE
    }

    private fun step(delta: Int) {
        val n = ChannelHolder.list.size
        if (n == 0) return
        playAt(Math.floorMod(ChannelHolder.index + delta, n))
    }

    private fun togglePlay() {
        player?.let { it.playWhenReady = !it.playWhenReady }
    }

    private fun toggleMute() {
        player?.let { it.volume = if (it.volume == 0f) 1f else 0f }
    }

    /** ლაივ ნაკადზე გადახვევა მხოლოდ DVR/არქივის ნაკადზე მუშაობს */
    private fun seekBy(ms: Long) {
        player?.let { it.seekTo(maxOf(0L, it.currentPosition + ms)) }
    }

    private fun showPanel(panel: View?) {
        channelsWrap.visibility = if (panel === channelsWrap) View.VISIBLE else View.GONE
        programsWrap.visibility = if (panel === programsWrap) View.VISIBLE else View.GONE
        if (panel === channelsWrap) {
            drawerAdapter.select(ChannelHolder.list.getOrNull(ChannelHolder.index)?.url ?: "")
            drawer.scrollToPosition(ChannelHolder.index.coerceAtLeast(0))
        }
    }

    private fun togglePanel(panel: View) {
        showPanel(if (panel.visibility == View.VISIBLE) null else panel)
    }

    private fun anyPanelVisible() =
        channelsWrap.visibility == View.VISIBLE || programsWrap.visibility == View.VISIBLE

    private fun flashInfo() {
        infoBar.visibility = View.VISIBLE
        h.removeCallbacks(hideInfo)
        h.postDelayed(hideInfo, 6000)
    }

    private fun showInfo() {
        val ch = ChannelHolder.list.getOrNull(ChannelHolder.index) ?: return
        chNum.text = (ChannelHolder.index + 1).toString()
        chName.text = ch.name
        ImageLoader.show(ch.logo, chLogo)
        val now = Epg.now(ch.epgId)
        val next = now?.let { n -> Epg.upcoming(ch.epgId, 6).firstOrNull { it.start >= n.stop } }
        chNow.text = when {
            now == null -> ""
            next == null -> "${Ui.timeOf(now.start)}  ${now.title}"
            else -> "${Ui.timeOf(now.start)}  ${now.title}  →  ${Ui.timeOf(next.start)}  ${next.title}"
        }
        progress.progress = Ui.progressOf(now)
        if (infoBar.visibility != View.VISIBLE) flashInfo()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val handled = when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                step(1); true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                step(-1); true
            }
            KeyEvent.KEYCODE_LAST_CHANNEL -> {
                if (lastIndex >= 0) playAt(lastIndex)
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                togglePlay(); true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                seekBy(-10_000); true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                seekBy(10_000); true
            }
            KeyEvent.KEYCODE_MEDIA_STOP -> {
                finish(); true
            }
            KeyEvent.KEYCODE_MUTE -> {
                toggleMute(); true
            }
            KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_PROG_YELLOW -> {
                if (infoBar.visibility == View.VISIBLE) infoBar.visibility = View.INVISIBLE else flashInfo()
                true
            }
            KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_PROG_GREEN -> {
                togglePanel(programsWrap); true
            }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_PROG_RED -> {
                togglePanel(channelsWrap); true
            }
            KeyEvent.KEYCODE_PROG_BLUE -> {
                showPanel(null); true
            }
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                if (anyPanelVisible()) showPanel(null) else finish()
                true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                togglePanel(channelsWrap); true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (anyPanelVisible()) false else { seekBy(-10_000); true }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (anyPanelVisible()) false else { seekBy(10_000); true }
            }
            else -> {
                if (keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9) {
                    ChannelHolder.digit(keyCode - KeyEvent.KEYCODE_0) { pos -> playAt(pos) }
                    true
                } else false
            }
        }
        return handled || super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        stopLoadAnim()
        h.removeCallbacks(autoSkip)
        clockR?.let { h.removeCallbacks(it) }
        player?.release()
        player = null
        super.onDestroy()
    }
}
