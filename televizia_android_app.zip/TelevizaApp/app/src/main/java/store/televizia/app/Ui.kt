package store.televizia.app

import android.os.Handler
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Ui {
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun timeOf(ms: Long): String = fmt.format(Date(ms))

    /** პროგრამის პროგრესი პროცენტებში (0..100) */
    fun progressOf(p: Program?): Int {
        if (p == null || p.stop <= p.start) return 0
        val t = System.currentTimeMillis()
        return (((t - p.start) * 100) / (p.stop - p.start)).toInt().coerceIn(0, 100)
    }

    /** საათი ეკრანის მარჯვენა ზედა კუთხეში; tick ყოველ 10 წამში */
    fun startClock(tv: TextView, h: Handler, tick: () -> Unit = {}): Runnable {
        val r = object : Runnable {
            override fun run() {
                tv.text = fmt.format(Date())
                tick()
                h.postDelayed(this, 10_000)
            }
        }
        h.post(r)
        return r
    }
}
