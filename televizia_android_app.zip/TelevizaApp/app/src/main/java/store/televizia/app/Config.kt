package store.televizia.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

const val BASE_URL = "https://televizia.store"

/** შესვლის მდგომარეობა (ტოკენი SharedPreferences-ში) */
object Session {
    private const val PREFS = "tv_session"

    fun save(ctx: Context, token: String, name: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("token", token).putString("name", name).apply()
    }

    fun token(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("token", null)

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}

/** სერვერთან კავშირი (HttpURLConnection, ფონურ ნაკადში გამოიძახება) */
object Api {
    class LoginResult(val ok: Boolean, val message: String, val token: String? = null, val name: String = "")
    class PlaylistResult(val ok: Boolean, val message: String, val body: String = "")

    fun login(email: String, password: String): LoginResult = try {
        val body = "email=" + URLEncoder.encode(email, "UTF-8") +
                "&password=" + URLEncoder.encode(password, "UTF-8")
        val conn = (URL("$BASE_URL/api/app.php?action=login").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        }
        conn.outputStream.use { it.write(body.toByteArray()) }
        val text = readAll(conn)
        val j = JSONObject(text)
        if (j.optBoolean("ok")) LoginResult(true, "", j.getString("token"), j.optString("name"))
        else LoginResult(false, loginError(j.optString("error")))
    } catch (e: Exception) {
        LoginResult(false, "კავშირის შეცდომა. შეამოწმეთ ინტერნეტი.")
    }

    /** მომხმარებლის არხების სია (M3U) */
    fun playlist(token: String): PlaylistResult = try {
        val url = "$BASE_URL/playlist/m3u.php?token=" + URLEncoder.encode(token, "UTF-8")
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
        }
        val text = readAll(conn)
        if (conn.responseCode in 200..299) PlaylistResult(true, "", text)
        else PlaylistResult(false, text.ifBlank { "პაკეტი არ არის აქტიური" })
    } catch (e: Exception) {
        PlaylistResult(false, "კავშირის შეცდომა. შეამოწმეთ ინტერნეტი.")
    }

    private fun readAll(conn: HttpURLConnection): String {
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        return stream?.bufferedReader()?.use { it.readText() } ?: ""
    }

    private fun loginError(code: String): String = when (code) {
        "bad_credentials" -> "ელ-ფოსტა ან პაროლი არასწორია."
        "no_active_package" -> "აქტიური პაკეტი არ გაქვთ."
        "no_token" -> "ანგარიში ვერ გააქტიურდა. დაუკავშირდით ადმინისტრაციას."
        else -> "შესვლა ვერ მოხერხდა."
    }
}

/** XMLTV პროგრამის სია (EPG). ჩასვით თქვენი პროვაიდერის XMLTV ლინკი. ცარიელი = პროგრამა არ ჩანს. */
const val EPG_URL = ""
