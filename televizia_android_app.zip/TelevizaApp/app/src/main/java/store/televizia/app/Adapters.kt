package store.televizia.app

import android.graphics.Color
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import store.televizia.app.databinding.ItemChannelBinding

/** არხების სია: ნომერი, ლოგო, სახელი, ამჟამინდელი გადაცემა */
class ChannelAdapter(private val onClick: (Channel, Int) -> Unit) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    private var items: List<Channel> = emptyList()
    private var selectedUrl: String? = null

    class VH(val b: ItemChannelBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(list: List<Channel>) {
        items = list
        notifyDataSetChanged()
    }

    fun select(url: String) {
        selectedUrl = url
        notifyDataSetChanged()
    }

    fun refresh() = notifyDataSetChanged()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemChannelBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val ch = items[position]
        h.b.num.text = (position + 1).toString()
        h.b.name.text = ch.name
        h.b.now.text = Epg.now(ch.epgId)?.let { "${Ui.timeOf(it.start)}  ${it.title}" } ?: ""
        ImageLoader.show(ch.logo, h.b.logo)
        h.b.root.isSelected = ch.url == selectedUrl
        h.b.root.setOnClickListener { onClick(ch, position) }
    }
}

/** კატეგორიების ღილაკები */
class GroupAdapter(private val onClick: (String) -> Unit) : RecyclerView.Adapter<GroupAdapter.VH>() {
    private var items: List<String> = emptyList()
    private var selected: String = ""

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    fun submit(list: List<String>, sel: String) {
        items = list
        selected = sel
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val tv = TextView(parent.context).apply {
            setPadding(36, 18, 36, 18)
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.item_bg)
            isFocusable = true
            isClickable = true
            layoutParams = ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 16, 0) }
        }
        return VH(tv)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val g = items[position]
        h.tv.text = g
        h.tv.isSelected = g == selected
        h.tv.setOnClickListener { onClick(g) }
    }
}

/** პროგრამის სია (EPG) — დრო და სათაური */
class ProgramAdapter : RecyclerView.Adapter<ProgramAdapter.VH>() {
    private var items: List<Program> = emptyList()

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    fun submit(list: List<Program>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val tv = TextView(parent.context).apply {
            setPadding(24, 16, 24, 16)
            setTextColor(Color.WHITE)
            textSize = 15f
            setBackgroundResource(R.drawable.item_bg)
            isFocusable = true
            layoutParams = ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, 8) }
        }
        return VH(tv)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = items[position]
        h.tv.text = "${Ui.timeOf(p.start)}   ${p.title}"
    }
}
