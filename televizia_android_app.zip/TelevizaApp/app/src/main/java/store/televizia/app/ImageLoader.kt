package store.televizia.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * არხის ლოგოების ჩამტვირთავი:
 *  - გადამისამართებებს (http <-> https) ხელით მიჰყვება, აქვს User-Agent
 *  - http ვერ გაიხსნა -> ვცდით https-ით (და პირიქით)
 *  - მეხსიერების + დისკის ქეში (მეორედ ჩატვირთვა მყისიერია)
 *  - სწრაფი გადახვევისას მოთხოვნები არ იკარგება: რიგი შეუზღუდავია, მაგრამ უკვე გადახვეული
 *    (სხვა ლოგოზე გადართული) ელემენტის მოთხოვნა ქსელში აღარ გადის; ახალი მოთხოვნები პირველია
 *  - წარუმატებელი ლოგო არ იბლოკება სამუდამოდ — 2 წუთის შემდეგ თავიდან ვცდილობთ
 *  - ლოგო რომ არ არის ან ვერ ჩაიტვირთა, ჩანს არხის პირველი ასოები
 */
object ImageLoader {
    private const val RETRY_AFTER_MS = 120_000L

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val failed = HashMap<String, Long>()
    private val pool = ThreadPoolExecutor(
        8, 8, 30, TimeUnit.SECONDS,
        object : LinkedBlockingDeque<Runnable>() {
            // ახალი (ეკრანზე ახლა ხილული) ლოგოები წინ მიდის
            override fun offer(e: Runnable): Boolean = offerFirst(e)
        }
    )
    private val main = Handler(Looper.getMainLooper())
    private var dir: File? = null
    private val dirReady = AtomicBoolean(false)

    fun show(rawUrl: String, view: ImageView, name: String = "") {
        val url = normalize(rawUrl)
        view.tag = url
        view.setImageDrawable(InitialsDrawable(name))
        if (url.isBlank()) return
        cache.get(url)?.let { view.setImageBitmap(it); return }
        val lastFail = synchronized(failed) { failed[url] }
        if (lastFail != null && System.currentTimeMillis() - lastFail < RETRY_AFTER_MS) return
        val ctx = view.context.applicationContext
        pool.execute {
            // ამ ელემენტს უკვე სხვა ლოგო აქვს (გადაახვიეს) — ტყუილად არ ვტვირთავთ
            if (view.tag != url) return@execute
            if (dirReady.compareAndSet(false, true)) {
                dir = File(ctx.cacheDir, "logos").also { it.mkdirs() }
            }
            val bmp = cache.get(url) ?: fromDisk(url) ?: downloadAny(url)
            if (bmp != null) {
                cache.put(url, bmp)
                synchronized(failed) { failed.remove(url) }
            } else {
                synchronized(failed) { failed[url] = System.currentTimeMillis() }
            }
            main.post { if (view.tag == url && bmp != null) view.setImageBitmap(bmp) }
        }
    }

    private fun normalize(raw: String): String {
        var u = raw.trim().replace(" ", "%20")
        if (u.isEmpty()) return ""
        if (u.startsWith("//")) u = "https:$u"
        else if (u.startsWith("/")) u = BASE_URL + u
        else if (!u.startsWith("http://") && !u.startsWith("https://")) return ""
        return u
    }

    private fun key(url: String): String =
        MessageDigest.getInstance("MD5").digest(url.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun fromDisk(url: String): Bitmap? = try {
        val f = File(dir, key(url))
        if (f.exists() && f.length() > 0) decode(f.readBytes()) else null
    } catch (e: Exception) {
        null
    }

    /** ორიგინალი ბმული; თუ ვერ ჩაიტვირთა — იგივე ბმული მეორე პროტოკოლით (http <-> https) */
    private fun downloadAny(url: String): Bitmap? {
        download(url, url)?.let { return it }
        val alt = when {
            url.startsWith("http://") -> "https://" + url.removePrefix("http://")
            url.startsWith("https://") -> "http://" + url.removePrefix("https://")
            else -> return null
        }
        return download(alt, url)
    }

    /** start — საიდან ვტვირთავთ; cacheKeyUrl — რა ბმულით ვინახავთ დისკზე */
    private fun download(start: String, cacheKeyUrl: String): Bitmap? {
        var url = start
        try {
            for (hop in 0..6) {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 12000
                c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/110 Mobile Safari/537.36")
                c.setRequestProperty("Accept", "image/png,image/jpeg,image/webp,image/*;q=0.8,*/*;q=0.5")
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location")
                    c.disconnect()
                    if (loc == null) return null
                    url = URL(URL(url), loc).toString()
                    continue
                }
                if (code !in 200..299) {
                    c.disconnect()
                    return null
                }
                val bytes = c.inputStream.use { it.readBytes() }
                c.disconnect()
                if (bytes.isEmpty() || bytes.size > 8_000_000) return null
                val bmp = decode(bytes) ?: return null
                try { File(dir, key(cacheKeyUrl)).writeBytes(bytes) } catch (e: Exception) { }
                return bmp
            }
        } catch (e: Exception) {
        }
        return null
    }

    /** დიდ სურათს ვამცირებთ (სიის ლოგოსთვის 200px საკმარისია) */
    private fun decode(bytes: ByteArray): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var sample = 1
        while (o.outWidth / (sample * 2) >= 200 && o.outHeight / (sample * 2) >= 200) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }
}

/** ლოგოს ნაცვლად: მომრგვალებული ბარათი არხის პირველი ასოებით */
class InitialsDrawable(name: String) : Drawable() {
    private val text: String = name.trim()
        .split(" ", ":", "-", "_")
        .filter { it.isNotBlank() }
        .let { parts ->
            val useful = parts.filter { it.uppercase() != "GE" && it.uppercase() != "HD" }.ifEmpty { parts }
            useful.take(2).joinToString("") { it.take(1) }.uppercase()
        }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#24305E") }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00D9C0")
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    override fun draw(c: Canvas) {
        val r = bounds
        if (r.isEmpty) return
        c.drawRoundRect(RectF(r), r.height() / 4f, r.height() / 4f, bg)
        fg.textSize = r.height() * 0.45f
        val y = r.exactCenterY() - (fg.descent() + fg.ascent()) / 2
        c.drawText(text, r.exactCenterX(), y, fg)
    }

    override fun setAlpha(alpha: Int) { bg.alpha = alpha; fg.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
