package store.televizia.app

data class Channel(val name: String, val logo: String, val url: String)

/** M3U სიის წამკითხველი (#EXTINF + URL) */
object M3u {
    private val logoRegex = Regex("tvg-logo=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = ""
        var logo = ""
        text.lines().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> {
                    name = line.substringAfterLast(',').trim()
                    logo = logoRegex.find(line)?.groupValues?.get(1) ?: ""
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    out.add(Channel(name.ifEmpty { "არხი" }, logo, line))
                    name = ""
                    logo = ""
                }
            }
        }
        return out
    }
}
