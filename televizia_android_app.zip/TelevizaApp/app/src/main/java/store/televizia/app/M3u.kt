package store.televizia.app

data class Channel(val name: String, val logo: String, val url: String, val group: String, val epgId: String = "")

/** M3U სიის წამკითხველი: სახელი, ლოგო, ჯგუფი (group-title) და სტრიმის ლინკი */
object M3u {
    private val logoRegex = Regex("tvg-logo=\"([^\"]*)\"")
    private val groupRegex = Regex("group-title=\"([^\"]*)\"")
    private val idRegex = Regex("tvg-id=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = ""
        var logo = ""
        var group = ""
        var epgId = ""
        text.lines().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> {
                    name = line.substringAfterLast(',').trim()
                    logo = logoRegex.find(line)?.groupValues?.get(1) ?: ""
                    group = groupRegex.find(line)?.groupValues?.get(1) ?: ""
                    epgId = idRegex.find(line)?.groupValues?.get(1) ?: ""
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    out.add(Channel(name.ifEmpty { "არხი" }, logo, line, group.ifBlank { "სხვა" }, epgId))
                    name = ""; logo = ""; group = ""; epgId = ""
                }
            }
        }
        return out
    }
}
