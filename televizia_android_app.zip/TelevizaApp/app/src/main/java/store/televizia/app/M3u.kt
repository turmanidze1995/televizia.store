package store.televizia.app

data class Channel(val name: String, val logo: String, val url: String, val group: String, val epgId: String = "")

/** M3U სიის წამკითხველი: სახელი, ლოგო, ჯგუფი (group-title) და სტრიმის ლინკი */
object M3u {
    private val logoRegex = Regex("""tvg-logo\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val groupRegex = Regex("""group-title\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val idRegex = Regex("""tvg-id\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
    private val tvgNameRegex = Regex("""tvg-name\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)

    fun parse(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = ""
        var logo = ""
        var group = ""
        var epgId = ""
        text.lines().forEach { raw ->
            val line = raw.trim().removePrefix("\uFEFF")
            when {
                line.startsWith("#EXTINF") -> {
                    name = if (line.contains(',')) line.substringAfterLast(',').trim() else ""
                    if (name.isEmpty()) name = tvgNameRegex.find(line)?.groupValues?.get(1)?.trim() ?: ""
                    logo = logoRegex.find(line)?.groupValues?.get(1) ?: ""
                    group = groupRegex.find(line)?.groupValues?.get(1) ?: ""
                    epgId = idRegex.find(line)?.groupValues?.get(1) ?: ""
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    out.add(Channel(name.ifEmpty { "არხი" }, logo, line, group.ifBlank { "სხვა" }, epgId))
                    name = ""; logo = ""; group = ""; epgId = ""
                }
            }
        }
        return out
    }
}
