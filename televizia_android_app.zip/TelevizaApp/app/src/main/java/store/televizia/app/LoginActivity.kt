package store.televizia.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import store.televizia.app.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var b: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.token(this) != null) {
            openMain()
            return
        }
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnLogin.setOnClickListener { doLogin() }
    }

    private fun doLogin() {
        val email = b.email.text.toString().trim()
        val password = b.password.text.toString()
        if (email.isEmpty() || password.isEmpty()) {
            b.status.text = "შეავსეთ ყველა ველი"
            return
        }
        b.btnLogin.isEnabled = false
        b.status.text = "შემოწმება…"
        Thread {
            val res = Api.login(email, password)
            runOnUiThread {
                b.btnLogin.isEnabled = true
                if (res.ok && res.token != null) {
                    Session.save(this, res.token, res.name)
                    openMain()
                } else {
                    b.status.text = res.message
                }
            }
        }.start()
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
