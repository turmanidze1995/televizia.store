package store.televizia.app

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.BarcodeFormat
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import store.televizia.app.databinding.ActivityLoginBinding

/**
 * შესვლის სამი გზა:
 *  1) ელფოსტა + პაროლი
 *  2) QR სკანირება ტელეფონით (კაბინეტის QR-დან)
 *  3) TV კოდი: TV აჩვენებს QR-ს და კოდს, ტელეფონით დადასტურება საიტზე
 */
class LoginActivity : AppCompatActivity() {
    private lateinit var b: ActivityLoginBinding
    private val h = Handler(Looper.getMainLooper())
    private var pollR: Runnable? = null

    private val scanner = registerForActivityResult(ScanContract()) { result ->
        val raw = result.contents ?: return@registerForActivityResult
        val code = Uri.parse(raw).getQueryParameter("code") ?: raw.trim()
        claimCode(code)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.token(this) != null) {
            openMain()
            return
        }
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)

        val hasCamera = packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
        b.btnScan.visibility = if (hasCamera) View.VISIBLE else View.GONE

        b.btnLogin.setOnClickListener { doLogin() }
        b.btnScan.setOnClickListener {
            scanner.launch(
                ScanOptions()
                    .setPrompt("დაასკანერეთ QR კოდი საიტის კაბინეტიდან")
                    .setBeepEnabled(false)
                    .setOrientationLocked(false)
            )
        }
        b.btnTv.setOnClickListener { startTvPairing() }
    }

    override fun onDestroy() {
        stopPolling()
        super.onDestroy()
    }

    private fun doLogin() {
        val email = b.email.text.toString().trim()
        val password = b.password.text.toString()
        if (email.isEmpty() || password.isEmpty()) {
            b.status.text = "შეავსეთ ყველა ველი"
            return
        }
        b.btnLogin.isEnabled = false
        b.status.text = "შემოწმება…"
        Thread {
            val res = Api.login(email, password)
            runOnUiThread {
                b.btnLogin.isEnabled = true
                if (res.ok && res.token != null) {
                    Session.save(this, res.token, res.name)
                    openMain()
                } else {
                    b.status.text = res.message
                }
            }
        }.start()
    }

    private fun claimCode(code: String) {
        b.status.text = "შემოწმება…"
        Thread {
            val res = PairApi.check(code)
            runOnUiThread {
                if (res.state == PairState.OK && res.token != null) {
                    Session.save(this, res.token, res.name)
                    openMain()
                } else {
                    b.status.text = res.message.ifEmpty { "კოდი ვერ დადასტურდა" }
                }
            }
        }.start()
    }

    private fun startTvPairing() {
        stopPolling()
        b.tvPanel.visibility = View.VISIBLE
        b.tvStatus.text = "კოდი მზადდება…"
        Thread {
            val start = PairApi.start()
            runOnUiThread {
                if (!start.ok) {
                    b.tvStatus.text = start.message
                    return@runOnUiThread
                }
                try {
                    val url = "$BASE_URL/public/pair.php?code=${start.code}"
                    b.qrImage.setImageBitmap(BarcodeEncoder().encodeBitmap(url, BarcodeFormat.QR_CODE, 520, 520))
                } catch (e: Exception) {
                    b.tvStatus.text = "QR ვერ შეიქმნა"
                    return@runOnUiThread
                }
                b.tvCode.text = start.code.chunked(4).joinToString("-")
                b.tvStatus.text = "დაასკანერეთ QR ტელეფონით და დაადასტურეთ საიტზე…"
                startPolling(start.code)
            }
        }.start()
    }

    private fun startPolling(code: String) {
        stopPolling()
        pollR = Runnable {
            Thread {
                val res = PairApi.check(code)
                runOnUiThread {
                    when (res.state) {
                        PairState.OK -> {
                            stopPolling()
                            Session.save(this, res.token!!, res.name)
                            openMain()
                        }
                        PairState.PENDING -> pollR?.let { h.postDelayed(it, 3000) }
                        PairState.ERROR -> {
                            stopPolling()
                            b.tvStatus.text = res.message
                        }
                    }
                }
            }.start()
        }
        pollR?.let { h.post(it) }
    }

    private fun stopPolling() {
        pollR?.let { h.removeCallbacks(it) }
        pollR = null
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
