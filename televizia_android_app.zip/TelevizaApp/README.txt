TELEVIZIA.STORE — ანდროიდ აპლიკაცია (ტელეფონი და Android TV / Smart TV)

აწყობა:
1. Android Studio-ში: File > Open > ეს საქაღალდე (TelevizaApp).
2. Android Studio თავისით ჩამოტვირთავს Gradle-ს და SDK-ს.
3. Build > Build APK(s)  (debug APK: app/build/outputs/apk/debug/app-debug.apk)
4. ტელეფონზე: APK დააინსტალირეთ (უცნობი წყაროდან ინსტალაცია უნდა ჩართოთ).
5. Android TV-ზე: APK შეიძლება USB-ით, ან "Downloader"-ით, ან ADB-ით დააინსტალიროთ.

ავტორიზაცია: მომხმარებელი შედის თავისი ელ-ფოსტით და პაროლით (იგივე, რაც საიტზე).
სერვერის endpoint: /api/app.php?action=login
არხები: /playlist/m3u.php?token=... (უკვე ამოწმებს გამოწერის ვადას)

შენიშვნა: BASE_URL კონფიგურაციაა Config.kt-ში.
