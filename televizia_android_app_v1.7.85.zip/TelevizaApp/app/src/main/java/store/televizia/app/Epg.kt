package store.televizia.app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

data class Program(val start: Long, val stop: Long, val title: String)

/**
 * XMLTV ტელეპროგრამა (EPG) — მონაცემები ინახება დისკზე, SQLite ბაზაში (epg.db), და არა მეხსიერებაში.
 *  - ჩამოტვირთვა/დამუშავება ფონურად, ნაკადით (XML სრულად არასდროს იტვირთება RAM-ში), პატარა პორციებით ბაზაში;
 *    ახალი ბაზა ცალკე ფაილში შენდება და მზად რომ იქნება, ერთბაშად ანაცვლებს ძველს — არხების ყურება/სია არ ფერხდება
 *  - ბმული: ფლეილისტის url-tvg + საიტის საერთო EPG (თუ არცერთი არ არის — ჩაშენებული სარეზერვო წყაროები)
 *  - .xml და .xml.gz ორივე იკითხება; რედირექტებს (http<->https) მიჰყვება
 *  - არხი უკავშირდება tvg-id-ით, ხოლო თუ ის არ ემთხვევა — არხის სახელით (display-name)
 *  - ინახება [ახლა-12სთ .. ახლა+30სთ], მხოლოდ ფლეილისტის არხებზე; მეორე გახსნისას მყისიერია (ბაზა უკვე მზადაა)
 */
object Epg {
    private const val DB_FILE = "epg.db"
    private const val DB_NEW = "epg_new.db"
    private const val SCHEMA = 2
    private const val FRESH_MS = 3 * 3600_000L
    private const val FRESH_METERED_MS = 12 * 3600_000L
    private const val PAST_MS = 12 * 3600_000L
    private const val FUTURE_MS = 30 * 3600_000L
    private const val BATCH = 1500
    /** თუ არც ფლეილისტს, არც საიტს EPG არ აქვს — ამ წყაროებიდან ვცდით (უფასო, საჯარო XMLTV) */
    private val FALLBACK = listOf("https://iptvx.one/EPG", "http://epg.it999.ru/epg.xml.gz")
    private val RE_PREFIX = Regex("^\\s*[A-Za-z]{2,3}\\s*[:|\\-]\\s*")
    private val RE_PAREN = Regex("[\\(\\[][^\\)\\]]*[\\)\\]]")

    @Volatile private var db: SQLiteDatabase? = null
    @Volatile private var keys: Set<String> = emptySet()
    @Volatile private var names: Map<String, String> = emptyMap()
    private val cache = HashMap<String, Triple<Long, Program?, Program?>>()   // არხი -> (სანამ მოქმედებს, ახლა, შემდეგი)

    val hasData: Boolean get() = keys.isNotEmpty()

    /** EPG-ის მდგომარეობა ეკრანზე ჩასაწერად (რატომ არ ჩანს ტელეპროგრამა): იტვირთება / მზადაა / შეცდომა */
    @Volatile var status: String = ""


    /** მობილურ ინტერნეტზე (ტრაფიკი/ბატარეა) დიდ EPG-ს იშვიათად ვანახლებთ: 12 საათში ერთხელ; Wi‑Fi-ზე — 3 საათში */
    private fun freshMsFor(ctx: Context): Long = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        if (cm.isActiveNetworkMetered) FRESH_METERED_MS else FRESH_MS
    } catch (e: Exception) { FRESH_MS }

    private fun openDb(f: File): SQLiteDatabase? = try {
        SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY or SQLiteDatabase.NO_LOCALIZED_COLLATORS)
    } catch (e: Exception) { null }

    private fun meta(d: SQLiteDatabase, k: String): String? = try {
        d.rawQuery("SELECT v FROM meta WHERE k = ?", arrayOf(k)).use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) { null }

    /** ძველი RAM-ქეშის ფაილი (წინა ვერსიებიდან) — წაიშლება */
    private fun cleanupOld(ctx: Context) { try { File(ctx.filesDir, "epg_cache.bin").delete() } catch (e: Exception) {} }

    /** true = მონაცემები მზადაა (ბაზიდან ან ახლახან ჩამოტვირთული) */
    fun load(ctx: Context, playlistUrls: List<String>, channels: List<Channel>, beforeNetwork: () -> Unit = {}): Boolean {
        cleanupOld(ctx)
        var urls = (playlistUrls + listOf(RemoteConfig.epgUrl())).map { it.trim() }.filter { it.startsWith("http") }
            .groupBy { it.substringAfter("://").lowercase() }.map { g -> g.value.firstOrNull { it.startsWith("https", true) } ?: g.value.first() }
        if (urls.isEmpty()) urls = FALLBACK   // „თვითონ ეძებს“: ფლეილისტს EPG არ აქვს — სარეზერვო წყაროები
        val hash = (urls.joinToString("|") + "#" + channels.size).hashCode().toString()
        val file = File(ctx.filesDir, DB_FILE)

        // 1) უკვე მზა ბაზა (ახალია და იგივე წყაროებისთვის) — მყისიერად
        val cur = openDb(file)
        if (cur != null) {
            val ok = meta(cur, "schema") == SCHEMA.toString() && meta(cur, "hash") == hash
            val saved = meta(cur, "saved")?.toLongOrNull() ?: 0L
            if (ok && System.currentTimeMillis() - saved < freshMsFor(ctx)) { activate(cur); attach(channels); return true }
            cur.close()
        }

        // 2) ახალი ბაზის აგება ცალკე ფაილში
        status = "ტელეპროგრამა იტვირთება"
        try { beforeNetwork() } catch (e: Exception) {}
        val wantIds = HashSet<String>()
        val wantNames = HashSet<String>()
        for (c in channels) {
            if (c.epgId.isNotBlank()) { wantIds.add(c.epgId.lowercase()); wantNames.add(norm(c.epgId)) }
            for (v in nameVariants(c.name)) wantNames.add(v)
        }
        val nf = File(ctx.filesDir, DB_NEW)
        nf.delete(); File(nf.path + "-journal").delete()
        var w: SQLiteDatabase? = null
        var built = false
        try {
            val wd = SQLiteDatabase.openOrCreateDatabase(nf, null)
            w = wd
            // PRAGMA-ები ანდროიდზე მნიშვნელობას აბრუნებს — execSQL-ით ზოგ ვერსიაზე შეცდომას იძლევა; ამიტომ rawQuery და უსაფრთხო try
            try { wd.rawQuery("PRAGMA journal_mode = OFF", null).use { it.moveToFirst() } } catch (e: Exception) {}
            try { wd.rawQuery("PRAGMA synchronous = OFF", null).use { it.moveToFirst() } } catch (e: Exception) {}
            wd.execSQL("CREATE TABLE prog (ch TEXT NOT NULL, st INTEGER NOT NULL, en INTEGER NOT NULL, title TEXT NOT NULL, PRIMARY KEY (ch, st, title)) WITHOUT ROWID")
            wd.execSQL("CREATE TABLE nm (n TEXT PRIMARY KEY, ch TEXT NOT NULL) WITHOUT ROWID")
            wd.execSQL("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
            val now = System.currentTimeMillis()
            var any = false
            for (u in urls) {
                try { open(u).use { parseInto(it, wd, now, wantIds, wantNames) }; any = true } catch (e: Exception) { android.util.Log.w("Epg", "source failed: " + u + " -> " + e) }
            }
            val cnt = wd.rawQuery("SELECT COUNT(*) FROM prog", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
            if (any && cnt > 0) {
                wd.execSQL("INSERT OR REPLACE INTO meta VALUES ('schema', '$SCHEMA')")
                wd.execSQL("INSERT OR REPLACE INTO meta VALUES ('hash', '$hash')")
                wd.execSQL("INSERT OR REPLACE INTO meta VALUES ('saved', '${System.currentTimeMillis()}')")
                built = true
            } else status = "ტელეპროგრამა ვერ ჩამოიტვირთა"
        } catch (e: Exception) {
            android.util.Log.w("Epg", "build failed", e)
            status = "ტელეპროგრამა ვერ ჩამოიტვირთა"
        } finally { try { w?.close() } catch (e: Exception) {} }

        if (built) {
            // ძველი ბაზა ერთბაშად იცვლება ახლით
            val old = db
            file.delete(); File(file.path + "-journal").delete()
            if (nf.renameTo(file)) {
                val nd = openDb(file)
                if (nd != null) { activate(nd); try { old?.close() } catch (e: Exception) {}; attach(channels); return true }
            }
        } else { nf.delete() }
        // ქსელი ვერ მუშაობს — ძველი ბაზა (თუ არის) სჯობს არაფერს
        val stale = openDb(file)
        if (stale != null && meta(stale, "schema") == SCHEMA.toString()) { activate(stale); attach(channels); return true }
        try { stale?.close() } catch (e: Exception) {}
        return false
    }

    /** ბაზას აქტიურად ვხდით; არხების გასაღებებსა და სახელებს (პატარაა) მეხსიერებაში ვტვირთავთ */
    private fun activate(d: SQLiteDatabase) {
        val k = HashSet<String>()
        val n = HashMap<String, String>()
        try { d.rawQuery("SELECT DISTINCT ch FROM prog", null).use { while (it.moveToNext()) k.add(it.getString(0)) } } catch (e: Exception) {}
        try { d.rawQuery("SELECT n, ch FROM nm", null).use { while (it.moveToNext()) n[it.getString(0)] = it.getString(1) } } catch (e: Exception) {}
        synchronized(cache) { cache.clear() }
        keys = k; names = n; db = d
        status = ""
    }

    /** არხების დაკავშირება EPG-სთან (გამოიძახეთ ყოველ ჯერზე, როცა არხების სია იცვლება) */
    fun attach(channels: List<Channel>) {
        val m = keys
        val nm = names
        // tvg-id რეგისტრის გარეშე + სახელის ვარიანტები ("GE: Digi+ Hits HD" -> "Digi+ Hits HD" და ა.შ.)
        val lower = HashMap<String, String>()
        for (k in m) lower.putIfAbsent(k.lowercase(), k)
        for (c in channels) {
            var key = ""
            if (c.epgId.isNotBlank()) key = if (m.contains(c.epgId)) c.epgId else (lower[c.epgId.lowercase()] ?: nm[norm(c.epgId)] ?: "")
            if (key.isEmpty()) {
                for (v in nameVariants(c.name)) {
                    val k = nm[v]
                    if (k != null) { key = k; break }
                    val k2 = lower[v]
                    if (k2 != null) { key = k2; break }
                }
            }
            c.epgKey = key
        }
        synchronized(cache) { cache.clear() }
    }

    /** არხის სახელის შესადარებელი ვარიანტები: სრული, ქვეყნის პრეფიქსის ("GE:", "RU |") გარეშე, ფრჩხილების გარეშე */
    private fun nameVariants(name: String): List<String> {
        val out = LinkedHashSet<String>()
        out.add(norm(name))
        val noPrefix = name.replace(RE_PREFIX, "")
        out.add(norm(noPrefix))
        val noParen = noPrefix.replace(RE_PAREN, "")
        out.add(norm(noParen))
        // "Imedi TV" / "TV Imedi" / "Imedi Channel" ↔ "Imedi"
        for (v in out.toList()) {
            for (suf in arrayOf("tv", "channel", "ge", "geo")) if (v.length > suf.length + 2 && v.endsWith(suf)) out.add(v.dropLast(suf.length))
            for (pre in arrayOf("tv", "ge", "geo")) if (v.length > pre.length + 2 && v.startsWith(pre)) out.add(v.drop(pre.length))
        }
        out.remove("")
        return out.toList()
    }


    // ---------- მოთხოვნები (ბაზიდან, ინდექსით — ერთი არხი წამის მემილიონედებში) ----------

    private fun query(ch: String, sql: String, args: Array<String>): List<Program> {
        val d = db ?: return emptyList()
        return try {
            d.rawQuery(sql, args).use { c ->
                val out = ArrayList<Program>(c.count)
                while (c.moveToNext()) out.add(Program(c.getLong(0), c.getLong(1), c.getString(2)))
                out
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun curNext(ch: Channel): Triple<Long, Program?, Program?> {
        val key = ch.epgKey
        val t = System.currentTimeMillis()
        synchronized(cache) { cache[key]?.let { if (it.first > t) return it } }
        // მიმდინარე: ბოლო გადაცემა, რომელიც t-მდე დაიწყო (გადაფარვის შემთხვევაში — წინა)
        val two = query(key, "SELECT st, en, title FROM prog WHERE ch = ? AND st <= ? ORDER BY st DESC LIMIT 2", arrayOf(key, t.toString()))
        var cur: Program? = null
        if (two.isNotEmpty() && t < two[0].stop) cur = two[0]
        else if (two.size > 1 && t < two[1].stop) cur = two[1]
        var nxt: Program? = null
        if (cur != null) nxt = query(key, "SELECT st, en, title FROM prog WHERE ch = ? AND st >= ? ORDER BY st LIMIT 1", arrayOf(key, cur.stop.toString())).firstOrNull()
        val until = minOf(cur?.stop ?: (t + 60_000L), t + 60_000L)
        val r = Triple(until, cur, nxt)
        synchronized(cache) { if (cache.size > 800) cache.clear(); cache[key] = r }
        return r
    }

    fun now(ch: Channel): Program? = if (ch.epgKey.isEmpty()) null else curNext(ch).second

    fun next(ch: Channel): Program? = if (ch.epgKey.isEmpty()) null else curNext(ch).third

    /** მიმდინარე და მომდევნო გადაცემები */
    fun upcoming(ch: Channel?, count: Int): List<Program> {
        if (ch == null || ch.epgKey.isEmpty()) return emptyList()
        return query(ch.epgKey, "SELECT st, en, title FROM prog WHERE ch = ? AND en > ? ORDER BY st LIMIT ${count.coerceIn(1, 200)}", arrayOf(ch.epgKey, System.currentTimeMillis().toString()))
    }

    /** მთელი პროგრამა (გასული გადაცემებიც), დროის მიხედვით */
    fun schedule(ch: Channel?): List<Program> {
        if (ch == null || ch.epgKey.isEmpty()) return emptyList()
        return query(ch.epgKey, "SELECT st, en, title FROM prog WHERE ch = ? ORDER BY st", arrayOf(ch.epgKey))
    }

    // ---------- ქსელი და დამუშავება ----------

    private fun open(url: String): InputStream {
        var u = url
        for (hop in 0..6) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/110 Mobile Safari/537.36")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw IOException("redirect")
                c.disconnect()
                u = URL(URL(u), loc).toString()
                continue
            }
            if (code !in 200..299) {
                c.disconnect()
                throw IOException("http $code")
            }
            val raw = BufferedInputStream(c.inputStream, 64 * 1024)
            raw.mark(2)
            val b0 = raw.read()
            val b1 = raw.read()
            raw.reset()
            return if (b0 == 0x1f && b1 == 0x8b) GZIPInputStream(raw, 64 * 1024) else raw
        }
        throw IOException("too many redirects")
    }


    /** XMLTV-ის ნაკადური დამუშავება: მხოლოდ ფლეილისტის არხები და საჭირო დროის ფანჯარა, პორციებით ბაზაში */
    private fun parseInto(stream: InputStream, w: SQLiteDatabase, now: Long, wantIds: Set<String>, wantNames: Set<String>) {
        val p = Xml.newPullParser()
        p.setInput(stream, null)
        val minStop = now - PAST_MS
        val maxStart = now + FUTURE_MS
        val ins = w.compileStatement("INSERT OR IGNORE INTO prog (ch, st, en, title) VALUES (?, ?, ?, ?)")
        val insN = w.compileStatement("INSERT OR IGNORE INTO nm (n, ch) VALUES (?, ?)")
        val keep = HashSet<String>()
        var sawChannels = false
        val sb = StringBuilder()
        var chId = ""
        var inDisp = false
        var inTitle = false
        var inProg = false
        var progCh = ""
        var start = 0L
        var stop = 0L
        var title = ""
        var inBatch = 0
        w.beginTransaction()
        try {
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "channel" -> chId = p.getAttributeValue(null, "id") ?: ""
                        "display-name" -> if (chId.isNotEmpty() && !inProg) { inDisp = true; sb.setLength(0) }
                        "programme" -> {
                            inProg = true
                            progCh = p.getAttributeValue(null, "channel") ?: ""
                            start = parseTime(p.getAttributeValue(null, "start"))
                            stop = parseTime(p.getAttributeValue(null, "stop"))
                            title = ""
                        }
                        "title" -> if (inProg && title.isEmpty()) { inTitle = true; sb.setLength(0) }
                    }
                    XmlPullParser.TEXT -> if (inDisp || inTitle) sb.append(p.text)
                    XmlPullParser.END_TAG -> when (p.name) {
                        "display-name" -> if (inDisp) {
                            val n = norm(sb.toString())
                            sawChannels = true
                            if (n.isNotEmpty() && (wantNames.contains(n) || wantIds.contains(chId.lowercase()))) {
                                keep.add(chId)
                                insN.bindString(1, n); insN.bindString(2, chId); insN.executeInsert()
                            } else if (wantIds.contains(chId.lowercase())) keep.add(chId)
                            inDisp = false
                        }
                        "channel" -> chId = ""
                        "title" -> if (inTitle) { title = sb.toString().trim(); inTitle = false }
                        "programme" -> {
                            inProg = false
                            if (progCh.isNotEmpty() && stop > minStop && start < maxStart && title.isNotEmpty() &&
                                (!sawChannels || keep.contains(progCh) || wantIds.contains(progCh.lowercase()))) {
                                ins.bindString(1, progCh); ins.bindLong(2, start); ins.bindLong(3, stop); ins.bindString(4, title)
                                ins.executeInsert()
                                if (++inBatch >= BATCH) {
                                    inBatch = 0
                                    w.setTransactionSuccessful(); w.endTransaction(); w.beginTransaction()
                                    Thread.yield()   // ინტერფეისსა და ფლეიერს პროცესორს ვუთმობთ
                                }
                            }
                        }
                    }
                }
                ev = p.next()
            }
            w.setTransactionSuccessful()
        } finally {
            try { w.endTransaction() } catch (e: Exception) {}
            ins.close(); insN.close()
        }
    }

    /** არხის სახელის გასასწორებლად: პატარა ასოები, მხოლოდ ასოები/ციფრები, HD/SD დაბოლოების გარეშე */
    fun norm(s: String): String {
        val b = StringBuilder()
        for (c in s.lowercase()) if (c.isLetterOrDigit()) b.append(c)
        var r = b.toString()
        for (suf in arrayOf("fhd", "uhd", "hd", "sd")) {
            if (r.length > suf.length + 1 && r.endsWith(suf)) { r = r.dropLast(suf.length); break }
        }
        return r
    }

    /** XMLTV დრო: 20261013120000 +0400 (SimpleDateFormat-ის გარეშე — ათიათასობით ჩანაწერზე ბევრად სწრაფია) */
    private fun parseTime(s: String?): Long {
        if (s == null) return 0L
        return try {
            val t = s.trim()
            val y = t.substring(0, 4).toInt()
            val mo = t.substring(4, 6).toInt()
            val d = t.substring(6, 8).toInt()
            val h = t.substring(8, 10).toInt()
            val mi = t.substring(10, 12).toInt()
            val se = if (t.length >= 14) t.substring(12, 14).toInt() else 0
            val days = daysFromCivil(y, mo, d)
            val base = (((days * 24 + h) * 60 + mi) * 60 + se) * 1000L
            val rest = if (t.length > 14) t.substring(14).trim() else ""
            val offMin = if (rest.length >= 5 && (rest[0] == '+' || rest[0] == '-')) {
                val oh = rest.substring(1, 3).toInt()
                val om = rest.substring(3, 5).toInt()
                (if (rest[0] == '+') 1 else -1) * (oh * 60 + om)
            } else 0
            base - offMin * 60_000L
        } catch (e: Exception) {
            0L
        }
    }

    private fun daysFromCivil(y0: Int, m: Int, d: Int): Long {
        val y = if (m <= 2) y0 - 1 else y0
        val era = (if (y >= 0) y else y - 399) / 400
        val yoe = y - era * 400
        val doy = (153 * (m + (if (m > 2) -3 else 9)) + 2) / 5 + d - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097L + doe - 719468L
    }
}
