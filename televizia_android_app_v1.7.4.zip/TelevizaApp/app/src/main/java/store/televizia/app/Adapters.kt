package store.televizia.app

import android.graphics.Color
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import store.televizia.app.databinding.ItemChannelBinding
import store.televizia.app.databinding.ItemProgramBinding

/** არხების სია: ნომერი, ლოგო, სახელი, ამჟამინდელი და შემდეგი გადაცემა (EPG) */
class ChannelAdapter(private val onClick: (Channel, Int) -> Unit) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    private var items: List<Channel> = emptyList()
    private var selectedUrl: String? = null

    class VH(val b: ItemChannelBinding) : RecyclerView.ViewHolder(b.root)

    private companion object {
        const val SEL = "sel"
    }

    fun submit(list: List<Channel>) {
        items = list
        notifyDataSetChanged()
    }

    /** მხოლოდ ორი ელემენტი ახლდება (ძველი და ახალი არჩეული) — მთელი სია თავიდან აღარ იხატება */
    fun select(url: String) {
        if (url == selectedUrl) return
        val old = items.indexOfFirst { it.url == selectedUrl }
        selectedUrl = url
        val new = items.indexOfFirst { it.url == url }
        if (old >= 0) notifyItemChanged(old, SEL)
        if (new >= 0) notifyItemChanged(new, SEL)
    }

    fun refresh() = notifyDataSetChanged()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val vh = VH(ItemChannelBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        vh.b.root.setOnClickListener {
            val pos = vh.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClick(items[pos], pos)
        }
        return vh
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty()) {
            h.b.root.isSelected = items[position].url == selectedUrl
            return
        }
        super.onBindViewHolder(h, position, payloads)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val ch = items[position]
        h.b.num.text = (position + 1).toString()
        h.b.name.text = ch.name
        val nowP = Epg.now(ch)
        h.b.epgBadge.visibility = if (nowP != null) View.VISIBLE else View.GONE
        if (nowP != null) {
            h.b.now.text = "${Ui.timeOf(nowP.start)}  ${nowP.title}"
            h.b.now.visibility = View.VISIBLE
            h.b.prog.progress = Ui.progressOf(nowP)
            h.b.prog.visibility = View.VISIBLE
            val nx = Epg.next(ch)
            if (nx != null) {
                h.b.next.text = "▸ ${Ui.timeOf(nx.start)}  ${nx.title}"
                h.b.next.visibility = View.VISIBLE
            } else h.b.next.visibility = View.GONE
        } else {
            h.b.now.visibility = View.GONE
            h.b.next.visibility = View.GONE
            h.b.prog.visibility = View.GONE
        }
        ImageLoader.show(ch.logo, h.b.logo, ch.name)
        h.b.root.isSelected = ch.url == selectedUrl
    }
}

/** კატეგორიების ღილაკები */
class GroupAdapter(private val vertical: Boolean, private val onClick: (String) -> Unit) : RecyclerView.Adapter<GroupAdapter.VH>() {
    private var items: List<String> = emptyList()
    private var selected: String = ""

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    fun submit(list: List<String>, sel: String) {
        items = list
        selected = sel
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val d = parent.resources.displayMetrics.density
        val tv = TextView(parent.context).apply {
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundResource(if (vertical) R.drawable.item_bg else R.drawable.chip_bg)
            isFocusable = true
            isClickable = true
            gravity = if (vertical) Gravity.START or Gravity.CENTER_VERTICAL else Gravity.CENTER
            layoutParams = if (vertical) {
                ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { setMargins(0, 0, 0, (4 * d).toInt()) }
            } else {
                ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { setMargins(0, 0, (8 * d).toInt(), 0) }
            }
        }
        val vh = VH(tv)
        tv.setOnClickListener {
            val pos = vh.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClick(items[pos])
        }
        return vh
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val g = items[position]
        h.tv.text = Lang.group(g)
        h.tv.isSelected = g == selected
    }
}

/** პროგრამის სია (EPG): დრო, სათაური; მიმდინარე გადაცემა გამოყოფილია და აქვს "ახლა" ბეჯი */
class ProgramAdapter : RecyclerView.Adapter<ProgramAdapter.VH>() {
    private var items: List<Program> = emptyList()

    class VH(val b: ItemProgramBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(list: List<Program>) {
        items = list
        notifyDataSetChanged()
    }

    /** მიმდინარე გადაცემის ადგილი სიაში (სიის გადასახვევად); გასული გადაცემები მასზე ზემოთაა */
    fun liveIndex(): Int {
        val t = System.currentTimeMillis()
        val i = items.indexOfFirst { t >= it.start && t < it.stop }
        return if (i >= 0) i else items.indexOfFirst { it.start > t }.coerceAtLeast(0)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemProgramBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = items[position]
        val t = System.currentTimeMillis()
        val live = t >= p.start && t < p.stop
        h.b.pTime.text = Ui.timeOf(p.start)
        h.b.pTitle.text = p.title
        h.b.pBadge.visibility = if (live) View.VISIBLE else View.GONE
        h.b.root.setBackgroundResource(if (live) R.drawable.program_live_bg else R.drawable.item_bg)
        val past = t >= p.stop
        h.b.root.alpha = if (past) 0.55f else 1f
        h.b.pTime.setTextColor(if (live) Color.WHITE else Color.parseColor("#9AA3C2"))
        h.b.pTitle.setTypeface(null, if (live) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
    }
}
