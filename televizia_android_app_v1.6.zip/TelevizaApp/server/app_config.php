<?php
/**
 * TELEVIZIA.STORE — აპლიკაციის დისტანციური მართვის ფაილი.
 *
 * ატვირთეთ საიტზე:  /api/app_config.php   (საქაღალდე api/ უნდა იყოს ჩაწერადი — აქ შეიქმნება app_config.json)
 *  - GET  ?action=get  → აპლიკაცია კითხულობს პარამეტრებს (საჯარო, საიდუმლო არაფერია)
 *  - POST ?action=set  → პარამეტრების შენახვა; აუცილებელია ადმინ-გასაღები (ADMIN_KEY)
 *
 * !!! ქვემოთ ADMIN_KEY შეცვალეთ გრძელი შემთხვევითი ტექსტით (მინ. 16 სიმბოლო). ეს გასაღები შეგყავთ აპლიკაციაში
 *     ადმინ-ეკრანზე "აპლიკაცია" ჩანართში. ნუ გაუზიარებთ არავის.
 */
const ADMIN_KEY = 'CHANGE_ME_TO_LONG_RANDOM_KEY';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$file = __DIR__ . '/app_config.json';

// სქემა: გასაღები => ტიპი (bool / int / str:მაქს.სიგრძე). სხვა გასაღებები ინახება არ ხდება.
$schema = [
    'maintenance.on'          => 'bool',
    'maintenance.message'     => 'str:500',
    'announcement.on'         => 'bool',
    'announcement.title'      => 'str:120',
    'announcement.text'       => 'str:2000',
    'announcement.url'        => 'str:500',
    'update.latest_code'      => 'int',
    'update.latest_name'      => 'str:30',
    'update.url'              => 'str:500',
    'update.force_below'      => 'int',
    'update.message'          => 'str:500',
    'urls.epg'                => 'str:500',
    'urls.admin'              => 'str:500',
    'features.qr_login'       => 'bool',
    'features.tv_login'       => 'bool',
    'features.lang_button'    => 'bool',
    'features.admin_button'   => 'bool',
    'texts.login_notice'      => 'str:500',
];
$defaults = [
    'maintenance.on' => false, 'maintenance.message' => '',
    'announcement.on' => false, 'announcement.title' => '', 'announcement.text' => '', 'announcement.url' => '',
    'update.latest_code' => 0, 'update.latest_name' => '', 'update.url' => '', 'update.force_below' => 0, 'update.message' => '',
    'urls.epg' => '', 'urls.admin' => '',
    'features.qr_login' => true, 'features.tv_login' => true, 'features.lang_button' => true, 'features.admin_button' => true,
    'texts.login_notice' => '',
];

function out($data, $code = 200) { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }

function nest(array $flat): array {
    $r = [];
    foreach ($flat as $path => $v) {
        $p = explode('.', $path);
        $ref = &$r;
        foreach ($p as $i => $k) {
            if ($i === count($p) - 1) { $ref[$k] = $v; }
            else { if (!isset($ref[$k]) || !is_array($ref[$k])) $ref[$k] = []; $ref = &$ref[$k]; }
        }
        unset($ref);
    }
    return $r;
}

function flatten(array $a, string $prefix = ''): array {
    $r = [];
    foreach ($a as $k => $v) {
        $key = $prefix === '' ? $k : "$prefix.$k";
        if (is_array($v)) $r += flatten($v, $key); else $r[$key] = $v;
    }
    return $r;
}

function current_flat(string $file, array $defaults): array {
    $flat = $defaults;
    if (is_file($file)) {
        $saved = json_decode((string)file_get_contents($file), true);
        if (is_array($saved)) foreach (flatten($saved) as $k => $v) if (array_key_exists($k, $defaults)) $flat[$k] = $v;
    }
    return $flat;
}

$action = $_GET['action'] ?? 'get';

if ($action === 'get') {
    out(['ok' => true, 'config' => nest(current_flat($file, $defaults))]);
}

if ($action === 'set' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (strlen(ADMIN_KEY) < 16 || ADMIN_KEY === 'CHANGE_ME_TO_LONG_RANDOM_KEY') {
        out(['ok' => false, 'error' => 'სერვერზე ADMIN_KEY ჯერ არ არის შეცვლილი (app_config.php)'], 500);
    }
    $body = json_decode((string)file_get_contents('php://input'), true);
    $key = is_array($body) ? (string)($body['key'] ?? '') : '';
    if (!hash_equals(ADMIN_KEY, $key)) {
        usleep(800000);   // გამოცნობის შენელება
        out(['ok' => false, 'error' => 'გასაღები არასწორია'], 403);
    }
    $cfg = is_array($body['config'] ?? null) ? flatten($body['config']) : [];
    $flat = current_flat($file, $defaults);
    foreach ($schema as $path => $type) {
        if (!array_key_exists($path, $cfg)) continue;
        $v = $cfg[$path];
        if ($type === 'bool') $flat[$path] = (bool)$v;
        elseif ($type === 'int') $flat[$path] = max(0, (int)$v);
        else {
            $max = (int)substr($type, 4);
            $s = trim((string)$v);
            $flat[$path] = function_exists('mb_substr') ? mb_substr($s, 0, $max) : substr($s, 0, $max);
        }
    }
    $json = json_encode(nest($flat), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    $tmp = $file . '.tmp';
    if (file_put_contents($tmp, $json, LOCK_EX) === false || !rename($tmp, $file)) {
        out(['ok' => false, 'error' => 'ფაილი ვერ ჩაიწერა — საქაღალდეს ჩაწერის უფლება სჭირდება'], 500);
    }
    out(['ok' => true, 'config' => nest($flat)]);
}

out(['ok' => false, 'error' => 'unknown action'], 400);
