package store.televizia.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector

/**
 * საერთო ფლეიერი ორივე ეკრანისთვის (სია და სრული ეკრანი). ერთი და იგივე ExoPlayer გადადის ეკრანიდან
 * ეკრანზე, ამიტომ "სრულ ეკრანზე" გახსნისას არხი თავიდან აღარ იტვირთება — ვიდეო წყვეტის გარეშე გრძელდება.
 *
 * არხს რამდენიმე გზით ცდილობს გახსნას:
 *  - http <-> https გადამისამართებებს მიჰყვება
 *  - ფორმატს ბმულიდან ხვდება, ხოლო თუ ვერ გაიხსნა — სცდის სხვა ფორმატებს (HLS, TS, ავტომატური)
 *  - ბოლოს სცდის ბრაუზერის User-Agent-ით
 *  - ცდას წყვეტს, თუ არხი 12 წამში არ ჩაირთო
 *  - ყველა ცდის შემდეგ უბრალოდ იძახებს onFailed — სხვა არხზე თავისით არასოდეს გადადის
 *
 * სისწრაფე: მცირე საწყისი ბუფერი (1 წმ), HLS-ის "chunkless" მომზადება, ეკრანის ზომაზე მორგებული
 * ხარისხი (4K ნაკადს ტელეფონზე ტყუილად არ ვტვირთავთ).
 */
class StreamController(private val ctx: Context) {
    companion object {
        private const val UA_VLC = "VLC/3.0.18 LibVLC/3.0.18"
        private const val UA_BROWSER =
            "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0 Safari/537.36"
        private const val START_TIMEOUT_MS = 12000L
        private val TS_REGEX = Regex("""\.ts($|[?/#])""")
        private const val RETRY_MS = 5000L
        private const val LOADING = 0
        private const val PLAYING = 1
        private const val FAILED = 2
    }

    var player: ExoPlayer? = null
        private set
    var currentUrl: String = ""
        private set

    private var owner: Any? = null
    private var onLoading: () -> Unit = {}
    private var onPlaying: () -> Unit = {}
    private var onFailed: () -> Unit = {}

    private val h = Handler(Looper.getMainLooper())
    private var attempt = 0
    private var everPlayed = false
    private var state = LOADING
    private val watchdog = Runnable { handleError(null) }
    private var retrying = false
    /** ბმულის განახლება (არხი ვერ ჩაირთო): ძველი ბმული -> ახალი ბმული ან null */
    var refresher: ((String) -> String?)? = null

    private fun restartSame() {
        if (player != null && currentUrl.isNotEmpty()) {
            attempt = 0
            everPlayed = false
            start()
        }
    }

    private val retry = Runnable {
        if (player == null || currentUrl.isEmpty()) return@Runnable
        val r = refresher
        if (r == null) { restartSame(); return@Runnable }
        val old = currentUrl
        Thread {
            val nu = try { r(old) } catch (e: Exception) { null }
            h.post {
                if (player == null || currentUrl != old) return@post   // ამასობაში სხვა არხი ჩაირთო
                if (nu != null && nu.isNotBlank()) currentUrl = nu.trim()
                restartSame()
            }
        }.start()
    }

    /** ეკრანი ("owner") ცვლის მოვლენების მიმღებს; unlisten(owner) მხოლოდ მაშინ ასუფთავებს, თუ ის ჯერ კიდევ მფლობელია */
    fun listen(owner: Any, loading: () -> Unit, playing: () -> Unit, failed: () -> Unit) {
        this.owner = owner
        onLoading = loading; onPlaying = playing; onFailed = failed
    }

    fun unlisten(owner: Any) {
        if (this.owner === owner) {
            this.owner = null
            onLoading = {}; onPlaying = {}; onFailed = {}
        }
    }

    /** ქმნის ფლეიერს (თუ ჯერ არ არის); PlayerView-ს მიამაგრეთ დაბრუნებული ობიექტი */
    fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        val renderers = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)
        val selector = DefaultTrackSelector(ctx).apply {
            setParameters(buildUponParameters().setViewportSizeToPhysicalDisplaySize(ctx, true))
        }
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(10_000, 30_000, 1_000, 2_000)
            .build()
        val p = ExoPlayer.Builder(ctx, renderers)
            .setTrackSelector(selector)
            .setLoadControl(load)
            .build()
        p.volume = 1f
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> {
                        h.removeCallbacks(watchdog)
                        h.removeCallbacks(retry)
                        retrying = false
                        everPlayed = true
                        state = PLAYING
                        onPlaying()
                    }
                    Player.STATE_BUFFERING -> {
                        if (!retrying) {
                            state = LOADING
                            onLoading()
                        }
                    }
                    Player.STATE_ENDED -> handleError(null)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                handleError(error)
            }
        })
        player = p
        return p
    }

    /** იგივე არხზე განმეორებითი გამოძახება არხს თავიდან აღარ იტვირთავს (თუ არ ჩაშლილა) */
    fun play(newUrl: String) {
        val u = newUrl.trim()
        ensurePlayer()
        if (u == currentUrl && state != FAILED) {
            dispatchState()
            return
        }
        currentUrl = u
        h.removeCallbacks(retry)
        retrying = false
        attempt = 0
        everPlayed = false
        state = LOADING
        onLoading()
        start()
    }

    /** ახალ ეკრანს ვუცხადებთ, რა მდგომარეობაშია ფლეიერი ახლა */
    fun dispatchState() {
        when (state) {
            PLAYING -> onPlaying()
            FAILED -> onFailed()
            else -> onLoading()
        }
    }

    fun release() {
        h.removeCallbacks(watchdog)
        h.removeCallbacks(retry)
        retrying = false
        owner = null
        onLoading = {}; onPlaying = {}; onFailed = {}
        player?.release()
        player = null
        currentUrl = ""
        state = LOADING
    }

    /** ფორმატების რიგი ბმულის მიხედვით: null = ავტომატური ამოცნობა */
    private fun formats(): List<String?> {
        val l = currentUrl.lowercase()
        return when {
            l.contains("m3u8") -> listOf(MimeTypes.APPLICATION_M3U8, null, MimeTypes.VIDEO_MP2T)
            TS_REGEX.containsMatchIn(l) -> listOf(MimeTypes.VIDEO_MP2T, MimeTypes.APPLICATION_M3U8, null)
            else -> listOf(null, MimeTypes.APPLICATION_M3U8, MimeTypes.VIDEO_MP2T)
        }
    }

    private fun spec(a: Int): Pair<String?, String> {
        val f = formats()
        return when (a) {
            0 -> Pair(f[0], UA_VLC)
            1 -> Pair(f[1], UA_VLC)
            2 -> Pair(f[2], UA_VLC)
            else -> Pair(f[0], UA_BROWSER)
        }
    }

    private fun start() {
        val p = player ?: return
        val (fmt, ua) = spec(attempt)
        val builder = MediaItem.Builder().setUri(currentUrl)
        if (fmt != null) builder.setMimeType(fmt)
        val item = builder.build()
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8000)
            .setReadTimeoutMs(12000)
        val dsf = DefaultDataSource.Factory(ctx, http)
        val source: MediaSource = if (fmt == MimeTypes.APPLICATION_M3U8) {
            HlsMediaSource.Factory(dsf).setAllowChunklessPreparation(true).createMediaSource(item)
        } else {
            DefaultMediaSourceFactory(dsf).createMediaSource(item)
        }
        p.setMediaSource(source)
        p.prepare()
        p.playWhenReady = true
        h.removeCallbacks(watchdog)
        h.postDelayed(watchdog, START_TIMEOUT_MS)
    }

    private fun isParseError(e: PlaybackException?): Boolean {
        if (e == null) return false
        return e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED
    }

    private fun handleError(e: PlaybackException?) {
        h.removeCallbacks(watchdog)
        val p = player ?: return
        if (e != null && e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            p.seekToDefaultPosition()
            p.prepare()
            h.postDelayed(watchdog, START_TIMEOUT_MS)
            return
        }
        if (everPlayed) {
            // ნაკადი გაჩერდა, მაგრამ აქამდე თამაშობდა — ერთხელ თავიდან ვუკავშირდებით
            everPlayed = false
            start()
            return
        }
        // ფორმატის შეცდომისას ვცდით შემდეგ ფორმატს; კავშირის/სერვერის შეცდომისას — ბრაუზერის სათაურს
        val next = when {
            attempt >= 3 -> -1
            isParseError(e) && attempt < 2 -> attempt + 1
            else -> 3
        }
        if (next < 0) {
            try { p.stop() } catch (ex: Exception) { }
            state = FAILED
            retrying = true
            onFailed()
            // იგივე არხს რამდენიმე წამში თავიდან ვცდით; სხვა არხზე არასოდეს გადადის
            h.removeCallbacks(retry)
            h.postDelayed(retry, RETRY_MS)
            return
        }
        attempt = next
        start()
    }
}

/** ერთი საერთო ფლეიერი მთელ აპლიკაციაზე */
object StreamHub {
    private var c: StreamController? = null

    fun get(ctx: Context): StreamController =
        c ?: StreamController(ctx.applicationContext).also {
            val app = ctx.applicationContext
            it.refresher = { u -> ChannelRefresher.refresh(app, u) }
            c = it
        }

    fun peek(): StreamController? = c

    fun release() {
        c?.release()
        c = null
    }
}
