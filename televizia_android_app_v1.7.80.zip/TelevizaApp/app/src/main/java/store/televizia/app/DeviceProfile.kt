package store.televizia.app

import android.app.ActivityManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Build

/**
 * მოწყობილობის ავტომატური მორგება. სამი ფენა:
 *
 * 1) ფორმულა: აპი ამოწმებს მეხსიერებას (heap, RAM), ეკრანს და იანგარიშებს ბუფერის ბაიტურ ზღვარს, ბუფერის დროს,
 *    ვიდეოს ხარისხის ზღვარს, ლოგოების ქეშს. ძლიერ მოწყობილობაზე (HIGH) პარამეტრები ზუსტად ისაა, რაც ადრე იყო.
 * 2) შეგუება: თუ მოწყობილობა მეხსიერებას/დეკოდერს ვერ უძლებს (OutOfMemory, ტრიმი, იშვიათი კადრები, VLC-ის კრაშის
 *    კვალი), "დონე" (level 0..3) იზრდება და ბუფერი/ხარისხი მცირდება; დონე ინახება მოწყობილობაზე. სტაბილური
 *    დაკვრის 20 წუთის შემდეგ დონე ნელ-ნელა ბრუნდება უკან.
 * 3) სარეზერვო ცხრილი LOW/MID/HIGH: გამოიყენება, თუ მოწყობილობის მონაცემები ვერ წაიკითხა, ან სერვერიდან
 *    player.profile = low/mid/high იძულებითაა მითითებული.
 *
 * სერვერიდან ხელით მითითებული პარამეტრები ყველაფერზე უპირატესია:
 *  player.profile, player.buf_min_ms, player.buf_max_ms, player.buf_start_ms, player.buf_rebuffer_ms,
 *  player.buf_max_mb, player.max_height, player.vlc_hw
 */
object DeviceProfile {
    enum class Tier { LOW, MID, HIGH }

    private const val PREFS = "device_profile"

    private var app: Context? = null
    private var prefs: SharedPreferences? = null
    private var ready = false
    private var formulaOk = false
    private var autoTier = Tier.MID
    private var ramMb = 0
    private var heapMb = 0
    private var dispMin = 0
    private var info = ""

    @Volatile private var level = 0
    private var lastDegrade = 0L
    private var playMs = 0L

    fun init(ctx: Context) {
        if (ready) return
        ready = true
        val a = ctx.applicationContext
        app = a
        try { prefs = a.getSharedPreferences(PREFS, Context.MODE_PRIVATE) } catch (_: Throwable) {}
        try { level = (prefs?.getInt("level", 0) ?: 0).coerceIn(0, 3) } catch (_: Throwable) {}
        try {
            val am = a.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
            ramMb = (mi.totalMem / (1024 * 1024)).toInt()
            heapMb = am.memoryClass
            val dm = a.resources.displayMetrics
            dispMin = minOf(dm.widthPixels, dm.heightPixels)
            val cores = Runtime.getRuntime().availableProcessors()
            val is64 = Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()
            val lowRam = am.isLowRamDevice
            autoTier = when {
                lowRam || ramMb in 1..1600 || heapMb in 1..128 || (!is64 && ramMb in 1..2300) || Build.VERSION.SDK_INT < 23 -> Tier.LOW
                ramMb in 1..3300 || heapMb in 1..192 || cores <= 4 -> Tier.MID
                else -> Tier.HIGH
            }
            formulaOk = ramMb > 0 && heapMb > 0
            info = "RAM ${ramMb}MB, heap ${heapMb}MB, cores $cores, ${if (is64) "64" else "32"}bit, SDK ${Build.VERSION.SDK_INT}, " +
                "${if (Device.tv(a)) "TV" else "phone"}, ეკრანი ${dispMin}p → $autoTier, level $level"
        } catch (_: Throwable) {
            formulaOk = false
            autoTier = Tier.MID
        }
        installCrashHook()
        checkUncleanVlc()
    }

    fun describe(): String = "$info (cap ${bufMaxMb()}MB, buf ${bufMinMs()}-${bufMaxMs()}ms, h≤${maxHeight()}, vlcHw ${vlcHw()}, level $level)"

    /** სერვერიდან იძულებითი პროფილი (თუ მითითებულია); null = ავტომატური */
    private fun forced(): Tier? = when (RemoteConfig.s("player.profile", "").trim().lowercase()) {
        "low" -> Tier.LOW
        "mid" -> Tier.MID
        "high" -> Tier.HIGH
        else -> null
    }

    private fun ov(key: String): Int? {
        val v = RemoteConfig.i(key, Int.MIN_VALUE)
        return if (v == Int.MIN_VALUE) null else v
    }

    private fun factor(): Double = when (level) { 0 -> 1.0; 1 -> 0.75; 2 -> 0.55; else -> 0.4 }

    // ---------------- ბუფერი ----------------

    /** ბაზური ზომა მბ-ში ფორმულით/ცხრილით; 0 = ლიმიტის გარეშე */
    private fun capBaseMb(): Int {
        val f = forced()
        if (f != null || !formulaOk) {
            return when (f ?: autoTier) { Tier.LOW -> 24; Tier.MID -> 48; Tier.HIGH -> 0 }
        }
        if (autoTier == Tier.HIGH) return 0
        return (heapMb * 0.2).toInt().coerceIn(16, 96)
    }

    fun bufMaxMb(): Int {
        ov("player.buf_max_mb")?.let { return it }
        val base = capBaseMb()
        if (base == 0 && level == 0) return 0
        val b = if (base == 0) 64 else base
        return (b * factor()).toInt().coerceAtLeast(12)
    }

    private fun scaled(v: Int, min: Int): Int = if (level == 0) v else (v * factor()).toInt().coerceAtLeast(min)

    fun bufMinMs(): Int {
        ov("player.buf_min_ms")?.let { return it }
        val base = capBaseMb()
        val v = if (base == 0) 20_000 else (base * 500).coerceIn(8_000, 20_000)
        return scaled(v, 5_000)
    }

    fun bufMaxMs(): Int {
        ov("player.buf_max_ms")?.let { return it }
        val base = capBaseMb()
        val v = if (base == 0) 50_000 else (base * 1000).coerceIn(12_000, 50_000)
        return scaled(v, 8_000)
    }

    fun bufStartMs(): Int = ov("player.buf_start_ms") ?: 1_500

    fun bufRebufferMs(): Int {
        ov("player.buf_rebuffer_ms")?.let { return it }
        val base = capBaseMb()
        return if (base == 0) 6_000 else (4_000 + base * 20).coerceIn(4_000, 6_000)
    }

    // ---------------- ხარისხი ----------------

    /** ვიდეოს სიმაღლის ზღვარი; 0 = ლიმიტის გარეშე */
    fun maxHeight(): Int {
        ov("player.max_height")?.let { return it }
        val f = forced()
        var cap = 0   // 0 = უსაზღვრო
        fun lim(v: Int) { cap = if (cap == 0) v else minOf(cap, v) }
        if (f != null || !formulaOk) {
            when (f ?: autoTier) { Tier.LOW -> lim(720); Tier.MID -> lim(1080); Tier.HIGH -> {} }
        } else {
            if (heapMb <= 128) lim(720) else if (heapMb <= 192) lim(1080)
            if (dispMin in 1..720) lim(720) else if (dispMin in 1..1080) lim(1080)
        }
        if (level >= 3) lim(480) else if (level == 2) lim(720) else if (level == 1) lim(1080)
        return cap
    }

    // ---------------- VLC ----------------

    /** აპარატურული დეკოდირება VLC-ში: სუსტზე (ან დონის ზრდისას) ირთვება, რომ პროცესორი არ გადაიტვირთოს */
    fun vlcHw(): Boolean {
        ov("player.vlc_hw")?.let { return it == 1 }
        val t = forced() ?: autoTier
        return t == Tier.LOW || level >= 2
    }

    // ---------------- ლოგოების ქეში ----------------

    fun logoCacheBytes(): Int {
        val f = forced()
        val mb = if (f != null || !formulaOk) when (f ?: autoTier) { Tier.LOW -> 6; Tier.MID -> 12; Tier.HIGH -> 24 }
                 else (heapMb / 16).coerceIn(6, 24)
        return mb * 1024 * 1024
    }

    // ---------------- შეგუება ----------------

    /** მოწყობილობა ვერ უძლებს: ბუფერი/ხარისხი მცირდება (ძალაში შედის ფლეიერის შემდეგ შექმნისას). gap — მინ. ინტერვალი ორ შემცირებას შორის */
    fun degrade(reason: String, gapMs: Long = 60_000L) {
        val now = System.currentTimeMillis()
        if (now - lastDegrade < gapMs || level >= 3) return
        lastDegrade = now
        level++
        playMs = 0
        saveLevel()
        note("degrade($reason) → level $level")
    }

    /** ყოველი სტაბილური დაკვრის მონაკვეთი (ExoPlayer-ის მონიტორიდან); 20 წუთის შემდეგ დონე 1-ით ბრუნდება */
    fun noteStable(ms: Long) {
        if (level <= 0) return
        playMs += ms
        if (playMs >= 20 * 60_000L) {
            playMs = 0
            level--
            saveLevel()
            note("recover → level $level")
        }
    }

    private fun saveLevel() { try { prefs?.edit()?.putInt("level", level)?.apply() } catch (_: Throwable) {} }

    private fun note(s: String) { try { prefs?.edit()?.putString("last_note", s)?.apply() } catch (_: Throwable) {} }

    // ---------------- VLC-ის კრაშის კვალი ----------------
    // VLC-ის მშობლიური ჩავარდნა ვერ იჭერება. ამიტომ VLC-ის დაწყებისას ბმულს ვინახავთ, გაჩერებისას ვშლით; თუ შემდეგ
    // გაშვებისას ჯერ კიდევ ჩანს — წინა სესია VLC-ზე გაწყდა: დონე იზრდება, ხოლო იმავე არხზე 2 ასეთი შემთხვევის შემდეგ VLC ამ არხზე აღარ იწყება.

    private fun vsKey(url: String) = "vs_" + url.hashCode()

    fun vlcStarted(url: String) { try { prefs?.edit()?.putString("vlc_active", url)?.apply() } catch (_: Throwable) {} }

    fun vlcStopped() {
        try {
            val p = prefs ?: return
            val u = p.getString("vlc_active", null) ?: return
            p.edit().remove("vlc_active").remove(vsKey(u)).apply()
        } catch (_: Throwable) {}
    }

    fun vlcBanned(url: String): Boolean = try { (prefs?.getInt(vsKey(url), 0) ?: 0) >= 2 } catch (_: Throwable) { false }

    private fun checkUncleanVlc() {
        try {
            val p = prefs ?: return
            val u = p.getString("vlc_active", null) ?: return
            p.edit().remove("vlc_active").putInt(vsKey(u), p.getInt(vsKey(u), 0) + 1).apply()
            degrade("vlc unclean", 0L)
        } catch (_: Throwable) {}
    }

    // ---------------- კრაშების ჩანაწერი ----------------

    private fun installCrashHook() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val oom = generateSequence<Throwable>(e) { it.cause }.any { it is OutOfMemoryError }
                val ed = prefs?.edit()
                if (ed != null) {
                    ed.putString("last_crash", android.util.Log.getStackTraceString(e).take(4000))
                    if (oom && level < 3) ed.putInt("level", level + 1)
                    ed.commit()
                }
            } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }

    /** ბოლო კრაშის ტექსტი (დიაგნოსტიკისთვის) */
    fun lastCrash(): String = try { prefs?.getString("last_crash", "") ?: "" } catch (_: Throwable) { "" }
}
