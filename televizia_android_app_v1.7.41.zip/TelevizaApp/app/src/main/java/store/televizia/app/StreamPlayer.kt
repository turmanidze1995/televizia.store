package store.televizia.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector

/**
 * საერთო ფლეიერი ორივე ეკრანისთვის (სია და სრული ეკრანი). ერთი და იგივე ExoPlayer გადადის ეკრანიდან
 * ეკრანზე, ამიტომ "სრულ ეკრანზე" გახსნისას არხი თავიდან აღარ იტვირთება — ვიდეო წყვეტის გარეშე გრძელდება.
 *
 * არხს რამდენიმე გზით ცდილობს გახსნას:
 *  - http <-> https გადამისამართებებს მიჰყვება
 *  - ფორმატს ბმულიდან ხვდება, ხოლო თუ ვერ გაიხსნა — სცდის სხვა ფორმატებს (HLS, TS, ავტომატური)
 *  - ბოლოს სცდის ბრაუზერის User-Agent-ით
 *  - ცდას წყვეტს, თუ არხი 12 წამში არ ჩაირთო
 *  - ყველა ცდის შემდეგ უბრალოდ იძახებს onFailed — სხვა არხზე თავისით არასოდეს გადადის
 *
 * სისწრაფე: მცირე საწყისი ბუფერი (1 წმ), HLS-ის "chunkless" მომზადება, ეკრანის ზომაზე მორგებული
 * ხარისხი (4K ნაკადს ტელეფონზე ტყუილად არ ვტვირთავთ).
 */
class StreamController(private val ctx: Context) {
    companion object {
        private const val UA_VLC = "VLC/3.0.18 LibVLC/3.0.18"
        private const val UA_BROWSER =
            "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0 Safari/537.36"
        private const val START_TIMEOUT_MS = 22000L
        private val TS_REGEX = Regex("""\.ts($|[?/#])""")
        private const val RETRY_MS = 3000L
        private const val LOADING = 0
        private const val PLAYING = 1
        private const val FAILED = 2
    }

    var player: ExoPlayer? = null
        private set
    var currentUrl: String = ""
        private set

    private var owner: Any? = null
    private var onLoading: () -> Unit = {}
    private var onPlaying: () -> Unit = {}
    private var onFailed: () -> Unit = {}
    /** ფლეიერი ახლით შეიცვალა (დეკოდერის "დაღლილობის" გამო) — ეკრანმა ახალი ობიექტი უნდა მიიმაგროს */
    var onRebuilt: ((ExoPlayer) -> Unit)? = null
    private var zaps = 0
    private var lastRebuild = 0L
    private var fpsSince = 0L
    private var fpsCount = -1L

    private val h = Handler(Looper.getMainLooper())
    private var attempt = 0
    private var everPlayed = false
    private var state = LOADING
    private val watchdog = Runnable { handleError(null) }
    private var retrying = false
    private var awaitFrame = false
    private var cycles = 0
    private var lastCode = 0
    private var retryAfterMs = 0L
    private var lastErr = ""
    /** მოკლე დიაგნოსტიკა ეკრანზე: რამდენჯერ სცადა და რა შეცდომა იყო */
    fun diag(): String = "ცდა #$cycles · $lastErr"
    private var guardStage = 0
    private val frameGuard = Runnable { runGuard() }

    private fun runGuard() {
        // ხმა/დრო მიდის, მაგრამ ახალ ზედაპირზე კადრი არ დახატულა (გაყინული სურათი)
        if (awaitFrame && state == PLAYING && player != null && currentUrl.isNotEmpty()) {
            if (guardStage == 0) {
                // ჯერ მსუბუქად: პირდაპირ ეთერზე ვხტებით (ახალი გასაღები-კადრი), ქსელს თავიდან არ ვტვირთავთ
                guardStage = 1
                player?.seekToDefaultPosition()
                h.postDelayed(frameGuard, 3500)
            } else {
                awaitFrame = false
                restartSame()
            }
        }
    }

    // --- ეთერში გაყინვის მეთვალყურე: მუშაობს ყველა ეკრანზე (სრულ ეკრანზეც), OK-ის დაჭერა საჭირო აღარ არის ---
    private var monLastCount = -1L
    private var monSince = 0L
    private var bufSince = 0L
    private val monitor = object : Runnable {
        override fun run() {
            try { tick() } catch (_: Exception) {}
            if (player != null) h.postDelayed(this, 500)
        }
        private fun tick() {
            val p = player ?: return
            val now = System.currentTimeMillis()
            if (currentUrl.isEmpty() || retrying || state == FAILED) { monLastCount = -1; bufSince = 0; return }
            // 1) ბუფერიზაციაში გაიჭედა თამაშის შემდეგ
            if (p.playbackState == Player.STATE_BUFFERING && p.playWhenReady) {
                if (bufSince == 0L) bufSince = now
                if (now - bufSince > 12000) { bufSince = 0; monLastCount = -1; forceRefresh() }   // 4 წმ-ზე ნელ ქსელზე არხს განუწყვეტლივ თავიდან ვუკავშირდებოდით
                return
            }
            bufSince = 0
            // 2) ხმა/დრო მიდის, მაგრამ ახალი კადრები აღარ იხატება
            if (p.playbackState == Player.STATE_READY && p.playWhenReady && p.videoFormat != null) {
                val c = p.videoDecoderCounters ?: return
                c.ensureUpdated()
                val n = c.renderedOutputBufferCount.toLong()
                if (n != monLastCount) { monLastCount = n; monSince = now }
                else if (now - monSince > 6000) { monLastCount = -1; forceRefresh() }
                // 3) კადრები იხატება, მაგრამ ძალიან იშვიათად (დეკოდერი "დაიღალა") — ფლეიერს ვანახლებთ
                if (fpsCount < 0 || now - fpsSince > 6000) {
                    if (fpsCount >= 0) {
                        val perSec = (n - fpsCount) * 1000.0 / (now - fpsSince)
                        val fr = p.videoFormat?.frameRate?.takeIf { it > 0f } ?: 25f
                        if (perSec < minOf(10.0, fr * 0.4)) rebuildPlayer()
                    }
                    fpsCount = n; fpsSince = now
                }
            } else { monLastCount = -1; fpsCount = -1 }
        }
    }

    /** ნაკადი გაიჭედა: ბმულს ვანახლებთ სიიდან და იგივე არხს თავიდან ვუკავშირდებით */
    private var lastForce = 0L
    private fun forceRefresh() {
        val now = System.currentTimeMillis()
        if (now - lastForce < 20000) return   // სერვერს ზედმეტად არ ვტვირთავთ (429)
        lastForce = now
        h.removeCallbacks(retry)
        retry.run()
    }

    /** ფლეიერს თავიდან ვქმნით (იგივეა, რაც აპლიკაციის გადატვირთვა) და იგივე არხს ვუშვებთ */
    private fun rebuildPlayer(restart: Boolean = true) {
        val now = System.currentTimeMillis()
        if (restart && now - lastRebuild < 15000) return
        lastRebuild = now
        zaps = 0; fpsCount = -1; monLastCount = -1
        h.removeCallbacks(watchdog)
        try { player?.clearVideoSurface() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        val np = ensurePlayer()
        onRebuilt?.invoke(np)
        if (restart && currentUrl.isNotEmpty()) {
            retrying = false; attempt = 0; everPlayed = false; state = LOADING
            onLoading()
            start()
        }
    }

    /** ვიდეოს ზედაპირს ვწყვეტთ ახალ ეკრანზე გადასვლამდე: დეკოდერი თავიდან ინიციალიზდება და სურათი არ ეჭედება */
    fun detachVideo() {
        try { player?.clearVideoSurface() } catch (_: Exception) {}
    }

    /** ფლეიერი ახალ PlayerView-ზე გადავიდა: თუ 2.5 წმ-ში კადრი არ გამოჩნდა, ვაახლებთ */
    private fun armFrameGuard() {
        h.removeCallbacks(frameGuard)
        if (state != PLAYING) { awaitFrame = false; return }
        awaitFrame = true
        guardStage = 0
        h.postDelayed(frameGuard, 3500)
    }
    /** ბმულის განახლება (არხი ვერ ჩაირთო): ძველი ბმული -> ახალი ბმული ან null */
    var refresher: ((String) -> String?)? = null

    private fun restartSame() {
        if (player != null && currentUrl.isNotEmpty()) {
            attempt = 0
            everPlayed = false
            start()
        }
    }

    private val retry = Runnable {
        if (player == null || currentUrl.isEmpty()) return@Runnable
        val r = refresher
        if (r == null) { restartSame(); return@Runnable }
        val old = currentUrl
        Thread {
            val nu = try { r(old) } catch (e: Exception) { null }
            h.post {
                if (player == null || currentUrl != old) return@post   // ამასობაში სხვა არხი ჩაირთო
                if (nu != null && nu.isNotBlank()) currentUrl = nu.trim()
                restartSame()
            }
        }.start()
    }

    /** ეკრანი ("owner") ცვლის მოვლენების მიმღებს; unlisten(owner) მხოლოდ მაშინ ასუფთავებს, თუ ის ჯერ კიდევ მფლობელია */
    fun listen(owner: Any, loading: () -> Unit, playing: () -> Unit, failed: () -> Unit) {
        this.owner = owner
        onLoading = loading; onPlaying = playing; onFailed = failed
    }

    fun unlisten(owner: Any) {
        if (this.owner === owner) {
            this.owner = null
            onRebuilt = null
            onLoading = {}; onPlaying = {}; onFailed = {}
        }
    }

    /** ქმნის ფლეიერს (თუ ჯერ არ არის); PlayerView-ს მიამაგრეთ დაბრუნებული ობიექტი */
    fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        val renderers = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)
        val selector = DefaultTrackSelector(ctx).apply {
            setParameters(buildUponParameters().setViewportSizeToPhysicalDisplaySize(ctx, true))
        }
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(10_000, 30_000, 1_000, 2_000)
            .build()
        val p = ExoPlayer.Builder(ctx, renderers)
            .setTrackSelector(selector)
            .setLoadControl(load)
            .setWakeMode(androidx.media3.common.C.WAKE_MODE_NETWORK)   // ეკრანი/Wi-Fi არ დაიძინოს დაკვრისას
            .setAudioAttributes(androidx.media3.common.AudioAttributes.Builder().setUsage(androidx.media3.common.C.USAGE_MEDIA).setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
            .setBandwidthMeter(DefaultBandwidthMeter.Builder(ctx).setInitialBitrateEstimate(1_500_000L).build())
            .build()
        p.volume = 1f
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> {
                        h.removeCallbacks(watchdog)
                        h.removeCallbacks(retry)
                        retrying = false
                        everPlayed = true
                        state = PLAYING
                        onPlaying()
                    }
                    Player.STATE_BUFFERING -> {
                        if (!retrying) {
                            state = LOADING
                            onLoading()
                        }
                    }
                    Player.STATE_ENDED -> handleError(null)
                }
            }

            override fun onRenderedFirstFrame() {
                awaitFrame = false
                h.removeCallbacks(frameGuard)
            }

            override fun onPlayerError(error: PlaybackException) {
                handleError(error)
            }
        })
        player = p
        h.removeCallbacks(monitor)
        h.postDelayed(monitor, 500)
        return p
    }

    /** იგივე არხზე განმეორებითი გამოძახება არხს თავიდან აღარ იტვირთავს (თუ არ ჩაშლილა) */
    fun play(newUrl: String) {
        val u = newUrl.trim()
        ensurePlayer()
        if (u == currentUrl && state != FAILED) {
            dispatchState()
            armFrameGuard()
            return
        }
        if (++zaps >= 8) rebuildPlayer(false)   // ყოველ 8 გადართვაზე დეკოდერი სუფთავდება
        currentUrl = u
        cycles = 0
        lastErr = ""
        h.removeCallbacks(retry)
        retrying = false
        attempt = 0
        everPlayed = false
        state = LOADING
        onLoading()
        start()
    }

    /** ახალ ეკრანს ვუცხადებთ, რა მდგომარეობაშია ფლეიერი ახლა */
    fun dispatchState() {
        when (state) {
            PLAYING -> onPlaying()
            FAILED -> onFailed()
            else -> onLoading()
        }
    }

    fun release() {
        h.removeCallbacks(watchdog)
        h.removeCallbacks(retry)
        h.removeCallbacks(frameGuard)
        h.removeCallbacks(monitor)
        retrying = false
        owner = null
        onLoading = {}; onPlaying = {}; onFailed = {}
        player?.release()
        player = null
        currentUrl = ""
        state = LOADING
    }

    /** ფორმატების რიგი ბმულის მიხედვით: null = ავტომატური ამოცნობა */
    private fun formats(): List<String?> {
        val l = currentUrl.lowercase()
        return when {
            l.contains("m3u8") -> listOf(MimeTypes.APPLICATION_M3U8, null, MimeTypes.VIDEO_MP2T)
            TS_REGEX.containsMatchIn(l) -> listOf(MimeTypes.VIDEO_MP2T, MimeTypes.APPLICATION_M3U8, null)
            else -> listOf(null, MimeTypes.APPLICATION_M3U8, MimeTypes.VIDEO_MP2T)
        }
    }

    private fun spec(a: Int): Pair<String?, String> {
        val f = formats()
        return when (a) {
            0 -> Pair(f[0], UA_VLC)
            1 -> Pair(f[1], UA_VLC)
            2 -> Pair(f[2], UA_VLC)
            else -> Pair(f[0], UA_BROWSER)
        }
    }

    private fun start() {
        val p = player ?: return
        val (fmt, ua) = spec(attempt)
        val builder = MediaItem.Builder().setUri(currentUrl)
        if (fmt != null) builder.setMimeType(fmt)
        val item = builder.build()
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8000)
            .setReadTimeoutMs(12000)
        val dsf = DefaultDataSource.Factory(ctx, http)
        val source: MediaSource = if (fmt == MimeTypes.APPLICATION_M3U8) {
            HlsMediaSource.Factory(dsf).setAllowChunklessPreparation(true).createMediaSource(item)
        } else {
            DefaultMediaSourceFactory(dsf).createMediaSource(item)
        }
        p.setMediaSource(source)
        p.prepare()
        p.playWhenReady = true
        h.removeCallbacks(watchdog)
        h.postDelayed(watchdog, START_TIMEOUT_MS)
    }

    private fun isParseError(e: PlaybackException?): Boolean {
        if (e == null) return false
        return e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ||
            e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED
    }

    /** 429/503: ვაცდით სერვერს (Retry-After ან 6, 12, 24, 30 წმ); სხვა შეცდომა: 3 წმ */
    private fun retryDelay(): Long {
        if (lastCode != 429 && lastCode != 503) return RETRY_MS
        if (retryAfterMs > 0) return retryAfterMs.coerceIn(3000L, 60000L)
        return (6000L shl (cycles - 1).coerceIn(0, 2)).coerceAtMost(30000L)
    }

    private fun handleError(e: PlaybackException?) {
        h.removeCallbacks(watchdog)
        lastCode = 0; retryAfterMs = 0L
        (e?.cause as? androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException)?.let { c ->
            lastCode = c.responseCode
            val ra = c.headerFields.entries.firstOrNull { it.key.equals("Retry-After", true) }?.value?.firstOrNull()
            retryAfterMs = (ra?.trim()?.toLongOrNull() ?: 0L) * 1000L
        }
        lastErr = if (e == null) "ვადა გავიდა" else {
            val c = e.cause
            val http = if (c is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) " HTTP " + c.responseCode else ""
            e.errorCodeName.removePrefix("ERROR_CODE_") + http
        }
        val p = player ?: return
        if (e != null && e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            p.seekToDefaultPosition()
            p.prepare()
            h.postDelayed(watchdog, START_TIMEOUT_MS)
            return
        }
        if (everPlayed) {
            // ნაკადი გაჩერდა, მაგრამ აქამდე თამაშობდა — ერთხელ თავიდან ვუკავშირდებით
            everPlayed = false
            start()
            return
        }
        // ფორმატის შეცდომისას ვცდით შემდეგ ფორმატს; კავშირის/სერვერის შეცდომისას — ბრაუზერის სათაურს
        val next = when {
            attempt >= 3 -> -1
            lastCode == 429 || lastCode == 503 -> -1   // სერვერი ზღუდავს მოთხოვნებს: ზედმეტ მოთხოვნას აღარ ვუშვებთ
            isParseError(e) && attempt < 2 -> attempt + 1
            else -> 3
        }
        if (next < 0) {
            try { p.stop() } catch (ex: Exception) { }
            state = FAILED
            cycles++
            retrying = true
            onFailed()
            // იგივე არხს რამდენიმე წამში თავიდან ვცდით; სხვა არხზე არასოდეს გადადის
            h.removeCallbacks(retry)
            h.postDelayed(retry, retryDelay())
            return
        }
        attempt = next
        start()
    }
}

/** ერთი საერთო ფლეიერი მთელ აპლიკაციაზე */
object StreamHub {
    private var c: StreamController? = null

    fun get(ctx: Context): StreamController =
        c ?: StreamController(ctx.applicationContext).also {
            val app = ctx.applicationContext
            it.refresher = { u -> ChannelRefresher.refresh(app, u) }
            c = it
        }

    fun peek(): StreamController? = c

    fun release() {
        c?.release()
        c = null
    }
}
