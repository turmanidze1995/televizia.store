package store.televizia.app

import android.animation.ValueAnimator
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Timeline
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * სრული ეკრანის ფლეიერი.
 * შეხება/გადასმა (ტელეფონი): შეხება → მართვა (გადახვევა, პაუზა, LIVE), ზევით/მარცხნივ გადასმა → შემდეგი არხი,
 *   ქვევით/მარჯვნივ → წინა არხი, ორმაგი შეხება → ეკრანზე მორგება (ჩატევა / გაშლა / გაჭიმვა).
 * TV პულტი: OK / MENU / GUIDE / EPG / RED / GREEN → ორმხრივი პანელი (მარცხნივ არხები, მარჯვნივ ტელეპროგრამა —
 *   ზუსტად როგორც მთავარ ეკრანზე), CH+/CH− (P▲/P▼) და ↑/↓ → არხის გადართვა, ციფრები 0–9, LAST/DEL → წინა არხი,
 *   INFO/YELLOW → ინფო, BLUE → პანელის დახურვა, ◀◀ / ▶▶ და ←/→ → გადახვევა ±10 წმ (მართვის პანელის გარეშე),
 *   ⏯ → პაუზა, STOP → გასვლა, SUBTITLE → სუბტიტრები, AUDIO → ხმოვანი არხი, ზომის ღილაკი → ეკრანზე მორგება,
 *   BACK / EXIT → პანელი ან გასვლა.
 * ტელეფონზე ქვედა მართვის პანელი (−10 წმ, პაუზა, LIVE, მორგება, არხები, პროგრამა) ინარჩუნებს მუშაობას.
 */
class PlayerActivity : BaseActivity() {
    private val h = Handler(Looper.getMainLooper())
    private var clockR: Runnable? = null
    private var prevChannel: Channel? = null
    private var seeking = false
    private var resizeIdx = 0
    private var toast: Toast? = null

    private val created = android.os.SystemClock.uptimeMillis()
    private val hideInfo = Runnable {
        infoBar.visibility = View.INVISIBLE
    }
    private val hideControls = Runnable { controls.visibility = View.GONE }
    private val seekTick = object : Runnable {
        override fun run() {
            if (controls.visibility == View.VISIBLE) {
                updateSeek()
                h.postDelayed(this, 500)
            }
        }
    }

    private lateinit var pv: PlayerView
    private lateinit var infoBar: View
    private lateinit var loadingLogo: ImageView
    private lateinit var playerError: TextView
    private var loadAnim: ValueAnimator? = null
    private lateinit var channelsWrap: View
    private lateinit var programsWrap: View
    private lateinit var programsEmpty: TextView
    private lateinit var drawer: RecyclerView
    private lateinit var programList: RecyclerView
    private lateinit var chNum: TextView
    private lateinit var chName: TextView
    private lateinit var chNow: TextView
    private lateinit var chLogo: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var controls: View
    private lateinit var seek: ScrubBar
    private var rngStart = 0L
    private var rngEnd = 1L
    private lateinit var liveTxt: TextView
    private lateinit var btnPlay: TextView
    private lateinit var numBox: View
    private lateinit var numDigits: TextView
    private lateinit var numName: TextView
    private lateinit var numLogo: ImageView
    /** ახლა არქივის (გასული გადაცემის) ბმული თამაშდება; null = პირდაპირი ეთერი */
    private var archiveUrl: String?
        get() = ChannelHolder.current?.let { Timeshift.activeFor(it) }
        set(v) { if (v == null) Timeshift.clear() }
    private lateinit var drawerAdapter: ChannelAdapter
    private val programAdapter = ProgramAdapter(
        onClick = { onProgramClick(it) },
        canPlay = { p -> ChannelHolder.current?.let { Catchup.canPlay(it, p) } == true }
    )
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val resizeNames by lazy {
        arrayOf(getString(R.string.resize_fit), getString(R.string.resize_zoom), getString(R.string.resize_stretch))
    }

    private val isTv: Boolean get() = Device.tv(this)

    private val digits = DigitEntry(
        size = { ChannelHolder.list.size },
        nameAt = { ChannelHolder.list.getOrNull(it)?.name },
        onUpdate = { d, name, valid ->
            numBox.visibility = View.VISIBLE
            numDigits.text = d
            numDigits.setTextColor(if (valid) 0xFF00D9C0.toInt() else 0xFFFF5C72.toInt())
            numName.text = when {
                name != null -> name
                valid -> ""
                else -> getString(R.string.no_such_channel)
            }
            // არხის ლოგო სახელის გვერდით (თუ ლოგო არ აქვს — იგივე სახელის სხვა არხისა, ბოლოს — ინიციალები)
            val chn = if (valid) d.toIntOrNull()?.let { ChannelHolder.list.getOrNull(it - 1) } else null
            if (chn != null) {
                numLogo.visibility = View.VISIBLE
                ImageLoader.show(logoOf(chn), numLogo, chn.name)
            } else {
                numLogo.visibility = View.GONE
            }
        },
        onCommit = { pos -> ChannelHolder.list.getOrNull(pos)?.let { ChannelHolder.markPos(pos); playChannel(it) } },
        onClose = { numBox.visibility = View.GONE }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ჭრილის (notch) ქვეშაც ვიდეო სრულ ეკრანზე
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_player)
        val url = intent.getStringExtra("url") ?: run { finish(); return }

        pv = findViewById(R.id.playerView)
        QrOverlay.attach(pv)   // პატარა QR (საიტი) ვიდეოს კუთხეში
        infoBar = findViewById(R.id.infoBar)
        loadingLogo = findViewById(R.id.loadingLogo)
        playerError = findViewById(R.id.playerError)
        channelsWrap = findViewById(R.id.channelsWrap)
        programsWrap = findViewById(R.id.programsWrap)
        programsEmpty = findViewById(R.id.programsEmpty)
        drawer = findViewById(R.id.drawer)
        programList = findViewById(R.id.programList)
        chNum = findViewById(R.id.chNum)
        chName = findViewById(R.id.chName)
        chNow = findViewById(R.id.chNow)
        chLogo = findViewById(R.id.chLogo)
        progress = findViewById(R.id.progress)
        controls = findViewById(R.id.controls)
        seek = findViewById(R.id.seek)
        liveTxt = findViewById(R.id.liveTxt)
        btnPlay = findViewById(R.id.btnPlay)
        numBox = findViewById(R.id.numBox)
        numDigits = findViewById(R.id.numDigits)
        numName = findViewById(R.id.numName)
        numLogo = findViewById(R.id.numLogo)

        // ჭრილი / სისტემური ზოლები: ყველა წარწერა უსაფრთხო ზონაში ჩანს, ვიდეო კი მთელ ეკრანზეა
        val overlays = findViewById<View>(R.id.overlays)
        ViewCompat.setOnApplyWindowInsetsListener(overlays) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            insets
        }

        // ეკრანის ზომაზე მორგება (პატარა ტელეფონზეც ყველაფერი ეტევა)
        val dm = resources.displayMetrics
        loadingLogo.layoutParams = loadingLogo.layoutParams.apply { width = minOf((520 * dm.density).toInt(), (dm.widthPixels * 0.55f).toInt()) }
        // TV: ორივე პანელი ერთდროულად — არხები მარცხნივ, ტელეპროგრამა მარჯვნივ (როგორც მთავარ ეკრანზე)
        applyPanelLayout()

        pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        val exit = findViewById<View>(R.id.btnExit)
        exit.visibility = if (isTv) View.GONE else View.VISIBLE
        exit.setOnClickListener { finish() }

        drawerAdapter = ChannelAdapter { ch, p ->
            ChannelHolder.markPos(p)
            playChannel(ch)
            showPanel(null)
        }
        drawer.layoutManager = LinearLayoutManager(this)
        drawer.setHasFixedSize(true)
        drawer.adapter = drawerAdapter
        drawerAdapter.submit(ChannelHolder.list)
        programList.layoutManager = LinearLayoutManager(this)
        programList.adapter = programAdapter

        setupTouch()
        setupControls()

        // მიმდინარე არხი: უკვე არჩეული (სიიდან) ან მხოლოდ ბმული
        if (ChannelHolder.current == null || ChannelHolder.current?.url != url) {
            ChannelHolder.current = ChannelHolder.list.firstOrNull { it.url == url } ?: Channel("", "", url, "")
        }
        updateChannelUi(ChannelHolder.current!!)
        showInfo()
        flashInfo()
    }

    override fun onStart() {
        super.onStart()
        if (!::pv.isInitialized) return
        val ch = ChannelHolder.current ?: return
        val sc = StreamHub.get(this)
        sc.listen(
            this,
            loading = { startLoadAnim() },
            playing = {
                stopLoadAnim()
                playerError.visibility = View.GONE
                btnPlay.text = if (sc.player?.playWhenReady == false) getString(R.string.resume) else getString(R.string.pause)
            },
            failed = {
                // არხი ვერ გაიხსნა: მხოლოდ შეტყობინება, სხვა არხზე თავისით არ გადავდივართ
                stopLoadAnim()
                playerError.text = getString(R.string.channel_off)
                playerError.visibility = View.VISIBLE
            }
        )
        sc.detachVideo()
        pv.player = sc.ensurePlayer()
        sc.host = pv
        sc.player?.addListener(autoFit)
        sc.onRebuilt = { np -> pv.player = np; np.addListener(autoFit) }
        sc.player?.videoSize?.let { applyAutoFit(it.width, it.height, it.pixelWidthHeightRatio) }
        sc.play(if (Timeshift.isArchive(sc.currentUrl)) sc.currentUrl else ch.url)   // იგივე არხი უკვე თამაშობს (სიიდან) → თავიდან აღარ იტვირთება
        clockR = Ui.startClock(findViewById<TextView>(R.id.clock), h) {
            if (infoBar.visibility == View.VISIBLE) showInfo()
        }
        scheduleListSync()
    }

    // არხების სიის ავტომატური განახლება სრულ ეკრანზეც (app.auto_refresh_min, ნაგულისხმევი 3 წუთი; 0 = გამორთული)
    private var liveCfgSig = ""
    private val listSyncRunnable = Runnable {
        if (!isFinishing && !isDestroyed) {
            if (!AdGate.showing) {
                Gate.check(this, {}) { val sig = RemoteConfig.json.toString(); if (sig != liveCfgSig) { liveCfgSig = sig; QrOverlay.attach(pv) } }
                AdGate.refresh(this, force = true)
            }
            ChannelRefresher.liveTick(this, RemoteConfig.i("app.auto_refresh_min", 3).coerceIn(1, 60) * 60_000L) { if (!isFinishing && !isDestroyed) drawerAdapter.submit(ChannelHolder.list) }
            scheduleListSync()
        }
    }

    private fun scheduleListSync() {
        h.removeCallbacks(listSyncRunnable)
        val ms = if (RemoteConfig.i("app.auto_refresh_min", 3) <= 0) 0L else RemoteConfig.i("app.live_check_sec", 30).coerceIn(10, 300) * 1000L
        if (ms > 0) h.postDelayed(listSyncRunnable, ms)
    }

    override fun onStop() {
        super.onStop()
        if (!::pv.isInitialized) return
        h.removeCallbacks(listSyncRunnable)
        h.removeCallbacks(hideControls)
        h.removeCallbacks(seekTick)
        clockR?.let { h.removeCallbacks(it) }
        clockR = null
        digits.cancel()
        StreamHub.peek()?.player?.removeListener(autoFit)
        pv.player = null
        StreamHub.peek()?.releaseHost(pv)
        StreamHub.peek()?.unlisten(this)
        // Home-ზე გასვლისას ფლეიერს ვთიშავთ; უკან დაბრუნებისას (finish) ის სიას რჩება
        if (!isFinishing && !isChangingConfigurations) StreamHub.release()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ---------- შეხება და მართვა ----------

    private fun setupTouch() {
        pv.setOnTouchListener(SwipeTouch(this, onTap = {
            if (anyPanelVisible()) showPanel(null) else { toggleControls(); showInfo(); flashInfo() }
        }, onDouble = { }, onSwipe = { next -> step(if (next) 1 else -1) }))
    }

    private fun setupControls() {
        findViewById<View>(R.id.btnBack).setOnClickListener { seekBy(-10_000); keepControls() }
        findViewById<View>(R.id.btnFwd).setOnClickListener { seekBy(10_000); keepControls() }
        findViewById<View>(R.id.btnLive).setOnClickListener { goLive(); keepControls() }
        btnPlay.setOnClickListener { togglePlay(); keepControls() }
        findViewById<View>(R.id.btnChannels).setOnClickListener { hideControlsNow(); showPanel(channelsWrap) }
        findViewById<View>(R.id.btnGuide).setOnClickListener { hideControlsNow(); showPanel(programsWrap) }
        // YouTube-ის სტილის ზოლი: თითით გადაათრევ, გაშვებისას იმ დროზე გადადის (ეთერის ფანჯარაში ან არქივიდან)
        seek.labelFor = { f -> Ui.mmss(((rngEnd - rngStart) * f).toLong()) }
        seek.onStart = {
            seeking = true
            h.removeCallbacks(hideControls)
            val w = Timeshift.wallMs(StreamHub.peek())
            val (st, en, _) = Timeshift.range(ChannelHolder.current, w)
            rngStart = st; rngEnd = if (en <= st) st + 1 else en
        }
        seek.onCommit = { f ->
            seeking = false
            val target = rngStart + ((rngEnd - rngStart) * f).toLong()
            if (!Timeshift.seekToWall(this, target)) flash(getString(R.string.seek_unavailable))
            keepControls()
        }
    }

    private fun showControls() {
        if (isTv) return   // TV-ზე −10/+10/პაუზა პანელი არ გვაქვს
        controls.visibility = View.VISIBLE
        updateSeek()
        h.removeCallbacks(seekTick)
        h.postDelayed(seekTick, 500)
        keepControls()
    }

    private fun keepControls() {
        h.removeCallbacks(hideControls)
        h.postDelayed(hideControls, 6000)
    }

    private fun hideControlsNow() {
        h.removeCallbacks(hideControls)
        controls.visibility = View.GONE
    }

    private fun toggleControls() {
        if (controls.visibility == View.VISIBLE) hideControlsNow() else showControls()
    }

    /** ავტომატური მორგება: ეკრანთან თითქმის თანაბარი ფორმატი — ეკრანს ავსებს, დანარჩენი — მთლიანად ჩანს (ზოლებით) */
    private val autoFit = object : Player.Listener {
        override fun onVideoSizeChanged(videoSize: VideoSize) {
            applyAutoFit(videoSize.width, videoSize.height, videoSize.pixelWidthHeightRatio)
        }
    }

    private fun applyAutoFit(w: Int, hgt: Int, par: Float) {
        if (w <= 0 || hgt <= 0) return
        val dm = resources.displayMetrics
        val video = w * par / hgt
        val screen = dm.widthPixels.toFloat() / dm.heightPixels
        val diff = Math.abs(video - screen) / screen
        // ვიწრო ნაკადი (4:3, 5:4): გამოსახულებას 16:9 კადრზე ვჭიმავთ, როგორც სხვა არხებს
        if (video < 1.70f) {
            val cf = pv.findViewById<AspectRatioFrameLayout>(resources.getIdentifier("exo_content_frame", "id", packageName))
            cf?.setAspectRatio(maxOf(dm.widthPixels, dm.heightPixels).toFloat() / minOf(dm.widthPixels, dm.heightPixels))   // ვიწრო ნაკადი ეკრანს ავსებს
        }
        pv.resizeMode = if (diff < 0.12f) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
    }

    /** მოკლე შეტყობინება ეკრანზე (წინა შეტყობინება იცვლება, არ გროვდება) */
    private fun flash(msg: String) {
        toast?.cancel()
        toast = Toast.makeText(this, msg, Toast.LENGTH_SHORT).also { it.show() }
    }

    // ---------- სუბტიტრები და ხმოვანი არხი ----------

    private fun trackName(g: androidx.media3.common.Tracks.Group): String {
        val f = g.getTrackFormat(0)
        val lang = f.language?.takeIf { it.isNotBlank() && it != "und" }
            ?.let { java.util.Locale.forLanguageTag(it).getDisplayLanguage(java.util.Locale.forLanguageTag(Lang.current())) }
            ?.takeIf { it.isNotBlank() }
        return f.label?.takeIf { it.isNotBlank() } ?: lang ?: getString(R.string.track_default)
    }

    /** SUBTITLE / SUB.T: გამორთული → 1-ლი → 2-რე … → გამორთული */
    private fun cycleSubtitles() {
        val p = StreamHub.peek()?.player ?: return
        val groups = p.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported }
        if (groups.isEmpty()) { flash(getString(R.string.subs_none)); return }
        val cur = groups.indexOfFirst { it.isSelected }
        val next = cur + 1
        val params = p.trackSelectionParameters.buildUpon()
        if (next >= groups.size) {
            params.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            flash(getString(R.string.subs_off))
        } else {
            params.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .setOverrideForType(TrackSelectionOverride(groups[next].mediaTrackGroup, 0))
            flash(getString(R.string.subs_fmt, trackName(groups[next])))
        }
        p.trackSelectionParameters = params.build()
    }

    /** AUDIO: ციკლურად შემდეგი ხმოვანი არხი */
    private fun cycleAudio() {
        val p = StreamHub.peek()?.player ?: return
        val groups = p.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported }
        if (groups.size < 2) { flash(getString(R.string.audio_none)); return }
        val cur = groups.indexOfFirst { it.isSelected }.coerceAtLeast(0)
        val next = (cur + 1) % groups.size
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(groups[next].mediaTrackGroup, 0))
            .build()
        flash(getString(R.string.audio_fmt, trackName(groups[next])))
    }

    // ---------- გადახვევა ----------

    private fun behindLiveMs(p: androidx.media3.exoplayer.ExoPlayer): Long = Timeshift.behindLiveMs(p)

    private fun updateSeek() {
        val sc = StreamHub.peek() ?: return
        val p = sc.player ?: return
        val inArchive = Timeshift.isArchive(sc.currentUrl)
        val behind = if (inArchive) (System.currentTimeMillis() - Timeshift.wallMs(sc)).coerceAtLeast(0) else behindLiveMs(p)
        if (!seeking) {
            // ზოლი = იმ გადაცემის დიაპაზონი, რომელშიც ახლა ვართ (EPG-ის გარეშე — ბოლო 2 საათი); ეთერში წრე ბოლოშია
            val w = Timeshift.wallMs(sc)
            val (st, en, _) = Timeshift.range(ChannelHolder.current, w)
            rngStart = st; rngEnd = if (en <= st) st + 1 else en
            seek.setFraction((w - rngStart).toFloat() / (rngEnd - rngStart).toFloat())
        }
        val live = !inArchive && behind < 4000
        liveTxt.text = if (live) "● LIVE" else "−" + Ui.mmss(behind)
        liveTxt.setTextColor(if (live) 0xFFFF5C72.toInt() else 0xFFFFFFFF.toInt())
        btnPlay.text = if (!p.playWhenReady) getString(R.string.resume) else getString(R.string.pause)
    }

    /** ±ms გადახვევა: ეთერის ფანჯარაში ან (უფრო შორს / ფანჯრის გარეშე) არქივიდან იმავე წუთზე */
    private fun seekBy(ms: Long) {
        if (!Timeshift.seekBy(this, ms)) { flash(getString(R.string.seek_unavailable)); return }
        if (isTv) flash(getString(if (ms < 0) R.string.seek_back else R.string.seek_fwd))
    }

    private fun goLive() {
        Timeshift.goLive(this)   // არქივიდან — ეთერის ბმული; ეთერში — ფანჯრის ბოლო
    }

    private fun togglePlay() {
        StreamHub.peek()?.player?.let {
            it.playWhenReady = !it.playWhenReady
            btnPlay.text = if (it.playWhenReady) getString(R.string.pause) else getString(R.string.resume)
            if (isTv) flash(if (it.playWhenReady) "▶" else "⏸ " + getString(R.string.pause))
        }
    }

    private fun toggleMute() {
        StreamHub.peek()?.player?.let { it.volume = if (it.volume == 0f) 1f else 0f }
    }

    // ---------- არხები ----------

    private fun step(delta: Int) {
        val list = ChannelHolder.list
        if (list.isEmpty()) return
        val ex = ChannelHolder.exactIndex
        val lp = ChannelHolder.lastPos()
        // არხი ვერ მოიძებნა (-1) → ადრე 1-ელ არხზე (QR) გადადიოდა; ახლა ბოლო ცნობილი პოზიციიდან გრძელდება
        val base = when {
            ex >= 0 -> ex
            lp in list.indices -> lp
            delta > 0 -> -1
            else -> 0
        }
        val pos = Math.floorMod(base + delta, list.size)
        ChannelHolder.markPos(pos)
        playChannel(list[pos])
    }

    private fun playChannel(ch: Channel) {
        val cur = ChannelHolder.current
        if (cur != null && cur.url != ch.url) prevChannel = cur
        ChannelHolder.current = ch
        archiveUrl = null
        Store.setLastUrl(this, ch.url)
        playerError.visibility = View.GONE
        startLoadAnim()
        AdGate.run(this, ch.url) { StreamHub.get(this).play(ch.url) }
        updateChannelUi(ch)
        showInfo()
        flashInfo()
    }

    /** გადაცემაზე დაჭერა/OK: გასული — არქივი, მიმდინარე — პირდაპირ ეთერი */
    private fun onProgramClick(p: Program) {
        val ch = ChannelHolder.current ?: return
        val t = System.currentTimeMillis()
        when {
            t >= p.start && t < p.stop -> { archiveUrl = null; playerError.visibility = View.GONE; startLoadAnim(); StreamHub.get(this).play(ch.url); showPanel(null) }
            p.start > t -> flash("ეს გადაცემა ჯერ არ დაწყებულა")
            Catchup.canPlay(ch, p) -> {
                playerError.visibility = View.GONE
                startLoadAnim()
                Timeshift.playProgram(this, ch, p)
                showPanel(null)
                flash("📼 ${Ui.timeOf(p.start)} ${p.title}")
            }
            else -> flash("ამ გადაცემის არქივი მიუწვდომელია")
        }
    }

    private fun updateChannelUi(ch: Channel) {
        drawerAdapter.select(ch.url)
        val list = Epg.schedule(ch)
        programAdapter.submit(list)
        (programList.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager)
            ?.scrollToPositionWithOffset(programAdapter.liveIndex(), 0)
        programsEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        programList.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        findViewById<TextView>(R.id.programsTitle).text = getString(R.string.programs_title, ch.name)
    }

    /** ჩატვირთვისას: TELEVIZIA.STORE ლოგო ფერებში ციმციმებს */
    private fun startLoadAnim() {
        loadingLogo.visibility = View.VISIBLE
        if (loadAnim != null) return
        val cm = ColorMatrix()
        loadAnim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { va ->
                val d = va.animatedValue as Float
                cm.setRotate(2, d * 0.3f)
                loadingLogo.colorFilter = ColorMatrixColorFilter(cm)
                loadingLogo.alpha = 0.55f + 0.45f * Math.abs(Math.sin(Math.toRadians(d.toDouble()))).toFloat()
            }
            start()
        }
    }

    private fun stopLoadAnim() {
        loadAnim?.cancel()
        loadAnim = null
        loadingLogo.colorFilter = null
        loadingLogo.alpha = 1f
        loadingLogo.visibility = View.GONE
    }

    /** პანელების ზომა და ადგილი: TV — ორივე ერთდროულად (არხები მარცხნივ, პროგრამა მარჯვნივ); ტელეფონი — მარჯვნივ */
    private fun applyPanelLayout() {
        val dm = resources.displayMetrics
        val tv = isTv
        val panelW = if (tv) minOf((480 * dm.density).toInt(), (dm.widthPixels * 0.42f).toInt())
        else minOf((420 * dm.density).toInt(), (dm.widthPixels * 0.62f).toInt())
        channelsWrap.layoutParams = (channelsWrap.layoutParams as FrameLayout.LayoutParams).apply {
            width = panelW
            gravity = if (tv) Gravity.START else Gravity.END
        }
        programsWrap.layoutParams = programsWrap.layoutParams.apply { width = panelW }
    }

    /** TV: ნებისმიერი პანელის მოთხოვნა ორივეს ხსნის (მარცხნივ არხები + მარჯვნივ პროგრამა); ტელეფონზე — მხოლოდ არჩეულს */
    private fun showPanel(panel: View?) {
        if (isTv && panel != null) { finish(); return }   // TV: OK/მენიუ → მთავარი ეკრანი (კატეგორიები + არხები)
        applyPanelLayout()
        val both = isTv && panel != null
        channelsWrap.visibility = if (panel === channelsWrap || both) View.VISIBLE else View.GONE
        programsWrap.visibility = if (panel === programsWrap || both) View.VISIBLE else View.GONE
        if (channelsWrap.visibility == View.VISIBLE) {
            drawerAdapter.select(ChannelHolder.current?.url ?: "")
            val idx = ChannelHolder.index.coerceAtLeast(0)
            (drawer.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, (120 * resources.displayMetrics.density).toInt())
            if (isTv) focusDrawerItem(idx, 4)
        }
        if (programsWrap.visibility == View.VISIBLE) {
            ChannelHolder.current?.let { updateChannelUi(it) }
        }
    }

    /** პულტით: ფოკუსი მიმდინარე არხზე, რომ OK/↑↓ მაშინვე იმუშაოს და ჩანდეს სად ხარ */
    private fun focusDrawerItem(idx: Int, retries: Int) {
        drawer.postDelayed({
            if (channelsWrap.visibility != View.VISIBLE) return@postDelayed
            val v = drawer.findViewHolderForAdapterPosition(idx)?.itemView
            if (v != null) v.requestFocus() else if (retries > 0) focusDrawerItem(idx, retries - 1)
        }, 60)
    }

    private fun togglePanel(panel: View) {
        showPanel(if (panel.visibility == View.VISIBLE) null else panel)
    }

    private fun anyPanelVisible() =
        channelsWrap.visibility == View.VISIBLE || programsWrap.visibility == View.VISIBLE

    private fun flashInfo() {
        infoBar.visibility = View.VISIBLE

        h.removeCallbacks(hideInfo)
        h.postDelayed(hideInfo, 6000)
    }

    private fun logoOf(ch: Channel): String = ChannelHolder.logoOf(ch)

    private fun showInfo() {
        val ch = ChannelHolder.current ?: return
        val idx = ChannelHolder.index
        chNum.text = if (idx >= 0) (idx + 1).toString() else ""
        chName.text = ch.name
        ImageLoader.show(logoOf(ch), chLogo, ch.name)
        val now = Epg.now(ch)
        val next = Epg.next(ch)
        chNow.text = when {
            now == null -> ""
            next == null -> "${Ui.timeOf(now.start)}  ${now.title}"
            else -> "${Ui.timeOf(now.start)}  ${now.title}  →  ${Ui.timeOf(next.start)}  ${next.title}"
        }
        val hasEpg = now != null
        chNow.visibility = if (hasEpg) View.VISIBLE else View.GONE
        progress.visibility = if (hasEpg) View.VISIBLE else View.GONE
        progress.progress = Ui.progressOf(now)
        if (infoBar.visibility != View.VISIBLE) flashInfo()
    }

    // ---------- პულტი ----------

    /**
     * TV: ←↑→↓ და ◀◀ ▶▶ — არხის გადართვა (↑ → შემდეგი, ↓ ← წინა). პაუზაზე ←/→ და ◀◀/▶▶ გადაახვევს ±10 წმ.
     * ტელეფონზე (კლავიატურა): ←/→ და ◀◀/▶▶ — გადახვევა, ↑/↓ — ფოკუსი.
     */
    private fun zapOrSeek(next: Boolean, rep: Boolean) {
        val pl = StreamHub.peek()?.player
        // გადახვევა მხოლოდ პაუზაზე და მხოლოდ თუ ნაკადი გადახვევადია; სხვა შემთხვევაში (მაგ. QR არხი) ყოველთვის არხი იცვლება
        val paused = pl?.playWhenReady == false && (pl.isCurrentMediaItemSeekable || ChannelHolder.current?.let { Catchup.has(it) } == true)
        if (paused) seekBy(if (next) 10_000 else -10_000)
        else if (!rep) step(if (next) 1 else -1)
    }

    private fun toggleInfo() {
        if (infoBar.visibility == View.VISIBLE) infoBar.visibility = View.INVISIBLE else { showInfo(); flashInfo() }
    }

    /** მორგებული (შესწავლილი) ღილაკის მოქმედება */
    private fun performAction(a: KeyMap.Act, rep: Boolean) {
        when (a) {
            KeyMap.Act.NEXT_CH -> if (!rep) step(1)
            KeyMap.Act.PREV_CH -> if (!rep) step(-1)
            KeyMap.Act.PANEL -> if (!rep) togglePanel(channelsWrap)
            KeyMap.Act.GUIDE -> if (!rep) togglePanel(programsWrap)
            KeyMap.Act.INFO -> if (!rep) toggleInfo()
            KeyMap.Act.SUBS -> if (!rep) cycleSubtitles()
            KeyMap.Act.AUDIO -> if (!rep) cycleAudio()
            KeyMap.Act.ASPECT -> {}
            KeyMap.Act.LAST -> if (!rep) prevChannel?.let { playChannel(it) }
            KeyMap.Act.PAUSE -> if (!rep) togglePlay()
            KeyMap.Act.SEEK_BACK -> seekBy(-10_000)
            KeyMap.Act.SEEK_FWD -> seekBy(10_000)
            KeyMap.Act.FAV -> if (!rep) ChannelHolder.current?.let {
                flash(if (UserLists.toggleFav(this, it)) "★ დაემატა ფავორიტებში" else "ამოიღეთ ფავორიტებიდან")
            }
            KeyMap.Act.HIDE, KeyMap.Act.PREV_GROUP, KeyMap.Act.NEXT_GROUP, KeyMap.Act.GROUP_MENU -> {}   // მხოლოდ მთავარ ეკრანზე / TV სრულ ეკრანზე
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (AdGate.showing) return AdGate.key(event)
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val rep = (event?.repeatCount ?: 0) > 0
        // აპლიკაციის გახსნისას პულტის "OK"-ის ბოლო დაჭერა პანელს ნუ გახსნის
        if (isTv && android.os.SystemClock.uptimeMillis() - created < 1500 &&
            (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)) return true
        KeyMap.get(this, keyCode)?.let { performAction(it, rep); return true }
        val handled = when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                if (!rep) step(1); true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if (!rep) step(-1); true
            }
            KeyEvent.KEYCODE_LAST_CHANNEL -> {
                prevChannel?.let { playChannel(it) }
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                togglePlay(); true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (isTv) zapOrSeek(false, rep) else seekBy(-10_000); true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                if (isTv) zapOrSeek(true, rep) else seekBy(10_000); true
            }
            KeyEvent.KEYCODE_MEDIA_STOP -> {
                finish(); true
            }
            KeyEvent.KEYCODE_MUTE -> {
                toggleMute(); true
            }
            KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_PROG_YELLOW -> {
                toggleInfo()
                true
            }
            KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_PROG_GREEN, KeyEvent.KEYCODE_TV_DATA_SERVICE -> {
                togglePanel(programsWrap); true
            }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_PROG_RED, KeyEvent.KEYCODE_TV_CONTENTS_MENU,
            KeyEvent.KEYCODE_SEARCH, KeyEvent.KEYCODE_SETTINGS -> {
                togglePanel(channelsWrap); true
            }
            KeyEvent.KEYCODE_PROG_BLUE -> {
                showPanel(null); true
            }
            KeyEvent.KEYCODE_CAPTIONS -> {   // SUBTITLE / SUB.T
                cycleSubtitles(); true
            }
            KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK -> {   // AUDIO
                cycleAudio(); true
            }
            KeyEvent.KEYCODE_TV_ZOOM_MODE, KeyEvent.KEYCODE_ZOOM_IN -> true   // მორგება ავტომატურია
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {   // BACK / EXIT
                when {
                    digits.active -> digits.cancel()
                    anyPanelVisible() -> showPanel(null)
                    controls.visibility == View.VISIBLE -> hideControlsNow()
                    else -> finish()
                }
                true
            }
            KeyEvent.KEYCODE_DEL -> {   // LAST/DEL
                if (digits.active) digits.cancel() else prevChannel?.let { playChannel(it) }
                true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                // OK: პანელი ღიაა → არხზე ფოკუსი თვითონ დააჭერს; დახურულია → ორმხრივი პანელი
                if (digits.active) digits.commit() else togglePanel(channelsWrap)
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (anyPanelVisible()) false else { if (isTv) zapOrSeek(false, rep) else seekBy(-10_000); true }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (anyPanelVisible()) false else { if (isTv) zapOrSeek(true, rep) else seekBy(10_000); true }
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (anyPanelVisible() || !isTv) false else { zapOrSeek(true, rep); true }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (anyPanelVisible() || !isTv) false else { zapOrSeek(false, rep); true }
            }
            else -> when (keyCode) {
                in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> { digits.digit(keyCode - KeyEvent.KEYCODE_0); true }
                in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> { digits.digit(keyCode - KeyEvent.KEYCODE_NUMPAD_0); true }
                else -> false
            }
        }
        return handled || super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        if (::loadingLogo.isInitialized) stopLoadAnim()
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
