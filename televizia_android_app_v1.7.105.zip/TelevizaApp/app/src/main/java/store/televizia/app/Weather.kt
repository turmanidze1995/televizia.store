package store.televizia.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

/**
 * ამინდის შეტყობინებები (v1.7.105): დღეში 2 პროგნოზი (დილით — დღევანდელი, საღამოთი — ხვალინდელი)
 * და ცვლილებები: წვიმა იწყება/გადაიღებს, ჭექა-ქუხილი, თოვლი, მოიღრუბლება, გამოიდარებს.
 * მონაცემები: $BASE_URL/api/app_weather.php. მუშაობს დახურულ აპზეც (AlarmManager). TV-ზე — ფანჯარა (როგორც შეხსენებები).
 * ჩართვა/გამორთვა სერვერიდან: features.weather; საათები: weather.morning_hour / weather.evening_hour; შემოწმება: weather.check_min.
 */
object WeatherNotify {
    private const val PREFS = "weather"
    private const val CH_INFO = "weather"
    private const val CH_ALERT = "weather_alert"
    const val ACTION = "store.televizia.app.WEATHER_CHECK"

    val cities = listOf(
        "tbilisi" to "თბილისი", "batumi" to "ბათუმი", "kutaisi" to "ქუთაისი", "rustavi" to "რუსთავი", "gori" to "გორი",
        "zugdidi" to "ზუგდიდი", "poti" to "ფოთი", "telavi" to "თელავი", "kobuleti" to "ქობულეთი", "ozurgeti" to "ოზურგეთი",
        "akhaltsikhe" to "ახალციხე", "ambrolauri" to "ამბროლაური", "mtskheta" to "მცხეთა", "sighnaghi" to "სიღნაღი",
        "mestia" to "მესტია", "gudauri" to "გუდაური", "borjomi" to "ბორჯომი", "zestaponi" to "ზესტაფონი", "samtredia" to "სამტრედია",
        "senaki" to "სენაკი", "khashuri" to "ხაშური", "marneuli" to "მარნეული", "tskaltubo" to "წყალტუბო", "chiatura" to "ჭიათურა",
        "lanchkhuti" to "ლანჩხუთი", "akhalkalaki" to "ახალქალაქი", "bakuriani" to "ბაკურიანი", "stepantsminda" to "სტეფანწმინდა"
    )

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun serverOn(): Boolean = RemoteConfig.b("features.weather", true)
    fun digestOn(ctx: Context) = sp(ctx).getBoolean("digest", true)
    fun changesOn(ctx: Context) = sp(ctx).getBoolean("changes", true)
    fun cityId(ctx: Context): String = sp(ctx).getString("city", "tbilisi") ?: "tbilisi"
    fun cityName(ctx: Context): String = cities.firstOrNull { it.first == cityId(ctx) }?.second ?: "თბილისი"

    fun setDigest(ctx: Context, on: Boolean) { sp(ctx).edit().putBoolean("digest", on).apply(); arm(ctx) }
    fun setChanges(ctx: Context, on: Boolean) { sp(ctx).edit().putBoolean("changes", on).apply(); arm(ctx) }
    fun setCity(ctx: Context, id: String) { sp(ctx).edit().putString("city", id).remove("seen").apply() }

    // ---------- ალარმი ----------
    private fun pi(ctx: Context): PendingIntent {
        val i = Intent(ctx, WeatherReceiver::class.java).setAction(ACTION)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return PendingIntent.getBroadcast(ctx, 7301, i, flags)
    }

    private fun slotMs(hour: Int, dayOffset: Int): Long {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, dayOffset)
        c.set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23)); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun morningH() = RemoteConfig.i("weather.morning_hour", 8)
    private fun eveningH() = RemoteConfig.i("weather.evening_hour", 20)
    private fun checkMs() = RemoteConfig.i("weather.check_min", 30).coerceIn(10, 180) * 60_000L

    /** შემდეგი გაღვიძება: ან მორიგი შემოწმება, ან დილის/საღამოს პროგნოზის დრო — რომელიც უფრო ახლოა */
    fun arm(ctx: Context) {
        try {
            val am = ctx.applicationContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val p = pi(ctx)
            if (!serverOn() || (!digestOn(ctx) && !changesOn(ctx))) { am.cancel(p); return }
            val now = System.currentTimeMillis()
            var at = now + checkMs()
            var exact = false
            if (digestOn(ctx)) {
                for (h in intArrayOf(morningH(), eveningH())) for (d in 0..1) {
                    val s = slotMs(h, d)
                    if (s > now + 5_000L && s < at) { at = s; exact = true }
                }
            }
            val canExact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (Build.VERSION.SDK_INT >= 23) {
                if (exact && canExact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            } else am.set(AlarmManager.RTC_WAKEUP, at, p)
        } catch (_: Exception) {}
    }

    // ---------- მონაცემები ----------
    private fun fetch(ctx: Context): JSONObject? = try {
        val conn = (URL("$BASE_URL/api/app_weather.php?city=" + cityId(ctx)).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 10000
        }
        if (conn.responseCode !in 200..299) null else {
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            if (j.optBoolean("ok")) j else null
        }
    } catch (_: Exception) { null }

    /** ბლოკავს — ფონურ ნაკადში გამოიძახეთ. force=true: პროგნოზს მაშინვე აჩვენებს (ტესტი მენიუდან) */
    fun check(ctx: Context, force: Boolean = false) {
        if (!serverOn() && !force) return
        val j = fetch(ctx) ?: return
        val now = System.currentTimeMillis()
        val p = sp(ctx)
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)

        if (force) {
            post(ctx, 9001, "🌦 " + cityName(ctx) + " — დღეს", j.optString("text_today"), false, window = true)
            return
        }
        // დილის / საღამოს პროგნოზი: სლოტის დროიდან 3 საათში, დღეში ერთხელ თითოეული
        if (digestOn(ctx)) {
            val day = cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR)
            val slots = arrayOf(Triple("m", morningH(), "text_today"), Triple("e", eveningH(), "text_tomorrow"))
            for ((tag, h, field) in slots) {
                val s = slotMs(h, 0)
                val key = "$day$tag"
                if (now >= s && now < s + 3 * 3600_000L && p.getString("digest_$tag", "") != key) {
                    p.edit().putString("digest_$tag", key).apply()
                    val title = "🌦 " + cityName(ctx) + (if (tag == "m") " — დღეს" else " — ხვალ")
                    post(ctx, if (tag == "m") 9101 else 9102, title, j.optString(field), false, window = true)
                }
            }
        }
        // ცვლილებები
        if (changesOn(ctx)) {
            val seen = try { JSONObject(p.getString("seen", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
            val it0 = seen.keys().asSequence().toList()
            for (k in it0) if (now - seen.optLong(k) > 24 * 3600_000L) seen.remove(k)
            val ev = j.optJSONArray("events")
            if (ev != null) for (i in 0 until ev.length()) {
                val e = ev.getJSONObject(i)
                val key = e.optString("key")
                if (key.isEmpty() || seen.has(key)) continue
                val sev = e.optInt("sev", 0)
                if ((hour < 7 || hour >= 23) && sev < 2) continue   // ღამით მხოლოდ ჭექა-ქუხილი
                seen.put(key, now)
                post(ctx, 9200 + (key.hashCode() and 0xFFF), e.optString("title"), e.optString("text"), true, window = true)
            }
            p.edit().putString("seen", seen.toString()).apply()
        }
    }

    // ---------- ჩვენება ----------
    private fun post(ctx: Context, id: Int, title: String, text: String, alert: Boolean, window: Boolean) {
        if (text.isBlank()) return
        notify(ctx, id, title, text, alert)
        if (window && Device.tv(ctx) && (Reminders.foreground > 0 || Reminders.canOverlay(ctx))) {
            try {
                ctx.startActivity(Intent(ctx, WeatherActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    .putExtra("t", title).putExtra("m", text))
            } catch (_: Exception) {}
        }
    }

    private fun notify(ctx: Context, id: Int, title: String, text: String, alert: Boolean) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                if (nm.getNotificationChannel(CH_INFO) == null) nm.createNotificationChannel(NotificationChannel(CH_INFO, "ამინდი (პროგნოზი)", NotificationManager.IMPORTANCE_DEFAULT))
                if (nm.getNotificationChannel(CH_ALERT) == null) nm.createNotificationChannel(NotificationChannel(CH_ALERT, "ამინდი (ცვლილებები, ჭექა-ქუხილი)", NotificationManager.IMPORTANCE_HIGH))
            }
            if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
            val open = if (launch != null) PendingIntent.getActivity(ctx, 7302, launch, flags) else null
            val b = NotificationCompat.Builder(ctx, if (alert) CH_ALERT else CH_INFO)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(if (alert) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
                .setCategory(NotificationCompat.CATEGORY_RECOMMENDATION)
                .setAutoCancel(true)
            if (open != null) b.setContentIntent(open)
            nm.notify(id, b.build())
        } catch (_: Exception) {}
    }

    fun askPermissions(a: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7201)
        } catch (_: Exception) {}
    }

    /** პარამეტრების ფანჯარა (MENU → „ამინდის შეტყობინებები“) */
    fun showSettings(a: Activity) {
        val ctx = a.applicationContext
        val labels = arrayOf("🌦 დილის და საღამოს პროგნოზი (დღეს / ხვალ)", "⚡ ცვლილებები (წვიმა, ჭექა-ქუხილი, მოღრუბლვა)")
        val checked = booleanArrayOf(digestOn(ctx), changesOn(ctx))
        androidx.appcompat.app.AlertDialog.Builder(a)
            .setTitle("ამინდის შეტყობინებები — " + cityName(ctx))
            .setMultiChoiceItems(labels, checked) { _, which, on -> checked[which] = on }
            .setPositiveButton("შენახვა") { _, _ ->
                setDigest(ctx, checked[0]); setChanges(ctx, checked[1])
                if (checked[0] || checked[1]) askPermissions(a)
                android.widget.Toast.makeText(a, if (checked[0] || checked[1]) "ამინდის შეტყობინებები ჩართულია" else "ამინდის შეტყობინებები გამორთულია", android.widget.Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("ქალაქი…") { _, _ -> showCityPicker(a) }
            .setNegativeButton("ტესტი") { _, _ ->
                Thread { check(ctx, force = true) }.start()
                askPermissions(a)
            }
            .show()
    }

    private fun showCityPicker(a: Activity) {
        val ctx = a.applicationContext
        val names = cities.map { it.second }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(a)
            .setTitle("ქალაქი")
            .setSingleChoiceItems(names, cities.indexOfFirst { it.first == cityId(ctx) }.coerceAtLeast(0)) { d, which ->
                setCity(ctx, cities[which].first)
                d.dismiss()
                android.widget.Toast.makeText(a, "ქალაქი: " + cities[which].second, android.widget.Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("დახურვა", null)
            .show()
    }
}

class WeatherReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            WeatherNotify.ACTION -> {
                val pr = goAsync()
                Thread {
                    try { WeatherNotify.check(ctx) } catch (_: Throwable) {}
                    try { WeatherNotify.arm(ctx) } catch (_: Throwable) {}
                    pr.finish()
                }.start()
            }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, "android.intent.action.QUICKBOOT_POWERON" -> WeatherNotify.arm(ctx)
        }
    }
}

/** ამინდის ფანჯარა ტელევიზორზე (პულტითაც იხურება; 25 წმ-ში თვითონ იხურება) */
class WeatherActivity : Activity() {
    private var dlg: android.app.AlertDialog? = null
    private val h = android.os.Handler(android.os.Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        show(intent)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); show(intent) }

    private fun show(i: Intent) {
        dlg?.dismiss()
        val d = android.app.AlertDialog.Builder(this)
            .setTitle(i.getStringExtra("t") ?: "🌦")
            .setMessage(i.getStringExtra("m") ?: "")
            .setPositiveButton("დახურვა") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        dlg = d
        d.show()
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ if (!isFinishing) finish() }, 25_000L)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { dlg?.dismiss() } catch (_: Exception) {}
        super.onDestroy()
    }
}
