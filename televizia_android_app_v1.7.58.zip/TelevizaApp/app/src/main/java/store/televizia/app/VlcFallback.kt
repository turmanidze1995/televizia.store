package store.televizia.app

import android.content.Context
import android.net.Uri
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.FrameLayout
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

/**
 * სარეზერვო ფლეიერი (libVLC): ირთვება მხოლოდ იმ არხზე, რომელსაც ძირითადი ფლეიერი (ExoPlayer) ვერ ხსნის,
 * ხმა არ ესმის, ან ვიდეო/ხმის ფორმატი ტელეფონის დეკოდერს არ აქვს. ძირითადი ფლეიერი და დანარჩენი ფუნქციები არ იცვლება.
 */
class VlcFallback(
    private val ctx: Context,
    private val onPlaying: () -> Unit,
    private val onBuffering: () -> Unit,
    private val onError: () -> Unit
) {
    private var lib: LibVLC? = null
    private var mp: MediaPlayer? = null
    private var sv: SurfaceView? = null
    private var parent: FrameLayout? = null
    private var volumePct = 100

    @Volatile var active = false
        private set

    /** ვიდეოს კონტეინერი (PlayerView-ს overlay); ეკრანის შეცვლისას ახალზე გადადის */
    fun setHost(host: FrameLayout?) {
        detachSurface()
        parent = host
        if (active) attachSurface()
    }

    private fun attachSurface() {
        val p = parent ?: return
        val m = mp ?: return
        val v = SurfaceView(ctx)
        v.setZOrderMediaOverlay(true)
        v.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {}
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                try { m.vlcVout.setWindowSize(width, height) } catch (_: Throwable) {}
            }
            override fun surfaceDestroyed(holder: SurfaceHolder) {}
        })
        p.addView(v, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        sv = v
        try {
            val out = m.vlcVout
            out.setVideoView(v)
            out.attachViews()
        } catch (_: Throwable) {}
    }

    private fun detachSurface() {
        try { mp?.vlcVout?.detachViews() } catch (_: Throwable) {}
        val v = sv
        if (v != null) { try { parent?.removeView(v) } catch (_: Throwable) {} }
        sv = null
    }

    fun start(url: String) {
        stop()
        try {
            val l = lib ?: LibVLC(ctx, arrayListOf("--network-caching=2000", "--live-caching=2000", "--http-reconnect")).also { lib = it }
            val m = MediaPlayer(l)
            mp = m
            m.setEventListener { e ->
                when (e.type) {
                    MediaPlayer.Event.Playing -> onPlaying()
                    MediaPlayer.Event.Vout -> if (e.voutCount > 0) onPlaying()
                    MediaPlayer.Event.Buffering -> if (e.buffering < 100f) onBuffering() else onPlaying()
                    MediaPlayer.Event.EncounteredError, MediaPlayer.Event.EndReached -> onError()
                    else -> {}
                }
            }
            val media = Media(l, Uri.parse(url))
            media.setHWDecoderEnabled(true, false)
            m.media = media
            media.release()
            active = true
            attachSurface()
            m.volume = volumePct
            m.play()
        } catch (t: Throwable) {
            active = false
            onError()
        }
    }

    fun setPaused(paused: Boolean) {
        val m = mp ?: return
        try { if (paused) m.pause() else m.play() } catch (_: Throwable) {}
    }

    fun setVolume(v: Float) {
        volumePct = (v.coerceIn(0f, 1f) * 100).toInt()
        try { mp?.volume = volumePct } catch (_: Throwable) {}
    }

    /** გაჩერება: stop()/release() ფონურ ნაკადში, რომ ეკრანი არ გაჭედოს */
    fun stop() {
        active = false
        val old = mp
        mp = null
        try { old?.setEventListener(null) } catch (_: Throwable) {}
        detachSurface()
        if (old != null) Thread { try { old.stop() } catch (_: Throwable) {}; try { old.release() } catch (_: Throwable) {} }.start()
    }

    fun release() {
        stop()
        val l = lib
        lib = null
        if (l != null) Thread { try { l.release() } catch (_: Throwable) {} }.start()
    }
}
