package store.televizia.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * მრგვალი ჩატვირთვის ინდიკატორი TELEVIZIA.STORE-ის გრადიენტული ფერებით (ტიალი → ლურჯ-ნაცრისფერი → ვარდისფერი).
 * თავისით ბრუნავს, სანამ ხილულია; დამალვისას ანიმაცია ჩერდება.
 */
class GradientSpinner @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x22FFFFFF
    }
    private val rect = RectF()
    private var angle = 0f
    private var sweepAnim = 0f
    private var rotator: ValueAnimator? = null
    private var shader: SweepGradient? = null

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val stroke = minOf(w, h) * 0.11f
        arcPaint.strokeWidth = stroke
        trackPaint.strokeWidth = stroke
        val pad = stroke / 2f + dp(1f)
        rect.set(pad, pad, w - pad, h - pad)
        // გრადიენტი მხოლოდ რკალის სიგრძეზე (270°): თავიდან ტიალი, ბოლოში ვარდისფერი
        shader = SweepGradient(
            w / 2f, h / 2f,
            intArrayOf(0xFF17CDBD.toInt(), 0xFF7F9AB4.toInt(), 0xFFE668AA.toInt(), 0x00E668AA),
            floatArrayOf(0f, 0.38f, 0.75f, 0.76f)
        )
        arcPaint.shader = shader
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val def = dp(72f).toInt() // საშუალო ზომა
        val w = resolveSize(def, widthMeasureSpec)
        val h = resolveSize(def, heightMeasureSpec)
        val s = minOf(w, h)
        setMeasuredDimension(s, s)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawOval(rect, trackPaint)
        canvas.save()
        canvas.rotate(angle, width / 2f, height / 2f)
        canvas.drawArc(rect, 0f, 270f, false, arcPaint)
        canvas.restore()
    }

    private fun startSpin() {
        if (rotator != null) return
        rotator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { angle = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun stopSpin() {
        rotator?.cancel()
        rotator = null
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) startSpin() else stopSpin()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (visibility == VISIBLE && windowVisibility == VISIBLE) startSpin()
    }

    override fun onDetachedFromWindow() {
        stopSpin()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE && this.visibility == VISIBLE) startSpin() else stopSpin()
    }
}
