package store.televizia.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

const val BASE_URL = "https://televizia.store"

/** შესვლის მდგომარეობა (ტოკენი SharedPreferences-ში) */
object Session {
    private const val PREFS = "tv_session"

    fun save(ctx: Context, token: String, name: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("token", token).putString("name", name).apply()
    }

    fun token(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("token", null)

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun plan(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("plan", "") ?: ""

    fun rev(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("rev", "") ?: ""
    fun setRev(ctx: Context, v: String) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("rev", v).apply() }

    fun setPlan(ctx: Context, text: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("plan", text).apply()
    }
}

/** სერვერთან კავშირი (HttpURLConnection, ფონურ ნაკადში გამოიძახება) */
object Api {
    class LoginResult(val ok: Boolean, val message: String, val token: String? = null, val name: String = "")
    class PlaylistResult(val ok: Boolean, val message: String, val body: String = "", val denied: Boolean = false)

    fun login(email: String, password: String): LoginResult = try {
        val body = "email=" + URLEncoder.encode(email, "UTF-8") +
                "&password=" + URLEncoder.encode(password, "UTF-8")
        val conn = (URL("$BASE_URL/api/app.php?action=login").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            ClientId.apply(this)
        }
        conn.outputStream.use { it.write(body.toByteArray()) }
        val text = readAll(conn)
        val j = JSONObject(text)
        if (j.optBoolean("ok")) LoginResult(true, "", j.getString("token"), j.optString("name"))
        else LoginResult(false, loginError(j.optString("error")))
    } catch (e: Exception) {
        LoginResult(false, Lang.s(R.string.err_connection))
    }

    /** მომხმარებლის არხების სია (M3U). denied=true → სერვერმა პირდაპირ უარი თქვა (ვადა გაუვიდა და ა.შ.) */
    fun playlist(token: String): PlaylistResult = try {
        val url = "$BASE_URL/playlist/m3u.php?src=tvapp&token=" + URLEncoder.encode(token, "UTF-8")
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 20000
            ClientId.apply(this)
        }
        val text = readAll(conn)
        val code = conn.responseCode
        when {
            code in 200..299 -> PlaylistResult(true, "", text)
            // მხოლოდ რეალური უარი (ტოკენი/პაკეტი/მოწყობილობა) ითვლება უარად; 429, 5xx, ცარიელი პასუხი — დროებითი შეცდომაა,
            // ამ დროს ძველ სიას და ფლეიერს არ ვეხებით (ადრე ასეთ დროს ეწერა "პაკეტი არ არის აქტიური" და სია იშლებოდა)
            code == 400 || code == 401 || code == 403 || code == 404 || code == 409 || code == 410 ->
                PlaylistResult(false, text.ifBlank { Lang.s(R.string.pkg_inactive) }, denied = true)
            else -> PlaylistResult(false, Lang.s(R.string.err_connection))
        }
    } catch (e: Exception) {
        PlaylistResult(false, Lang.s(R.string.err_connection))
    }

    /** პაკეტები და სატესტო 24 სთ ვადებით -> ერთი ტექსტი მთავარი ეკრანისთვის (null = ვერ მოვიდა) */
    /** სერვერის „ვერსია“ არხების სიისთვის (api/app.php info → rev); ცარიელი = სერვერი ჯერ არ აბრუნებს */
    @Volatile var lastRev: String = ""

    fun planText(token: String): String? = try {
        val conn = (URL("$BASE_URL/api/app.php?action=info&token=" + URLEncoder.encode(token, "UTF-8")).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 10000
            ClientId.apply(this)
        }
        val j = JSONObject(readAll(conn))
        if (!j.optBoolean("ok")) null else {
            lastRev = j.optString("rev", "")
            val parts = ArrayList<String>()
            val pk = j.optJSONArray("packages")
            if (pk != null) for (i in 0 until pk.length()) {
                val o = pk.getJSONObject(i)
                parts.add("📦 " + o.optString("name") + " · " + untilText(o.optString("expires_at")))
            }
            val t = j.optJSONObject("trial")
            if (t != null) parts.add("🎁 " + Lang.s(R.string.trial_24) + " · " + untilText(t.optString("expires_at")))
            parts.joinToString("\n")
        }
    } catch (e: Exception) {
        null
    }

    private fun untilText(raw: String): String {
        val m = Regex("(\\d{4})-(\\d{2})-(\\d{2}) (\\d{2}:\\d{2})").find(raw) ?: return raw
        return Lang.s(R.string.valid_until) + " " + m.groupValues[3] + "." + m.groupValues[2] + "." + m.groupValues[1] + " " + m.groupValues[4]
    }

    private fun readAll(conn: HttpURLConnection): String {
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        return stream?.bufferedReader()?.use { it.readText() } ?: ""
    }

    private fun loginError(code: String): String = when (code) {
        "bad_credentials" -> Lang.s(R.string.err_bad_credentials)
        "no_active_package" -> Lang.s(R.string.err_no_package)
        "no_token" -> Lang.s(R.string.err_no_token)
        else -> Lang.s(R.string.err_login_failed)
    }
}

/**
 * XMLTV პროგრამის სია (EPG).
 * ცარიელი დატოვეთ, თუ არხების სია (M3U) თავად შეიცავს url-tvg="..." ბმულს — მაშინ აპლიკაცია მას თავისით აიღებს.
 * სხვა შემთხვევაში ჩასვით თქვენი პროვაიდერის XMLTV ბმული (.xml ან .xml.gz), მაგ.: "https://example.com/epg.xml.gz"
 */
const val EPG_URL = ""

/** საიტის საადმინო პანელის ნაგულისხმევი მისამართი (აპლიკაციაში შეიძლება შეიცვალოს: ადმინ-ეკრანი → ⚙) */
const val ADMIN_URL = "$BASE_URL/admin/"

/** ლოკალური მეხსიერება: არხების სიის ქეში (აპლიკაცია მყისიერად იხსნება) და ბოლო არხი/პარამეტრები */
/** ფავორიტები და აპლიკაციაში "წაშლილი" არხები (მხოლოდ ამ მოწყობილობაზე; საიტის ბაზას არ ეხება, გასვლისას არ იშლება) */
object UserLists {
    private const val P = "user_lists"
    private var favs: MutableSet<String>? = null
    private var hid: MutableSet<String>? = null
    private fun load(ctx: Context, key: String): MutableSet<String> =
        ctx.applicationContext.getSharedPreferences(P, Context.MODE_PRIVATE).getStringSet(key, emptySet())!!.toMutableSet()
    private fun save(ctx: Context, key: String, v: Set<String>) {
        ctx.applicationContext.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putStringSet(key, HashSet(v)).apply()
    }
    private fun favSet(ctx: Context) = favs ?: load(ctx, "fav").also { favs = it }
    private fun hidSet(ctx: Context) = hid ?: load(ctx, "hidden").also { hid = it }
    fun key(ch: Channel) = ch.name
    fun isFav(ctx: Context, ch: Channel) = key(ch) in favSet(ctx)
    fun isHidden(ctx: Context, ch: Channel) = key(ch) in hidSet(ctx)
    fun hiddenCount(ctx: Context) = hidSet(ctx).size
    /** true = დაემატა ფავორიტებში, false = ამოიშალა */
    fun toggleFav(ctx: Context, ch: Channel): Boolean {
        val s = favSet(ctx)
        val added = s.add(key(ch))
        if (!added) s.remove(key(ch))
        save(ctx, "fav", s)
        return added
    }
    fun hide(ctx: Context, ch: Channel) {
        val s = hidSet(ctx); s.add(key(ch)); save(ctx, "hidden", s)
        val f = favSet(ctx); if (f.remove(key(ch))) save(ctx, "fav", f)
    }
    fun unhideAll(ctx: Context) { hidSet(ctx).clear(); save(ctx, "hidden", emptySet()) }
}

object Store {
    private const val PREFS = "tv_state"
    private const val M3U = "playlist.m3u"

    fun saveM3u(ctx: Context, text: String) {
        try { java.io.File(ctx.filesDir, M3U).writeText(text) } catch (e: Exception) { }
    }

    fun loadM3u(ctx: Context): String? = try {
        val f = java.io.File(ctx.filesDir, M3U)
        if (f.exists() && f.length() > 0) f.readText() else null
    } catch (e: Exception) {
        null
    }

    /** ქეშირებული სიის ასაკი მილიწამებში (-1 = ქეში არ არის) */
    fun m3uAgeMs(ctx: Context): Long = try {
        val f = java.io.File(ctx.filesDir, M3U)
        if (f.exists() && f.length() > 0) System.currentTimeMillis() - f.lastModified() else -1L
    } catch (e: Exception) { -1L }

    fun clear(ctx: Context) {
        try { java.io.File(ctx.filesDir, M3U).delete() } catch (e: Exception) { }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun lastUrl(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("last_url", null)

    fun setLastUrl(ctx: Context, url: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("last_url", url).apply()
    }

    fun lastGroup(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("last_group", null)

    fun setLastGroup(ctx: Context, g: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("last_group", g).apply()
    }

    /** ვიდეოს მორგების რეჟიმი სრულ ეკრანზე: 0 = ჩატევა, 1 = გაშლა (zoom), 2 = გაჭიმვა */
    fun resizeMode(ctx: Context): Int =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("resize", 0)

    fun setResizeMode(ctx: Context, v: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("resize", v).apply()
    }
}

/**
 * აპის „პირადობა“ სერვერისთვის: ვერსია + მოწყობილობის ნომერი (შემთხვევითი, ინახება ტელეფონში; განახლებისას არ იცვლება,
 * წაშლა/ხელახალი ინსტალაციისას ახალი ხდება). სერვერი ამით ითვლის მომხმარებლებს/მოწყობილობებს ვერსიების მიხედვით
 * და ახალი ინსტალაციისას ადმინს აგზავნის შეტყობინებას. პირად მონაცემებს არ შეიცავს.
 */
object ClientId {
    @Volatile var ua: String = "TeleviziaApp"
    @Volatile var did: String = ""

    fun init(ctx: android.content.Context) {
        try {
            val sp = ctx.getSharedPreferences("client_id", android.content.Context.MODE_PRIVATE)
            var id = sp.getString("did", "") ?: ""
            if (id.length < 8) {
                id = java.util.UUID.randomUUID().toString().replace("-", "").take(24)
                sp.edit().putString("did", id).apply()
            }
            val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
            val model = (android.os.Build.MODEL ?: "").replace(Regex("[^A-Za-z0-9 ._-]"), "").take(30)
            did = id
            ua = "TeleviziaApp/$ver (Android ${android.os.Build.VERSION.RELEASE}; $model) TVSDID/$id"
        } catch (e: Exception) {
        }
    }

    /**
     * „ხმა“ სერვერს: აპი დაინსტალირებულია და გაიხსნა (ანგარიშში შესვლის გარეშეც). ფონურ ნაკადში, ჩუმად;
     * ინტერნეტის გარეშე უბრალოდ გამოტოვდება და შემდეგ გახსნისას ისევ სცდის. ერთ მოწყობილობაზე 6 საათში ერთხელ.
     */
    fun ping(ctx: android.content.Context) {
        val app = ctx.applicationContext
        Thread {
            try {
                if (did.length < 8) return@Thread
                val sp = app.getSharedPreferences("client_id", android.content.Context.MODE_PRIVATE)
                val ver = try { app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
                val last = sp.getLong("ping_at", 0L)
                if (sp.getString("ping_ver", "") == ver && System.currentTimeMillis() - last < 6 * 3600_000L) return@Thread
                val body = JSONObject().apply {
                    put("did", did); put("ver", ver)
                    put("model", ((android.os.Build.MANUFACTURER ?: "") + " " + (android.os.Build.MODEL ?: "")).trim())
                    put("android", android.os.Build.VERSION.RELEASE ?: "")
                    put("tv", Device.tv(app))
                }.toString()
                val c = (URL("$BASE_URL/api/app_ping.php").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; doOutput = true; connectTimeout = 8000; readTimeout = 8000
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("User-Agent", ua)
                }
                c.outputStream.use { it.write(body.toByteArray()) }
                if (c.responseCode in 200..299) sp.edit().putLong("ping_at", System.currentTimeMillis()).putString("ping_ver", ver).apply()
                c.disconnect()
            } catch (e: Exception) {
            }
        }.start()
    }

    fun apply(c: HttpURLConnection) {
        c.setRequestProperty("User-Agent", ua)
        if (did.length >= 8) c.setRequestProperty("X-Televizia-Device", did)
    }
}
