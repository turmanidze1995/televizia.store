package store.televizia.app

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import store.televizia.app.databinding.ActivityMainBinding

class MainActivity : BaseActivity() {
    companion object {
        const val ALL = Lang.ALL
        private var autoOpened = false   // პროცესზე ერთხელ: გახსნისას ბოლო არხი სრულ ეკრანზე
    }
    private var autoPending = false

    private lateinit var b: ActivityMainBinding
    private val h = Handler(Looper.getMainLooper())
    private var clockR: Runnable? = null
    private var tickCount = 0
    private var groups: List<String> = emptyList()
    private var group = ALL
    private var current: Channel? = null
    private var started = false
    private var goingFullscreen = false
    private var prevChannel: Channel? = null
    private var offered = false

    private val isTv: Boolean get() = Device.tv(this)
    private val landscape: Boolean by lazy {
        resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    /** TV: OK = არხი იწყება და იხსნება სრულ ეკრანზე. ტელეფონი: პირველი შეხება = გადართვა, ხელახლა იმავეზე = სრული ეკრანი */
    private val channelAdapter = ChannelAdapter { ch, _ ->
        if (isTv) {
            play(ch)
            openFullscreen()
        } else if (ch.url == current?.url) {
            openFullscreen()
        } else {
            play(ch)
        }
    }
    private lateinit var groupAdapter: GroupAdapter
    private val programAdapter = ProgramAdapter(
        onClick = { onProgramClick(it) },
        canPlay = { p -> current?.let { Catchup.canPlay(it, p) } == true }
    )

    private val digits = DigitEntry(
        size = { ChannelHolder.list.size },
        nameAt = { ChannelHolder.list.getOrNull(it)?.name },
        onUpdate = { d, name, valid ->
            b.status.text = when {
                name != null -> "$d · $name"
                valid -> d
                else -> "$d · ${getString(R.string.no_such_channel)}"
            }
        },
        onCommit = { pos ->
            ChannelHolder.list.getOrNull(pos)?.let {
                play(it)
                b.channels.scrollToPosition(pos)
            }
        },
        onClose = { b.status.text = statusText() }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.token(this) == null) {
            goLogin()
            return
        }
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        sizePreview()

        if (savedInstanceState == null && !autoOpened) { autoOpened = true; autoPending = isTv }   // მხოლოდ TV: გახსნისას არხი სრულ ეკრანზე
        applyDeviceButtons()
        showPlan(Session.plan(this))
        refreshPlan()
        b.channels.layoutManager = LinearLayoutManager(this)
        b.channels.setHasFixedSize(true)
        b.channels.setItemViewCacheSize(10)
        b.channels.adapter = channelAdapter

        groupAdapter = GroupAdapter(landscape) { g -> selectGroup(g) }
        b.groups.layoutManager = if (landscape) LinearLayoutManager(this)
        else LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.groups.adapter = groupAdapter

        b.epgList.layoutManager = LinearLayoutManager(this)
        b.epgList.adapter = programAdapter

        // ტელეფონი ვერტიკალურად: ინფო ბლოკზე შეხებით იხსნება/იკეცება მთელი ტელეპროგრამა
        if (!landscape) {
            updateEpgHint()
            b.infoBlock.setOnClickListener {
                b.epgList.visibility = if (b.epgList.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                updateEpgHint()
            }
        }

        b.groupPrev?.setOnClickListener { stepGroup(-1) }
        b.groupNext?.setOnClickListener { stepGroup(1) }
        b.btnKeys?.setOnClickListener { startActivity(Intent(this, KeysActivity::class.java)) }
        b.btnLang.visibility = View.GONE   // ენის არჩევა მხოლოდ შესვლის გვერდზეა

        b.btnFullscreen.setOnClickListener { openFullscreen() }
        // ვიდეოზე: შეხება = სრული ეკრანი, გადასმა = შემდეგი/წინა არხი
        b.preview.setOnTouchListener(SwipeTouch(this, onTap = { openFullscreen() }, onSwipe = { next ->
            stepChannel(if (next) 1 else -1)
        }))
        b.btnLogout.setOnClickListener {
            StreamHub.release()
            Session.clear(this)
            Store.clear(this)
            ChannelHolder.reset()
            Epg.attach(emptyList())
            goLogin()
        }
        if (ChannelHolder.all.isEmpty()) ChannelHolder.group = Store.lastGroup(this) ?: ALL
        loadChannels()
        Gate.check(this) { }
    }

    private fun showPlan(text: String) {
        b.planInfo.text = text
        b.planInfo.visibility = if (text.isBlank()) View.GONE else View.VISIBLE
    }

    private fun refreshPlan() {
        val token = Session.token(this) ?: return
        val app = applicationContext
        Thread {
            val t = Api.planText(token)
            if (t != null) {
                Session.setPlan(app, t)
                runOnUiThread { if (alive()) showPlan(t) }
            }
        }.start()
    }

    /** TV-ზე "პულტი / სრული ეკრანი" არ ჩანს — მხოლოდ მობილურზე */
    private fun applyDeviceButtons() {
        val v = if (isTv) View.GONE else View.VISIBLE
        b.btnLogout.visibility = View.VISIBLE   // TV-ზეც: გასვლა მთავარ ეკრანზე (OK-ით)
        b.btnKeys?.visibility = v
        b.btnFullscreen.visibility = v
        if (isTv) {   // კატეგორიას ←/→ ცვლის; ისრებზე ფოკუსი აღარ გადადის
            b.groupPrev?.isFocusable = false
            b.groupNext?.isFocusable = false
        }
    }

    /** TV: ფოკუსი "გასვლა" ღილაკზე */
    private fun focusLogout() {
        if (b.btnLogout.visibility == View.VISIBLE) b.btnLogout.requestFocus()
    }

    /** ბოლო არხი სრულ ეკრანზე გაიხსნას აპლიკაციის ჩართვისას */
    private fun maybeAutoOpen() {
        if (autoPending && started && current != null && alive()) {
            autoPending = false
            openFullscreen()
        }
    }

    /** TV: ფოკუსი მიმდინარე არხზე (და არა კატეგორიის ისრებზე) */
    private fun focusCurrent(retries: Int) {
        if (!isTv || !::b.isInitialized) return
        focusPosition(ChannelHolder.list.indexOfFirst { it.url == current?.url }, retries)
    }

    private fun focusPosition(pos: Int, retries: Int) {
        if (pos < 0 || !::b.isInitialized) return
        b.channels.scrollToPosition(pos)
        b.channels.postDelayed({
            if (!alive()) return@postDelayed
            val v = b.channels.findViewHolderForAdapterPosition(pos)?.itemView
            v?.requestFocus()
            // სიის ხელახლა აგებისას ფოკუსი ისრებზე გადადიოდა — ვამოწმებთ და საჭიროებისას ვიმეორებთ
            if ((v == null || !v.hasFocus()) && retries > 0) focusPosition(pos, retries - 1)
        }, 120)
    }

    /** TV: ფოკუსი ტელეპროგრამაზე (მიმდინარე გადაცემაზე) */
    private fun focusEpg(retries: Int) {
        if (!::b.isInitialized || (b.epgList.adapter?.itemCount ?: 0) == 0) return
        val idx = programAdapter.liveIndex().coerceAtLeast(0)
        b.epgList.scrollToPosition(idx)
        b.epgList.postDelayed({
            if (!alive()) return@postDelayed
            val v = b.epgList.findViewHolderForAdapterPosition(idx)?.itemView
            v?.requestFocus()
            if ((v == null || !v.hasFocus()) && retries > 0) focusEpg(retries - 1)
        }, 120)
    }

    /** TV: სიის ბოლოდან/თავიდან წრიულად; ←/→ — წინა/შემდეგი კატეგორია. true = დამუშავდა */
    private fun tvListKey(k: Int): Boolean {
        if (!isTv) return false
        val f = currentFocus ?: return false
        val n = ChannelHolder.list.size
        if (n == 0) return false
        if (f === b.btnLogout) {   // გასვლიდან ↑ — არხების სიის ბოლოში
            if (k == KeyEvent.KEYCODE_DPAD_UP) { focusPosition(n - 1, 8); return true }
            return false
        }
        if (f.parent === b.epgList) {   // ტელეპროგრამაში ← არხებზე ბრუნდება
            if (k == KeyEvent.KEYCODE_DPAD_LEFT) { focusCurrent(8); return true }
            if (k == KeyEvent.KEYCODE_DPAD_RIGHT) return true
            return false
        }
        val onArrow = f.id == R.id.groupPrev || f.id == R.id.groupNext
        if (f.parent !== b.channels && !onArrow) return false
        val pos = if (onArrow) -1 else b.channels.getChildAdapterPosition(f)
        when (k) {
            KeyEvent.KEYCODE_DPAD_UP -> if (pos == 0) { focusPosition(n - 1, 8); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> if (pos == n - 1) { if (b.btnLogout.visibility == View.VISIBLE) focusLogout() else focusPosition(0, 8); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> return true   // კატეგორია: წითელი / მწვანე ღილაკი
            KeyEvent.KEYCODE_DPAD_RIGHT -> { focusEpg(8); return true }
        }
        return false
    }

    /** გადახედვის სიმაღლე: 16:9, მაგრამ დაბალ ეკრანზე არა უმეტეს 34%-ისა — სია ყოველთვის საკმარისად ჩანს */
    private fun sizePreview() {
        if (landscape) return
        val dm = resources.displayMetrics
        val byWidth = dm.widthPixels * 9 / 16
        val cap = (dm.heightPixels * 0.34f).toInt()
        val lp = b.previewBox.layoutParams
        lp.height = minOf(byWidth, cap)
        b.previewBox.layoutParams = lp
    }

    override fun onStart() {
        super.onStart()
        if (!::b.isInitialized) return
        started = true
        goingFullscreen = false
        clockR = Ui.startClock(b.clock, h) {
            // ყოველ წუთს გადაცემების სახელები და პროგრესი ახლდება
            if (++tickCount % 6 == 0) {
                channelAdapter.refresh()
                updateEpg(current)
            }
        }
        val sc = StreamHub.get(this)
        sc.listen(
            this,
            loading = {
                b.previewLoading.visibility = View.VISIBLE
                b.previewError.visibility = View.GONE
            },
            playing = {
                b.previewLoading.visibility = View.GONE
                b.previewError.visibility = View.GONE
                b.status.text = statusText()
            },
            failed = {
                b.previewLoading.visibility = View.GONE
                b.previewError.visibility = View.VISIBLE
            }
        )
        b.preview.player = sc.ensurePlayer()
        syncFromHolder()
        current?.let { sc.play(it.url) }
        applyDeviceButtons()
        focusCurrent(5)
        maybeAutoOpen()
    }

    override fun onStop() {
        super.onStop()
        started = false
        clockR?.let { h.removeCallbacks(it) }
        clockR = null
        if (!::b.isInitialized) return
        digits.cancel()
        b.preview.player = null
        StreamHub.peek()?.unlisten(this)
        // სრულ ეკრანზე გადასვლისას ან ეკრანის შებრუნებისას ფლეიერი რჩება; სხვა შემთხვევაში (Home) ვთიშავთ
        if (!goingFullscreen && !isChangingConfigurations) StreamHub.release()
    }

    // ---------- არხების ჩატვირთვა ----------

    private fun alive() = !isFinishing && !isDestroyed

    /** 1) მყისიერად: მეხსიერებიდან ან დისკის ქეშიდან  2) ფონურად: სერვერიდან განახლება */
    private fun loadChannels() {
        val token = Session.token(this) ?: run { goLogin(); return }
        val app = applicationContext

        if (ChannelHolder.all.isNotEmpty()) {
            showChannels(startPlayback = ChannelHolder.current == null)
        } else {
            b.status.text = getString(R.string.channels_loading)
        }

        Thread {
            var m3uText: String? = null
            if (ChannelHolder.all.isEmpty()) {
                val cached = Store.loadM3u(app)
                if (cached != null) {
                    val parsed = M3u.parse(cached)
                    if (parsed.isNotEmpty()) {
                        Epg.attach(parsed)
                        ChannelHolder.all = parsed
                        m3uText = cached
                        runOnUiThread { if (alive()) showChannels(startPlayback = true) }
                    }
                }
            }

            val res = Api.playlist(token)
            if (res.ok && res.body.isNotBlank()) {
                Store.saveM3u(app, res.body)
                val parsed = M3u.parse(res.body)
                if (parsed.isNotEmpty()) {
                    m3uText = res.body
                    val old = ChannelHolder.all
                    val same = old.size == parsed.size &&
                        old.indices.all { old[it].url == parsed[it].url && old[it].name == parsed[it].name && old[it].logo == parsed[it].logo }
                    if (!same) {
                        Epg.attach(parsed)
                        ChannelHolder.all = parsed
                        runOnUiThread { if (alive()) showChannels(startPlayback = ChannelHolder.current == null) }
                    }
                }
            } else if (res.denied) {
                // სერვერმა უარი თქვა (პაკეტი/ვადა) — ძველ სიას აღარ ვტოვებთ
                Store.clear(app)
                ChannelHolder.all = emptyList()
                ChannelHolder.list = emptyList()
                runOnUiThread {
                    if (alive()) {
                        StreamHub.release()
                        channelAdapter.submit(emptyList())
                        b.status.text = res.message
                    }
                }
                return@Thread
            } else if (ChannelHolder.all.isEmpty()) {
                runOnUiThread { if (alive()) b.status.text = res.message }
            }

            startEpg(m3uText)
        }.start()
    }

    /** EPG ცალკე ფონურად (პროცესზე ერთხელ); დასრულებისას სია და პროგრამა ახლდება */
    private fun startEpg(m3uText: String?) {
        if (ChannelHolder.epgStarted) return
        ChannelHolder.epgStarted = true
        val app = applicationContext
        val urls = if (m3uText != null) M3u.epgUrls(m3uText) else emptyList()
        val ok = Epg.load(app, urls, ChannelHolder.all)
        if (ok) {
            runOnUiThread {
                if (alive()) {
                    channelAdapter.refresh()
                    updateEpg(current)
                }
            }
        } else {
            ChannelHolder.epgStarted = false   // შემდეგ გახსნაზე ისევ ვცადოთ
        }
    }

    private fun showChannels(startPlayback: Boolean) {
        val all = ChannelHolder.all
        groups = listOf(ALL) + all.map { it.group }.distinct()
        group = if (ChannelHolder.group in groups) ChannelHolder.group else ALL
        groupAdapter.submit(groups, group)
        applyFilter()
        if (startPlayback) {
            val last = Store.lastUrl(this)
            val ch = ChannelHolder.list.firstOrNull { it.url == last }
                ?: all.firstOrNull { it.url == last }
                ?: ChannelHolder.list.firstOrNull()
            if (ch != null) {
                play(ch)
                val pos = ChannelHolder.list.indexOfFirst { it.url == ch.url }
                if (pos >= 0) b.channels.scrollToPosition(pos)
                focusCurrent(5)
                maybeAutoOpen()
            }
        } else {
            syncFromHolder()
        }
    }

    private fun selectGroup(g: String) {
        group = g
        ChannelHolder.group = g
        Store.setLastGroup(this, g)
        groupAdapter.submit(groups, group)
        applyFilter()
    }

    private fun applyFilter() {
        ChannelHolder.group = group
        val shown = if (group == ALL) ChannelHolder.all else ChannelHolder.all.filter { it.group == group }
        ChannelHolder.list = shown
        updateGroupHeader()
        channelAdapter.submit(shown)
        current?.let { channelAdapter.select(it.url) }
        b.status.text = statusText()
    }

    private fun statusText(): String {
        val n = ChannelHolder.list.size
        return if (landscape) {
            getString(R.string.status_land, n, groups.indexOf(group).coerceAtLeast(0) + 1, groups.size.coerceAtLeast(1))
        } else {
            getString(R.string.status_portrait, Lang.group(group), n)
        }
    }

    /** ლანდშაფტში: კატეგორიის სახელი გადამრთველში */
    private fun updateGroupHeader() {
        b.groupTitle?.text = Lang.group(group)
    }

    private fun stepGroup(delta: Int) {
        if (groups.isEmpty()) return
        val i = Math.floorMod(groups.indexOf(group) + delta, groups.size)
        selectGroup(groups[i])
    }

    /** ტელეფონი ვერტიკალურად: წარწერა "▾ ტელეპროგრამა" არხის ქვემოთ (ღია პროგრამაზე ▴ და გამოყოფილია) */
    private fun updateEpgHint() {
        val hint = b.epgHint ?: return
        val open = b.epgList.visibility == View.VISIBLE
        hint.text = (if (open) "▴ " else "▾ ") + getString(R.string.programs_hint)
        hint.isSelected = open
        hint.setTextColor(if (open) 0xFFFFFFFF.toInt() else 0xFF00F0D4.toInt())
    }

    private fun nameLabel(ch: Channel): String =
        if (landscape) getString(R.string.programs_title, ch.name) else ch.name

    // ---------- დაკვრა ----------

    private fun play(ch: Channel) {
        val old = current
        if (old != null && old.url != ch.url) prevChannel = old
        current = ch
        ChannelHolder.current = ch
        Store.setLastUrl(this, ch.url)
        b.nowName.text = nameLabel(ch)
        channelAdapter.select(ch.url)
        b.btnFullscreen.isEnabled = true
        updateEpg(ch)
        if (started) StreamHub.get(this).play(ch.url)
    }

    /** გადაცემაზე დაჭერა: გასული — არქივი, მიმდინარე — პირდაპირ ეთერი */
    private fun onProgramClick(p: Program) {
        val ch = current ?: return
        val t = System.currentTimeMillis()
        when {
            t >= p.start && t < p.stop -> { b.nowName.text = nameLabel(ch); StreamHub.get(this).play(ch.url) }
            p.start > t -> Toast.makeText(this, "ეს გადაცემა ჯერ არ დაწყებულა", Toast.LENGTH_SHORT).show()
            Catchup.canPlay(ch, p) -> {
                b.nowName.text = "📼 ${ch.name} · ${Ui.timeOf(p.start)} ${p.title}"
                StreamHub.get(this).play(Catchup.url(ch, p))
            }
            else -> Toast.makeText(this, "ამ გადაცემის არქივი მიუწვდომელია", Toast.LENGTH_SHORT).show()
        }
    }

    /** პროგრამის სია იხსნება მიმდინარე გადაცემაზე; გასული გადაცემები ზემოთ გადასახვევია */
    private fun scrollProgramsToLive() {
        val i = programAdapter.liveIndex()
        (b.epgList.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager)
            ?.scrollToPositionWithOffset(i, 0)
    }

    /** გადაცემა ახლა / შემდეგ და მთელი პროგრამა */
    private fun updateEpg(ch: Channel?) {
        if (ch == null) return
        val now = Epg.now(ch)
        if (now != null) {
            b.epgNow.text = "${Ui.timeOf(now.start)}–${Ui.timeOf(now.stop)}  ${now.title}"
            b.epgNow.visibility = View.VISIBLE
            b.epgProgress.progress = Ui.progressOf(now)
            b.epgProgress.visibility = View.VISIBLE
            val nx = Epg.next(ch)
            if (nx != null) {
                b.epgNext.text = getString(R.string.next_fmt, Ui.timeOf(nx.start), nx.title)
                b.epgNext.visibility = View.VISIBLE
            } else b.epgNext.visibility = View.GONE
        } else {
            b.epgNow.visibility = View.GONE
            b.epgProgress.visibility = View.GONE
            b.epgNext.visibility = View.GONE
        }
        programAdapter.submit(Epg.schedule(ch))
        scrollProgramsToLive()
    }

    private fun openFullscreen() {
        val ch = current ?: return
        ChannelHolder.current = ch
        goingFullscreen = true
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", ch.url))
    }

    /** სრულ ეკრანიდან დაბრუნებისას ან ეკრანის შებრუნებისას — მიმდინარე არხის სინქრონიზაცია */
    private fun syncFromHolder() {
        val ch = ChannelHolder.current ?: return
        current = ch
        b.nowName.text = nameLabel(ch)
        channelAdapter.select(ch.url)
        b.btnFullscreen.isEnabled = true
        updateEpg(ch)
        val pos = ChannelHolder.list.indexOfFirst { it.url == ch.url }
        if (pos >= 0 && !b.channels.canScrollVertically(-1) && pos > 3) b.channels.scrollToPosition(pos)
    }

    private fun stepChannel(delta: Int) {
        val list = ChannelHolder.list
        if (list.isEmpty()) return
        val pos = Math.floorMod(ChannelHolder.index + delta, list.size)
        play(list[pos])
        b.channels.scrollToPosition(pos)
    }

    /**
     * პულტი (TV): CH+/CH− (P▲/P▼), ციფრები 0–9, LAST/DEL → წინა არხი, ⏯ → სრული ეკრანი,
     * RED/GREEN → წინა/შემდეგი კატეგორია (FAV-იც → შემდეგი), YELLOW → ენა, BLUE → სრული ეკრანი,
     * EXIT → გასვლა, OK → არხი სრულ ეკრანზე.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        Device.noteKey(event)
        if (event.action == KeyEvent.ACTION_DOWN && ::b.isInitialized) {
            val k = event.keyCode
            offerKeysOnce()
            if (tvListKey(event.keyCode)) return true
            // მორგებული ღილაკები (↑↓←→ მთავარზე ფოკუსისთვისაა და არ გამოიყენება)
            if (!KeyMap.isDpad(k)) {
                when (KeyMap.get(this, k)) {
                    KeyMap.Act.NEXT_CH -> { if (event.repeatCount == 0) stepChannel(1); return true }
                    KeyMap.Act.PREV_CH -> { if (event.repeatCount == 0) stepChannel(-1); return true }
                    KeyMap.Act.LAST -> {
                        if (event.repeatCount == 0) prevChannel?.let {
                            play(it)
                            val pos = ChannelHolder.list.indexOfFirst { c -> c.url == it.url }
                            if (pos >= 0) b.channels.scrollToPosition(pos)
                        }
                        return true
                    }
                    else -> {}
                }
            }
            when {
                k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_PAGE_UP -> {
                    stepChannel(1)
                    return true
                }
                k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_PAGE_DOWN -> {
                    stepChannel(-1)
                    return true
                }
                // ◀◀ ▶▶ და ⏮ ⏭ — წინა / შემდეგი არხი (გამეორებას ვუგულებელვყოფთ)
                k == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || k == KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    if (event.repeatCount == 0) stepChannel(1)
                    return true
                }
                k == KeyEvent.KEYCODE_MEDIA_REWIND || k == KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    if (event.repeatCount == 0) stepChannel(-1)
                    return true
                }
                k == KeyEvent.KEYCODE_MEDIA_PLAY || k == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || k == KeyEvent.KEYCODE_PROG_BLUE -> {
                    if (current != null) {
                        openFullscreen()
                        return true
                    }
                }
                k == KeyEvent.KEYCODE_PROG_RED -> {
                    stepGroup(-1)
                    return true
                }
                k == KeyEvent.KEYCODE_PROG_GREEN || k == KeyEvent.KEYCODE_BOOKMARK -> {
                    stepGroup(1)
                    return true
                }
                k == KeyEvent.KEYCODE_PROG_YELLOW || k == KeyEvent.KEYCODE_MENU -> {
                    focusLogout()   // TV: სწრაფად "გასვლა" ღილაკზე
                    return true
                }
                k == KeyEvent.KEYCODE_LAST_CHANNEL || (k == KeyEvent.KEYCODE_DEL && !digits.active) -> {
                    prevChannel?.let {
                        play(it)
                        val pos = ChannelHolder.list.indexOfFirst { c -> c.url == it.url }
                        if (pos >= 0) b.channels.scrollToPosition(pos)
                    }
                    return true
                }
                k in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                    digits.digit(k - KeyEvent.KEYCODE_0)
                    return true
                }
                k in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> {
                    digits.digit(k - KeyEvent.KEYCODE_NUMPAD_0)
                    return true
                }
                (k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER) && digits.active -> {
                    digits.commit()
                    return true
                }
                (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_DEL) && digits.active -> {
                    digits.cancel()
                    return true
                }
                k == KeyEvent.KEYCODE_ESCAPE -> {   // EXIT
                    if (digits.active) digits.cancel() else finish()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    /** პულტის პირველივე ღილაკზე ერთხელ შევთავაზოთ ღილაკების მორგება (მხოლოდ თუ პულტითაა და ჯერ არ მოუგვარებია) */
    private fun offerKeysOnce() {
        if (!Device.remoteSeen || offered) return
        val prefs = getSharedPreferences("tv_keys", MODE_PRIVATE)
        if (prefs.getBoolean("offered", false) || !KeyMap.isEmpty(this)) { offered = true; return }
        offered = true
        prefs.edit().putBoolean("offered", true).apply()
        h.post {
            if (isFinishing || isDestroyed) return@post
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(R.string.keys_offer_title)
                .setMessage(R.string.keys_offer_msg)
                .setPositiveButton(R.string.keys_offer_yes) { _, _ -> startActivity(Intent(this, KeysActivity::class.java)) }
                .setNegativeButton(R.string.later_btn, null)
                .show()
        }
    }

    private fun goLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
