<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/social.php';

$p = $_GET['provider'] ?? '';
// აპლიკაციიდან შესვლა: pair კოდი ვინახავთ — შესვლის შემდეგ pair.php თავისით დაადასტურებს და აპლიკაციაში დააბრუნებს
$pairCode = preg_replace('/[^A-Za-z0-9]/', '', (string)($_GET['pair'] ?? ''));
if ($pairCode !== '' && strlen($pairCode) <= 32) $_SESSION['app_pair_code'] = $pairCode; else unset($_SESSION['app_pair_code']);
if (!social_ready($pdo, $p)) social_fail('ეს შესვლის მეთოდი ამჟამად მიუწვდომელია.');

if ($p === 'telegram') {
    // Telegram-ს OAuth-გადამისამართება არ აქვს: გვერდზე ჩანს Telegram-ის ღილაკი (Login Widget)
    $_SESSION['oauth_next'] = next_param($_GET['next'] ?? '');
    $bot = social_cfg($pdo, 'telegram', 'bot_username');
    ?><!DOCTYPE html>
<html lang="ka"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Telegram-ით შესვლა — <?= e(site_name($pdo)) ?></title>
<?php render_head_css(); ?></head>
<body>
<?php render_header($pdo); ?>
<div class="form-wrap" style="text-align:center;">
    <h2>Telegram-ით შესვლა</h2>
    <p style="color:var(--text-secondary); margin:10px 0 20px;">დააჭირეთ ღილაკს და დაადასტურეთ შესვლა Telegram-ში.</p>
    <div style="display:flex; justify-content:center; min-height:48px;">
        <script async src="https://telegram.org/js/telegram-widget.js?22" data-telegram-login="<?= e($bot) ?>" data-size="large" data-radius="10" data-userpic="false" data-request-access="write" data-auth-url="<?= e(social_redirect_uri() . '?tg=1') ?>"></script>
    </div>
    <div class="form-footer"><a href="login.php" style="color:var(--accent);">← უკან შესვლის გვერდზე</a></div>
</div>
<?php render_footer($pdo); ?>
</body></html>
<?php
    exit;
}

$state = $p . '.' . bin2hex(random_bytes(16));
$_SESSION['oauth_state'] = $state;
$_SESSION['oauth_next']  = next_param($_GET['next'] ?? '');
redirect(social_auth_url($pdo, $p, $state));
