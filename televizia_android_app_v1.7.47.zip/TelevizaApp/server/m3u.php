<?php
/**
 * მომხმარებლის playlist.
 *   /playlist/m3u.php?token=USER_TOKEN
 *   /playlist/m3u.php/USER_TOKEN.m3u8   (PATH_INFO)
 */
ob_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
ini_set('display_errors', '0');

$token = $_GET['token'] ?? '';
if ($token === '' && !empty($_SERVER['PATH_INFO'])) {
    $token = preg_replace('/\.(m3u8?|xspf)$/i', '', trim($_SERVER['PATH_INFO'], '/'));
}
$token = preg_replace('/[^a-zA-Z0-9]/', '', $token);

if ($token === '') {
    playlist_fail($pdo, 'user', '', 400, 'token არ არის მითითებული');
}

ensure_device_schema($pdo);
$stmt = $pdo->prepare("SELECT * FROM users WHERE playlist_token = ?");
$stmt->execute([$token]);
$user = $stmt->fetch();

// ტოკენი შეიძლება ეკუთვნოდეს კონკრეტულ შეძენილ პაკეტს (თითო პაკეტის საკუთარი ლინკი)
$scopeSub = null;
if (!$user) {
    $scopeSub = subscription_by_token($pdo, $token);
    if ($scopeSub) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$scopeSub['user_id']]);
        $user = $stmt->fetch();
    }
}

// 24-საათიანი პირადი ტესტის ტოკენი (აპლიკაცია იყენებს) -> ტესტის playlist
if (!$user) {
    ensure_user_trials($pdo);
    $utc = $pdo->prepare("SELECT 1 FROM user_trials WHERE token = ?");
    $utc->execute([$token]);
    if ($utc->fetchColumn()) { require __DIR__ . '/trial.php'; exit; }
}

if (!$user) {
    playlist_fail($pdo, 'user', $token, 404, 'მომხმარებელი ვერ მოიძებნა');
}

if (!user_has_playlist_access($pdo, $user)) {
    // ანგარიში აქტიურია, მაგრამ გამოწერა/ტესტი ამოიწურა -> ერთი არხი QR კოდით ეკრანზე
    if ($user['status'] === 'active' && promo_expired_enabled($pdo)) {
        promo_expired_send($pdo, promo_expired_kind_for_user($pdo, $user['id']), 'user', $token);
    }
    playlist_fail($pdo, 'user', $token, 403, 'წვდომა შეზღუდულია: ანგარიში გათიშულია ან გამოწერა ამოწურულია');
}

// პაკეტის საკუთარი ლინკი: მხოლოდ ამ პაკეტის ვადა ითვლება
if ($scopeSub && !($scopeSub['status'] === 'active' && strtotime($scopeSub['expires_at']) > time())) {
    playlist_fail($pdo, 'user', $token, 403, 'ამ პაკეტის ვადა ამოიწურა');
}

$gate = device_gate($pdo, $user);
if (!$gate['ok']) {
    playlist_fail($pdo, 'user', $token, $gate['code'], $gate['msg']);
}

try {
    $pdo->prepare("INSERT INTO access_logs (user_id, ip_address, user_agent) VALUES (?, ?, ?)")
        ->execute([$user['id'], $_SERVER['REMOTE_ADDR'] ?? '', substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250)]);
} catch (Throwable $e) {
}

// ავტო-განახლება: ვადამოსული playlist-ები თავისით განახლდება (პასუხის გაგზავნის შემდეგ)
playlist_refresh_after_response($pdo);

// ყველა აქტიური პაკეტის არხები ერთ ლინკში (პაკეტის ვადის გასვლისას მისი არხები თავისით ქრება)
$pkgIds = $scopeSub ? [(int)$scopeSub['package_id']]
                    : array_map('intval', array_column(get_active_subscriptions($pdo, $user['id']), 'package_id'));
$playlistIds = [];
if ($pkgIds) {
    $stmt = $pdo->prepare("SELECT DISTINCT playlist_id FROM package_playlists WHERE package_id IN (" . implode(',', array_fill(0, count($pkgIds), '?')) . ") ORDER BY playlist_id");
    $stmt->execute($pkgIds);
    $playlistIds = array_column($stmt->fetchAll(), 'playlist_id');
}

$m3u = build_m3u($pdo, $playlistIds, ['type' => 'u', 'token' => $token]);
$count = substr_count($m3u, '#EXTINF');

playlist_send($pdo, 'user', $token, $m3u, 'playlist.m3u', 'ok, არხები: ' . $count);
