<?php
/** ტელევიზორის დადასტურება: მომხმარებელი ტელეფონით სკანირებს და აქ ადასტურებს */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/app_pairs.php';
app_pairs_ensure($pdo);

$code = app_pair_clean($_POST['code'] ?? $_GET['code'] ?? '');
$msg = '';
$ok = false;
$loggedIn = is_user_logged_in();
// აპლიკაციიდან სოციალური შესვლა: auto=1 -> დადასტურება თავისით და დაბრუნება აპლიკაციაში
$auto = ($_GET['auto'] ?? $_POST['auto'] ?? '') === '1';
$appBack = 'intent://login#Intent;scheme=televizia;package=store.televizia.app;end';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $loggedIn) {
    $row = app_pair_get($pdo, $code);
    if (!$row || $row['status'] !== 'pending' || strtotime($row['expires_at']) < time()) {
        $msg = 'კოდი არასწორია ან ვადა გაუვიდა. ტელევიზორზე ხელახლა სცადეთ.';
    } else {
        $st = $pdo->prepare("UPDATE app_pairs SET user_id = ?, status = 'approved' WHERE code = ? AND status = 'pending'");
        $st->execute([(int)$_SESSION['user_id'], $code]);
        $ok = $st->rowCount() === 1;
        $msg = $ok ? 'შესვლა დადასტურდა. ტელევიზორი ავტომატურად შევა ანგარიშში.' : 'კოდი უკვე გამოყენებულია.';
    }
}
?>
<!DOCTYPE html>
<html lang="ka">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ტელევიზორზე შესვლა — TELEVIZIA.STORE</title>
<?php render_head_css(); ?>
</head>
<body>
<?php render_header($pdo); ?>
<div class="container" style="padding-top:36px;padding-bottom:60px;max-width:560px;">
    <div class="card">
        <h3>ტელევიზორზე შესვლა</h3>
        <?php if ($msg !== ''): ?>
            <p style="margin:12px 0;"><?= e($msg) ?></p>
        <?php endif; ?>

        <?php if (!$loggedIn): ?>
            <p>ამ გვერდზე დასადასტურებლად ჯერ შედით თქვენს ანგარიშში.</p>
            <a class="btn btn-primary" href="login.php<?= $code !== '' ? '?next=' . urlencode('/public/pair.php?code=' . $code . ($auto ? '&auto=1' : '')) : '' ?>">შესვლა</a>
        <?php elseif (!$ok): ?>
            <p>ტელევიზორზე გამოჩენილი კოდი: <b style="font-family:monospace;letter-spacing:2px;"><?= e($code) ?></b></p>
            <form method="POST" action="pair.php" id="pairForm">
                <input type="hidden" name="code" value="<?= e($code) ?>">
                <?php if ($auto): ?><input type="hidden" name="auto" value="1"><?php endif; ?>
                <button type="submit" class="btn btn-primary btn-block">დადასტურება</button>
            </form>
            <?php if ($auto): ?>
            <p style="margin-top:12px;color:var(--text-secondary);">აპლიკაციის დადასტურება 2 წამში... <a href="/user/dashboard.php" style="color:var(--accent);">გაუქმება</a></p>
            <script>setTimeout(function(){ document.getElementById('pairForm').submit(); }, 2000);</script>
            <?php endif; ?>
        <?php endif; ?>
        <?php if ($ok && $auto): ?>
            <a class="btn btn-primary btn-block" style="margin-top:12px;" href="<?= e($appBack) ?>">↩ დაბრუნება აპლიკაციაში</a>
            <script>setTimeout(function(){ location.href = <?= json_encode($appBack) ?>; }, 400);</script>
        <?php endif; ?>
    </div>
</div>
<?php render_footer($pdo); ?>
</body>
</html>
