<?php
/**
 * აპლიკაციის API (ანდროიდ ტელეფონი / Smart TV).
 *   POST ?action=login                       email, password            -> token
 *   GET  ?action=pair_start                  -> code  (TV აჩვენებს QR-ს და კოდს)
 *   GET  ?action=pair_check&code=...         -> token (როცა დადასტურებულია) | 202 pending
 * QR კაბინეტიდან: აპი სკანერით იღებს კოდს და იძახებს pair_check-ს.
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/app_pairs.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function app_out($code, array $data) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/** პაკეტები და 24-საათიანი ტესტი (ვადებით) — აპლიკაცია აჩვენებს მთავარ ეკრანზე */
function app_plan($pdo, array $user) {
    $out = ['packages' => [], 'trial' => null];
    foreach (get_active_subscriptions($pdo, $user['id']) as $s) {
        $out['packages'][] = ['name' => (string)$s['package_name'], 'expires_at' => (string)$s['expires_at']];
    }
    $t = get_user_trial($pdo, $user['id']);
    if ($t && strtotime($t['expires_at']) > time()) $out['trial'] = ['expires_at' => (string)$t['expires_at']];
    return $out;
}

function app_user_payload($pdo, array $user) {
    if ($user['status'] !== 'active') app_out(403, ['ok' => false, 'error' => 'no_active_package']);
    $plan = app_plan($pdo, $user);
    if (user_has_playlist_access($pdo, $user)) {
        if (empty($user['playlist_token'])) app_out(403, ['ok' => false, 'error' => 'no_token']);
        $token = (string)$user['playlist_token'];
        $kind = 'package';
    } elseif ($plan['trial']) {
        // მხოლოდ სატესტო 24 საათი: აპლიკაცია იღებს ტესტის ტოკენს (m3u.php მას ტესტის playlist-ზე გადაიყვანს)
        $t = get_user_trial($pdo, $user['id']);
        $token = (string)$t['token'];
        $kind = 'trial';
    } else {
        app_out(403, ['ok' => false, 'error' => 'no_active_package']);
    }
    return [
        'ok'           => true,
        'token'        => $token,
        'kind'         => $kind,
        'name'         => (string)($user['full_name'] ?? ''),
        'playlist_url' => 'https://televizia.store/playlist/m3u.php?token=' . urlencode($token),
        'packages'     => $plan['packages'],
        'trial'        => $plan['trial'],
    ];
}

ensure_device_schema($pdo);
app_pairs_ensure($pdo);
$action = $_GET['action'] ?? '';

if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    if ($email === '' || $password === '') app_out(400, ['ok' => false, 'error' => 'missing_fields']);
    $st = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $st->execute([$email]);
    $user = $st->fetch(PDO::FETCH_ASSOC);
    if (!$user || !password_verify($password, $user['password_hash'])) {
        app_out(401, ['ok' => false, 'error' => 'bad_credentials']);
    }
    app_out(200, app_user_payload($pdo, $user));
}

if ($action === 'info' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $tok = preg_replace('/[^a-zA-Z0-9]/', '', (string)($_GET['token'] ?? ''));
    if ($tok === '') app_out(400, ['ok' => false, 'error' => 'bad_request']);
    $st = $pdo->prepare("SELECT * FROM users WHERE playlist_token = ?");
    $st->execute([$tok]);
    $user = $st->fetch(PDO::FETCH_ASSOC);
    if (!$user) {
        ensure_user_trials($pdo);
        $st = $pdo->prepare("SELECT u.* FROM user_trials ut JOIN users u ON u.id = ut.user_id WHERE ut.token = ?");
        $st->execute([$tok]);
        $user = $st->fetch(PDO::FETCH_ASSOC);
    }
    if (!$user) app_out(404, ['ok' => false, 'error' => 'invalid_token']);
    app_out(200, ['ok' => true] + app_plan($pdo, $user));
}

if ($action === 'pair_start' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $code = app_pair_new($pdo, null, 'pending', 600);
    app_out(200, ['ok' => true, 'code' => $code, 'expires_in' => 600]);
}

if ($action === 'pair_check' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $code = app_pair_clean($_GET['code'] ?? '');
    $row = app_pair_get($pdo, $code);
    if (!$row) app_out(404, ['ok' => false, 'error' => 'invalid_code']);
    if (strtotime($row['expires_at']) < time()) app_out(410, ['ok' => false, 'error' => 'expired']);
    if ($row['status'] === 'claimed') app_out(410, ['ok' => false, 'error' => 'used']);
    if ($row['status'] === 'pending') app_out(202, ['ok' => false, 'error' => 'pending']);

    // ატომური მონიშვნა: კოდი მხოლოდ ერთხელ გამოიყენება
    $st = $pdo->prepare("UPDATE app_pairs SET status = 'claimed' WHERE code = ? AND status = 'approved'");
    $st->execute([$code]);
    if ($st->rowCount() !== 1) app_out(410, ['ok' => false, 'error' => 'used']);

    $u = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $u->execute([(int)$row['user_id']]);
    $user = $u->fetch(PDO::FETCH_ASSOC);
    if (!$user) app_out(404, ['ok' => false, 'error' => 'invalid_code']);
    app_out(200, app_user_payload($pdo, $user));
}

app_out(400, ['ok' => false, 'error' => 'bad_request']);
