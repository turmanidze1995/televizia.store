<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/social.php';
require_once __DIR__ . '/../includes/reglimit.php';
social_ensure_tables($pdo);

$pend = $_SESSION['social_pending'] ?? null;
if (!$pend) redirect(SITE_URL . '/public/login.php');

$error = '';
if (!registration_open($pdo)) { unset($_SESSION['social_pending']); social_fail('რეგისტრაცია დროებით დახურულია.'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'ელ-ფოსტის ფორმატი არასწორია.';
    } else {
        $st = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $st->execute([$email]);
        if ($st->fetch()) {
            $error = 'ეს ელ-ფოსტა უკვე რეგისტრირებულია. შედით პაროლით ან გამოიყენეთ სხვა ელ-ფოსტა.';
        } elseif (($limitErr = reg_limit_check($pdo, '')) !== '') {
            $error = $limitErr;
        } else {
            $uid = social_create_user($pdo, $pend['p'], $pend['profile'], $email);
            reg_limit_record($pdo, (int)$uid, '');
            unset($_SESSION['social_pending']);
            social_start_session($pdo, $uid, 'register');
            if (!empty($_SESSION['app_pair_code'])) { $c = (string)$_SESSION['app_pair_code']; unset($_SESSION['app_pair_code']); redirect(SITE_URL . '/public/pair.php?code=' . urlencode($c) . '&auto=1'); }
            redirect(after_register_url(next_target($pend['next'] ?? '')));
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ka">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ელ-ფოსტის მითითება — <?= e(site_name($pdo)) ?></title>
<?php render_head_css(); ?>
</head>
<body>
<?php render_header($pdo); ?>
<div class="form-wrap">
    <h2>ერთი ნაბიჯიღა დარჩა</h2>
    <p style="color:var(--text-secondary); margin-bottom:18px;"><?= e(social_providers()[$pend['p']]['label'] ?? '') ?>-მა ელ-ფოსტა არ გადმოგვცა. მიუთითეთ ელ-ფოსტა ანგარიშის დასასრულებლად (გამოგვადგება პაროლის აღდგენისთვის).</p>
    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" data-no-ajax>
        <div class="field"><label>ელ-ფოსტა</label><input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required autofocus></div>
        <button type="submit" class="btn btn-primary" style="width:100%;">გაგრძელება</button>
    </form>
</div>
<?php render_footer($pdo); ?>
</body>
</html>
