<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/social.php';
social_ensure_tables($pdo);

/** აპლიკაციიდან დაწყებული შესვლა: წარმატების შემდეგ pair.php-ზე (თავისით დადასტურება + დაბრუნება აპლიკაციაში) */
function pair_redirect($url) {
    if (!empty($_SESSION['app_pair_code'])) {
        $c = (string)$_SESSION['app_pair_code'];
        unset($_SESSION['app_pair_code']);
        redirect(SITE_URL . '/public/pair.php?code=' . urlencode($c) . '&auto=1');
    }
    redirect($url);
}

if (($_GET['tg'] ?? '') === '1' && !empty($_GET['hash'])) {
    // Telegram Login Widget: ხელმოწერით მოწმდება (state არ გამოიყენება)
    $p = 'telegram';
    $next = (string)($_SESSION['oauth_next'] ?? '');
    unset($_SESSION['oauth_state'], $_SESSION['oauth_next']);
    if (!social_ready($pdo, $p)) social_fail('ეს შესვლის მეთოდი ამჟამად მიუწვდომელია.');
    $profile = social_telegram_profile($pdo, $_GET, $err);
    if (!$profile) social_fail($err ?: 'ავტორიზაცია ვერ შესრულდა.');
} else {
    $state = (string)($_GET['state'] ?? '');
    $saved = (string)($_SESSION['oauth_state'] ?? '');
    $next  = (string)($_SESSION['oauth_next'] ?? '');
    unset($_SESSION['oauth_state'], $_SESSION['oauth_next']);

    if ($saved === '' || !hash_equals($saved, $state)) social_fail('სესია ვადაგასულია, სცადეთ თავიდან.');
    $p = explode('.', $state, 2)[0];
    if (!social_ready($pdo, $p)) social_fail('ეს შესვლის მეთოდი ამჟამად მიუწვდომელია.');

    if (!empty($_GET['error']) || empty($_GET['code'])) social_fail('შესვლა გაუქმდა.');

    $profile = social_fetch_profile($pdo, $p, (string)$_GET['code'], $err);
    if (!$profile) social_fail($err ?: 'ავტორიზაცია ვერ შესრულდა.');
}

// 1) ეს სოციალური ანგარიში უკვე დაკავშირებულია?
$st = $pdo->prepare("SELECT s.id AS sid, s.user_id, u.id AS uid FROM social_accounts s LEFT JOIN users u ON u.id = s.user_id WHERE s.provider = ? AND s.provider_uid = ?");
$st->execute([$p, $profile['uid']]);
$row = $st->fetch();
if ($row && $row['uid']) {
    if (!social_start_session($pdo, (int)$row['user_id'], 'social')) social_fail('თქვენი ანგარიში დეაქტივირებულია. დაუკავშირდით ადმინისტრაციას.');
    $pdo->prepare("UPDATE social_accounts SET last_login = NOW() WHERE id = ?")->execute([$row['sid']]);
    pair_redirect(next_target($next));
}
if ($row) $pdo->prepare("DELETE FROM social_accounts WHERE id = ?")->execute([$row['sid']]); // წაშლილი მომხმარებლის ნარჩენი

$email = $profile['email'];
if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $email = '';

// 2) ელ-ფოსტა არ მოვიდა — ვთხოვთ მომხმარებელს
if ($email === '') {
    if (!registration_open($pdo)) social_fail('რეგისტრაცია დროებით დახურულია.');
    $_SESSION['social_pending'] = ['p' => $p, 'profile' => $profile, 'next' => $next];
    redirect(SITE_URL . '/public/social_email.php');
}

// 3) ასეთი ელ-ფოსტით მომხმარებელი უკვე არსებობს?
$st = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$st->execute([$email]);
$existing = $st->fetchColumn();

if ($existing) {
    if (!$profile['verified']) social_fail('ეს ელ-ფოსტა უკვე რეგისტრირებულია. შედით პაროლით.');
    social_link($pdo, (int)$existing, $p, $profile['uid'], $email);
    if (!social_start_session($pdo, (int)$existing, 'social')) social_fail('თქვენი ანგარიში დეაქტივირებულია. დაუკავშირდით ადმინისტრაციას.');
    pair_redirect(next_target($next));
}

// 4) ახალი მომხმარებელი
if (!registration_open($pdo)) social_fail('რეგისტრაცია დროებით დახურულია.');
require_once __DIR__ . '/../includes/reglimit.php';
if (($limitErr = reg_limit_check($pdo, '')) !== '') social_fail($limitErr);
$uid = social_create_user($pdo, $p, $profile, $email);
reg_limit_record($pdo, (int)$uid, '');
social_start_session($pdo, $uid, 'register');
pair_redirect(after_register_url(next_target($next)));   // ჯერ შესვლის ისტორია, მერე კაბინეტი
