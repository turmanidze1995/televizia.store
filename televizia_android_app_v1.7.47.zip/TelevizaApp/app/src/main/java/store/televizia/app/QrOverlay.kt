package store.televizia.app

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * პატარა QR კოდი (საიტის მისამართი) ვიდეოს კუთხეში — როგორც სატელევიზიო არხებზე.
 * იმართება სერვერიდან (api/app_config.php → overlay.*):
 *   overlay.qr_on (ჩართვა), overlay.qr_corner (bl/br/tl/tr), overlay.qr_size_dp, overlay.qr_text,
 *   overlay.qr_every_min (0 = მუდმივად; N = ყოველ N წუთში), overlay.qr_show_sec (რამდენ წამს ჩანს).
 * მიმაგრებულია ვიდეოს კონტეინერზე (PlayerView-ს მშობელი FrameLayout), ამიტომ ორივე ეკრანზე (სია/სრული ეკრანი) ჩანს.
 */
object QrOverlay {
    private const val TAG = "tv_qr_overlay"

    fun attach(pv: View) {
        val parent = pv.parent as? FrameLayout ?: return
        parent.findViewWithTag<View>(TAG)?.let { parent.removeView(it) }
        if (!RemoteConfig.b("overlay.qr_on", true)) return

        val ctx = pv.context
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val size = RemoteConfig.i("overlay.qr_size_dp", 64).coerceIn(32, 160)
        val text = RemoteConfig.s("overlay.qr_text", "TELEVIZIA.STORE")
        val every = RemoteConfig.i("overlay.qr_every_min", 0).coerceAtLeast(0)
        val showSec = RemoteConfig.i("overlay.qr_show_sec", 20).coerceIn(5, 600)
        val gravity = when (RemoteConfig.s("overlay.qr_corner", "bl")) {
            "br" -> Gravity.BOTTOM or Gravity.END
            "tl" -> Gravity.TOP or Gravity.START
            "tr" -> Gravity.TOP or Gravity.END
            else -> Gravity.BOTTOM or Gravity.START
        }

        // ბარათის სიგანე = მეტი (QR ან წარწერა), რომ წარწერა არ ჭრიდეს „TELEVIZIA.STORE“-ს
        val label = if (text.isNotBlank()) TextView(ctx).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
            isSingleLine = true
            setShadowLayer(3f, 0f, 1f, Color.BLACK)
            isFocusable = false
        } else null
        val textW = label?.let { (it.paint.measureText(text) + dp(8)).toInt() } ?: 0
        val boxW = maxOf(dp(size), textW)

        val box = LinearLayout(ctx).apply {
            tag = TAG
            orientation = LinearLayout.VERTICAL
            this.gravity = Gravity.CENTER_HORIZONTAL
            isClickable = false
            isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            elevation = 6f * d
            if (label != null) addView(label, LinearLayout.LayoutParams(boxW, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(ImageView(ctx).apply {
                setImageResource(R.drawable.qr_overlay)
                scaleType = ImageView.ScaleType.FIT_CENTER
                isFocusable = false
            }, LinearLayout.LayoutParams(dp(size), dp(size)).apply { topMargin = dp(2); gravity = Gravity.CENTER_HORIZONTAL })
        }
        parent.addView(box, FrameLayout.LayoutParams(boxW, FrameLayout.LayoutParams.WRAP_CONTENT, gravity).apply {
            setMargins(dp(14), dp(14), dp(14), dp(14))
        })

        if (every > 0) {
            // ყოველ N წუთში გამოჩნდება showSec წამით
            var visible = false
            box.visibility = View.GONE
            val tick = object : Runnable {
                override fun run() {
                    visible = !visible
                    box.visibility = if (visible) View.VISIBLE else View.GONE
                    box.postDelayed(this, if (visible) showSec * 1000L else every * 60_000L)
                }
            }
            box.postDelayed(tick, 15_000L)
            box.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) {}
                override fun onViewDetachedFromWindow(v: View) { v.removeCallbacks(tick) }
            })
        }
    }
}
