package store.televizia.app

import android.content.Context
import android.os.Handler
import android.os.Looper

/**
 * არხი არ ირთვება -> სერვერიდან არხების სიას თავიდან ვიღებთ და იგივე არხის (სახელით / tvg-id-ით) ახალ ლინკს ვეძებთ.
 * თუ ლინკი შეიცვალა — ვანახლებთ ყველგან და ახალ ლინკს ვაბრუნებთ. სხვა არხზე არასოდეს გადადის.
 */
object ChannelRefresher {
    private const val MIN_GAP_MS = 120000L   // ბმულები სერვერზე მუდმივია (s.php/ID) — ხშირი განახლება მხოლოდ სერვერს ტვირთავდა
    @Volatile private var last = 0L

    /** ფონურ ნაკადში გამოიძახეთ. აბრუნებს ახალ ლინკს ან null-ს (ლინკი იგივეა / ვერ მოიძებნა / ქსელი არ არის) */
    fun refresh(ctx: Context, failingUrl: String): String? {
        val now = System.currentTimeMillis()
        if (now - last < MIN_GAP_MS) return null
        last = now
        val app = ctx.applicationContext
        val token = Session.token(app) ?: return null
        val old = ChannelHolder.all.firstOrNull { it.url == failingUrl } ?: return null   // არქივი/უცნობი ლინკი — არ ვეხებით
        val res = Api.playlist(token)
        if (!res.ok || res.body.isBlank()) return null
        val fresh = M3u.parse(res.body)
        if (fresh.isEmpty()) return null

        val match = (if (old.epgId.isNotBlank()) fresh.firstOrNull { it.epgId == old.epgId && it.name == old.name } else null)
            ?: fresh.firstOrNull { it.name == old.name && it.group == old.group }
            ?: fresh.firstOrNull { it.name == old.name }
            ?: return null
        if (match.url == failingUrl) return null

        Store.saveM3u(app, res.body)
        Epg.attach(fresh)
        // მდგომარეობას მთავარ ნაკადში ვცვლით და მხოლოდ მაშინ, თუ მომხმარებელი ამ არხზეა: ადრე ფონური ნაკადი
        // ChannelHolder.current-ს ძველ არხს უბრუნებდა, სანამ მომხმარებელი უკვე სხვა არხებზე გადადიოდა — აქედან იყო არხების არევა
        Handler(Looper.getMainLooper()).post {
            val cur = ChannelHolder.current
            ChannelHolder.all = fresh
            // იგივე წესით, რაც MainActivity.applyFilter-ში: დამალული არხები არ ბრუნდება, ★ ფავორიტების კატეგორია არ ცარიელდება
            val vis = fresh.filter { !UserLists.isHidden(app, it) }
            val g = ChannelHolder.group
            ChannelHolder.list = when (g) {
                Lang.ALL -> vis
                Lang.FAV -> vis.filter { UserLists.isFav(app, it) }
                else -> vis.filter { it.group == g }
            }
            val target = if (cur == null || cur.url == failingUrl) match
                         else (ChannelHolder.equivalentIn(cur, fresh) ?: cur)
            ChannelHolder.current = target
            val mi = ChannelHolder.list.indexOfFirst { it === target }
            if (mi >= 0) ChannelHolder.markPos(mi)
            if (target === match) Store.setLastUrl(app, match.url)
        }
        return match.url
    }
}
