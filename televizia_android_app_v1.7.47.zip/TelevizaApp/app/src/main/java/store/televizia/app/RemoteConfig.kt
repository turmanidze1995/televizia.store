package store.televizia.app

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * დისტანციური მართვა: პარამეტრებს აპლიკაცია სერვერიდან კითხულობს ($BASE_URL/api/app_config.php),
 * ინახავს ტელეფონში (ოფლაინშიც მუშაობს ბოლო ცნობილი პარამეტრებით). იცვლება ადმინ-ეკრანიდან.
 */
object RemoteConfig {
    private const val PREFS = "tv_remote"
    private const val ENDPOINT = "$BASE_URL/api/app_config.php"

    @Volatile
    var json: JSONObject = JSONObject()
        private set

    class Result(val ok: Boolean, val message: String, val config: JSONObject? = null)

    fun init(ctx: Context) {
        val t = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("json", null)
        json = try { if (t != null) JSONObject(t) else JSONObject() } catch (e: Exception) { JSONObject() }
    }

    private fun node(path: String): Pair<JSONObject?, String> {
        val parts = path.split('.')
        var o: JSONObject? = json
        for (i in 0 until parts.size - 1) o = o?.optJSONObject(parts[i])
        return o to parts.last()
    }

    fun s(path: String, def: String = ""): String {
        val (o, k) = node(path)
        return if (o != null && o.has(k) && !o.isNull(k)) o.optString(k, def) else def
    }

    fun b(path: String, def: Boolean): Boolean {
        val (o, k) = node(path)
        return if (o != null && o.has(k) && !o.isNull(k)) o.optBoolean(k, def) else def
    }

    fun i(path: String, def: Int): Int {
        val (o, k) = node(path)
        return if (o != null && o.has(k) && !o.isNull(k)) o.optInt(k, def) else def
    }

    /** EPG ბმული: სერვერიდან, თორემ Config.kt-დან */
    fun epgUrl(): String = s("urls.epg").ifBlank { EPG_URL }

    fun store(ctx: Context, cfg: JSONObject) {
        json = cfg
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("json", cfg.toString()).apply()
    }

    /** ბლოკავს — ფონურ ნაკადში გამოიძახეთ */
    fun fetch(ctx: Context): Boolean {
        val r = adminGet()
        if (r.ok && r.config != null) {
            store(ctx, r.config)
            return true
        }
        return false
    }

    fun adminGet(): Result = try {
        val conn = (URL("$ENDPOINT?action=get").openConnection() as HttpURLConnection).apply {
            connectTimeout = 7000
            readTimeout = 7000
        }
        parse(read(conn))
    } catch (e: Exception) {
        Result(false, Lang.s(R.string.err_connection_short))
    }

    /** გასაღების შემოწმება სერვერზე (ადმინ-ფორმის გასახსნელად) */
    fun adminCheck(key: String): Result = try {
        val conn = (URL("$ENDPOINT?action=check").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        conn.outputStream.use { it.write(JSONObject().put("key", key).toString().toByteArray(Charsets.UTF_8)) }
        parse(read(conn))
    } catch (e: Exception) {
        Result(false, Lang.s(R.string.err_connection_short))
    }

    fun adminSet(key: String, cfg: JSONObject): Result = try {
        val body = JSONObject().put("key", key).put("config", cfg).toString()
        val conn = (URL("$ENDPOINT?action=set").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 10000
            readTimeout = 10000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        parse(read(conn))
    } catch (e: Exception) {
        Result(false, Lang.s(R.string.err_connection_short))
    }

    private fun read(conn: HttpURLConnection): String {
        val stream = if (conn.responseCode < 400) conn.inputStream else conn.errorStream
        return stream?.bufferedReader()?.use { it.readText() } ?: ""
    }

    private fun parse(text: String): Result = try {
        val j = JSONObject(text)
        if (j.optBoolean("ok")) Result(true, "", j.optJSONObject("config"))
        else Result(false, j.optString("error", "შეცდომა"))
    } catch (e: Exception) {
        Result(false, "სერვერის პასუხი ვერ წაიკითხა (app_config.php ატვირთულია?)")
    }
}
