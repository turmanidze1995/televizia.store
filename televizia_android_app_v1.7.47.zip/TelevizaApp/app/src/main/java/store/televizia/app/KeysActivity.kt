package store.televizia.app

import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

/**
 * პულტის მორგება: ეკრანი თითო მოქმედებას ეკითხება "დააჭირეთ ღილაკს..." — პულტზე ნებისმიერი ღილაკის დაჭერა
 * ინახება ამ მოქმედებისთვის. შეიძლება რამდენიმე ღილაკი (მაგ. ორივე პულტის). გასაგრძელებლად — OK.
 * OK, უკან (BACK), Home, ხმა და Power სისტემურია და არ ისწავლება; ციფრები არხის ნომრისთვისაა დაცული.
 */
class KeysActivity : BaseActivity() {
    private val acts = KeyMap.Act.values()
    private var step = 0
    private var pressed = false
    private lateinit var tvStep: TextView
    private lateinit var tvPrompt: TextView
    private lateinit var tvHint: TextView
    private lateinit var tvLast: TextView
    private lateinit var tvAssigned: TextView
    private lateinit var tvSummary: TextView
    private lateinit var btnNext: Button
    private lateinit var btnRestart: Button
    private lateinit var btnDefault: Button
    private lateinit var btnClose: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_keys)
        tvStep = findViewById(R.id.keysStep)
        tvPrompt = findViewById(R.id.keysPrompt)
        tvHint = findViewById(R.id.keysHint)
        tvLast = findViewById(R.id.keysLast)
        tvAssigned = findViewById(R.id.keysAssigned)
        tvSummary = findViewById(R.id.keysSummary)
        btnNext = findViewById(R.id.keysNext)
        btnRestart = findViewById(R.id.keysRestart)
        btnDefault = findViewById(R.id.keysDefault)
        btnClose = findViewById(R.id.keysClose)
        btnNext.setOnClickListener { step++; render() }
        btnRestart.setOnClickListener { step = 0; render() }
        btnDefault.setOnClickListener { KeyMap.clear(this); render() }
        btnClose.setOnClickListener { finish() }
        render()
    }

    private fun keysText(a: KeyMap.Act): String {
        val ks = KeyMap.keysFor(this, a)
        return if (ks.isEmpty()) "—" else ks.joinToString(", ") { KeyMap.name(it) }
    }

    private fun render() {
        pressed = false
        val done = step >= acts.size
        val live = if (done) View.GONE else View.VISIBLE
        tvStep.visibility = live
        tvPrompt.visibility = live
        tvHint.visibility = live
        tvLast.visibility = live
        tvAssigned.visibility = live
        btnNext.visibility = live
        tvSummary.visibility = if (done) View.VISIBLE else View.GONE
        btnRestart.visibility = if (done) View.VISIBLE else View.GONE
        btnDefault.visibility = if (done) View.VISIBLE else View.GONE
        btnClose.visibility = if (done) View.VISIBLE else View.GONE
        if (!done) {
            val a = acts[step]
            tvStep.text = getString(R.string.keys_step_fmt, step + 1, acts.size)
            tvPrompt.text = getString(R.string.keys_press_fmt, getString(a.label))
            tvLast.text = ""
            tvAssigned.text = getString(R.string.keys_assigned_fmt, keysText(a))
            btnNext.text = getString(if (KeyMap.keysFor(this, a).isEmpty()) R.string.keys_skip else R.string.keys_next)
            btnNext.requestFocus()
        } else {
            tvSummary.text = acts.joinToString("\n") { getString(it.label) + "  ←  " + keysText(it) }
            btnClose.requestFocus()
        }
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val k = e.keyCode
        // სწავლის დროს ყველა ღილაკს ვიჭერთ, გარდა სისტემურისა (OK, უკან...)
        if (step >= acts.size || KeyMap.isSystem(k)) return super.dispatchKeyEvent(e)
        Device.noteKey(this, e)
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) capture(k)
        return true
    }

    private fun capture(k: Int) {
        tvLast.text = getString(R.string.keys_last_fmt, KeyMap.name(k), k)
        if (KeyMap.isDigit(k)) {
            Toast.makeText(this, R.string.keys_reserved, Toast.LENGTH_SHORT).show()
            return
        }
        val a = acts[step]
        if (!pressed) {
            KeyMap.clearAction(this, a)   // ხელახალი მორგება ძველს ანაცვლებს
            pressed = true
        }
        KeyMap.assign(this, k, a)
        tvAssigned.text = getString(R.string.keys_assigned_fmt, keysText(a))
        btnNext.text = getString(R.string.keys_next)
    }
}
