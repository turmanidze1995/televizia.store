package store.televizia.app

import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.view.KeyEvent

/**
 * TV / ტელეფონის გარჩევა. ბევრ Smart TV-ზე და TV-ბოქსზე "leanback" ფუნქცია არ არის გამოცხადებული,
 * ამიტომ მხოლოდ მას არ ვენდობით: ვამოწმებთ TV რეჟიმს, შეხების ეკრანის არარსებობას და — ყველაზე საიმედოდ —
 * პულტის ღილაკის (←↑→↓, CH, ფერადი, GUIDE, ◀◀ ▶▶) პირველივე დაჭერისას ვრთავთ TV რეჟიმს.
 */
object Device {
    @Volatile
    var remoteSeen = false

    fun tv(ctx: Context): Boolean {
        if (remoteSeen) return true
        if (ctx.getSharedPreferences("device", Context.MODE_PRIVATE).getBoolean("remote", false)) { remoteSeen = true; return true }
        val pm = ctx.packageManager
        if (pm.hasSystemFeature("android.software.leanback") ||
            pm.hasSystemFeature("android.hardware.type.television") ||
            pm.hasSystemFeature("android.hardware.type.embedded")
        ) return true
        val ui = ctx.resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK
        if (ui == Configuration.UI_MODE_TYPE_TELEVISION) return true
        if (!pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)) return true
        return false
    }

    /** ამ ღილაკებს ტელეფონი არ აგზავნის — თუ მოვიდა, პულტია */
    fun noteKey(ctx: Context, e: KeyEvent) {
        if (remoteSeen || e.action != KeyEvent.ACTION_DOWN) return
        when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_GUIDE,
            KeyEvent.KEYCODE_PROG_RED, KeyEvent.KEYCODE_PROG_GREEN, KeyEvent.KEYCODE_PROG_YELLOW,
            KeyEvent.KEYCODE_PROG_BLUE, KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_MEDIA_REWIND,
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_CAPTIONS, KeyEvent.KEYCODE_LAST_CHANNEL -> {
                remoteSeen = true
                ctx.getSharedPreferences("device", Context.MODE_PRIVATE).edit().putBoolean("remote", true).apply()   // მომდევნო გახსნისას TV რეჟიმი თავიდანვე ჩაირთოს
            }
        }
    }
}
