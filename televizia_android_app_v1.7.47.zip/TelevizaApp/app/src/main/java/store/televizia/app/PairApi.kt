package store.televizia.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

enum class PairState { OK, PENDING, ERROR }

class PairStart(val ok: Boolean, val code: String = "", val message: String = "")

class PairResult(val state: PairState, val token: String? = null, val name: String = "", val message: String = "")

/** TV კოდი და QR-ით შესვლა (სერვერის pair_* endpoint-ები) */
object PairApi {
    fun start(): PairStart = try {
        val j = getJson("$BASE_URL/api/app.php?action=pair_start")
        if (j.optBoolean("ok")) PairStart(true, j.getString("code"))
        else PairStart(false, message = Lang.s(R.string.code_not_received))
    } catch (e: Exception) {
        PairStart(false, message = Lang.s(R.string.err_connection))
    }

    fun check(code: String): PairResult = try {
        val url = "$BASE_URL/api/app.php?action=pair_check&code=" + URLEncoder.encode(code, "UTF-8")
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
        }
        val status = conn.responseCode
        val stream = if (status in 200..299 || status == 202) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        val j = JSONObject(text)
        when {
            j.optBoolean("ok") -> PairResult(PairState.OK, j.getString("token"), j.optString("name"))
            j.optString("error") == "pending" -> PairResult(PairState.PENDING)
            else -> PairResult(PairState.ERROR, message = pairError(j.optString("error")))
        }
    } catch (e: Exception) {
        PairResult(PairState.ERROR, message = Lang.s(R.string.err_connection_short))
    }

    private fun getJson(url: String): JSONObject {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
        }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        return JSONObject(stream?.bufferedReader()?.use { it.readText() } ?: "{}")
    }

    private fun pairError(code: String): String = when (code) {
        "invalid_code" -> Lang.s(R.string.err_invalid_code)
        "expired" -> Lang.s(R.string.err_expired)
        "used" -> Lang.s(R.string.err_used)
        "no_active_package" -> Lang.s(R.string.err_no_package)
        else -> Lang.s(R.string.err_login_failed)
    }
}
