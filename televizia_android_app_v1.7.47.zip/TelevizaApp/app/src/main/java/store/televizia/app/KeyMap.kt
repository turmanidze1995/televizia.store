package store.televizia.app

import android.content.Context
import android.view.KeyEvent

/**
 * პულტის ღილაკების მორგება (სწავლის რეჟიმი): მომხმარებელი თვითონ ასწავლის აპლიკაციას, რომელი ღილაკი რას აკეთებს.
 * ინახება ტელევიზორში: ღილაკის კოდი → მოქმედება. ერთ მოქმედებას რამდენიმე ღილაკი შეიძლება (ორი პულტი).
 * მორგებული ღილაკი ნაგულისხმევს აჭარბებს.
 */
object KeyMap {
    enum class Act(val label: Int) {
        NEXT_CH(R.string.act_next_ch), PREV_CH(R.string.act_prev_ch), PANEL(R.string.act_panel),
        GUIDE(R.string.act_guide), INFO(R.string.act_info), SUBS(R.string.act_subs),
        AUDIO(R.string.act_audio), ASPECT(R.string.act_aspect), LAST(R.string.act_last),
        PAUSE(R.string.act_pause), SEEK_BACK(R.string.act_seek_back), SEEK_FWD(R.string.act_seek_fwd),
        FAV(R.string.act_fav), HIDE(R.string.act_hide),
        PREV_GROUP(R.string.act_prev_group), NEXT_GROUP(R.string.act_next_group), GROUP_MENU(R.string.act_group_menu)
    }

    private const val PREFS = "tv_keys"
    @Volatile private var cache: Map<Int, Act>? = null

    /** სისტემური ღილაკები: არ ისწავლება, ჩვეულებრივად მუშაობს (OK, უკან, Home, ხმა, Power...) */
    fun isSystem(k: Int) = when (k) {
        KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_HOME, KeyEvent.KEYCODE_POWER, KeyEvent.KEYCODE_DPAD_CENTER,
        KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_ESCAPE,
        KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_VOLUME_MUTE,
        KeyEvent.KEYCODE_APP_SWITCH, KeyEvent.KEYCODE_SLEEP, KeyEvent.KEYCODE_WAKEUP,
        KeyEvent.KEYCODE_ASSIST, KeyEvent.KEYCODE_VOICE_ASSIST, KeyEvent.KEYCODE_TV_POWER,
        KeyEvent.KEYCODE_TV_INPUT, KeyEvent.KEYCODE_STB_POWER, KeyEvent.KEYCODE_STB_INPUT,
        KeyEvent.KEYCODE_UNKNOWN -> true
        else -> false
    }

    /** ციფრები არხის ნომრის საკრეფადაა დაცული */
    fun isDigit(k: Int) = k in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 || k in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9

    fun isDpad(k: Int) = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN ||
        k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT

    fun name(k: Int): String = KeyEvent.keyCodeToString(k).removePrefix("KEYCODE_")

    private fun load(ctx: Context): Map<Int, Act> {
        cache?.let { return it }
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("map", "") ?: ""
        val m = HashMap<Int, Act>()
        for (p in raw.split(',')) {
            val kv = p.split(':')
            if (kv.size != 2) continue
            val code = kv[0].toIntOrNull() ?: continue
            val act = try { Act.valueOf(kv[1]) } catch (e: Exception) { continue }
            m[code] = act
        }
        cache = m
        return m
    }

    private fun save(ctx: Context, m: Map<Int, Act>) {
        cache = m
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("map", m.entries.joinToString(",") { "${it.key}:${it.value.name}" }).apply()
    }

    fun get(ctx: Context, keyCode: Int): Act? = load(ctx)[keyCode]

    fun keysFor(ctx: Context, a: Act): List<Int> = load(ctx).filterValues { it == a }.keys.sorted()

    fun assign(ctx: Context, keyCode: Int, a: Act) {
        save(ctx, HashMap(load(ctx)).also { it[keyCode] = a })
    }

    fun clearAction(ctx: Context, a: Act) {
        save(ctx, load(ctx).filterValues { it != a })
    }

    fun clear(ctx: Context) = save(ctx, emptyMap())

    fun isEmpty(ctx: Context) = load(ctx).isEmpty()
}
